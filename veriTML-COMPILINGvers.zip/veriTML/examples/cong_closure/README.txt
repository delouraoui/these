This folder provides some tests on the congruence closure with higher order terms.
All of the theses tests files are with increasing difficulty in function of theme
number. Bigger it is then harder it is to resolves and involves some critics
points that we want to check.