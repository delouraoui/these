# options="--ccfv"
options=""
# options="--inst-deletion-loops --inst-deletion-track-vars --inst-deletion --index-SAT-triggers --index-SAT --prune-cnf --prime-implicant --bool-required --ematch-exp=100000000 --ccfv-index=100000 --ccfv"
# list="-v --list=ccfv/time_max+ccfv/success+del/promoted_ccfv+del/promoted_triggers+del/promoted_sorts+del/deepest+insts/rounds+ccfv/insts+triggers/insts+sorts/insts"
flags="--disable-banner --disable-print-success"
# valgrind="valgrind --leak-check=yes"

echo "Options: $options"
echo

for name in /home/delour/Stage-2017/verit/veriT/examples/HO-stage1/*.smt2; do
# for name in ~/smt/trunk/benchmarks/smt-lib2/tests/*; do
    echo "veriT on $name";
    $valgrind veriT $options $flags $list "$name";
    # valgrind --leak-check=yes veriT --proof="$name".proof $options $flags $list "$name";
    # ulimit -S -t 10;./wrapper-veriT.sh "$name";

    # valgrind --leak-check=yes veriT --ccfv-score --ccfv --ujobs --ccfv-restrict --ccfv-refute --disable-banner --disable-print-success "$name";
    # veriT-best --ccfv --ccfv-refute --ematch-index --disable-banner --disable-print-success  "$name";
    # veriT --inst-deletion --index-SAT-triggers --index-sorts --prime-implicant --bool-required --index-SAT --ccfv --ccfv-refute  --disable-banner --disable-print-success  "$name";

    # veriT --ccfv --ccfv-refute --disable-banner --disable-print-success  "$name";
    # veriT --enable-nnf-simp --triggers-new --triggers-single-weak --triggers-m-inc  --ccfv --ccfv-refute --disable-banner --disable-print-success  "$name";
    # echo
    # for name in ci-*; do
    #     echo "z3 on $name";
    #     z3 "$name";
    # done;
    # rm ci-*;
    echo "=====================================";
done
