Tested on

ENVIRONMENT 1:
Linux 3.2.0-23-generic #36-Ubuntu SMP x86_64 GNU/Linux
gcc (Ubuntu/Linaro 4.6.3-1ubuntu5) 4.6.3

ENVIRONMENT 2:
Darwin 11.4.2: root:xnu-1699.32.7~1/RELEASE_X86_64 x86_64
i686-apple-darwin11-llvm-gcc-4.2 (GCC) 4.2.1 (Based on Apple Inc. build 5658) (LLVM build 2336.9.00)

ENVIRONMENT 3:
Apple clang version 3.1 (tags/Apple/clang-318.0.58) (based on LLVM 3.1svn)
Target: x86_64-apple-darwin11.4.2
Thread model: posix

ENVIRONMENT 4:
Linux 3.2.0-23-generic #36-Ubuntu SMP x86_64 GNU/Linux
Ubuntu clang version 3.0-6ubuntu3 (tags/RELEASE_30/final) (based on LLVM 3.0)
Target: x86_64-pc-linux-gnu
Thread model: posix
