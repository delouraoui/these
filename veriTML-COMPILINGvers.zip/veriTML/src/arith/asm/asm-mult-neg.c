/*
 * Temporary code to illustrate an assembly version for LAsigned_mult
 */
#include <limits.h>
#include <stdio.h>

/*
  Fast signed int integer multiplication with overflow detection

  Calls to this routine compiled with gcc -O2 result in:
    movl    _dummy(%rip), %ecx   # loads overflow to %ecx
        ...
    negl  %esi;                  # negates 
    imull %esi, %edx;
    cmovo %ecx, %eax;
*/
static int overflow = 0;

#define SIGNED_MULT_NEG(a, b)                                \
  __asm__ ( "movl $1, %%eax;\n\t"                            \
            "negl %[target];\n\t"                            \
        "imull %[multiplicand], %[target];\n\t"          \
        "cmovo %%eax, %[overflow];\n\t"                  \
        : [target] "+r" (a), [overflow] "+r" (overflow)  \
        : [multiplicand] "r" (b))

int main (void)
{
  int a, b;
  printf("%i\n", INT_MAX);
  while (scanf("%i", &a) != 1) {}
  while (scanf("%i", &b) != 1) {}

  SIGNED_MULT_NEG(a, b);

  printf("%i, %i, %i\n", a, b, overflow);
  return 0;
}
