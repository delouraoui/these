/*
  --------------------------------------------------------------
  Module for handling higher order constants, beta reduction,...
  --------------------------------------------------------------
*/

/* PF IMPROVE
   - rename bound variables, so that better sharing */

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

#include "config.h"

#include "general.h"

#include "DAG.h"
#include "DAG-prop.h"
#include "DAG-tmp.h"
#include "DAG-print.h"
#include "DAG-prop.h"
#include "veriT-DAG.h"
#include "DAG-symb-DAG.h"
#include "recursion.h"

#include "HOL.h"

/* #define DEBUG_HOL */
/* #define DEBUG_UNCURRY */


/*
  --------------------------------------------------------------
  Temporary
  --------------------------------------------------------------

  #include "DAG-prop.h"

  bool trigger_free_val = true;

  static bool
  trigger_free_aux(TDAG src)
  {
  if (!quantifier(DAG_symb(src)) || !DAG_prop_get(src, DAG_PROP_TRIGGER))
  return true;
  my_DAG_message("Trigger %D\n", src);
  return false;
  }

  static void
  check_trigger_free(TDAG src)
  {
  trigger_free_val = structural_recursion_pred(src, trigger_free_aux);
  }

  static void
  recheck_trigger_free(TDAG src)
  {
  unsigned tmp = structural_recursion_pred(src, trigger_free_aux);
  assert(trigger_free_val == tmp);
  }
*/


/*
  --------------------------------------------------------------
  General functions
  --------------------------------------------------------------
*/

static bool
is_FOL_node(TDAG src)
{
  return DAG_sort(src) && !DAG_sort_functional(DAG_sort(src));
}

/*--------------------------------------------------------------*/

bool
is_FOL(TDAG src)
{
  return structural_recursion_pred(src, is_FOL_node);
}

/*--------------------------------------------------------------*/

static bool
is_FOL_strict_node(TDAG src)
{
  unsigned i;
  if (DAG_symb(src) == LET ||
      DAG_symb(src) == LAMBDA ||
      DAG_symb(src) == APPLY)
    {
#ifdef DEBUG_HOL
      my_DAG_error("is_FOL_strict_node (%D)\n", src);
#endif
      return false;
    }
  if (quantifier(DAG_symb(src)))
    {
      assert(DAG_arity(src) > 0);
      for (i = 0; i < DAG_arity(src) - 1u; i++)
        if (DAG_sort(DAG_arg(src, i)) == SORT_BOOLEAN)
          {
#ifdef DEBUG_HOL
            my_DAG_error("is_FOL_strict_node (%D)\n", src);
#endif
            return false;
          }
      return true;
    }
  if (DAG_arity(src) &&
      !(boolean_connector(DAG_symb(src)) || DAG_symb(src) == FUNCTION_ITE))
    for (i = 0; i < DAG_arity(src); i++)
      if (DAG_sort(DAG_arg(src, i)) == SORT_BOOLEAN &&
          DAG_arg(src, i) != DAG_TRUE && DAG_arg(src, i) != DAG_FALSE)
        {
#ifdef DEBUG_HOL
          my_DAG_error("is_FOL_strict_node (%D)\n", src);
#endif
          return false;
        }
  if (DAG_symb(src) == FUNCTION_ITE &&
      DAG_sort(DAG_arg(src, 1)) == SORT_BOOLEAN)
    {
#ifdef DEBUG_HOL
      my_DAG_error("is_FOL_strict_node (%D)\n", src);
#endif
      return false;
    }
  return DAG_sort(src) && !DAG_sort_polymorphic(DAG_sort(src)) &&
    !DAG_sort_functional(DAG_sort(src));
  /* every node should be of non-functional sort */
}

/*--------------------------------------------------------------*/

static bool
is_LFREE_strict_node(TDAG src)
{
  unsigned i;
  if (DAG_symb(src) == LET ||
      DAG_symb(src) == LAMBDA ||
      DAG_symb(src) == APPLY)
    {
#ifdef DEBUG_HOL
      my_DAG_message("is_FOL_strict_node (%D)\n", src);
#endif
      return false;
    }
  if (quantifier(DAG_symb(src)))
    {
      assert(DAG_arity(src) > 0);
      for (i = 0; i < DAG_arity(src) - 1u; i++)
        if (DAG_sort(DAG_arg(src, i)) == SORT_BOOLEAN)
          {
#ifdef DEBUG_HOL
            my_DAG_message("is_FOL_strict_node (%D)\n", src);
#endif
            return true;
          }
      return true;
    }
  if (DAG_arity(src) &&
      !(boolean_connector(DAG_symb(src)) || DAG_symb(src) == FUNCTION_ITE))
    for (i = 0; i < DAG_arity(src); i++)
      if (DAG_sort(DAG_arg(src, i)) == SORT_BOOLEAN &&
          DAG_arg(src, i) != DAG_TRUE && DAG_arg(src, i) != DAG_FALSE)
        {
#ifdef DEBUG_HOL
          my_DAG_message("is_FOL_strict_node (%D)\n", src);
#endif
          return true;
        }
  if (DAG_symb(src) == FUNCTION_ITE &&
      DAG_sort(DAG_arg(src, 1)) == SORT_BOOLEAN)
    {
#ifdef DEBUG_HOL
      my_DAG_message("is_FOL_strict_node (%D)\n", src);
#endif
      return true;
    }
  return true;
  /* every node should be of non-functional sort */
}

bool
is_LFREE_strict(TDAG src)
{
  return structural_recursion_pred(src, is_LFREE_strict_node);
}

bool
is_FOL_strict(TDAG src)
{
  return structural_recursion_pred(src, is_FOL_strict_node);
}

/*
  --------------------------------------------------------------
  General functions
  --------------------------------------------------------------
*/

static bool
is_binder_free_node(TDAG src)
{
  return !(binder(DAG_symb(src)) || DAG_symb(src) == LET);
}

/*--------------------------------------------------------------*/

bool
is_binder_free(TDAG src)
{
  return structural_recursion_pred(src, is_binder_free_node);
}

/*--------------------------------------------------------------*/

static bool
is_quantifier_free_node(TDAG src)
{
  return !quantifier(DAG_symb(src));
}

/*--------------------------------------------------------------*/

bool
is_quantifier_free(TDAG src)
{
  return structural_recursion_pred(src, is_quantifier_free_node);
}

/*
  --------------------------------------------------------------
  Beta reduction
  --------------------------------------------------------------
*/

/*
  simp s v = vs                                               OK
  simp s (A \wedge B) = (simp s A) \wedge (simp s B)          OK
  simp s (f t) = let f = f \delta in
  let t' = simp s t in
  match f with
  f simple func -> f t'                       OK
  \lambda x.u   -> simp (s + {x -> t'}) u     OK
  ite(c,f1,f2)  -> ite simp s c               OK
  simp s (f1 t) !!NOT t'!
  simp s (f2 t)
  default: T -> ????                          Unsupported
  simp s (forall x t) = let x' fresh in
  forall x' simp (s + {x --> x'}) t   OK
  simp s (f = g) = let x fresh in
  forall x (simp s (f x)) = (simp s (g x)) OK
*/

/* PF This submodule applies lambda expressions exhaustively
   DAG_symb_(set or get)_bind are used to link variables and their values
   The code here is complicated also because of the fact that functions
   are not handled as normal terms within DAG module */

/*--------------------------------------------------------------*/

static TDAG
assert_FOL_node(TDAG src)
{
  if (!is_FOL_node(src))
    my_DAG_error("Formula is higher order (%D)\n", src);
  return src;
}

/*
  --------------------------------------------------------------
  Equality lowering
  --------------------------------------------------------------
*/

static TDAG HOL_to_FOL_tree(TDAG src);

/**
   \author Pascal Fontaine
   applies equality lowering to top most symbol if it can be.
   Rewrites equalities T1 = T2 where T1 and T2 have function
   (or predicate) sort into
   forall x_1 ... x_n . T1(x_1, ... , x_n) = T2(x_1, ... , x_n)
   New quantified variables symbols are of the form ?veriT__<n>, so
   such symbols should not be used elsewhere
   \param src the term (or formula) to rewrite
   \return the beta-reduced term
   \remarks destructive
   \remarks DAG-linear
   \remarks no particular requirements on formula (no variable capture,
   behaves honestly with quantifiers), if the binders are not used elsewhere.
   \remark ite-, quantifier-, lambda-, apply-tolerant */
static TDAG
equality_lower_one(TDAG src)
/* Safe for structural recursion if restriction on bound vars applies. */
{
  unsigned i, j;
  unsigned nb_bound;
  Tsymb *symb;
  TDAG *PDAG, *PDAG2, tmp;
  MY_MALLOC(PDAG2, 2 * sizeof(TDAG));
  assert(DAG_symb(src) == PREDICATE_EQ &&
         DAG_sort_functional(DAG_sort(DAG_arg0(src))));
  assert(DAG_sort(DAG_arg0(src)) == DAG_sort(DAG_arg1(src)));
  if (DAG_sort_parametric(DAG_sort(DAG_arg0(src))))
    my_DAG_error("parametric sorts in equality (%D)\n", src);
  assert(DAG_sort_arity(DAG_sort(DAG_arg0(src))) != DAG_SORT_NARY);
  assert(DAG_sort_arity(DAG_sort(DAG_arg0(src))) > 0);

  nb_bound = DAG_sort_arity(DAG_sort(DAG_arg0(src))) - 1;
  MY_MALLOC(symb, nb_bound * sizeof(Tsymb));
  for (i = 0; i < nb_bound; i++)
    if (DAG_sort(DAG_arg0(src)) == SORT_BOOLEAN)
      my_DAG_error("equality lowering introduces Bool quantifier (%D)\n", src);
    else
      symb[i] = DAG_symb_variable(DAG_sort_sub(DAG_sort(DAG_arg0(src)), i));
  for (i = 0; i < 2; i++)
    {
      MY_MALLOC(PDAG, (nb_bound + 1) * sizeof(TDAG));
      PDAG[0] = DAG_arg(src, i);
      for (j = 0; j < nb_bound; j++)
        PDAG[j + 1] = DAG_new_nullary(symb[j]);
      tmp = DAG_dup(DAG_new(APPLY, nb_bound + 1, PDAG));
      PDAG2[i] = HOL_to_FOL_tree(tmp);
      DAG_free(tmp);
    }
  MY_MALLOC(PDAG, (nb_bound + 1) * sizeof(TDAG));
  for (i = 0; i < nb_bound; i++)
    PDAG[i] = DAG_new_nullary(symb[i]);
  PDAG[i] = DAG_new((DAG_sort(PDAG2[0]) == SORT_BOOLEAN)?
                    CONNECTOR_EQUIV:PREDICATE_EQ, 2, PDAG2);
  tmp = DAG_dup(DAG_new(QUANTIFIER_FORALL,nb_bound + 1 , PDAG));
  DAG_free(DAG_arg0(DAG_arg_last(tmp)));
  DAG_free(DAG_arg1(DAG_arg_last(tmp)));
  free(symb);
  DAG_free(src);
  return tmp;
}

/*
  --------------------------------------------------------------
  HOL_to_FOL
  --------------------------------------------------------------
*/

static TDAG
HOL_to_FOL_tree(TDAG src)
{
#ifdef DEBUG_HOL
  my_DAG_message("In Enter tree : %D\n", src);
#endif
  unsigned shift = 0;
  TDAG f, dest;
  Tstack_DAGstack triggers = NULL;
  if (!DAG_arity(src))
    {
      if (DAG_symb_DAG[DAG_symb(src)])
        return /* assert_FOL_node */(DAG_dup(DAG_symb_DAG[DAG_symb(src)]));
      return /* assert_FOL_node */(DAG_dup(src));
    }
  if (quantifier(DAG_symb(src)))
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - 1u; i++)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(src, i))];
          PDAG2[i] =
            DAG_new_nullary(DAG_symb_variable(DAG_sort(DAG_arg(src, i))));
          DAG_symb_DAG[DAG_symb(DAG_arg(src,i))] = DAG_dup(PDAG2[i]);
        }
      PDAG[i] = PDAG2[i] = HOL_to_FOL_tree(DAG_arg(src, i));
      {
        Tstack_DAGstack *Ptriggers = DAG_prop_get(src, DAG_PROP_TRIGGER);
        if (Ptriggers)
          {
            unsigned i, j;
            stack_INIT_s(triggers, stack_size(*Ptriggers));
            for (i = 0; i < stack_size(*Ptriggers); ++i)
              {
                Tstack_DAG old_trigger = stack_get(*Ptriggers, i);
                Tstack_DAG trigger;
                stack_INIT_s(trigger, stack_size(old_trigger));
                for (j = 0; j < stack_size(old_trigger); ++j)
                  stack_push(trigger,
                             HOL_to_FOL_tree(stack_get(old_trigger, j)));
                stack_push(triggers, trigger);
              }
          }
      }

      for (i = 0; i < DAG_arity(src) - 1u; i++)
        {
          DAG_symb_DAG[DAG_symb(DAG_arg(src,i))] = PDAG[i];
          PDAG[i] = PDAG2[i];
        }
      dest = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG2));
      if (triggers)
        DAG_prop_set(dest, DAG_PROP_TRIGGER, &triggers);
      for (i = 0; i < DAG_arity(src); i++)
        DAG_free(PDAG[i]);
      free(PDAG);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  if (DAG_symb(src) == LET)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
      assert(DAG_arity(src) >= 3);
      /* Get the variable values */
      for (i = 1; i < DAG_arity(src); i += 2)
        PDAG[i] = HOL_to_FOL_tree(DAG_arg(src, i));
      /* Attach values to variables */
      for (i = 0; i < DAG_arity(src) - 1u; i += 2)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(src,i))];
          DAG_symb_DAG[DAG_symb(DAG_arg(src,i))] = PDAG[i + 1];
        }
      /* Compute term wrapped in let */
      dest = HOL_to_FOL_tree(DAG_arg_last(src));
      /* Detach variable values, and free them */
      for (i = 0; i < DAG_arity(src) - 1u; i += 2)
        {
          DAG_symb_DAG[DAG_symb(DAG_arg(src,i))] = PDAG[i];
          DAG_free(PDAG[i + 1]);
        }
      free(PDAG);
      free(PDAG2);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  /* Translates f = g into forall x. f(x) = g(x) */
  if (DAG_symb(src) == PREDICATE_EQ &&
      DAG_sort_functional(DAG_sort(DAG_arg0(src))))
    return equality_lower_one(DAG_dup(src));
  if (DAG_symb(src) == APPLY)
    {
      f = DAG_arg(src, 0);
      shift = 1;
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else if (DAG_symb_DAG[DAG_symb(src)])
    {
      f = DAG_symb_DAG[DAG_symb(src)];
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else
    f = src;

  if (!DAG_arity(f) || f == src ) /* f is a simple function */
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i] = PDAG2[i] = HOL_to_FOL_tree(DAG_arg(src, i + shift));
      dest = DAG_dup(DAG_new(DAG_symb(f), DAG_arity(src) - shift, PDAG2));

      for (i = 0; i < DAG_arity(src) - shift; i++)
        DAG_free(PDAG[i]);
      free(PDAG);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif

      /* printf("In Output tree :  ");DAG_print(src);printf("\n"); */
      return /* assert_FOL_node */(dest);
    }
  if (DAG_symb(f) == LAMBDA)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      assert(DAG_arity(f) == DAG_arity(src) + 1 - shift);
      MY_MALLOC(PDAG, (DAG_arity(f) - 1u) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(f) - 1u) * sizeof(TDAG));
      /* Get the argument values and save previous attached vals */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(f, i))];
          PDAG2[i] = HOL_to_FOL_tree(DAG_arg(src, i + shift));
        }
      /* Attach arguments to variables */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG2[i];
      /* Compute body */
      dest = HOL_to_FOL_tree(DAG_arg(f, i));
      /* Free and restore previous values */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          DAG_free(PDAG2[i]);
          DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG[i];
        }
      free(PDAG);
      free(PDAG2);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  if (DAG_symb(f) == FUNCTION_ITE)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      TDAG cond = HOL_to_FOL_tree(DAG_arg(f, 0));
      TDAG then_case, else_case, tmp;
      MY_MALLOC(PDAG, (DAG_arity(src) - shift + 1u) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(src) - shift + 1u) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i + 1] = PDAG2[i + 1] = DAG_arg(src, i + shift);
      PDAG[0] = PDAG2[0] = DAG_arg(f, 1);
      tmp = DAG_dup(DAG_new(APPLY, DAG_arity(src) - shift + 1u, PDAG));
      then_case = HOL_to_FOL_tree(tmp);
      DAG_free(tmp);
      MY_MALLOC(PDAG, (DAG_arity(src) - shift + 1u) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i + 1] = PDAG2[i + 1];
      PDAG[0] = PDAG2[0] = DAG_arg(f, 2);
      tmp = DAG_dup(DAG_new(APPLY, DAG_arity(src) - shift + 1u, PDAG));
       else_case = HOL_to_FOL_tree(tmp);
      DAG_free(tmp);
      for (i = 1; i < DAG_arity(src) - shift + 1u; i++)
        DAG_free(PDAG2[i]);
      free(PDAG2);
      if (DAG_sort(then_case) == SORT_BOOLEAN)
        dest = DAG_dup(DAG_new_args(CONNECTOR_ITE,
                                    cond, then_case, else_case, DAG_NULL));
      else
        dest = DAG_dup(DAG_new_args(FUNCTION_ITE,
                                    cond, then_case, else_case, DAG_NULL));
      DAG_free(cond);
      DAG_free(then_case);
      DAG_free(else_case);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  /* last Case when we have some partial application or fully apply function but 
     with apply symbol at left but with at least one argument alredy apply at f 
     symbol as following example :
   g : Int -> Int
   f : (Int -> Int) -> Int -> Int
   x : Int
   (f g) = g /\ (g x = x) ~~> forall (x0 : Int) (@apply (f g) x0) = (g x0) /\ (g x = x)
  */
  /* if (DAG_sort_functional_partial(src) ){ */
    unsigned i;
    TDAG * PDAG, * PDAG2;
    MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
    MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
    for (i = 0; i < DAG_arity(src) ; i++){
      PDAG[i] = PDAG2[i] = HOL_to_FOL_tree(DAG_arg(src, i ));
    }
    dest = DAG_dup(DAG_new(APPLY, DAG_arity(src) , PDAG2));
    for (i = 0; i < DAG_arity(src) - shift; i++)
      DAG_free(PDAG[i]);
    free(PDAG);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
  /* /\* left hand side might be an application too *\/ */
  /* /\* my_error("HOL_to_FOL: not implemented\n"); *\/ */
  /* return src; */
}

/*--------------------------------------------------------------*/

static TDAG
HOL_to_FOL_DAG(TDAG src)
{ 
  unsigned i;
  TDAG *PDAG, tmp;
  if (DAG_tmp_DAG[src])
    return DAG_tmp_DAG[src];
  if (DAG_symb(src) == APPLY ||
      quantifier(DAG_symb(src)) ||
      DAG_symb(src) == LET ||
      (DAG_symb(src) == PREDICATE_EQ &&
       DAG_sort_functional_partial(DAG_sort(DAG_arg0(src))) )
      /* DAG_sort_functional(DAG_sort(DAG_arg0(src)))) */ )
    {
#ifdef DEBUG_HOL
      my_DAG_message("In Enter : %D\n", src);
#endif
      tmp = HOL_to_FOL_tree(src);
      DAG_tmp_DAG[src] = tmp;
      return tmp;
    }
  /* (f t1 ... tn) */
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = HOL_to_FOL_DAG(DAG_arg(src, i));
  tmp = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  DAG_tmp_DAG[src] = tmp;
  return tmp;
}
/*--------------------------------------------------------------*/
static bool
pre_def_symb(Tsymb src){
  return (DAG_symb(src) == LET ||
          DAG_symb(src) == CONNECTOR_NOT ||
          DAG_symb(src) == CONNECTOR_OR ||
          DAG_symb(src) == CONNECTOR_XOR ||
          DAG_symb(src) == CONNECTOR_IMPLIES ||
          DAG_symb(src) ==  FUNCTION_ITE ||
          DAG_symb(src) == CONNECTOR_ITE ||
          DAG_symb(src) == PREDICATE_LESS ||
          DAG_symb(src) == PREDICATE_LEQ ||
          DAG_symb(src) == PREDICATE_GREATER ||
          DAG_symb(src) == PREDICATE_GREATEREQ ||
          DAG_symb(src) == PREDICATE_DISTINCT ||
          quantifier(DAG_symb(src)) ||
          DAG_symb(src) == FUNCTION_MINUS ||
          DAG_symb(src) == FUNCTION_SUM ||
          DAG_symb(src) == FUNCTION_MOD ||
          DAG_symb(src) == FUNCTION_PROD ||
          DAG_symb(src) == FUNCTION_UNARY_MINUS ||
          DAG_symb(src) == FUNCTION_UNARY_MINUS_ALT ||  
          DAG_symb(src) ==  FUNCTION_DIV ||
          unary_minus(DAG_symb(src)) ||
          DAG_symb(src) == CONNECTOR_EQUIV ||
          DAG_symb(src) == PREDICATE_EQ ||
          DAG_symb(src) ==  CONNECTOR_AND||
          DAG_symb(src) == APPLY);
}

static bool
is_fun_var(TDAG DAG)
{
  return  (DAG_arity(DAG) > 0 &&
           DAG_symb_type(DAG_symb(DAG)) & SYMB_VARIABLE);
}
static TDAG
curry_tree2(TDAG src)
{
#ifdef DEBUG_HOL
  my_DAG_message("In Enter tree : %D\n", src);
#endif
  unsigned shift = 0;
  TDAG f, dest;
  /* Tstack_DAGstack triggers = NULL; */
  if (!DAG_arity(src))
    {
      /* if (DAG_symb_DAG[DAG_symb(src)]) */
      /*   return DAG_dup(DAG_symb_DAG[DAG_symb(src)]); */
      return DAG_dup(src);
    }
  if (quantifier(DAG_symb(src)))
    return DAG_TRUE;
  if (pre_def_symb(src))
    {
#ifdef DEBUG_HOL 
     my_DAG_message("Current sub term %D \n", src);
#endif
    unsigned i;
    TDAG *PDAG;
    MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
    for (i = 0; i < DAG_arity(src); i++)
      PDAG[i] = curry_tree2(DAG_arg(src, i));
    dest = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
    return dest;
  }
  if (DAG_symb(src) == APPLY)
    {
      f = DAG_arg(src, 0);
      shift = 1;
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else if (DAG_symb_DAG[DAG_symb(src)])
    {
      f = DAG_symb_DAG[DAG_symb(src)];
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else
    f = src;
  if (is_fun_var(f)) /* f is a constante of function symbole*/
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, (DAG_arity(f) + 1) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(f) + 1) * sizeof(TDAG));
      PDAG[0] = PDAG2[0] = DAG_dup(DAG_new_nullary(DAG_symb(f)));
      /* my_DAG_message("zz %D %d %D %d\n", PDAG2[0], DAG_arity(PDAG2[0]), f, DAG_arity(f)); */
      for (i = 0; i < DAG_arity(f); i++)
        {
          PDAG[i + 1] = PDAG2[i + 1] = curry_tree2(DAG_arg(f, i));
          /* my_DAG_message("zz %D %d\n", PDAG2[i + 1], DAG_arity(PDAG2[i + 1])); */
        }

      if(DAG_arity(f) >= 1){
        /* my_DAG_message("Before %D After %d\n", src, DAG_arity(src)); */
        dest = DAG_dup(DAG_new(APPLY, DAG_arity(f) + 1, PDAG2));
        /* my_DAG_message("Before %D \n", dest); */
        /* exit(0); */
        /* for (i = 0; i < DAG_arity(src); i++){ */
        /*   if(i == 0){ */
        /*     dest = DAG_dup(DAG_new_binary(APPLY, DAG_new_nullary(DAG_symb(f)) , PDAG2[i])); */
        /*   } */
        /*   else */
        /*     dest = DAG_dup(DAG_new_binary(APPLY,dest,PDAG2[i])); */
        /* } */
      }else
        {
          dest = DAG_dup(DAG_new(DAG_symb(f), DAG_arity(f), PDAG2));
        }
      for (i = 0; i < DAG_arity(f) ; i++)
        DAG_free(PDAG[i]);
      free(PDAG);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  if (!DAG_arity(f) || f == src) /* f is a constante of function symbole*/
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i] = PDAG2[i] = curry_tree2(DAG_arg(src, i + shift));
      if(DAG_arity(f) >= 1){
        for (i = 0; i < DAG_arity(src); i++){
          if(i == 0){
            dest = DAG_dup(DAG_new_binary(APPLY, DAG_new_nullary(DAG_symb(f)) , PDAG2[i]));
          }
          else
            dest = DAG_dup(DAG_new_binary(APPLY,dest,PDAG2[i]));
        }
      }else
      /* dest = DAG_dup(DAG_new(DAG_symb(f), DAG_arity(src), PDAG)); */
      for (i = 0; i < DAG_arity(src) ; i++)
        DAG_free(PDAG[i]);
      free(PDAG);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  /* not fixed for the time we don't currify the lambda */
  if (DAG_symb(f) == LAMBDA)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      assert(DAG_arity(f) == DAG_arity(src) + 1 - shift);
      MY_MALLOC(PDAG, (DAG_arity(f) - 1u) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(f) - 1u) * sizeof(TDAG));
      /* Get the argument values and save previous attached vals */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(f, i))];
          PDAG2[i] = curry_tree2(DAG_arg(src, i + shift));
        }
      /* Attach arguments to variables */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG2[i];
        }
      /* Compute body */
      dest = curry_tree2(DAG_arg(f, i));
      /* Free and restore previous values */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          DAG_free(PDAG2[i]);
          DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG[i];
        }
      free(PDAG);
      free(PDAG2);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  return 0;
}

static TDAG
curry_tree(TDAG src)
{
#ifdef DEBUG_HOL
  my_DAG_message("In Enter tree : %D\n", src);
#endif
  unsigned shift = 0;
  TDAG f, dest;
  /* Tstack_DAGstack triggers = NULL; */
  if (!DAG_arity(src))
    {
      /* if (DAG_symb_DAG[DAG_symb(src)]) */
      /*   return DAG_dup(DAG_symb_DAG[DAG_symb(src)]); */
      return DAG_dup(src);
    }

  if (pre_def_symb(src))
    {
#ifdef DEBUG_HOL 
     my_DAG_message("Current sub term %D \n", src);
#endif
    unsigned i;
    TDAG *PDAG;
    MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
    for (i = 0; i < DAG_arity(src); i++)
      PDAG[i] = curry_tree(DAG_arg(src, i));
    dest = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
    return dest;
  }
  if (DAG_symb(src) == APPLY)
    {
      f = DAG_arg(src, 0);
      shift = 1;
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else if (DAG_symb_DAG[DAG_symb(src)])
    {
      f = DAG_symb_DAG[DAG_symb(src)];
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else
    f = src;
  if (is_fun_var(f)) /* f is a constante of function symbole*/
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, (DAG_arity(f) + 1) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(f) + 1) * sizeof(TDAG));
      PDAG[0] = PDAG2[0] = DAG_dup(DAG_new_nullary(DAG_symb(f)));
      /* my_DAG_message("zz %D %d %D %d\n", PDAG2[0], DAG_arity(PDAG2[0]), f, DAG_arity(f)); */
      for (i = 0; i < DAG_arity(f); i++)
        {
          PDAG[i + 1] = PDAG2[i + 1] = curry_tree(DAG_arg(f, i));
          /* my_DAG_message("zz %D %d\n", PDAG2[i + 1], DAG_arity(PDAG2[i + 1])); */
        }

      if(DAG_arity(f) >= 1){
        /* my_DAG_message("Before %D After %d\n", src, DAG_arity(src)); */
        dest = DAG_dup(DAG_new(APPLY, DAG_arity(f) + 1, PDAG2));
        /* my_DAG_message("Before %D \n", dest); */
        /* exit(0); */
        /* for (i = 0; i < DAG_arity(src); i++){ */
        /*   if(i == 0){ */
        /*     dest = DAG_dup(DAG_new_binary(APPLY, DAG_new_nullary(DAG_symb(f)) , PDAG2[i])); */
        /*   } */
        /*   else */
        /*     dest = DAG_dup(DAG_new_binary(APPLY,dest,PDAG2[i])); */
        /* } */
      }else
        {
          dest = DAG_dup(DAG_new(DAG_symb(f), DAG_arity(f), PDAG2));
        }
      for (i = 0; i < DAG_arity(f) ; i++)
        DAG_free(PDAG[i]);
      free(PDAG);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  if (!DAG_arity(f) || f == src) /* f is a constante of function symbole*/
    {
      unsigned i;
      TDAG * PDAG/* , * PDAG2 */;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      /* MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG)); */
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i] = /* PDAG2[i] =  */curry_tree(DAG_arg(src, i + shift));
      /* if(DAG_arity(f) >= 1){ */
      /*   for (i = 0; i < DAG_arity(src); i++){ */
      /*     if(i == 0){ */
      /*       dest = DAG_dup(DAG_new_binary(APPLY, DAG_new_nullary(DAG_symb(f)) , PDAG2[i])); */
      /*     } */
      /*     else */
      /*       dest = DAG_dup(DAG_new_binary(APPLY,dest,PDAG2[i])); */
      /*   } */
      /* }else */
      dest = DAG_dup(DAG_new(DAG_symb(f), DAG_arity(src), PDAG));
      /* for (i = 0; i < DAG_arity(src) ; i++) */
      /*   DAG_free(PDAG[i]); */
      /* free(PDAG); */
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  /* not fixed for the time we don't currify the lambda */
  if (DAG_symb(f) == LAMBDA)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      assert(DAG_arity(f) == DAG_arity(src) + 1 - shift);
      MY_MALLOC(PDAG, (DAG_arity(f) - 1u) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(f) - 1u) * sizeof(TDAG));
      /* Get the argument values and save previous attached vals */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(f, i))];
          PDAG2[i] = curry_tree(DAG_arg(src, i + shift));
        }
      /* Attach arguments to variables */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG2[i];
        }
      /* Compute body */
      dest = curry_tree(DAG_arg(f, i));
      /* Free and restore previous values */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          DAG_free(PDAG2[i]);
          DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG[i];
        }
      free(PDAG);
      free(PDAG2);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  return 0;
}

/*--------------------------------------------------------------*/

TDAG
head(TDAG src){
  if (DAG_symb(src) == APPLY){
    return head(DAG_arg(src,0));
  }
  return src;
}

TDAG
nb_app(TDAG src,int i)
{
  if (DAG_symb(src) == APPLY)
    return nb_app(DAG_arg(src,0),i+(DAG_arity(src)-1));
  return i;
}

bool
is_partial_arg(TDAG src, int i)
{
  return (DAG_arity(DAG_arg(src, i)) + 1 ==
          DAG_sort_arity(DAG_symb_sort(DAG_symb(DAG_arg(src, i)))));
}

/* TDAG */
/* get_arg_i(TDAG src, int i) */
/* { */
/*   if (DAG_symb(src) == APPLY) */
/*     { */
/*       if (DAG_arity(DAG_arg(src,0)) + 1 == */
/*           DAG_sort_arity(DAG_symb_sort(DAG_symb(DAG_arg(src,0))))) */
/*     } */
/*     return nb_app(DAG_arg(src,0),i+(DAG_arity(src)-1)); */
/*   else if (DAG_sort_arity(src) > 1) */
/*   return i; */
/* } */

void
args_app(TDAG src,TDAG *args,int i)
{
  unsigned j;
  Tstack_DAG stack_args, pending;
  stack_INIT(stack_args);
  stack_INIT(pending);
  stack_push(pending, src);
  while(!stack_is_empty(pending))
    {
      src = stack_pop(pending);
      if (DAG_symb(src) == APPLY)
        {
          for(j = 1; j < DAG_arity(src); j++)
            stack_push(stack_args, DAG_arg(src,j)); 
          stack_push(pending, DAG_arg(src, 0));
        }
    }
  for (j = 0; j < stack_size(stack_args); j++)
    {
#ifdef DEBUG_UNCURRY    
      /* my_DAG_message("arg(%d)=%D %d\n", j+i, stack_get(stack_args, j), i); */
#endif
      args[i + j] = stack_get(stack_args, j);
    }
  stack_reset(stack_args);
  stack_free(stack_args);
  stack_free(pending);
}

void
args_app_rec(TDAG src,TDAG *args,int i)
{
  int j;
#ifdef DEBUG_UNCURRY
  int k = 0;
#endif
  Tstack_DAG stack_args, pending;
  stack_INIT(stack_args);
  stack_INIT(pending);
  stack_push(pending, src);
  while(!stack_is_empty(pending))
    {
      src = stack_pop(pending);
      if (DAG_symb(src) == APPLY)
        {
          for(j = DAG_arity(src) - 1; j >= 1; j--)
            {
#ifdef DEBUG_UNCURRY
              my_DAG_message("APP arg(%d)=%D \n", k++, DAG_arg(src, j));
#endif
              stack_push(stack_args, DAG_arg(src, j)); 
            }
          stack_push(pending, DAG_arg(src, 0));
        }
      else if (DAG_arity(src) > 0)
        {
          for(j = DAG_arity(src) - 1; j >= 0; j--)
            {
#ifdef DEBUG_UNCURRY
              my_DAG_message("arg(%d)=%D \n", k++, DAG_arg(src, j));
#endif
              stack_push(stack_args, DAG_arg(src, j)); 
            }
          /* stack_push(pending, DAG_arg(src, 0)); */
        }
    }
#ifdef DEBUG_UNCURRY
  my_DAG_message("STOP\n");
#endif
  for (j = stack_size(stack_args) - 1; j >= 0; j--)
    {
#ifdef DEBUG_UNCURRY
      my_DAG_message("arg(%d)=%D %d\n", j+i, stack_get(stack_args, j), i);
#endif
      args[i + j] = stack_get(stack_args, stack_size(stack_args) - 1 - j);
    }
  stack_reset(stack_args);
  stack_free(stack_args);
  stack_free(pending);
}


/*--------------------------------------------------------------*/
TDAG
uncurry_tree(TDAG src)
{
  unsigned i;
  TDAG *PDAG, dest;
  if (!DAG_arity(src))
    {
      if (DAG_symb_DAG[DAG_symb(src)])
        return DAG_dup(DAG_symb_DAG[DAG_symb(src)]);
      return DAG_dup(src);
    }
  if (DAG_symb(src) == APPLY &&
      (!(DAG_symb_type(DAG_symb(head(src))) & SYMB_VARIABLE)))
    {
#ifdef DEBUG_UNCURRY
      my_DAG_message("ARG : [%D \n", src);
#endif
      size_t nb_args;
      TDAG * ARGS, dest, tmp;
      TDAG hd =  head(src);
      nb_args = nb_app(src, 0) + DAG_arity(hd);
      MY_MALLOC(ARGS, nb_args  * sizeof(TDAG));
      args_app(src, ARGS,DAG_arity(hd));
      for(i = 0; i < DAG_arity(hd); i++)
        ARGS[i] =  DAG_arg(hd,i);
      bool flag = false;
      if(DAG_symb(DAG_arg(src, 0)) == APPLY)
        {
          args_app_rec(src, ARGS, 0);
          for(i = 0; i < DAG_arity(src); i++)
            {
              if(i == 0) flag = true;
              ARGS[i] =  uncurry_tree(DAG_arg(src, i));
#ifdef DEBUG_UNCURRY
              my_DAG_message("ARG_LOOP : [%D:%S] %d \n", ARGS[i], DAG_sort(ARGS[i]), i);
#endif
              /* for(i = 0; i <= ((nb_args<1)?nb_args:1); i++){ */
              /*   if(i == 0) flag = true; */
              /*   ARGS[i] =  uncurry_tree(DAG_arg(src, i)); */
              /*   my_DAG_message("ARG_LOOP : [%D:%S] %d \n", ARGS[i], DAG_sort(ARGS[i]), i); */ 
            }
        }
      else
        {
#ifdef DEBUG_UNCURRY
          my_DAG_message("ARG : [%D \n", src);
#endif
          args_app_rec(src, ARGS, 0);
          for(i = 0; i < nb_args; i++)
            {
              ARGS[i] = uncurry_tree(ARGS[i]);
#ifdef DEBUG_UNCURRY
              my_DAG_message("ARG_LOOP : [%D:%S] %d \n", ARGS[i], DAG_sort(ARGS[i]), i);
#endif
            }
        }
      if(flag)
        {
          tmp = ARGS[0];
          for(i = 0; i < DAG_arity(tmp); i++)
            {
              if(i>0)
                {
                  ARGS[i + 1] = ARGS[i];
                }
              ARGS[i] = DAG_arg(tmp, i);
            }
        }
#ifdef DEBUG_UNCURRY
      my_DAG_message("TIn Enter : [%D] %D %d %S\n",
                     src, hd, nb_args, DAG_symb_sort(DAG_symb(hd)));
#endif
      dest = DAG_dup(DAG_new(DAG_symb(hd), nb_args , ARGS));
#ifdef DEBUG_UNCURRY
      my_DAG_message("TOUT Enter : %D\n", dest);
#endif
      return dest;
    }
  if (DAG_symb(src) == LAMBDA)
    {
      TDAG DAG;
      Tstack_DAG new_args;
      unsigned remove = DAG_arity(src) - 1, i, j, nb_var = 0;
      DAG = DAG_arg(src, DAG_arity(src) - 1);
#ifdef DEBUG_UNCURRY
      my_DAG_message("FOULEK %D %D %d %d %d\n", src, DAG, DAG_arity(src) - 1, DAG_arity(DAG), remove);
#endif
      if (!DAG_arity(DAG))
        return DAG_dup(src);
      if (DAG_arity(DAG) < remove)
        return DAG_dup(src);
      for (i = 0;  i < DAG_arity(DAG) - remove; i++)
        {
          for (j = 0; j < remove; j++)
            if (DAG_arg(DAG, i) == DAG_arg(src, j))
              return DAG_dup(src);
          for (j = 0; j < remove; j++)
            if (DAG_arg(DAG, i) == DAG_arg(src, j))
              nb_var++;
        }
#ifdef DEBUG_UNCURRY 
      my_DAG_message("DAG %D:%S %d %d\n",
                     DAG, DAG_symb_sort(DAG_symb(DAG)),
                     DAG_sort_arity(DAG_symb_sort(DAG_symb(DAG))), DAG_arity(DAG));
#endif
      if (!nb_var && !(DAG_sort_arity(DAG_symb_sort(DAG_symb(DAG))) - 1 - DAG_arity(DAG)))
        return DAG_dup(src);
      stack_INIT(new_args);
#ifdef DEBUG_UNCURRY
      my_DAG_message("FOULEK %D %D %d %d %d\n", src, DAG, DAG_arity(src) - 1, DAG_arity(DAG), remove);
#endif
      for (i = 0;  i < DAG_arity(DAG) - remove; i++)
        {
          stack_push(new_args, DAG_arg(DAG, i));
          /* my_DAG_message("DAG %D \n", DAG_arg(DAG, i)); */
        }
#ifdef DEBUG_UNCURRY
      my_DAG_message("DAG %D %D %d %d\n", src, DAG, DAG_arity(src) - 1, DAG_arity(DAG));
#endif
      DAG = DAG_dup(DAG_new_stack(DAG_symb(DAG), new_args));
#ifdef DEBUG_UNCURRY
      my_DAG_message("DAG %D \n", DAG);
#endif
      stack_reset(new_args);
      stack_free(new_args);
      return DAG;
    }
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = uncurry_tree(DAG_arg(src, i));
  dest = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  return dest;
}

static TDAG
uncurry_DAG(TDAG src, unsigned ok)
{
  unsigned i;
  TDAG *PDAG, tmp;
  if (DAG_tmp_DAG[src])
    return DAG_tmp_DAG[src];
  if ((DAG_symb(src) == APPLY /* || DAG_symb(src) == LAMBDA */) && ok)
    {
#ifdef DEBUG_HOL
      my_DAG_message("In Enter : %D\n", src);
#endif
      tmp = uncurry_tree(src);
      DAG_tmp_DAG[src] = tmp;
      return tmp;
    }
  /* (f t1 ... tn) */
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = uncurry_DAG(DAG_arg(src, i), 1);
  tmp = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  DAG_tmp_DAG[src] = tmp;
  return tmp;
}

/*--------------------------------------------------------------*/
static TDAG
curry_DAG(TDAG src)
{ 
  unsigned i;
  TDAG *PDAG, tmp;
  if (DAG_tmp_DAG[src])
    return DAG_tmp_DAG[src];
  if (DAG_arity(src) &&
      DAG_symb(src) != APPLY &&
      is_fun_var(src))
    {
#ifdef DEBUG_HOL
      my_DAG_message("In Enter : %D\n", src);
#endif
      tmp = curry_tree(src);
      /* my_DAG_message("Out Enter : %D\n", tmp); */
      DAG_tmp_DAG[src] = tmp;
      return tmp;
    }
  /* (f t1 ... tn) */
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = curry_DAG(DAG_arg(src, i));
  tmp = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  DAG_tmp_DAG[src] = tmp;
  /* my_DAG_message("In Enter : %D\n", tmp); */
  return tmp;
}

static TDAG
curry2_DAG(TDAG src)
{ 
  unsigned i;
  TDAG *PDAG, tmp;
  if (DAG_tmp_DAG[src])
    return DAG_tmp_DAG[src];
  if (DAG_arity(src) &&
      DAG_symb(src) != APPLY &&
      is_quantifier_free_node(src)
      /* is_fun_var(src) */)
    {
#ifdef DEBUG_HOL
      my_DAG_message("In Enter : %D\n", src);
#endif
      tmp = curry_tree2(src);
      /* my_DAG_message("Out Enter : %D\n", tmp); */
      DAG_tmp_DAG[src] = tmp;
      return tmp;
    }
  if (!is_quantifier_free_node(src))
    {
      /* DAG_tmp_DAG[src] = DAG_TRUE; */
      return DAG_TRUE;
    }
  /* (f t1 ... tn) */
  /* my_DAG_message("In Enter : %D\n", src); */
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = curry2_DAG(DAG_arg(src, i));
  tmp = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  DAG_tmp_DAG[src] = tmp;
  /* my_DAG_message("In Enter : %D\n", tmp); */
  return tmp;
}

Tstack_DAG new_lemmas;

static TDAG
app_term(TDAG lambda, Tstack_symb term_list)
{
  unsigned i, arity_lam = DAG_arity(lambda);
  TDAG DAG;
  Tstack_DAG fun_args;
  stack_INIT(fun_args);
  /* my_DAG_message("[LAMBDA]%D %d\n", lambda, stack_size(term_list)); */
  if (!DAG_arity(lambda))
    stack_push(fun_args, lambda);
  for (i = 0; i < arity_lam; i++)
    {
      /* my_DAG_message("[LAMBDA ARG]%D\n", DAG_arg(lambda, i)); */
      stack_push(fun_args, DAG_arg(lambda, i));
    }
  for (i = 0; i < stack_size(term_list); i++)
    {
      TDAG arg = DAG_dup(DAG_new_nullary(stack_get(term_list, i)));
      /* my_DAG_message("[LAMBDA ARG]%D %S\n", arg, DAG_sort(arg)); */
      stack_push(fun_args, arg);
    }
  if (!DAG_arity(lambda))
    {
      DAG = DAG_dup(DAG_new_stack(APPLY, fun_args)); 
    }
  else
    DAG = DAG_dup(DAG_new_stack(DAG_symb(lambda), fun_args));
  stack_reset(fun_args);
  stack_free(fun_args);
  /* my_DAG_message("[LAMBDA]%D %D\n", DAG, lambda); */
  return DAG;
}

extern TDAG
smt2_term_exists(Tstack_symb stack_var, TDAG term);

#include "free-vars.h"

static TDAG
extentionality_DAG(TDAG src)
{
  unsigned i;
  int arity_sort, arity;
  Tsort sort_fun;
  TDAG *PDAG, tmp, tmp2;
  Tstack_symb fun_args;
  if (DAG_tmp_DAG[src])
    return DAG_tmp_DAG[src];

  if (DAG_arity(src) && DAG_symb(src) == CONNECTOR_NOT &&
      DAG_symb(DAG_arg0(src)) == PREDICATE_EQ &&
      ground(src))
    {
#ifdef DEBUG_HOL
      my_DAG_message("In Enter : %D\n", src, ground(src));
#endif
      /* my_DAG_message("TYU Enter : %D %d\n", src, ground(src), DAG_arg0(src), DAG_arg1(src)); */
      tmp2 = src;
      src = DAG_arg0(src);
      if (DAG_arg0(src) == DAG_arg1(src))
        return tmp2;
      sort_fun = DAG_symb_sort(DAG_symb(DAG_arg0(src)));
      arity_sort = DAG_sort_arity(sort_fun) - 1;
      arity = DAG_arity(DAG_arg0(src));
      if (arity_sort > arity)
        {
          stack_INIT(fun_args);
          for (i = arity; i < arity_sort; i++)
            {
              Tsymb symb_fun_arg = DAG_symb_skolem(DAG_sort_sub(sort_fun, i));
              stack_push(fun_args, symb_fun_arg);
            }
          TDAG left = app_term(DAG_arg0(src), fun_args);
          TDAG right = app_term(DAG_arg1(src), fun_args);
          TDAG eq = DAG_dup(DAG_neq(left, right));
          tmp = DAG_dup(DAG_and2(tmp2, eq));
          stack_push(new_lemmas, tmp);
          stack_reset(fun_args);
          stack_free(fun_args);
          /* my_DAG_message("TYU Enter : %D %D\n", src, tmp); */
          /* my_DAG_message("In Enter :%D %D %D %d %d\n", tmp, src, DAG_arg0(src), arity_sort, arity); */
        }
      return tmp2;
    }
  /* (f t1 ... tn) */
  /* my_DAG_message("In Enter : %D\n", src); */
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = extentionality_DAG(DAG_arg(src, i));
  tmp = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  DAG_tmp_DAG[src] = tmp;
  /* my_DAG_message("In Enter : %D\n", tmp); */
  return tmp;
}



/*--------------------------------------------------------------*/
TDAG
uncurry(TDAG src)
{
  TDAG dest;
  DAG_tmp_reserve();
  dest = DAG_dup(uncurry_DAG(src, 1));
  DAG_tmp_free_DAG(src);
  DAG_tmp_release();
#ifdef DEBUG_HOL
  my_DAG_message("HOL_to_FOL\nbefore:%D\nafter:%D\n", src, dest);
#endif
  return dest;
}

TDAG
curry(TDAG src){
  TDAG dest;
  DAG_tmp_reserve();
  dest = DAG_dup(curry_DAG(src));
  DAG_tmp_free_DAG(src);
  DAG_tmp_release();
#ifdef DEBUG_HOL
  my_DAG_message("HOL_to_FOL\nbefore:%D\nafter:%D\n", src, dest);
#endif
  return dest;
}

TDAG
curry2(TDAG src){
  TDAG dest;
  DAG_tmp_reserve();
  dest = DAG_dup(curry2_DAG(src));
  DAG_tmp_free_DAG(src);
  DAG_tmp_release();
#ifdef DEBUG_HOL
  my_DAG_message("HOL_to_FOL\nbefore:%D\nafter:%D\n", src, dest);
#endif
  return dest;
}

TDAG
extentionality(TDAG src){
  TDAG dest;
  stack_INIT(new_lemmas);
  DAG_tmp_reserve();
  dest = DAG_dup(extentionality_DAG(src));
  DAG_tmp_free_DAG(src);
  DAG_tmp_release();
  stack_push(new_lemmas, dest);
  dest = DAG_dup(DAG_new_stack(CONNECTOR_AND, new_lemmas));
  stack_reset(new_lemmas);
  stack_free(new_lemmas);
#ifdef DEBUG_HOL
  my_DAG_message("HOL_to_FOL\nbefore:%D\nafter:%D\n", src, dest);
#endif

  return dest;
}

TDAG
HOL_to_FOL(TDAG src)
{
  TDAG dest;
  DAG_tmp_reserve();
  dest = DAG_dup(HOL_to_FOL_DAG(src));  
  DAG_tmp_free_DAG(src);
  DAG_tmp_release();
#ifdef DEBUG_HOL
  my_DAG_message("HOL_to_FOL\nbefore:%D\nafter:%D\n", src, dest);
#endif
  return dest;
}

/*--------------------------------------------------------------*/

void
HOL_to_FOL_array(unsigned n, TDAG * Psrc)
{
  unsigned i;
  TDAG * PDAG;
  DAG_tmp_reserve();
  MY_MALLOC(PDAG, n * sizeof(TDAG));
  for (i = 0; i < n; i++)
    PDAG[i] = DAG_dup(HOL_to_FOL_DAG(Psrc[i]));
  for (i = 0; i < n; i++)
    {
      DAG_tmp_free_DAG(Psrc[i]);
      DAG_free(Psrc[i]);
      Psrc[i] = PDAG[i];
    }
  free(PDAG);
  DAG_tmp_release();
}
