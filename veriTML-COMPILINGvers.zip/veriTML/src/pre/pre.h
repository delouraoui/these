/*
  --------------------------------------------------------------
  Symbolic Preprocessing for formulas
  --------------------------------------------------------------
*/
#ifdef PROOF
#include "proof.h"
#endif

#include "DAG.h"

void pre_init(void);
void pre_logic(char *);
void pre_done(void);

/* DD+PF Destructive */
TDAG rename_all(TDAG src);
TDAG restore_all(TDAG src);

TDAG pre_process(TDAG src);
/* like the previous, but benefit from the fact that some pre processing
   steps have already been applied on the formula generating instances
   Anyway, some preprocessing step in pre_process should never be applied
   on instances

   The reference counter of the result DAG is at least one.
*/
TDAG pre_process_instance(TDAG src);
#ifdef PROOF
TDAG pre_process_instance_proof(TDAG src, Tproof * Pproof);
#endif

/* PF like the previous but for array of formulas */
#ifdef PROOF
void pre_process_array_proof(unsigned n, TDAG * Psrc, Tproof * Pproof);
#endif
