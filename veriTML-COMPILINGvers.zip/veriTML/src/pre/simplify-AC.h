/*
  ------------------------------------------------------------------
  Module for simplifying symbols based on AC (AND, OR only for now)
  ------------------------------------------------------------------
*/

#ifndef SIMP_AC_H
#define SIMP_AC_H

#include "DAG.h"
#include "proof.h"

extern TDAG simplify_AC(TDAG src);

#ifdef PROOF

extern TDAG simplify_AC_proof(TDAG src, Tproof * Pproof);

#endif

#endif
