/*
  --------------------------------------------------------------
  Module for handling higher order constants, beta reduction,...
  --------------------------------------------------------------
*/

/* PF IMPROVE
   - rename bound variables, so that better sharing */

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>

#include "config.h"

#include "general.h"

#include "HOL.h"
#include "DAG.h"
#include "DAG-prop.h"
#include "DAG-tmp.h"
#include "DAG-print.h"
#include "DAG-prop.h"
#include "veriT-DAG.h"
#include "DAG-symb-DAG.h"
#include "recursion.h"
#include "reduction.h"

extern TDAG
smt2_term_lambda(Tstack_symb stack_var, TDAG term);

/*
  --------------------------------------------------------------
  Beta reduction
  --------------------------------------------------------------
*/

static TDAG
reduce_tree(TDAG src)
{
  unsigned shift = 0;
  TDAG f, dest;
  if (!DAG_arity(src))
    {
      if (DAG_symb_DAG[DAG_symb(src)])
        return DAG_dup(DAG_symb_DAG[DAG_symb(src)]);
      return DAG_dup(src);
    }
  if (quantifier(DAG_symb(src)))
     my_error("quantifier is not allowed");
  if (DAG_symb(src) == LET)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
      assert(DAG_arity(src) >= 3);
      /* Get the variable values */
      for (i = 1; i < DAG_arity(src); i += 2)
        PDAG[i] = reduce_tree(DAG_arg(src, i));
      /* Attach values to variables */
      for (i = 0; i < DAG_arity(src) - 1u; i += 2)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(src,i))];
          DAG_symb_DAG[DAG_symb(DAG_arg(src,i))] = PDAG[i + 1];
        }
      /* Compute term wrapped in let */
      dest = reduce_tree(DAG_arg_last(src));
      /* Detach variable values, and free them */
      for (i = 0; i < DAG_arity(src) - 1u; i += 2)
        {
          DAG_symb_DAG[DAG_symb(DAG_arg(src,i))] = PDAG[i];
          DAG_free(PDAG[i + 1]);
        }
      free(PDAG);
      free(PDAG2);
#ifdef DEBUG_HOL
      my_DAG_message("Before %D After %D\n", src, dest);
#endif
      return dest;
    }
  if (DAG_symb(src) == PREDICATE_EQ)
    my_error("equality is not allowed");
  if (DAG_symb(src) == APPLY)
    {
      f = DAG_arg(src, 0);
      /* my_DAG_message("APP : %D %D %s %D\n", src, f, DAG_symb_name2(DAG_symb(f)), DAG_symb_DAG[DAG_symb(f)]); */
      shift = 1;
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
      /* my_DAG_message("APP : %D\n", f); */
    }
  else if (DAG_symb_DAG[DAG_symb(src)])
    {
      f = DAG_symb_DAG[DAG_symb(src)];
      while (!DAG_arity(f) && DAG_symb_DAG[DAG_symb(f)])
        f = DAG_symb_DAG[DAG_symb(f)];
    }
  else
    f = src;

  if (!DAG_arity(f) || f == src ) /* f is a simple function */
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;

      if ((DAG_symb_type(DAG_symb(f)) & SYMB_VARIABLE) && (DAG_symb(src) == APPLY))
        {
          MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
          MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
          for (i = 0; i < DAG_arity(src); i++)
            {
              /* my_DAG_message("APP : %D\n", f); */
              PDAG[i] = PDAG2[i ] = reduce_tree(DAG_arg(src, i));
              /* my_DAG_message("OUT : %D %D\n", DAG_arg(src, i), PDAG[i]); */
            }
          /* my_DAG_message("ZEBI : %D %D %d\n", src, f, DAG_arity(src)); */
          dest = DAG_dup(DAG_new(APPLY, DAG_arity(src) , PDAG2));
          /* my_DAG_message("FINAL : %D\n", dest); */
          for (i = 0; i < DAG_arity(src); i++)
            DAG_free(PDAG[i]);
        }
      else
        {
          MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
          MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
          for (i = 0; i < DAG_arity(src) - shift; i++)
            PDAG[i] = PDAG2[i] = reduce_tree(DAG_arg(src, i + shift));
          dest = DAG_dup(DAG_new(DAG_symb(f), DAG_arity(src) - shift, PDAG2));
          for (i = 0; i < DAG_arity(src) - shift; i++)
            DAG_free(PDAG[i]);
        }
      /* my_DAG_message("TYUIO : %D\n", f); */
      free(PDAG);
      return dest;
    }
  if (DAG_symb(f) == LAMBDA)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      if (DAG_arity(f) > DAG_arity(src) + 1 - shift)
        {
          MY_MALLOC(PDAG, (DAG_arity(f) - 1u) * sizeof(TDAG));
          MY_MALLOC(PDAG2, (DAG_arity(src) - 1u) * sizeof(TDAG));
          /* Get the argument values and save previous attached vals */
          for (i = 0; i < DAG_arity(src) - 1u; i++)
            {
              PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(f, i))];
              PDAG2[i] = reduce_tree(DAG_arg(src, i + shift));
            }
          /* Attach arguments to variables */
          for (i = 0; i < DAG_arity(src) - 1u; i++)
            DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG2[i];

          /* Compute body */
          dest = reduce_tree(DAG_arg(f, DAG_arity(f) - 1));
          TDAG tmp;
          Tstack_symb arg_remains;
          stack_INIT(arg_remains);
          for (i = DAG_arity(src) - shift; i < DAG_arity(f) - 1u; i++)
            stack_push(arg_remains, DAG_symb(DAG_arg(f, i)));
          tmp = smt2_term_lambda(arg_remains, dest);
          dest = tmp;
          stack_reset(arg_remains);
          stack_free(arg_remains);
          /* Free and restore previous values */
          for (i = 0; i < DAG_arity(src) - 1u; i++)
            {
              DAG_free(PDAG2[i]);
              DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG[i];
            }

          free(PDAG);
          free(PDAG2);
          return dest;
        }
      assert(DAG_arity(f) == DAG_arity(src) + 1 - shift);
      MY_MALLOC(PDAG, (DAG_arity(f) - 1u) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(f) - 1u) * sizeof(TDAG));
      /* Get the argument values and save previous attached vals */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          PDAG[i] = DAG_symb_DAG[DAG_symb(DAG_arg(f, i))];
          PDAG2[i] = reduce_tree(DAG_arg(src, i + shift));
        }
      /* Attach arguments to variables */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG2[i];
      /* Compute body */
      dest = reduce_tree(DAG_arg(f, i));
      /* Free and restore previous values */
      for (i = 0; i < DAG_arity(f) - 1u; i++)
        {
          DAG_free(PDAG2[i]);
          DAG_symb_DAG[DAG_symb(DAG_arg(f, i))] = PDAG[i];
        }
      free(PDAG);
      free(PDAG2);
      return dest;
    }
  if (DAG_symb(f) == FUNCTION_ITE)
    {
      unsigned i;
      TDAG * PDAG, * PDAG2;
      TDAG cond = reduce_tree(DAG_arg(f, 0));
      TDAG then_case, else_case, tmp;
      MY_MALLOC(PDAG, (DAG_arity(src) - shift + 1u) * sizeof(TDAG));
      MY_MALLOC(PDAG2, (DAG_arity(src) - shift + 1u) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i + 1] = PDAG2[i + 1] = DAG_arg(src, i + shift);
      PDAG[0] = PDAG2[0] = DAG_arg(f, 1);
      tmp = DAG_dup(DAG_new(APPLY, DAG_arity(src) - shift + 1u, PDAG));
      then_case = reduce_tree(tmp);
      DAG_free(tmp);
      MY_MALLOC(PDAG, (DAG_arity(src) - shift + 1u) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) - shift; i++)
        PDAG[i + 1] = PDAG2[i + 1];
      PDAG[0] = PDAG2[0] = DAG_arg(f, 2);
      tmp = DAG_dup(DAG_new(APPLY, DAG_arity(src) - shift + 1u, PDAG));
       else_case = reduce_tree(tmp);
      DAG_free(tmp);
      for (i = 1; i < DAG_arity(src) - shift + 1u; i++)
        DAG_free(PDAG2[i]);
      free(PDAG2);
      if (DAG_sort(then_case) == SORT_BOOLEAN)
        dest = DAG_dup(DAG_new_args(CONNECTOR_ITE,
                                    cond, then_case, else_case, DAG_NULL));
      else
        dest = DAG_dup(DAG_new_args(FUNCTION_ITE,
                                    cond, then_case, else_case, DAG_NULL));
      DAG_free(cond);
      DAG_free(then_case);
      DAG_free(else_case);
      return dest;
    }
    unsigned i;
    TDAG * PDAG, * PDAG2;
    MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
    MY_MALLOC(PDAG2, DAG_arity(src) * sizeof(TDAG));
    for (i = 0; i < DAG_arity(src) ; i++){
      PDAG[i] = PDAG2[i] = reduce_tree(DAG_arg(src, i ));
    }
    dest = DAG_dup(DAG_new(APPLY, DAG_arity(src) , PDAG2));
    for (i = 0; i < DAG_arity(src) - shift; i++)
      DAG_free(PDAG[i]);
    free(PDAG);
    return dest;
}

/*--------------------------------------------------------------*/

static TDAG
reduce_DAG(TDAG src)
{
  unsigned i;
  TDAG *PDAG, tmp;
  if (DAG_tmp_DAG[src])
    return DAG_tmp_DAG[src];
  if (DAG_symb(src) == APPLY ||
      DAG_symb(src) == LET)
    {
#ifdef DEBUG_HOL
      my_DAG_message("In Enter : %D %D\n", src, DAG_symb_DAG[DAG_symb(DAG_arg(src, 0))]);
#endif
      tmp = reduce_tree(src);
      DAG_tmp_DAG[src] = tmp;
      return tmp;
    }
  /* (f t1 ... tn) */
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  for (i = 0; i < DAG_arity(src); i++)
    PDAG[i] = reduce_DAG(DAG_arg(src, i));
  tmp = DAG_dup(DAG_new(DAG_symb(src), DAG_arity(src), PDAG));
  DAG_tmp_DAG[src] = tmp;
  return tmp;
}

/*--------------------------------------------------------------*/

void
reduce_array(unsigned n, TDAG * Psrc)
{
  unsigned i;
  TDAG * PDAG;
  DAG_tmp_reserve();
  MY_MALLOC(PDAG, n * sizeof(TDAG));
  for (i = 0; i < n; i++)
    PDAG[i] = DAG_dup(reduce_DAG(Psrc[i]));
  for (i = 0; i < n; i++)
    {
      DAG_tmp_free_DAG(Psrc[i]);
      DAG_free(Psrc[i]);
      Psrc[i] = PDAG[i];
    }
  free(PDAG);
  DAG_tmp_release();
}

/*--------------------------------------------------------------*/

TDAG
reduce(TDAG src)
{
  TDAG dest;
  DAG_tmp_reserve();
  dest = DAG_dup(reduce_DAG(src));
  DAG_tmp_free_DAG(src);
  DAG_tmp_release();
  return dest;
}
