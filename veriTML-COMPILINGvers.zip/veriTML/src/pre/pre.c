#include <string.h>

#include "config.h"

#include "general.h"

#include "DAG.h"
#include "DAG-stat.h"
#include "options.h"

#ifdef DEBUG
#include "DAG-print.h"
#endif

#include "DAG-symb-DAG.h"
#include "fix-trigger.h"
#include "HOL.h"
#include "binder-rename.h"
#include "bfun-elim.h"
#include "bclauses.h"
#include "distinct-elim.h"
#include "ite-elim.h"
#include "free-vars.h"
#include "inst-pre.h"
#include "inst-trigger.h"
#include "inst-trigger-selection.h"
#include "nary-elim.h"
#include "pm.h"
#include "pre.h"
#include "qnt-tidy.h"
#include "qnt-utils.h"
#include "qnt-trigger.h"
#include "rare-symb.h"
#include "simplify.h"
#include "recursion.h"
#include "context-recursion.h"
#include "context-recursion-proof.h"
#include "skolem.h"
#include "connectives.h"
#include "let-elim.h"
#include "simp-sym.h"
#include "simp-unit.h"
#include "simp-formula-sat.h"
#include "proof.h"
#include "LA-pre.h"

static bool pre_quantifier = true;
bool compare_ml = false;
static bool pre_eq = false;

/**
   \addtogroup arguments_user

   - --disable-simp

   Disables simplification of expressions. */
static bool disable_simp = false;

static bool disable_unit_simp = false;
static bool disable_unit_subst_simp = false;
static bool disable_bclause = false;
static bool disable_ackermann = false;

/**
   \addtogroup arguments_user

   - --disable-sym

   Disables symmetry breaking. */
static bool disable_sym = false;

/**
   \addtogroup arguments_user

   - --enable-assumption-simp

   Enables application of simplifications of assumptions */
static bool enable_assumption_simp = 0;


extern bool option_learning_native;
bool enable_nnf_simp = false;

/*--------------------------------------------------------------*/

#ifdef PROOF

Tstack_DAG snapshot = NULL;

static void
pre_proof_snapshot(unsigned n, TDAG * Psrc)
{
  unsigned i;
  if (!snapshot)
    {
      stack_INIT(snapshot);
    }
  else
    for (i = 0; i < stack_size(snapshot); i++)
      DAG_free(stack_get(snapshot,i));
  stack_resize(snapshot, n);
  for (i = 0; i < n; i++)
    stack_set(snapshot, i, DAG_dup(Psrc[i]));
}

/*--------------------------------------------------------------*/

static void
pre_proof_compare(unsigned n, TDAG * Psrc, Tproof * Pproof,
                  Tproof (f) (Tproof, TDAG))
{
  unsigned i;
  assert (stack_size(snapshot) == n);
  for (i = 0; i < n; i++)
    if (Psrc[i] != stack_get(snapshot, i))
      Pproof[i] = f(Pproof[i], Psrc[i]);
}

/*--------------------------------------------------------------*/

static void
pre_proof_erase_snapshot(void)
{
  unsigned i;
  if (snapshot)
    for (i = 0; i < stack_size(snapshot); i++)
      DAG_free(stack_get(snapshot,i));
  stack_free(snapshot);
}
#endif

/*--------------------------------------------------------------*/

static TDAG
pre_HOL_to_FOL(TDAG src)
{
  TDAG dest;
  /**************** fix_triggers */
  /* DD normalizes triggers (quantification patterns)
     this should be done once and forall on every input formula
     instances should not be reprocessed */
  /* In principle this should also be applied on formulas coming from
     macros, etc.  However, since this is a favour for the user who
     writes badly formed formulas, it will not be applied on macros */
  fix_trigger_array(1, &src);
  
  /**************** macro_subst */
  /* PF HOL->FOL: the higher order processing */
  /* binder_rename is applied on macro body before expansion so that
     - no bound variable of the macro interacts with bound/unbound vars
     of the formula
     - no free symbol of the macro interacts with binders of the formulas
     thanks to the fact that binder_rename uses fresh names
     To avoid problems with macro containing macros, this occurs
     at macro expansion in macro_substitute */
  /* requires the binder_rename invariant
     should come high in the list because it will introduce new terms
     that also need processing */
  dest = context_structural_recursion(src, let_elim_init, let_elim_push,
                                      let_elim_pop, let_elim_reduce, NULL);
  /* dest = let_context_structural_recursion(src, let_elim_init, let_elim_push, */
  /*                                         let_elim_pop, let_elim_reduce); */
  DAG_free(src);
  src = dest;
  /**************** bfun_elim */
  dest = bfun_elim(src);
  DAG_free(src);
  src = dest;
  /* my_DAG_message("HOL_to_FOL %D\n", src); */
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static void
pre_HOL_to_FOL_array_proof(unsigned n, TDAG * Psrc, Tproof * Pproof)
{
  unsigned i;
  TDAG dest;
  /**************** fix_triggers */
  /* DD normalizes triggers (quantification patterns)
     this should be done once and forall on every input formula
     instances should not be reprocessed */
  /* In principle this should also be applied on formulas coming from
     macros, etc.  However, since this is a favour for the user who
     writes badly formed formulas, it will not be applied on macros */
  fix_trigger_array(n, Psrc);
  /**************** HOL_to_FOL */
  /* PF HOL->FOL: the higher order processing */
  /* binder_rename is applied on macro body before expansion so that
     - no bound variable of the macro interacts with bound/unbound vars
     of the formula
     - no free symbol of the macro interacts with binders of the formulas
     thanks to the fact that binder_rename uses fresh names
     To avoid problems with macro containing macros, this occurs
     at macro expansion in macro_substitute */
  /**************** let elimination */
  /* context_structural_recursion_array_proof(n, Psrc, Pproof, let_elim_ctx_aux_proof, CTX_NONE); */
  for (i = 0; i < n; ++i)
    {
      dest = context_structural_recursion_proof(Psrc[i], &Pproof[i],
                                                let_elim_init_proof,
                                                let_elim_push_proof,
                                                let_elim_pop_proof,
                                                let_elim_replacement,
                                                let_elim_reduce_proof, NULL);
      DAG_free(Psrc[i]);
      Psrc[i] = dest;
    }
  /* HOL-free, let-free below this point, but still bfuns */
  /**************** bfun_elim */
  pre_proof_snapshot(n, Psrc);
  bfun_elim_array(n, Psrc);
  pre_proof_compare(n, Psrc, Pproof, proof_tmp_bfun_elim);
  pre_proof_erase_snapshot();
}

#endif

/*--------------------------------------------------------------*/

static TDAG
distinct_elim_aux(TDAG src)
{
  unsigned i, j, k = 0;
  TDAG dest, *PDAG;
  if (DAG_symb(src) != PREDICATE_DISTINCT)
    return src;
  if (DAG_arity(src) <= 1)
    {
      DAG_free(src);
      return DAG_dup(DAG_TRUE);
    }
  if (DAG_sort(DAG_arg(src, 0)) == SORT_BOOLEAN)
    {
      dest = DAG_dup(DAG_arity(src) > 2 ? DAG_FALSE :
                     DAG_not(DAG_equiv(DAG_arg0(src), DAG_arg1(src))));
      DAG_free(src);
      return dest;
    }
  if (DAG_arity(src) == 2)
    {
      dest = DAG_dup(DAG_neq(DAG_arg0(src), DAG_arg1(src)));
      DAG_free(src);
      return dest;
    }
  MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
  memcpy(PDAG, DAG_args(src), DAG_arity(src) * sizeof(TDAG));
  simp_sym_notify(DAG_arity(src), PDAG);
  MY_MALLOC(PDAG, DAG_arity(src) * (DAG_arity(src) - 1) * sizeof(TDAG) / 2);
  for (i = 0; i < DAG_arity(src); i++)
    for (j = i + 1; j < DAG_arity(src); j++)
      PDAG[k++] = DAG_neq(DAG_arg(src, i), DAG_arg(src, j));
  dest = DAG_dup(DAG_new(CONNECTOR_AND, DAG_arity(src) * (DAG_arity(src) - 1) / 2,
                         PDAG));
  DAG_free(src);
  return dest;
}

#ifdef DEBUG
void
eq_norm_rec(TDAG src)
{
  if (DAG_symb(src) == PREDICATE_EQ &&
      (DAG_sort(DAG_arg0(src)) == SORT_BOOLEAN ||
       DAG_sort(DAG_arg1(src)) == SORT_BOOLEAN))
    my_error("equality over propositions found\n");
}
#endif

static TDAG
pre_lang_red(TDAG src)
{
  TDAG dest;
#ifdef DEBUG
  /* Check if there are equalities between propositions */
  structural_recursion_void(src, eq_norm_rec);
#endif
  /**************** nary_elim */
  /* replace n-ary by binary operators necessary for Skolemization */

  dest = context_structural_recursion(src, nary_elim_node_init,
                                            nary_elim_node_push, nary_elim_node_pop,
                                            nary_elim_node_reduce, NULL);
  DAG_free(src);
  src = dest;
  /**************** distinct_elim */
  dest = context_structural_recursion(src, distinct_elim_init,
                                            distinct_elim_push, distinct_elim_pop,
                                            distinct_elim_reduce, NULL);
  DAG_free(src);
  return dest;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static TDAG
pre_lang_red_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
#ifdef DEBUG
  /* Check if there are equalities between propositions */
  structural_recursion_void(src, eq_norm_rec);
#endif
  /**************** nary_elim */
  /* replace n-ary by binary operators necessary for Skolemization */
  dest =
    context_structural_recursion_proof(src, Pproof,
                                       nary_elim_node_init,
                                       nary_elim_node_push_proof,
                                       nary_elim_node_pop,
                                       nary_elim_node_replacement,
                                       nary_elim_node_reduce_proof, NULL);
  DAG_free(src);
  src = dest;
  /**************** distinct_elim */
  dest =
    context_structural_recursion_proof(src, Pproof,
                                       distinct_elim_init,
                                       distinct_elim_push_proof,
                                       distinct_elim_pop,
                                       distinct_elim_replacement,
                                       distinct_elim_reduce_proof, NULL);
  DAG_free(src);
  return dest;
}

#endif /* PROOF */

/*--------------------------------------------------------------*/


static bool
predef_symb(TDAG src)
{
  return (DAG_symb(src) == LET ||
          DAG_symb(src) == CONNECTOR_NOT ||
          DAG_symb(src) == CONNECTOR_OR ||
          DAG_symb(src) == CONNECTOR_XOR ||
          DAG_symb(src) == CONNECTOR_IMPLIES ||
          DAG_symb(src) ==  FUNCTION_ITE ||
          DAG_symb(src) == CONNECTOR_ITE ||
          DAG_symb(src) == PREDICATE_LESS ||
          DAG_symb(src) == PREDICATE_LEQ ||
          DAG_symb(src) == FUNCTION_MINUS ||
          DAG_symb(src) == FUNCTION_SUM ||
          DAG_symb(src) == FUNCTION_MOD ||
          DAG_symb(src) == FUNCTION_PROD ||
          DAG_symb(src) == FUNCTION_UNARY_MINUS ||
          DAG_symb(src) == FUNCTION_UNARY_MINUS_ALT ||  
          DAG_symb(src) == PREDICATE_GREATER ||
          DAG_symb(src) == PREDICATE_GREATEREQ ||
          DAG_symb(src) == PREDICATE_DISTINCT ||
          DAG_symb_type(DAG_symb(src)) & SYMB_VARIABLE ||
          DAG_symb(src) == CONNECTOR_EQUIV ||
          DAG_symb(src) == PREDICATE_EQ ||
          DAG_symb(src) == DAG_TRUE ||
          DAG_symb(src) == DAG_FALSE ||
          DAG_symb(src) == DAG_ZERO ||
          DAG_symb(src) == DAG_ONE ||
          !strcmp(DAG_symb_name2(DAG_symb(src)), "false") ||
          !strcmp(DAG_symb_name2(DAG_symb(src)), "true") ||
          !strcmp(DAG_symb_name2(DAG_symb(src)), "0") ||
          !strcmp(DAG_symb_name2(DAG_symb(src)), "1") ||
          DAG_symb(src) ==  FUNCTION_DIV ||
          unary_minus(DAG_symb(src)) ||
          quantifier(DAG_symb(src)) ||
          DAG_symb(src) ==  CONNECTOR_AND);
}


bool
DAG_all(TDAG DAG)
{
  return true;
}

Tstack_symb all_symb;

void
all_restore_init(void)
{
  unsigned i;
  for (i = 0; i < stack_size(all_symb); i += 2)
    {
      /* my_DAG_message("[INIT] %s --> %s\n", */
      /*                DAG_symb_name2(stack_get(all_symb, i + 1)), */
      /*                DAG_symb_name2(stack_get(all_symb, i))); */
      DAG_symb_DAG[stack_get(all_symb, i + 1)] = stack_get(all_symb, i);
    }
}


void
all_rename_init(void)
{
  unsigned i;
  for (i = 0; i < stack_size(all_symb); i += 2)
    {
      /* my_DAG_message("[INIT] %s --> %s\n", */
      /*                DAG_symb_name2(stack_get(all_symb, i)), */
      /*                DAG_symb_name2(stack_get(all_symb, i+1))); */
      DAG_symb_DAG[stack_get(all_symb, i)] = stack_get(all_symb, i + 1);
    }
}

/*--------------------------------------------------------------*/

void
all_rename_push(TDAG src, unsigned * pos)
{
  Tsymb symb;
  if (!predef_symb(src) && !DAG_symb_DAG[DAG_symb(src)] &&
      strncmp(DAG_symb_name2(DAG_symb(src)), "@cm", 3))
    {
      assert(!DAG_symb_DAG[DAG_symb(src)]);
      symb = DAG_symb_constml(DAG_symb_sort(DAG_symb(src)));
      DAG_symb_DAG[DAG_symb(src)] = symb;
      stack_push(all_symb, DAG_symb(src));
      stack_push(all_symb, symb);
    }
}

void
all_restore_push(TDAG src, unsigned * pos)
{
}


/*--------------------------------------------------------------*/

void
all_rename_pop(TDAG src, unsigned pos)
{
}

/*--------------------------------------------------------------*/

TDAG
all_rename_reduce(TDAG src)
{
  TDAG dest;
  unsigned i;
  Tsymb symb;
  Tstack_DAG args;

  if (DAG_symb_DAG[DAG_symb(src)])
    {
      symb = DAG_symb_DAG[DAG_symb(src)];
      if (DAG_arity(src))
        {
          stack_INIT(args);
          for (i = 0; i < DAG_arity(src); i++)
            stack_push(args, DAG_arg(src, i));
          dest = DAG_dup(DAG_new_stack(symb, args));
          stack_reset(args);
          stack_free(args);
        }
      else
        dest = DAG_dup(DAG_new(symb, 0, NULL));
      DAG_free(src);
      return dest;
    }
  if (!DAG_arity(src) &&
      !predef_symb(src) &&
      strncmp(DAG_symb_name2(DAG_symb(src)), "@ct", 3))
    {
      assert(!DAG_symb_DAG[DAG_symb(src)]);
      symb = DAG_symb_const(DAG_sort(src));
      DAG_symb_DAG[DAG_symb(src)] = symb;
      stack_push(all_symb, DAG_symb(src));
      stack_push(all_symb, symb);
      dest = DAG_dup(DAG_new(symb, 0, NULL));
      DAG_free(src);
      return dest;
    }
  return src;
}


TDAG
all_restore_reduce(TDAG src)
{
  TDAG dest;
  unsigned i;
  Tsymb symb;
  Tstack_DAG args;

  if (DAG_symb_DAG[DAG_symb(src)])
    {
      symb = DAG_symb_DAG[DAG_symb(src)];
      if (DAG_arity(src))
        {
          stack_INIT(args);
          for (i = 0; i < DAG_arity(src); i++)
            stack_push(args, DAG_arg(src, i));
          dest = DAG_dup(DAG_new_stack(symb, args));
          stack_reset(args);
          stack_free(args);
        }
      else
        dest = DAG_dup(DAG_new(symb, 0, NULL));
      DAG_free(src);
      return dest;
    }
   if (!DAG_arity(src) &&
       !strncmp(DAG_symb_name2(DAG_symb(src)), "@ct", 3))
    {
      assert(!DAG_symb_DAG[DAG_symb(src)]);
      for (i = 0; i < stack_size(all_symb); i+=2)
        if (stack_get(all_symb, i + 1) == DAG_symb(src))
          symb = stack_get(all_symb, i);
      DAG_symb_DAG[DAG_symb(src)] = symb;
      dest = DAG_dup(DAG_new(symb, 0, NULL));
      DAG_free(src);
      return dest;
    }
  return src;
}


TDAG
rename_all(TDAG src)
{
  TDAG dest;
  dest = nosub_context_structural_recursion(src, all_rename_init,
                                            all_rename_push, all_rename_pop,
                                            all_rename_reduce,
                                            DAG_all);
  DAG_free(src);
  src = dest;
  return src;
}

TDAG
restore_all(TDAG src)
{
  TDAG dest;
  dest = nosub_context_structural_recursion(src, all_restore_init,
                                            all_restore_push, all_rename_pop,
                                            all_restore_reduce,
                                            DAG_all);
  src = dest;
  return src;
}

#include "inst-pre.h"

static TDAG
pre_quant_ite(TDAG src)
{
  TDAG dest;
  bool first = true, changed = false;
  /* Initializing machinery for renaming bound variables */
  if (DAG_quant(src))
    {
      /* Whether there are free or reused variables */
      check_free_shadowed_vars(src);
      DAG_symb_var_resize(stack_size(DAG_sort_stack));
    }
  /* here is a loop to simplify quantifiers, eliminate skolem quant and ites */
  do
    {
      /* my_DAG_message("TRANS ==>\n%D\n", src); */
      /* Join sequential occurrences of the same quantifier  */
      dest = context_structural_recursion(src, qnt_join_init,
                                          qnt_join_push, qnt_join_pop,
                                          qnt_join_reduce,
                                          DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* QNT ONE-POINT RULE */
      dest = context_structural_recursion(src, qnt_simp_init,
                                          qnt_simp_push, qnt_simp_pop,
                                          qnt_simp_reduce,
                                          DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Remove variables which are not used */
      dest = context_structural_recursion(src, qnt_rm_unused_init,
                                          qnt_rm_unused_push, qnt_rm_unused_pop,
                                          qnt_rm_unused_reduce,
                                          DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Structurally identical formulas are canonized to have the same vars */
      dest = context_structural_recursion(src, qnt_canon_init,
                                          qnt_canon_push, qnt_canon_pop,
                                          qnt_canon_reduce,
                                          DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Formula simplifications */
      if (!disable_simp)
        src = simplify_formula(src);
      /* Remove variables which are not used. The simplifications may remove
         variables from the body (e.g. x * 0), and also canonization may expose
         unused variables, like in AxEyAx. F */
      dest = context_structural_recursion(src, qnt_rm_unused_init,
                                          qnt_rm_unused_push, qnt_rm_unused_pop,
                                          qnt_rm_unused_reduce,
                                          DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* ITE elimination */
      dest = ite_elim(src);
      /* if no ite elim, no new skolemizable quant */
      if (!first && src == dest)
        {
          DAG_free(dest);
          break;
        }
      else
        first = false;
      DAG_free(src);
      src = dest;
      /* Put quantified formulas in NNF and rewrite */
      if (enable_nnf_simp)
        {
          /* Put subformulas with quantifiers in NNF */
          dest = qnt_NNF(src);
          DAG_free(src);
          src = dest;
          /* forall x. forall y forall y -> forall x. forall y1 forall y2 */
          dest = qnt_uniq_vars(src);
          DAG_free(src);
          src = dest;
          if (!disable_simp)
            src = simplify_formula(src);
        }
      else
        {
          /* remove double pol connectives over subformulas with quantifiers */
          dest = context_structural_recursion(src, single_pol_qnt_init,
                                              single_pol_qnt_push,
                                              single_pol_qnt_pop,
                                              single_pol_qnt_reduce,
                                              DAG_quant_f);
          /* my_DAG_message(" =A= > %D\n", dest); */
          if (!option_learning_native && !compare_ml)
            {
              DAG_free(src);
              src = dest;
              /* forall x. forall y forall y -> forall x. forall y1 forall y2 */
              dest = context_structural_recursion(src, qnt_rename_init,
                                                  qnt_rename_push, qnt_rename_pop,
                                                  qnt_rename_reduce,
                                                  DAG_quant_or_under_binder);
              check_free_shadowed_vars(dest);
            }
          DAG_free(src);
          src = dest;
        }
      /* skolemization, which may make new ite terms appear and, if deep_SKO is
         on, joinable quantifiers */
      dest = skolemize(src);
      changed = src != dest;
      DAG_free(src);
      src = dest;
    }
  while (changed);
  /* Get rid of weak existentials */
  dest = context_structural_recursion(src, rewrite_w_exist_init,
                                      rewrite_w_exist_push,
                                      rewrite_w_exist_pop,
                                      rewrite_w_exist_reduce,
                                      rewrite_w_exist_cont);
  DAG_free(src);
  src = dest;
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static TDAG
pre_quant_ite_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
  int first = 1, changed = 0;
  /* Initializing machinery for renaming bound variables */
  if (DAG_quant(src))
    {
      /* Whether there are free or reused variables */
      check_free_shadowed_vars(src);
      DAG_symb_var_resize(stack_size(DAG_sort_stack));
    }
  do
    {
      /* Join sequential occurrences of the same quantifier  */
      dest = context_structural_recursion_proof(src, Pproof,
                                                qnt_join_init, qnt_join_push_proof,
                                                qnt_join_pop, qnt_join_replacement,
                                                qnt_join_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* QNT ONE-POINT RULE */
      dest = context_structural_recursion_proof(src, Pproof, qnt_simp_init,
                                                qnt_simp_push_proof, qnt_simp_pop,
                                                qnt_simp_replacement,
                                                qnt_simp_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Remove variables which are not used */
      dest = context_structural_recursion_proof(src, Pproof, qnt_rm_unused_init,
                                                qnt_rm_unused_push_proof,
                                                qnt_rm_unused_pop,
                                                qnt_rm_unused_replacement,
                                                qnt_rm_unused_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Structurally identical formulas are canonized to have the same vars */
      dest = context_structural_recursion_proof(src, Pproof,
                                                qnt_canon_init,
                                                qnt_canon_push_proof, qnt_canon_pop,
                                                qnt_canon_replacement,
                                                qnt_canon_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* Formula simplifications */
      if (!disable_simp)
        src = simplify_formula_proof(src, Pproof);
      /* Remove variables which are not used. The simplifications may remove
         variables from the body (e.g. x * 0), and also canonization may expose
         unused variables, like in AxEyAx. F */
      dest = context_structural_recursion_proof(src, Pproof, qnt_rm_unused_init,
                                                qnt_rm_unused_push_proof,
                                                qnt_rm_unused_pop,
                                                qnt_rm_unused_replacement,
                                                qnt_rm_unused_reduce_proof,
                                                DAG_quant_or_under_binder);
      DAG_free(src);
      src = dest;
      check_free_shadowed_vars(src);
      /* ITE elimination */
      dest = ite_elim(src);
      if (src != dest)
        *Pproof = proof_ite_intro(src, dest, *Pproof);
      /* if no ite elim, no new skolemizable quant */
      if (!first && src == dest)
        {
          DAG_free(dest);
          break;
        }
      else
        first = false;
      DAG_free(src);
      src = dest;
      /* double pol connectives */
      dest = context_structural_recursion_proof(src, Pproof,
                                                single_pol_qnt_init,
                                                single_pol_qnt_push_proof,
                                                single_pol_qnt_pop,
                                                single_pol_qnt_replacement,
                                                single_pol_qnt_reduce_proof,
                                                DAG_quant_f);
      changed = (src != dest);
      DAG_free(src);
      src = dest;
      /* skolemization, which may make new ite terms appear and, if deep_SKO is
         on, joinable quantifiers */
      dest = skolemize_proof(src, Pproof);
      /* my_DAG_message("%D\n", dest); */
      /* skolemize may make new ite terms appear */
      changed = changed || (src != dest);
      DAG_free(src);
      src = dest;
    }
  while (changed);
  /* get rid of weak existentials */
  dest = context_structural_recursion_proof(src, Pproof,
                                            rewrite_w_exist_init,
                                            rewrite_w_exist_push_proof,
                                            rewrite_w_exist_pop,
                                            rewrite_w_exist_replacement,
                                            rewrite_w_exist_reduce_proof,
                                            rewrite_w_exist_cont);
  DAG_free(src);
  src = dest;
  return src;
}

#endif

/*--------------------------------------------------------------*/

static TDAG
pre_ite(TDAG src)
{
  TDAG dest;
  /* simplify formula may handle ite in a more gentle way than
     ite_elim, it should therefore come before */
  if (!disable_simp)
      src = simplify_formula(src);
  /* This has no effect inside quantifiers
     This thus should be applied after any rewrite rule that may
     eliminate quantifiers */
  dest = ite_elim(src);
  DAG_free(src);
  src = dest;
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

static TDAG
pre_ite_proof(TDAG src, Tproof * Pproof)
{
  TDAG dest;
  /* simplify formula may handle ite in a more gentle way than
     ite_elim, it should therefore come before */
  if (!disable_simp)
    src = simplify_formula_proof(src, Pproof);
  /* This has no effect inside quantifiers
     This thus should be applied after any rewrite rule that may
     eliminate quantifiers */
  dest = ite_elim(src);
  if (src != dest)
    *Pproof = proof_ite_intro(src, dest, *Pproof);
    /* *Pproof = proof_tmp_ite_elim(*Pproof, dest); */
  DAG_free(src);
  src = dest;
  return src;
}

#endif

/*--------------------------------------------------------------*/

static TDAG
pre_non_essential(TDAG src)
{
  TDAG dest;
  if (!disable_ackermann)
    {
      dest = rare_symb(src);
      DAG_free(src);
      src = dest;
    }
  if (!disable_sym)
    {
      dest = simp_sym(src);
      DAG_free(src);
      src = dest;
    }
  if (!disable_unit_subst_simp)
    src = simplify_formula_sat(src);
  return src;
}

/*--------------------------------------------------------------*/

/* This uses NO, CC, etc..., and will only replace atoms by TRUE/FALSE
   this should come late */
/* Requires to have free access to the NO stack */
/* TODO: for incrementality, it should only be activated if the NO stack is empty */
static TDAG
pre_unit(TDAG src)
{
  TDAG dest;
  Tunsigned orig_n;
  Tunsigned dest_n = DAG_count_nodes(src);
  do
    {
      dest = simplify_unit(src);
      if (dest == src)
        {
          DAG_free(dest);
          break;
        }
      DAG_free(src);
      src = simplify_formula(dest);
      orig_n = dest_n;
      dest_n = DAG_count_nodes(src);
      check_free_shadowed_vars(src);
    }
  while ((dest_n > 1) && /* final formula is not TRUE or FALSE */
         /* previous decrease at least 10 % of nodes */
         ((orig_n - dest_n) * 10 > orig_n) &&
         /* previous decrease of at least 20 nodes */
         ((orig_n - dest_n) > 20));

  return src;
}

/*--------------------------------------------------------------*/

void
pre_process_array(unsigned n, TDAG * Psrc)
{
  TDAG dest;
  unsigned i;
  fix_trigger_array(n, Psrc);
  for (i = 0; i < n; ++i)
    {
      dest = context_structural_recursion(Psrc[i], let_elim_init,
                                          let_elim_push,
                                          let_elim_pop,
                                          let_elim_reduce, NULL);
      DAG_free(Psrc[i]);
      Psrc[i] = dest;
    }
  bfun_elim_array(n, Psrc);
  for (i = 0; i < n; i++)
    Psrc[i] = pre_lang_red(Psrc[i]);
  for (i = 0; i < n; ++i)
    if (pre_quantifier && DAG_quant(Psrc[i]))
      Psrc[i] = pre_quant_ite(Psrc[i]);
    else
      Psrc[i] = pre_ite(Psrc[i]);
  if (!disable_simp)
    for (i = 0; i < n; ++i)
      Psrc[i] = simplify_formula(Psrc[i]);
  if (pre_quantifier)
    for (i = 0; i < n; ++i)
      if (DAG_quant(Psrc[i]))
        set_fvars(Psrc[i]);
  if (pre_eq)
    for (i = 0; i < n; ++i)
      {
        TDAG dest = context_structural_recursion(Psrc[i],  rewrite_eq_init,
                                                       rewrite_eq_push,
                                                       rewrite_eq_pop,
                                                       rewrite_eq_reduce, NULL);
        DAG_free(Psrc[i]);
        Psrc[i] = dest;
      }
}

/*--------------------------------------------------------------*/

TDAG
pre_process(TDAG src)
{
  TDAG dest;
  if (option_learning_native || compare_ml)
    {
      unsigned i;
      TDAG * PDAG;
      MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
      for (i = 0; i < DAG_arity(src) ; i++)
        PDAG[i] = DAG_arg(src, i);
      pre_process_array(DAG_arity(src) , PDAG);
      DAG_free(src);
      dest = DAG_dup(DAG_new(CONNECTOR_AND, DAG_arity(src), PDAG));
      return dest;
    }
  /* my_DAG_message("HOL_to_FOL\nbefore:%D \n", src); */
  src = pre_HOL_to_FOL(src);

  /* HOL-free, let-free below this point */
  src = pre_lang_red(src);

  /* HOL-free, let-free, symbol-normalized below this point */
  /* [TODO] Fix this, it's messy now because deep sko rearrange quantifiers,
     makes the static simplifications necessary again. */
  /* quantifier handling (skolem, tidy, simplify) is sensitive to HOL
     it should come after HOL elimination */
  if (pre_quantifier && DAG_quant(src))
    src = pre_quant_ite(src);
  else
    src = pre_ite(src);
  src = pre_non_essential(src);
  if (!disable_simp)
    src = simplify_formula(src);

  /* HB sets variables infrastructure; ground info is used in congruence
     closure, and quantifier handling, so this should come before unit
     simplification */
  /* [TODO] HB The "ground" function seems to be necessary only in
     bclauses_add. If the function "DAG_is_clean" from simp-unit.c were to be
     used there, then this setting of free variables could be performed only at
     the end of pre-processing, as it should. */
  if (pre_quantifier)
    set_fvars(src);
  if (!disable_unit_simp)
    src = pre_unit(src);
  if (!disable_bclause)
    {
      dest = bclauses_add(src);
      DAG_free(src);
      src = simplify_formula(dest);
      check_free_shadowed_vars(src);
    }
  /* PF this should come late because = may be used or generated before,
     e.g. for ite terms */
  if (pre_eq)
    {
      dest = context_structural_recursion(src, rewrite_eq_init,
                                          rewrite_eq_push, rewrite_eq_pop,
                                          rewrite_eq_reduce, NULL);
      DAG_free(src);
      src = dest;
    }
  /* [TODO] HB Doing again because some previous simplification is killing
     variables */
  if (pre_quantifier)
    set_fvars(src);

  /* HOL-free
     let-free
     symbol-normalized i.e. side ite terms */
  /* for (int i = 0; i < DAG_arity(src); i++) */
  /*   my_DAG_message("%D\n", DAG_arg(src, i)); */
  return src;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

extern unsigned ctx_nb;

void
pre_process_array_proof(unsigned n, TDAG * Psrc, Tproof * Pproof)
{
  unsigned i;
  pre_HOL_to_FOL_array_proof(n, Psrc, Pproof);
  /* for (i = 0; i < n; ++i) */
  /*   assert(is_FOL_strict(Psrc[i])); */
  /* HOL-free, let-free below this point */
  for (i = 0; i < n; i++)
    Psrc[i] = pre_lang_red_proof(Psrc[i], &Pproof[i]);
  /* HOL-free, let-free, symbol-normalized below this point */
  /* [TODO] Fix this, it's messy now because deep sko rearrange quantifiers,
     makes the static simplifications necessary again. */
  /* quantifier handling (skolem, tidy, simplify) is sensitive to HOL
     it should come after HOL elimination */
  for (i = 0; i < n; ++i)
    if (pre_quantifier && DAG_quant(Psrc[i]))
      Psrc[i] = pre_quant_ite_proof(Psrc[i], &Pproof[i]);
    else
      Psrc[i] = pre_ite_proof(Psrc[i], &Pproof[i]);
  if (!disable_simp)
    for (i = 0; i < n; ++i)
      Psrc[i] = simplify_formula_proof(Psrc[i], &Pproof[i]);
  /* this should come very last because it only tags formulas
     ground bit is used in congruence closure, and quantifier handling,
     so this should come before unit simplification */
  /* HB sets variables infrastructure */
  if (pre_quantifier)
    for (i = 0; i < n; ++i)
      if (DAG_quant(Psrc[i]))
        set_fvars(Psrc[i]);

  /* PF this should come late because = may be used or generated before,
     e.g. for ite terms */
  /* PF this should come late because = may be used or generated before,
     e.g. for ite terms */
  if (pre_eq)
    /* context_structural_recursion_array_proof(n, Psrc, Pproof, let_elim_ctx_aux_proof, CTX_NONE); */
    for (i = 0; i < n; ++i)
      {
        TDAG dest = context_structural_recursion_proof(Psrc[i], &Pproof[i],
                                                       rewrite_eq_init,
                                                       rewrite_eq_push_proof,
                                                       rewrite_eq_pop,
                                                       rewrite_eq_replacement,
                                                       rewrite_eq_reduce_proof, NULL);
        DAG_free(Psrc[i]);
        Psrc[i] = dest;
      }
  /* HOL-free let-free symbol-normalized i.e. variety of symbols are rewritten
     (or n-ary to binary) so that no attention to those is necessary in the
     solver qnt_ground should be applied qnt_tidy should be applied ite should
     only occur in quantified formulas no strong (skolemizable) quantifier
     outside ite terms */
    /* for (int i = 0; i < n; i++) */
    /*   my_DAG_message("%D\n", Psrc[i]); */
}

#endif

/*--------------------------------------------------------------*/

TDAG
pre_process_instance(TDAG src)
{
  TDAG quant, instance, lemma;
  assert(DAG_arity(src) == 2);
  quant = DAG_arg0(src);
  instance = DAG_dup(DAG_arg1(src));
  if (pre_quantifier && DAG_quant(instance))
    instance = pre_quant_ite(instance);
  else
    instance = pre_ite(instance);
  if (!disable_simp)
    instance = simplify_formula(instance);
  lemma = DAG_dup(DAG_or2(quant, instance));

  /* this should come very last because it only tags formulas
     ground bit is used in congruence closure, and quantifier handling,
     so this should come before unit simplification */
  check_free_shadowed_vars(lemma);
  /* [TODO] how to avoid working on ground terms which were already checked? */
  /* sets variables infrastructure */
  set_fvars(lemma);
  DAG_free(src);
  DAG_free(instance);
  return lemma;
}

/*--------------------------------------------------------------*/

#ifdef PROOF

TDAG
pre_process_instance_proof(TDAG src, Tproof * Pproof)
{
  TDAG quant, instance, lemma;
  Tproof proof;
  assert(DAG_arity(src) == 2);
  quant = DAG_arg0(src);
  instance = DAG_dup(DAG_arg1(src));
  /* quantifier handling (skolem, tidy, simplify) is sensitive to HOL
     it should come after HOL elimination */
  proof_subproof_begin(ps_type_subproof);
  proof = proof_add_input(instance);
  if (pre_quantifier && DAG_quant(instance))
    instance = pre_quant_ite_proof(instance, &proof);
  else
    instance = pre_ite_proof(instance, &proof);
  if (!disable_simp)
    instance = simplify_formula_proof(instance, &proof);
  if (DAG_arg1(src) != instance)
    {
      Tproof proof1, proof2, proof3;
      proof = proof_subproof_end_input();
      lemma = DAG_dup(DAG_or2(quant, instance));
      proof1 = proof_or(*Pproof);
      proof2 = proof_or_neg(lemma, 0);
      proof3 = proof_or_neg(lemma, 1);
      *Pproof = proof_resolve(4, proof1, proof, proof2, proof3);
    }
  else
    {
      proof_subproof_remove();
      lemma = DAG_dup(src);
    }
  /* this should come very last because it only tags formulas
     ground bit is used in congruence closure, and quantifier handling,
     so this should come before unit simplification */
  check_free_shadowed_vars(lemma);
  /* [TODO] how to avoid working on ground terms which were already checked? */
  /* sets variables infrastructure */
  set_fvars(lemma);
  /* my_DAG_message("%D --> %D\n", src, lemma); */
  DAG_free(src);
  DAG_free(instance);
  return lemma;
}
#endif

/*--------------------------------------------------------------*/

void
pre_init(void)
{
  qnt_tidy_init();
  skolemize_init();
  simp_sym_init();
  bclauses_init();
  options_new(0, "disable-simp", "Disable simplification of expressions.",
              &disable_simp);
  options_new(0, "disable-unit-simp",
              "Disable unit clause propagation as simplification."
              "Only available in non-interactive mode",
              &disable_unit_simp);
  options_new(0, "disable-unit-subst-simp",
              "Disables unit clause rewriting as simplification."
              "Only available in non-interactive mode",
              &disable_unit_subst_simp);
  options_new(0, "disable-ackermann",
              "Disable local Ackermannization and elimination of rare symbols.",
              &disable_ackermann);
  options_new(0, "disable-sym",
              "Disable symmetry breaking.",
              &disable_sym);
  options_new(0, "enable-assumption-simp", "Enable simplifications of assumptions",
              &enable_assumption_simp);
  options_new(0, "enable-nnf-simp", "Qnt formulas into NNF, with var renaming",
              &enable_nnf_simp);
  options_new(0, "disable-bclause",
              "Do not optimize for binary clauses.",
              &disable_bclause);
  pre_quantifier = true;
  options_new(0, "compare-ml-native",
              "same configuration to compare with ml stuff",
              &compare_ml);
  compare_ml = false;
  stack_INIT(all_symb);
}

/*--------------------------------------------------------------*/

void
pre_logic(char * logic)
{
  if (strcmp(logic, "QF_UF") == 0 ||
      strcmp(logic, "QF_UFIDL") == 0 ||
      strcmp(logic, "QF_IDL") == 0 ||
      strcmp(logic, "QF_RDL") == 0 ||
      strcmp(logic, "QF_LRA") == 0 ||
      strcmp(logic, "QF_UFLRA") == 0 ||
      strcmp(logic, "QF_LIA") == 0 ||
      strcmp(logic, "QF_UFLIA") == 0)
    pre_quantifier = false;
  else
    pre_quantifier = true;
  if (strcmp(logic, "QF_RDL") == 0 ||
      strcmp(logic, "QF_IDL") == 0 ||
      strcmp(logic, "QF_LRA") == 0 ||
      strcmp(logic, "QF_LIA") == 0)
    pre_eq = true;
}

/*--------------------------------------------------------------*/

void
pre_done(void)
{
  bclauses_done();
  simp_sym_done();
  qnt_tidy_done();
  skolemize_done();
  stack_reset(all_symb);
  stack_free(all_symb);
}
