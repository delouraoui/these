/*
  --------------------------------------------------------------
  Module for handling higher order constants, beta reduction,...
  --------------------------------------------------------------
*/

#ifndef __RED_H
#define __RED_H

#include "DAG.h"
/** Does the beta reduction **/
TDAG    reduce(TDAG src);

#endif /* __RED_H */
