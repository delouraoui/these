#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "config.h"

#include "DAG-arith.h"
#include "bool.h"
#include "congruence.h"
#include "veriT-state.h"
#include "veriT-status.h"
#include "veriT-DAG.h"

#include "veriT-signal.h"

#ifdef PROOF
#include "proof.h"
#endif

#ifdef DEBUG
#include "options.h"
#endif

#include "nla.h"

// redlog interactions
#include "nla_redlog.h"

/* #define DEBUG_NLA */

enum solver { raSAT, redlog};

int option_nla_reduce_only = 0;

bool redlog_initialized = false;

#define UNSAT_CORE
// #define VERIFY_RASAT_UNSAT_CORE


// #ifdef DEBUG
// static Tstack_str DAGs_already_defined = NULL;
// #endif


/*--------------------------------------------------------------*/

typedef struct Tto_redlog {
  enum {
    TYPE_DAG,
    TYPE_LIT_POS,
    TYPE_LIT_NEG
  } type;
  TDAG DAG;
} Tto_redlog;

TSstack(_to_redlog,Tto_redlog);

static Tstack_to_redlog to_redlog;
static Tstack_lit input_literals;

static Tstatus NLA_status = UNDEF;

#ifdef UNSAT_CORE
static Tstack_lit unsat_core_ids;
#endif

static int litFalse;
static int litFalseIx;



/*
  --------------------------------------------------------------
  Redlog interaction
  --------------------------------------------------------------
*/


static char * solver_output = NULL;

/*
  --------------------------------------------------------------
  Output functions
  --------------------------------------------------------------
*/

static unsigned redlog_buffer_size = 0;
static unsigned redlog_buffer_p = 0;
static char * redlog_buffer = NULL;

static void
redlog_buffer_add(char *str)
{
  unsigned size = (unsigned) strlen(str) + 1;
  if (redlog_buffer_p + size >= redlog_buffer_size)
    {
      while (redlog_buffer_p + size >= redlog_buffer_size)
        {
          redlog_buffer_size *= 2;
          MY_REALLOC(redlog_buffer, redlog_buffer_size);
        }
    }
  strcpy(redlog_buffer + redlog_buffer_p, str);
  redlog_buffer_p += size - 1;
}

/*--------------------------------------------------------------*/

static void
redlog_buffer_clean(void)
{
  redlog_buffer_p = 0;
  redlog_buffer[0] = 0;
}

/*
  --------------------------------------------------------------
  DAG to redlog
  --------------------------------------------------------------
*/

static Tstack_DAG DAG_todo;

/*--------------------------------------------------------------*/

/**
   \brief accumulates all monoms in DAG
   \param DAG a DAG
   \remark if term is not a linear term, introduce a variable for it and adds
   its subterms for deep inspection */
static void
NLA_notify_term(TDAG DAG)
{
  unsigned i;
  char *str;
  Tsymb symb = DAG_symb(DAG);
  if (symb == FUNCTION_SUM ||
      symb == FUNCTION_PROD ||
      symb == FUNCTION_UNARY_MINUS ||
      symb == FUNCTION_UNARY_MINUS_ALT ||
      symb == FUNCTION_MINUS ||
      symb == FUNCTION_DIV)
    {
      redlog_buffer_add("(");
      redlog_buffer_add(DAG_symb_name2(symb));
      for (i = 0; i < DAG_arity(DAG); i++)
        {
          redlog_buffer_add(" ");
          NLA_notify_term(DAG_arg(DAG, i));
        }
      redlog_buffer_add(")");
      return;
    }
  if (DAG_is_number(DAG))
    {
      char * tmp = DAG_number_str(DAG);
      redlog_buffer_add(tmp);
      return;
    }
  MY_MALLOC(str, 20 * sizeof(char));
#ifdef SIMPLE_CONG
  snprintf(str, 20, "v%d", CCS_abstract(DAG));
#else
  snprintf(str, 20, "v%d", CC_abstract(DAG));
#endif
  // #ifdef DEBUG
  //   if (redlog_smt2_log>)
  //     {
  //       unsigned i;
  //       int already_defined = 0;
  //       for (i = 0; i < stack_size(DAGs_already_defined); i++)
  //  if (!strcmp(str, stack_get(DAGs_already_defined, i)))
  //    already_defined = 1;
  //       if (!already_defined)
  //         {
  //           stack_push(DAGs_already_defined, strmake(str));
  //           if (f_smt2)
  //             fprintf(f_smt2, "(declare-fun %s () Real)\n", str);
  //         }
  //     }
  // #endif
  redlog_buffer_add(str);
  free(str);
  if (DAG_arity(DAG))
    for (i = 0; i < DAG_arity(DAG); i++)
      stack_push(DAG_todo, DAG_arg(DAG,i));
}

/*--------------------------------------------------------------*/

/**
   \brief introduces arithmetic definition for all arithmetic subterms in DAG
   \param DAG a DAG */
static void
NLA_notify_deep_terms(TDAG DAG)
{
  unsigned i;
  char *str;
  Tsymb symb = DAG_symb(DAG);
#ifdef DEBUG_NLA
  my_DAG_message("NLA_notify_deep_terms: %D\n", DAG);
#endif
  if (symb == FUNCTION_SUM ||
      symb == FUNCTION_PROD ||
      symb == FUNCTION_UNARY_MINUS ||
      symb == FUNCTION_UNARY_MINUS_ALT ||
      symb == FUNCTION_MINUS ||
      symb == FUNCTION_DIV)
    {
      stack_inc(to_redlog);
      stack_top(to_redlog).type = TYPE_DAG;
      stack_top(to_redlog).DAG = DAG;
      redlog_buffer_add("(assert (= ");
      MY_MALLOC(str, 20 * sizeof(char));
#ifdef SIMPLE_CONG
      snprintf(str, 20, "v%d", CCS_abstract(DAG));
#else
      snprintf(str, 20, "v%d", CC_abstract(DAG));
#endif
      redlog_buffer_add(str);
      free(str);
      redlog_buffer_add(" (");
      redlog_buffer_add(DAG_symb_name2(symb));
      for (i = 0; i < DAG_arity(DAG); i++)
        {
          redlog_buffer_add(" ");
          NLA_notify_term(DAG_arg(DAG, i));
        }
      redlog_buffer_add(")))");
      // redlog_command(redlog_buffer);
      redlog_buffer_clean();
      return;
    }
  if (DAG_is_number(DAG))
    {
      char * tmp = DAG_number_str(DAG);
      redlog_buffer_add("(assert (= ");
      MY_MALLOC(str, 20 * sizeof(char));
#ifdef SIMPLE_CONG
      snprintf(str, 20, "v%d", CCS_abstract(DAG));
#else
      snprintf(str, 20, "v%d", CC_abstract(DAG));
#endif
      redlog_buffer_add(str);
      free(str);
      redlog_buffer_add(" ");
      redlog_buffer_add(tmp);
      free(tmp);
      redlog_buffer_add("))");
      // redlog_command(redlog_buffer);
      redlog_buffer_clean();
      return;
    }
  for (i = 0; i < DAG_arity(DAG); i++)
    NLA_notify_deep_terms(DAG_arg(DAG,i));
}

/*--------------------------------------------------------------*/

/**
   \brief stores arithmetic definition for the atom,
   and all arithmetic terms in DAG
   \param DAG a DAG
   \param pol the polarity of DAG */
static inline void
NLA_notify_atom(TDAG DAG, int pol)
{
  if (DAG_symb(DAG) == PREDICATE_LESS ||
      DAG_symb(DAG) == PREDICATE_LEQ ||
      DAG_symb(DAG) == PREDICATE_GREATER ||
      DAG_symb(DAG) == PREDICATE_GREATEREQ ||
      DAG_symb(DAG) == PREDICATE_EQ)
    {
      stack_inc(to_redlog);
      stack_top(to_redlog).DAG = DAG;

      // if (id==538) {
      //  my_DAG_message("%D", DAG);

      // }

      // printf("Id: %d, to_redlog size: %d\n", id, stack_size(to_redlog));

      stack_top(to_redlog).type = pol?TYPE_LIT_POS:TYPE_LIT_NEG;

      redlog_buffer_add(pol?"(assert ":"(assert (not ");

      redlog_buffer_add("(");
      redlog_buffer_add(DAG_symb_name2(DAG_symb(DAG)));
      redlog_buffer_add(" ");
      NLA_notify_term(DAG_arg0(DAG));
      redlog_buffer_add(" ");
      NLA_notify_term(DAG_arg1(DAG));
      redlog_buffer_add(")");

      redlog_buffer_add(pol?")":"))");

      // pass assert command to solvers
      if (option_nla_reduce_only)
        redlog_command(redlog_buffer);
      else
        raSAT_assert(redlog_buffer, stack_size(to_redlog)-1);


      redlog_buffer_clean();
    }
  else if (DAG_symb(DAG) == PREDICATE_ISINT)
    my_error("DAG2LA: not implemented\n");
  else if (DAG_symb_type(DAG_symb(DAG)) | SYMB_QUANTIFIER) {
    // printf("id: %d, ", id);
    // my_DAG_message("%D", DAG);
    // printf("\n");
    return;
  }
  else
    {
      // printf("id: %d\n", id);
      // my_DAG_message("%D", DAG);
      unsigned i;
      for (i = 0; i < DAG_arity(DAG); i++)
        stack_push(DAG_todo, DAG_arg(DAG, i));
    }
  while (stack_size(DAG_todo))
    NLA_notify_deep_terms(stack_pop(DAG_todo));
}



/*
  --------------------------------------------------------------
  Public functions
  --------------------------------------------------------------
*/


/*--------------------------------------------------------------*/

void
NLA_init(void)
{
  redlog_buffer_size = 0;
  redlog_buffer_p = 0;
  // #ifdef DEBUG
  //   options_new(0, "redlog-log",
  //         "Produce REDLOG formulas during NLA reasoning.  "
  //         "Useful for debugging", &redlog_log);
  //   options_new(0, "redlog-smt2-log",
  //         "Produce REDLOG formulas during NLA reasoning in SMT2 format.  "
  //         "Useful for debugging", &redlog_smt2_log);
  //   stack_INIT(DAGs_already_defined);
  // #endif

}

/*--------------------------------------------------------------*/

void
NLA_done(void)
{
  if (!redlog_buffer_size)
    return;
  if (redlog_initialized){
    redlog_command("(exit)");
    redlog_done();
  }

  stack_free(DAG_todo);
  stack_free(input_literals);
  stack_free(to_redlog);
#ifdef UNSAT_CORE
  stack_free(unsat_core_ids);
#endif
  free(redlog_buffer);
  redlog_buffer = NULL;
  redlog_buffer_size = 0;
  redlog_buffer_p = 0;
  // #ifdef DEBUG
  //   if (redlog_smt2_log)
  //     {
  //       unsigned i;
  //       for (i = 0; i < stack_size(DAGs_already_defined); i++)
  //   free(stack_get(DAGs_already_defined, i));
  //       stack_free(DAGs_already_defined);
  //     }
  // #endif
}


void init_redlog() {
  if (!redlog_initialized){
    veriT_signal_register(&redlog_exit);
    redlog_check();
    redlog_init();
    redlog_command("smt_mainloop();");
    redlog_command("(set-logic QF_NRA)");
    redlog_initialized = true;
  }
}

/*--------------------------------------------------------------*/

void
NLA_activate(void)
{
  stack_INIT(input_literals);
  stack_INIT(to_redlog);
#ifdef UNSAT_CORE
  stack_INIT(unsat_core_ids);
#endif
  stack_INIT(DAG_todo);
  redlog_buffer_size = 256;
  MY_MALLOC(redlog_buffer, redlog_buffer_size * sizeof(char));

  if (option_nla_reduce_only)
    init_redlog();
  else
    raSAT_set_logic("QF_NRA");

  // raSAT_set_logic("QF_NRA");
  // init_redlog();
}

/*--------------------------------------------------------------*/

Tstatus
NLA_assert(Tlit lit)
{
  stack_push(input_literals, lit);
  return NLA_status;
}

void solvers_reset() {
  if (option_nla_reduce_only)
    redlog_command("(reset)");
  else
    raSAT_reset();
}

void NLA_reset() {
  solvers_reset();

}

/*--------------------------------------------------------------*/

void
NLA_clear(void)
{
  NLA_status = UNDEF;
  stack_reset(input_literals);
  stack_reset(to_redlog);
#ifdef UNSAT_CORE
  stack_reset(unsat_core_ids);
#endif

  NLA_reset();
}

/*--------------------------------------------------------------*/

Tstatus
NLA_solve(void)
{
  unsigned i;
  Tlit lit;
  TDAG DAG;
  // #ifdef DEBUG
  //   static unsigned nb = 1;
  //   static unsigned nb_smt2 = 1;
  // #endif
  redlog_buffer_clean();
  if (!stack_size(input_literals))
    return SAT;

  // #ifdef DEBUG
  //   if (redlog_log)
  //     {
  //       char filename[128];
  //       sprintf(filename, "reduce_%05d.red", nb++);
  //       f_red = fopen(filename, "w");
  //       fprintf(f_red, "smt();\n");
  //       fprintf(f_red, "(set-logic QF_NRA)\n");
  //     }
  //   if (redlog_smt2_log)
  //     {
  //       char smtfilename[128];
  //       sprintf(smtfilename, "reduce_%05d.smt2", nb_smt2++);
  //       f_smt2 = fopen(smtfilename, "w");
  //       fprintf(f_smt2, "(set-logic QF_NRA)\n");
  //     }
  // #endif
  litFalseIx = -1;
  for (i = 0; i < stack_size(input_literals); ++i)
    {
      litFalse = 0;
      lit = stack_get(input_literals, i);
      // printf("%d, ", i);
      if (!lit)
        continue;
      DAG = var_to_DAG(lit_var(lit));
      // if (i==538) my_DAG_message ("%D", DAG);
      assert(DAG);
      NLA_notify_atom(DAG, lit_pol(lit));
    }
  // printf("\n");
  // #ifdef DEBUG
  //   if (redlog_log && f_red)
  //     {
  //       fprintf(f_red, "(check-sat)\n");
  //       fclose(f_red);
  //       f_red = NULL;
  //     }
  //   if (redlog_smt2_log && f_smt2)
  //     {
  //       unsigned i;
  //       fprintf(f_smt2, "(check-sat)\n");
  //       fclose(f_smt2);
  //       f_smt2 = NULL;
  //       for (i = 0; i < stack_size(DAGs_already_defined); i++)
  //   free(stack_get(DAGs_already_defined, i));
  //       stack_free(DAGs_already_defined);
  //       stack_INIT(DAGs_already_defined);
  //     }
  // #endif

#ifdef DEBUG_NLA
  my_message("NLA_solve: %s\n", solver_output);
#endif

  if (solver_output){
    free(solver_output);
    solver_output = NULL;
  }

#ifdef UNSAT_CORE
  stack_reset(unsat_core_ids);
#endif
  if (option_nla_reduce_only){
    redlog_command("(check-sat)");
    solver_output = get_redlog_result();
  } else
    solver_output = strmake(raSAT_solve("(check-sat)"));

  // printf("Tung test: %s\n", solver_output);

  if (!strcmp(solver_output, "sat"))
    return NLA_status = SAT;
  if (!strcmp(solver_output, "unsat"))
    return NLA_status = UNSAT;
  if (!strcmp(solver_output, "unknown"))
    return NLA_status = UNDEF;
  my_error("NLA_solve: unexpected result %s\n");
  return UNDEF;
}


#ifdef UNSAT_CORE
void raSAT_conflict () {

  char* unsat_core_string = strmake(raSAT_get_unsat_core());

  // printf("raSAT unsat cores: %s\n", unsat_core_string);
  // exit(1);

  // switch to redlog to verify unsat core of raSAT
#ifdef VERIFY_RASAT_UNSAT_CORE
  option_nla_reduce_only = 1;
  if (!redlog_initialized){
    init_redlog();
  }

  NLA_status = UNDEF;
  stack_reset(input_literals);
  stack_reset(to_redlog);
  redlog_command("(reset)");
#endif

  // printf("Pushing ");
  char *end = unsat_core_string;
  while (*end) {
    long id = strtol(unsat_core_string, &end, 10);
    while (*end == ' ') {
      end++;
    }
    // printf("%d ", id);
    stack_push(unsat_core_ids, id);
    unsat_core_string = end;
  }

  // printf("\n");

#ifdef VERIFY_RASAT_UNSAT_CORE
  if (NLA_solve() != UNSAT) {
    printf("Wrong unsat core of raSAT, exitting.....\n");
    printf("UNSAT cores passed to Redlog:\n");
    redlog_command("(print-assertions)");
    printf("%s\n\n\n", solver_output);
    printf("UNSAT cores produced by raSAT:\n");
    raSAT_print_unsat_cores();
    exit(1);
  }
#endif
}
#endif


/*--------------------------------------------------------------*/

/**
   \brief accumulates all monoms in DAG
   \param DAG a DAG
   \remark if term is not a linear term, introduce a variable for it and adds
   its subterms for deep inspection */
static void
NLA_collect_vars(TDAG DAG, Tstack_DAG * Pstack_vars)
{
  unsigned i;
  Tsymb symb = DAG_symb(DAG);
  if (symb == FUNCTION_SUM ||
      symb == FUNCTION_PROD ||
      symb == FUNCTION_UNARY_MINUS ||
      symb == FUNCTION_UNARY_MINUS_ALT ||
      symb == FUNCTION_MINUS ||
      symb == FUNCTION_DIV)
    {
      for (i = 0; i < DAG_arity(DAG); i++)
        NLA_collect_vars(DAG_arg(DAG, i), Pstack_vars);
      return;
    }

  stack_push(*Pstack_vars, DAG);

  if (DAG_is_number(DAG))
    return;

  if (DAG_arity(DAG))
    for (i = 0; i < DAG_arity(DAG); i++)
      stack_push(DAG_todo, DAG_arg(DAG,i));
}

/*--------------------------------------------------------------*/

/**
   \brief introduces arithmetic definition for all arithmetic subterms in DAG
   \param DAG a DAG */
static void
NLA_collect_vars_deep(TDAG DAG, Tstack_DAG * Pstack_vars)
{
  unsigned i;
  Tsymb symb = DAG_symb(DAG);
  if (symb == FUNCTION_SUM ||
      symb == FUNCTION_PROD ||
      symb == FUNCTION_UNARY_MINUS ||
      symb == FUNCTION_UNARY_MINUS_ALT ||
      symb == FUNCTION_MINUS ||
      symb == FUNCTION_DIV ||
      DAG_is_number(DAG))
    {
      stack_push(*Pstack_vars, DAG);
      for (i = 0; i < DAG_arity(DAG); i++)
        {
          NLA_collect_vars(DAG_arg(DAG, i), Pstack_vars);
        }
      return;
    }
  for (i = 0; i < DAG_arity(DAG); i++)
    NLA_collect_vars_deep(DAG_arg(DAG,i), Pstack_vars);
}

/*--------------------------------------------------------------*/

/**
   \brief stores arithmetic definition for the atom,
   and all arithmetic terms in DAG
   \param DAG a DAG
   \param pol the polarity of DAG */
static inline void
NLA_collect_vars_atom(TDAG DAG, Tstack_DAG * Pstack_vars)
{
  if (DAG_symb(DAG) == PREDICATE_LESS ||
      DAG_symb(DAG) == PREDICATE_LEQ ||
      DAG_symb(DAG) == PREDICATE_GREATER ||
      DAG_symb(DAG) == PREDICATE_GREATEREQ ||
      DAG_symb(DAG) == PREDICATE_EQ)
    {
      NLA_collect_vars(DAG_arg0(DAG), Pstack_vars);
      NLA_collect_vars(DAG_arg1(DAG), Pstack_vars);
    }
  else if (DAG_symb(DAG) == PREDICATE_ISINT){
    my_error("DAG2LA: not implemented\n");
  }
  else if (DAG_symb_type(DAG_symb(DAG)) | SYMB_QUANTIFIER)
    return;
  else
    {
      unsigned i;
      for (i = 0; i < DAG_arity(DAG); i++)
        stack_push(DAG_todo, DAG_arg(DAG, i));
    }
  while (stack_size(DAG_todo))
    NLA_collect_vars_deep(stack_pop(DAG_todo), Pstack_vars);
}

/*--------------------------------------------------------------*/

static int
comp_CC_abstract(TDAG * PDAG1, TDAG * PDAG2)
{
#ifdef SIMPLE_CONG
  return ((int)CCS_abstract(*PDAG1)) - ((int)CCS_abstract(*PDAG2));
#else
  return ((int)CC_abstract(*PDAG1)) - ((int)CC_abstract(*PDAG2));
#endif
}


#ifdef UNSAT_CORE
void
NLA_conflict(void)
{
  if (option_nla_reduce_only) {
    if (NLA_status == UNSAT)
      unsat_core_ids = get_redlog_unsat_core_ids();
    else {
      unsigned i;
      for (i=0; i < stack_size(to_redlog); i++)
        stack_push(unsat_core_ids, i);
    }
  }else
    raSAT_conflict();


  unsigned i;
  Tstack_DAG DAGs = NULL;
  // assert(NLA_status == UNSAT);
#ifdef DEBUG_NLA
  my_message("NLA conflict [%d]/[%d]\n", stack_size(unsat_core_ids),
             stack_size(input_literals));
#endif
  // printf("unsat cores: ");
  stack_INIT(DAGs);
  for (i = 0; i < stack_size(unsat_core_ids); ++i)
    {
      Tlit lit;
      if (stack_get(to_redlog, stack_get(unsat_core_ids, i)).type ==
          TYPE_DAG)
        {
          NLA_collect_vars_atom(stack_get(to_redlog,
                                          stack_get(unsat_core_ids, i)).DAG, &DAGs);
          continue;
        }
      lit = DAG_to_lit(stack_get(to_redlog, stack_get(unsat_core_ids, i)).DAG);
      if (stack_get(to_redlog, stack_get(unsat_core_ids, i)).type == TYPE_LIT_NEG)
        lit = lit_neg(lit);;
#ifdef DEBUG_NLA
      my_DAG_message("lit %d %D\n", lit,
                     stack_get(to_redlog, stack_get(unsat_core_ids, i)).DAG);
#endif
      // printf("%d - %d, ", stack_get(unsat_core_ids, i), lit);
      stack_push(veriT_conflict, lit);
      NLA_collect_vars_atom(lit_to_DAG(lit), &DAGs);
    }
  // printf("\n");
  stack_sort(DAGs, comp_CC_abstract);
#ifdef SIMPLE_CONG
  for (i = 1; i < stack_size(DAGs); i++)
    if (CCS_abstract(stack_get(DAGs, i - 1)) == CCS_abstract(stack_get(DAGs, i)))
      {
        stack_push(veriT_conflict_eqs, stack_get(DAGs, i - 1));
        stack_push(veriT_conflict_eqs, stack_get(DAGs, i));
      }
#else
  for (i = 1; i < stack_size(DAGs); i++)
    if (CC_abstract(stack_get(DAGs, i - 1)) == CC_abstract(stack_get(DAGs, i)))
      {
        stack_push(veriT_conflict_eqs, stack_get(DAGs, i - 1));
        stack_push(veriT_conflict_eqs, stack_get(DAGs, i));
      }
#endif
}

#else
void
NLA_conflict(void)
{
  /*printf("\tCONFLICT\n");*/
  Tlit lit;
  unsigned i;
  assert(NLA_status == UNSAT);
  for (i = 0; i < stack_size(input_literals); ++i)
    {
      lit = stack_get(input_literals, i);
      // printf("%d,", lit);
      if (!lit)
        continue;
      stack_push(veriT_conflict, lit);
    }
}
#endif

/*--------------------------------------------------------------*/

#ifdef PROOF
Tproof
NLA_conflict_proof(void)
{
  Tstack_DAG lits;
  unsigned i;
  Tproof proof;
  assert(NLA_status == UNSAT);
  if (option_nla_reduce_only)
    {
      if (NLA_status == UNSAT)
        unsat_core_ids = get_redlog_unsat_core_ids();
      else
        for (i=0; i < stack_size(to_redlog); i++)
          stack_push(unsat_core_ids, i);
    }
  else
    raSAT_conflict();

  stack_INIT(lits);
#ifdef UNSAT_CORE
  for (i = 0; i < stack_size(unsat_core_ids); ++i)
    {
      Tlit lit = stack_get(input_literals, stack_get(unsat_core_ids, i));
#else
      for (i = 0; i < stack_size(input_literals); ++i)
        {
          Tlit lit = stack_get(input_literals, i);
#endif

          TDAG DAG = lit_to_DAG(lit);
          if (!lit)
            continue;
          stack_push(veriT_conflict, lit);
          stack_push(lits, DAG_dup(lit_pol(lit)?DAG_not(DAG):DAG));
        }
      proof = proof_step_valid_stack(ps_type_nla_generic, lits);
      stack_apply(lits, DAG_free);
      stack_free(lits);
      return proof;
    }
#endif

  /*--------------------------------------------------------------*/

  bool
    NLA_has_lemma(void)
  {
    return false;
  }

  /*--------------------------------------------------------------*/

  TSstack(_stack_DAG, Tstack_DAG);

#define eat_spaces() do { while (solver_output[i] && solver_output[i] == ' ') i++; } while (0)
#define jump_end_id() do { while (solver_output[i] && solver_output[i] != ' ' && solver_output[i] != ')') i++; } while (0)


  /*--------------------------------------------------------------*/

  bool
    NLA_model_eq(void)
  {
    // return false;
    unsigned i, j = 0;
    Tstack_stack_DAG partition;
    unsigned counter = 0;
    assert(NLA_status != UNSAT);
    assert(NLA_status != UNDEF);
    // if (NLA_status == UNDEF)
    //   return false;
    // if (!redlog_initialized) return false;
    // printf("Getting model eq \n");
    stack_INIT(partition);
    if (option_nla_reduce_only) {
        redlog_command("(set-option :model-values \"hidden\")");
        redlog_command("(get-model)");
        solver_output = get_redlog_result();
    } else
        solver_output = raSAT_get_model_eq();

    //printf("Got output: %s\n", solver_output);
    for (i = 0; solver_output[i]; i++)
      if (solver_output[i] == '\n')
        solver_output[i] = ' ';
    if (solver_output[0])
      for (i = 1, j = 0; solver_output[i]; i++)
        if (solver_output[i] != ' ' || solver_output[j] != ' ')
          solver_output[++j] = solver_output[i];
    solver_output[++j] = 0;
    i = 0;
    assert(solver_output[i] == '(');
    i++;
    while (solver_output[i])
      {
        Tstack_DAG DAG_set;
        eat_spaces();
        if (solver_output[i] == ')')
          break;
        assert(solver_output[i] == '('); /* start of new variable cluster */
        i++;
        eat_spaces();
        assert(solver_output[i] == '('); /* start new variable list */
        i++;
        eat_spaces();
        stack_INIT(DAG_set);
        while (solver_output[i] != ')') /* end of variable list */
          {
            if (!strncmp(solver_output + i, "v", 9))
              {
                TDAG DAG = 0;
                i += 9;
                while (solver_output[i] >= '0' && solver_output[i] <= '9')
                  {
                    DAG *= 10;
                    DAG += solver_output[i++] - '0';
                  }
                stack_push(DAG_set, DAG);
              }
            else
              jump_end_id();
            eat_spaces();
          }
        i++;
        eat_spaces();
        /* eat expression */
        while (solver_output[i] && (solver_output[i] != ')' || counter))
          {
            if (solver_output[i] == '(') counter++;
            else if (solver_output[i] == ')')
              counter--;
            i++;
          }
        assert(solver_output[i] == ')'); /* end of variable cluster */
        i++;
        if (stack_size(DAG_set) >= 2)
          stack_push(partition, DAG_set);
        else
          stack_free(DAG_set);
      }
    for (i = 0; i < stack_size(partition); i++)
      {
        Tstack_DAG DAG_set = stack_get(partition, i);
        TDAG DAGi = stack_get(DAG_set, 0);
        for (j = 1; j < stack_size(DAG_set); j++)
          {
            TDAG DAGj = stack_get(DAG_set, j);
            veriT_xenqueue_type(XTYPE_NLA_MODEL_EQ);
            veriT_xenqueue_DAG(DAGi);
            veriT_xenqueue_DAG(DAGj);
          }
      }
    for (i = 0; i < stack_size(partition); i++)
      stack_free(stack_get(partition, i));
    stack_free(partition);
    return stack_size(xqueue) != 0;
  }

  /*--------------------------------------------------------------*/

  /*
    load_package smtsupp;
    on smtsplain;
    smts_mainloop();
    3: (jkdahsdjkash)
    error
    3: (set-logic QF_NRA)
    3: (assert (not (= x X)))
    3: (print-assertions)
    (not (= x X))
    3: (get-model)
    error
    (((x) x) ((X) X))
    3: (check-sat)
    sat
    3: (get-model)
    (((x) infinity1) ((X) X))
    3: (assert (= 1 0))
    3: (get-model)
    error
    (((x) x) ((X) X))
    3: (check-sat)
    unsat
    3: (get-model)
    error
    (((x) x) ((X) X))
    3: (reset)
    3: (assert (and (= x y) (not (= y z))))
    3: (check-sat)
    sat
    3: (get-model)
    (((z) infinity1) ((y x) x))
    3: (exit)

    4: quit;

    Quitting

  */
