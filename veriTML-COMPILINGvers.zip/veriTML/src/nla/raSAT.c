#include <stdio.h>
#include <string.h>
#include "raSAT.h"

#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/mlvalues.h>
#include <caml/callback.h>
#include <caml/fail.h>

void  catch_ocaml_exception (value* exception) {
	if (Is_exception_result(* exception)) {
		// printf("%s\n", String_val(caml_format_exception (Extract_exception(*exception)))); 
		redlog_exit();
		exit(EXIT_FAILURE);
	}
}

void raSAT_reset() { 
	CAMLparam0();
	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL)
		caml_gen_closure = caml_named_value("raSAT_reset");

	CAMLlocal1(result);
	result = caml_callback_exn(*caml_gen_closure, Val_int(0));
	
	catch_ocaml_exception (&result);

	CAMLreturn0;
}

void raSAT_print_unsat_cores(){ 
	CAMLparam0();
	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL)
		caml_gen_closure = caml_named_value("raSAT_print_unsat_cores");
	CAMLlocal1(result);
	result = caml_callback_exn(*caml_gen_closure, Val_int(0));
	catch_ocaml_exception (&result);

	CAMLreturn0;
}

void raSAT_init(char** argv){
	caml_startup(argv);
}

char* raSAT_solve(){
	CAMLparam0();
	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL)
		caml_gen_closure = caml_named_value("raSAT_solve");
	
	CAMLlocal1(result);
	result = caml_callback_exn(*caml_gen_closure, Val_int(0));
	catch_ocaml_exception (&result);

	CAMLreturnT(char*, strdup(String_val(result)));
	/* We copy the C string returned by String_val to the C heap
	 so that it remains valid after garbage collection. */
}

void raSAT_set_logic(char* logic){
	CAMLparam0();
	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL)
		caml_gen_closure = caml_named_value("raSAT_set_logic");

	CAMLlocal1(result);
	result = caml_callback_exn(*caml_gen_closure, caml_copy_string(logic));
	catch_ocaml_exception (&result);

	CAMLreturn0;
}

char* raSAT_assert(char* assert, int id){
	// printf("raSAT assert: %s, %d\n", assert, pol);
	CAMLparam0();
	CAMLlocalN(ml_args, 2);
	//printf("0\n");
	ml_args[0] = caml_copy_string(assert);
	//printf("1\n");
	ml_args[1] = Val_int(id);

	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL) {
	  //printf("5\n");
		caml_gen_closure = caml_named_value("raSAT_assert");
	}

	// polyConstraints = caml_callbackN(*caml_gen_closure, 3, ml_args);

	CAMLlocal1(result);
	result = caml_callbackN_exn(*caml_gen_closure, 2, ml_args);
	catch_ocaml_exception (&result);		

	CAMLreturnT(char*, strdup(String_val(result)));
	/* We copy the C string returned by String_val to the C heap
	 so that it remains valid after garbage collection. */
}

char* raSAT_get_unsat_core(){
	CAMLparam0();
	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL)
		caml_gen_closure = caml_named_value("raSAT_get_unsat_core");
	
	CAMLlocal1(result);
	result = caml_callback_exn(*caml_gen_closure, Val_int(0));
	catch_ocaml_exception (&result);

	CAMLreturnT(char*, strdup(String_val(result)));
}

char* raSAT_get_model_eq() {
	CAMLparam0();
	static value * caml_gen_closure = NULL;
	if (caml_gen_closure == NULL)
		caml_gen_closure = caml_named_value("raSAT_get_model_eq");
	
	CAMLlocal1(result);
	result = caml_callback_exn(*caml_gen_closure, Val_int(0));
	catch_ocaml_exception (&result);

	CAMLreturnT(char*, strdup(String_val(result)));
}