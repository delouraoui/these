#include <stdio.h>
#include "bool.h"

#include "reduce.h"

#include "nla_redlog.h"

char * reduce_path = NULL;

static RedProc redlog_process;


#define UNSAT_CORE


#ifdef UNSAT_CORE 
static Tstack_lit unsat_core_ids;
#endif

/*--------------------------------------------------------------*/

#ifdef DEBUG
/**
   \addtogroup arguments_developer

   - --redlog-log

   Generates files in redlog format with the formula given to it
   during nla reasoning. Useful to debug nla (only available
   when compiled with DEBUG defined). */
bool redlog_log = false;

/**
   \addtogroup arguments_developer

   - --redlog-smt2-log

   Generates files in SMT2 format with the formula given to redlog
   Useful to debug nla (only available
   when compiled with DEBUG defined). */
bool redlog_smt2_log = false;

static FILE *f_red = NULL;
static FILE *f_smt2 = NULL;
TSstack(_str, char *);
static Tstack_str DAGs_already_defined = NULL;
#endif



static char * redlog_output = NULL;
static unsigned redlog_buffer_size = 0;

void redlog_check(void)
{
  FILE * file;
  if (reduce_path && (file = fopen(reduce_path, "r")))
    {
      fclose(file);
      return;
    }
  my_error("No reduce executable found\n"
     "Please export in VERIT_REDUCE_PATH the full path to redpsl\n");
}


void
redlog_init(void)
{
  redlog_process = RedProc_new(reduce_path);
  #ifdef UNSAT_CORE
  stack_INIT(unsat_core_ids);
  #endif
}


void
redlog_done(void)
{
  if (redlog_output){
    free(redlog_output);
    redlog_output = NULL;
  }
  RedProc_delete(redlog_process);
}

/*--------------------------------------------------------------*/

void
redlog_command(char * command)
{
  // printf("%s\n", command);
  RedAns output = RedAns_new(redlog_process, command);
#ifdef DEBUG
  if (redlog_log && f_red)
    fprintf(f_red, "%s\n", command);
  if (redlog_smt2_log && f_smt2)
    fprintf(f_smt2, "%s\n", command);
#endif
#ifdef DEBUG_NLA
  my_message("Command: %s\n", command);
#endif
  if (redlog_output){
    free(redlog_output);
    redlog_output = NULL;
  }
  if (output->error)
    {
      // RedProc_error(redlog_process, command, output);
      // printf("Error and Output: %s\n", strmake(output->result));
      redlog_output = strmake("unknown");
      return;
      // RedProc_delete(redlog_process);
      // exit(-1);
    }
  // if (output->result != NULL)
    // printf("Output: %s\n", strmake(output->result));
  redlog_output = strmake(output->result);
  // printf("redlog_output: %s\n", redlog_output);

#ifdef DEBUG_NLA
  printf("Output: %s\n", output->result);
#endif
  RedAns_delete(output);
  
}



void
redlog_exit(void)
{
  // if (!redlog_buffer_size)
  //   return;
  RedProc_delete(redlog_process);
}

char* get_redlog_result(){
  if (redlog_output) {
    return strmake(redlog_output);
  }
  return NULL;
}

Tstack_lit get_redlog_unsat_core_ids() {
  redlog_command("(get-unsat-core)");
#ifdef UNSAT_CORE  
  if (redlog_output != NULL)
    {
      char *token, *state;
      char *es, *ee;
      int ind_start, ind_end;
      char *st = redlog_output;
      unsigned len;

#ifdef DEBUG_NLA
      my_message("Unsat core: %s\n", st);
#endif
      
      stack_reset(unsat_core_ids);
      
      es = strchr(st, '(')+1;
      ee = strchr(st, ')');
      ind_start = (int)(es - st);
      ind_end = (int)(ee - st);
        
      len = ind_end - ind_start;
      char core_ids[len+1]; 
      strncpy(core_ids, st + ind_start, len);
      core_ids[len] = '\0';

      /*printf("\n--------------------------\n");*/
      
      for (token = strtok_r(core_ids, " \n", &state);
           token != NULL; token = strtok_r(NULL, " \n", &state))
        {
          int idRed = atoi(strmake(token)); 
          // printf("idRedlog [%d] ok [%d]\n", idRed, idRed); 
          stack_push(unsat_core_ids, idRed);      
        }
      /*printf("TOKEN [%s]\n", strmake(token));
  exit(0);*/      
    }
#endif

  return unsat_core_ids;
}

int get_redlog_unsat_cores_ids_length() {
  return stack_size(unsat_core_ids); 
}

int get_redlog_unsat_cores_id(int index){
  return stack_get(unsat_core_ids, index);
}