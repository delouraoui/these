#ifndef REDLOG_CAML_H
#define REDLOG_CAML_H

/*
	Iterfaces for ICP in Ocaml to access Redlog facilities.
*/


#include <caml/alloc.h>
#include <caml/memory.h>
#include <caml/mlvalues.h>
#include <caml/callback.h>
#include <caml/fail.h>

#include "nla_redlog.h"
#include "nla.h"

/*
	ICP asks Redlog to init its environment
*/
void caml_init_redlog();


/*
	ICP passes a SMT2 command to Redlog
*/
value caml_redlog_command(value command);


/*
	ICP gets the result of (check-sat) command from Redlog
*/
value caml_get_redlog_result(value unit);


/*
	ICP gets the output of the previous command from Redlog
*/
value caml_get_redlog_output(value unit);


/*
	ICP gets unsat core ids from Redlogs
	Return an Ocaml list of unsate core ids
*/
value calm_get_redlog_unsat_core_ids(value unit);


#endif