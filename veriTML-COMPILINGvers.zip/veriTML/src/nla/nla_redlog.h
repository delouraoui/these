#ifndef NLA_REDLOG_H
#define NLA_REDLOG_H

/*
	SMT2-specific Interfaces of Redlog
*/

#include "literal.h"


/*
	Init Redlog
*/
void redlog_init();


/*
	Check executables of Redlog
*/
void redlog_check();


/*
	Finish Redlog, clean resources
*/
void redlog_done();


/*
	Pass an SMT2 command to Redlog
*/
void redlog_command(char * command);


/*
	Exit Redlog
*/
void redlog_exit();


/*
	Get the result of the previous command passed to Redlog
*/
char* get_redlog_result();


/*
	Get the length of unsat core ids
*/
int get_redlog_unsat_cores_ids_length();

/*
	Get id of unsat core at a given index
*/
int get_redlog_unsat_cores_id(int index);


/*
	Get the unsat core ids as a stack
*/
Tstack_lit get_redlog_unsat_core_ids();

#endif