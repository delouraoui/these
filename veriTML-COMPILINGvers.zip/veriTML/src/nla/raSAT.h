#ifndef raSAT_H
#define raSAT_H

/*
	Interactions with Ocaml side
	ICP is implemented in Ocaml
*/

/*
	Init ocaml environment for interacting with C
*/
void raSAT_init(char** argv);


/*
	Tell ICP which logics being considered
	Supported logics: QF_NRA, and QF_NIA
*/
void raSAT_set_logic(char* logic);


/*
	Pass an assert statement to ICP
	Arguments:
		. assert: the string describling a atomic polynomial constraint
		. id 	: the id of the assert statement, used in unsat core.
				  id here is the order of asserts being passed to ICP
*/
char* raSAT_assert(char* assert, int id);

/*
	Solve the conjunction of assertions passed to ICP
*/
char* raSAT_solve();


/*
	Reset all the searching states
*/
void raSAT_reset();


/*
	Get unsat core from ICP
*/
char* raSAT_get_unsat_core();

/*
	Print unsat cores for debugging
*/
void raSAT_print_unsat_cores();


/*
	Providing equalities between variables in the case of SAT
	Output example: ((x 0.1) ((y z) 2.5))
*/
char* raSAT_get_model_eq();


#endif