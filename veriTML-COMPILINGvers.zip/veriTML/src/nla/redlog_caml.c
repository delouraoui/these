#include "redlog_caml.h"

// implementation of interfaces to ocaml
value caml_redlog_command(value command){
	CAMLparam1 (command);
	redlog_command (String_val(command));
	CAMLreturn (Val_unit);
}

value caml_get_redlog_result(value unit){
	CAMLparam1 (unit);
	char* result = get_redlog_result();

	if (!strcmp(result, "sat"))
		CAMLreturn (Val_int (1));
	if (!strcmp(result, "unsat")) {
		get_redlog_unsat_core_ids();
    	CAMLreturn (Val_int (-1));
	}
	if (!strcmp(result, "unknown")) 
		CAMLreturn (Val_int (0));

	my_error("NLA_solve: unexpected result %s\n");
	CAMLreturn (Val_int (0));	
}

value caml_get_redlog_output(value unit){
	CAMLparam1 (unit);
	CAMLreturn(caml_copy_string(get_redlog_result()));
}

CAMLprim value calm_get_redlog_unsat_core_ids(value unit) {
	CAMLparam1 (unit);
	
	CAMLlocal2( cli, cons );

	cli = Val_emptylist;

	for (int i = 0; i < get_redlog_unsat_cores_ids_length(); ++i) {
		cons = caml_alloc(2, 0);
		Store_field( cons, 0, Val_int(get_redlog_unsat_cores_id(i)) );  // head
        Store_field( cons, 1, cli );              // tail
        cli = cons;
	}

	CAMLreturn (cli);
}

void caml_init_redlog(){
	CAMLparam0 ();
	init_redlog();
	CAMLreturn0;
}