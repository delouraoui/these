open IA
open Variable
open Interval

module Util = struct

  (*CI to AF1 conversion, id <=size*)
   let toAf1 (it: IA.interval) (id:int) (size: int) = 
     let a = (it#l +.it#h)*.0.5 in
     let b = (it#h -.it#l)*.0.5 in
     let result = new IA.af1 size in
     result#set_a a;
     result#set_k 0.0;
     let ar1 = Array.create size 0.0 in
     if id > 0 then
	 Array.set ar1 (id-1) b;
     result#set_ar ar1;
     result

   (*CI to AF2 conversion, id <=size*)
   let toAf2 (intv: Interval.interval) (id:int) (size: int) = 
      (* if intv.low = neg_infinity || intv.high = infinity then raise (Failure "AA2 does not support infinity")
      else *) 
      let result = new IA.af2 size in
      result#set_kp 0.0;
      result#set_kn 0.0;
      result#set_k 0.0;

      let a = 
        if id = 0 then 
          intv
        else
          {low=intv.low;high=intv.low} /$. 2. +$ {low=intv.high;high=intv.high} /$. 2. 
      in
      result#set_a a;

      let ar1 = Array.create size {low=0.;high=0.} in
      if id > 0 then begin
        let b = 
          {low=intv.high;high=intv.high} /$. 2. -$ {low=intv.low;high=intv.low} /$. 2. 
        in
        Array.set ar1 (id-1) b;  
      end;
        
      result#set_ar ar1;
      result
     
     (*CI to AF2 conversion, id <=size*)
   (*let toAf2 (it: IA.interval) (id:int) (size: int) = 
     let a = (it#l +.it#h)*.0.5 in
     let b = (it#h -.it#l)*.0.5 in
     let result = new IA.af2 size in
     result#set_a a;
     result#set_kp 0.0;
     result#set_kn 0.0;
     result#set_k 0.0;
     let ar1 = Array.create size 0.0 in
     if id > 0 then
       Array.set ar1 (id-1) b;
     result#set_ar ar1;
     result*)
   
   (*CI to CAF conversion, id <=size*)
   let toCaf2 (it: IA.interval) (id:int) (size: int) = 
     let a = new IA.interval it#l ((it#l+.it#h)*.0.5) in
     let b = new IA.interval 0. ((it#h -.it#l)*.0.5) in
     let result = new IA.caf2 size in
     result#set_a a;
     result#set_k (new IA.interval 0.0 0.0);
     let ar1 = Array.create size (new IA.interval 0. 0.) in
     if id > 0 then
       Array.set ar1 (id-1) b;
     result#set_ar ar1;
     result

   (*CI to CAI1 conversion, id <=size*)
   let toCai1 (it: IA.interval) (id:int) (size: int) = 
     let a = new IA.interval ((it#l+.it#h)*.0.5) ((it#l+.it#h)*.0.5) in
     let b = new IA.interval ((it#h-.it#l)*.0.5) ((it#h-.it#l)*.0.5) in
     let result = new IA.cai1 size in
     result#set_a a;
     let zero = new IA.interval 0.0 0.0 in
     result#set_k zero;
     let ar1 = Array.create (2*size) zero in
     if id > 0 then
       Array.set ar1 (id-1) b;
     result#set_ar ar1;
     result

   (*CI to CAI2 conversion, id <=size*)
   let toCai2 (it: IA.interval) (id:int) (size: int) = 
     let a = new IA.interval ((it#l+.it#h)*.0.5) ((it#l+.it#h)*.0.5) in
     let b = new IA.interval ((it#h-.it#l)*.0.5) ((it#h-.it#l)*.0.5) in
     let result = new IA.cai2 size in
     result#set_a a;
     let zero = new IA.interval 0.0 0.0 in
     result#set_k zero;
     let ar1 = Array.create (2*size) zero in
     if id > 0 then
       Array.set ar1 (id-1) b;
     result#set_ar ar1;

     let ma1 = (Array.make_matrix size size (new IA.interval 0.0 0.0)) in
     result#set_m1 ma1;

     let ma2 = (Array.make_matrix size size (new IA.interval 0.0 0.0)) in
     result#set_m2 ma2;

     let ma3 = (Array.make_matrix size size (new IA.interval 0.0 0.0)) in
     result#set_m3 ma3;     
     result  

   (*CI to CAI3 conversion, id <=size*)
   let toCai3 (it: IA.interval) (id:int) (size: int) = 
     let a = new IA.interval ((it#l+.it#h)*.0.5) ((it#l+.it#h)*.0.5) in
     let b = new IA.interval ((it#h-.it#l)*.0.5) ((it#h-.it#l)*.0.5) in
     let result = new IA.cai3 size in
     result#set_a a;
     let zero = new IA.interval 0.0 0.0 in
     result#set_k zero;
     let ar1 = Array.create (2*size) zero in
     if id > 0 then
       Array.set ar1 (id-1) b;
     result#set_ar ar1;

     let ma = (Array.make_matrix size size (new IA.interval 0.0 0.0)) in
     result#set_m ma;

     result  

	(*Reduce list to set*)
	let rec set_list l1 l2 = 
		match l2 with
		|[] -> l1
		|h::t -> 
			if (List.mem h l1) then 
			  set_list l1 t
			else
			  set_list (h::l1) t

		let red_list l = set_list [] l
		
	(* =============== START has_common_element ======================= *)	
	(* This function return true if two lists have some common elements*)
  let rec has_common_element list1 list2 = 
    match list1 with 
    | [] -> false 
    | h::t -> (List.mem h list2) || (has_common_element t list2)		
	(* ============== END has_common_element ========================== *)	  
	
	
	(* Function for converting a list of variables to be learned into minisat codes*)
	let rec learn_vars varsList intvMap polyConsMiniSATCode = match varsList with
	  | [] ->
	    if polyConsMiniSATCode > 0 then "-" ^ string_of_int polyConsMiniSATCode ^ " "
	    else string_of_int (-polyConsMiniSATCode) ^ " "
    | h::t -> 
      let (_, varId) = StringMap.find h intvMap in
      "-" ^ string_of_int varId ^ " " ^ (learn_vars  t intvMap polyConsMiniSATCode)
      
      
  (* This function convert the list of unsat cores into minisat learnt clauses.*)
  let rec learn_vars_cores varsCores intvMap polyConsMiniSATCode = match varsCores with
    | [] -> ""
    | varsList :: [] -> learn_vars varsList intvMap polyConsMiniSATCode
    | varsList :: remainingVarsCores -> (
      let learntVars = learn_vars varsList intvMap polyConsMiniSATCode in
      learntVars ^ "0 " ^ learn_vars_cores remainingVarsCores intvMap polyConsMiniSATCode
    )
    
      
  (* Function for converting a list of vars to a string *)
  let rec vars_to_string varsList = match varsList with
    | [] -> ""
    | var::remainingVars -> var ^ " " ^ vars_to_string remainingVars

  (* function for getting interval from the map *)
  let get_var_intv var varsIntvsMap = 
    try
      StringMap.find var varsIntvsMap 
    with Not_found -> 
      {low=neg_infinity;high=infinity}
      (* {low=(-8.);high=8.} *)
  

  let add_unsat_core polyCons unsat_core = 
    (* if not (IntSet.mem polyCons#get_miniSATCode unsat_core) then
              print_endline ("(assert " ^ polyCons#to_string_prefix ^ ")");
              flush stdout; *)
    IntSet.add (polyCons#get_miniSATCode) unsat_core


  let float_to_string f = 
    let abs_string = (Printf.sprintf "%.324f" (abs_float f)) in 
   
    (* remove ending zeros *)
    let abs_string = Str.replace_first (Str.regexp "0+$") "" abs_string in

    (* remove ending . *)
    let abs_string = Str.replace_first (Str.regexp "\\.+$") "" abs_string in

    if f < 0. then
      Printf.sprintf "(- %s)" abs_string
    else
      abs_string

  (* =================================== START log_intervals =========================================== *)
  let string_of_intv intv = 
    let lower_string = float_to_string intv.low in 
    let upper_string = float_to_string intv.high in     
    Printf.sprintf "[%s, %s]" lower_string upper_string
    
  (* This functions converts the list of intervals of variables into the string format*)
  let rec log_intervals varsIntvsMap =
    let add_string_of_newInterval var intv oldString =
      let intv_string = string_of_intv intv in
      Printf.sprintf "%s in %s\n%s" var intv_string oldString
    in 
    StringMap.fold add_string_of_newInterval varsIntvsMap ""
  (* =================================== END log_intervals ============================================== *)

  let num_of_float c = 
    let c_string = float_to_string c in

    let c_string = Str.global_replace (Str.regexp "[()]") "" c_string in

    (* print_endline c_string;
    flush stdout; *)

    try
      let dot_index = String.index c_string '.' in

      let rec gen_denum current_denum = function 
        | 0 -> current_denum
        | remaining_0s -> 
          assert (remaining_0s > 0);
          gen_denum (current_denum ^ "0") (remaining_0s - 1)
      in

      let denum_string = 
        gen_denum "1" (String.length c_string - dot_index - 1) 
      in 

      let denum_value = Num.num_of_string denum_string in

      let enum_string = 
        Str.replace_first (Str.regexp "\\.") "" c_string 
      in

      (* print_endline enum_string;
      flush stdout; *)

      let enum_value = Num.num_of_string enum_string in

      (* Printf.printf "%s / %s\n" enum_string denum_string; *)
      (* Printf.printf "%s\n" (Num.string_of_num (Num.div_num enum_value denum_value)); *)
      
      Num.div_num enum_value denum_value
    with 
      | _ -> Num.num_of_string c_string

  (* let num_to_string_prefix num = 
    let abs_num = Num.abs_num num in
    let infix_abs_string = Num.string_of_num abs_num in 

    let regex = Str.regexp "/" in

    let add_sign num_string = 
      if Num.sign_num num = -1 then 
        Printf.sprintf "(- %s)" num_string
      else 
        num_string
    in

    match Str.split regex infix_abs_string with
    | [h] -> add_sign infix_abs_string
    | h::[t] -> add_sign (Printf.sprintf "(/ %s %s)" h t)
    | _ -> failwith "Wrong implementation of ocaml Num" *)

  let string_prefix_of_abs_num = function 
  | Num.Int i -> string_of_int i
  | Num.Big_int bi -> Big_int.string_of_big_int bi
  | Num.Ratio r -> 
    let numerator_string = Big_int.string_of_big_int (Ratio.numerator_ratio r) in
    let denominator_string = Big_int.string_of_big_int (Ratio.denominator_ratio r) in
    Printf.sprintf "/ %s %s" numerator_string denominator_string 

  let string_prefix_of_num num = 
    let abs_num = Num.abs_num num in
    let abs_string_prefix = string_prefix_of_abs_num abs_num in 
    match Num.sign_num num with
    | -1 -> Printf.sprintf "(- %s)" abs_string_prefix
    | _ -> abs_string_prefix

  let intv_of_big_int bi = 
    let n = Big_int.num_bits_big_int bi in
    if n <= 53 then 
      let bi_float = Big_int.float_of_big_int bi in
      let result = {low=bi_float;high=bi_float} in
      
      (* Printf.printf "Result of %s is %s\n" (Big_int.string_of_big_int bi) 
          (sprintf_I "%.0f" result);
      flush stdout; *)

      result
    else begin
      let n = n - 53 in
      (* Extract top 53 bits of x *)
      let top = Big_int.shift_right_big_int bi n in

      let top_float = Big_int.float_of_big_int top in
      let two_I = {low=2.;high=2.} in
      let two_I_to_n = pow_I_i two_I n in

      (* intv of mantissa *)
      let mantissa_intv = {low=top_float; high=top_float +. 1.} in
      
      (* compute final interval *)
      let result = mantissa_intv *$ two_I_to_n in 

      (* Printf.printf "Result of %s is %s\n" (Big_int.string_of_big_int bi) 
          (sprintf_I "%.0f" result);
      flush stdout; *)

      result
    end

  let intv_of_num = function
  | Num.Int i -> float_i i
  | Num.Big_int bi -> intv_of_big_int bi
  | Num.Ratio r -> 
    let numerator_intv = intv_of_big_int (Ratio.numerator_ratio r) in
    let denominator_intv = intv_of_big_int (Ratio.denominator_ratio r) in
    numerator_intv /$ denominator_intv
end
