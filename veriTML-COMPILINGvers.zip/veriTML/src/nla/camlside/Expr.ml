open Ast
open Multiset
open Interval
open Util
open Variable
open Num

module MultiVar = struct 
    (* multisets naively implemented as sorted lists  *)
    type t = string 
    let compare = Pervasives.compare 
    let to_string s = s
end 

module MultiVarSet = Multiset.Make(MultiVar)
module Poly = Map.Make(MultiVarSet) 

type poly = 
  | Monomials of poly_expr Poly.t * int
  | MonoAdd of poly * poly * int
  | MonoSub of poly * poly * int
  | MonoMul of poly * poly * int
  | MonoDiv of poly * poly  * int

let get_type = function
  | Monomials(_, polType) -> polType
  | MonoAdd (_, _, polType) -> polType
  | MonoSub (_, _, polType) -> polType
  | MonoMul (_, _, polType) -> polType
  | MonoDiv (_, _, polType) -> polType

let print_monomials p =
  let print_monomial vars coefficient =
    MultiVarSet.print_tree print_string vars;
    print_string (": " ^ string_of_float coefficient);
    print_endline "";
    flush stdout;
  in
  Poly.iter print_monomial p

let get_var_type var variables =
  try
    StringMap.find var variables 
  with Not_found -> realType


(* evaluate expressions into values *) 
let rec eval = function 
  | Cons (c, _, polType, _, _, _) as poly_cons -> 
    Monomials (Poly.singleton MultiVarSet.empty poly_cons, polType)
  | Var (v, polType, _, _, _)  -> 
    let poly_cons_one = Cons (one_num, false, polType, one_I, new IA.af2 0, false) in
    Monomials (Poly.singleton (MultiVarSet.add v MultiVarSet.empty)  poly_cons_one, 
                polType)
  | Add(e1, e2, polType, _, _) -> 
    let newE1 = eval e1 in
    let newE2 = eval e2 in
    let polType1 = get_type newE1 in
    let polType2 = get_type newE2 in
    if polType1 != polType2 then
      raise (Failure "Wrong types of expressions")
    else
      (
      match (newE1, newE2) with
        | (Monomials (m1, _), Monomials (m2, _)) -> 
          Monomials ((plus m1 m2), polType1)
        | _ -> MonoAdd (newE1, newE2, polType1)
      )
  | Sub(e1, e2, polType, _, _) -> 
    let newE1 = eval e1 in
    let newE2 = eval e2 in
    let polType1 = get_type newE1 in
    let polType2 = get_type newE2 in
    if polType1 != polType2 then
      raise (Failure "Wrong types of expressions")
    else
      (
      match (newE1, newE2) with
        | (Monomials (m1, _), Monomials (m2, _)) -> Monomials ((minus m1 m2), polType1)
        | _ -> MonoSub (newE1, newE2, polType1)
      )
  | Mul(e1, e2, polType, _, _) -> 
    let newE1 = eval e1 in
    let newE2 = eval e2 in
    let polType1 = get_type newE1 in
    let polType2 = get_type newE2 in
    if polType1 != polType2 then
      raise (Failure "Wrong types of expressions")
    else
      (
      match (newE1, newE2) with
        | (Monomials (m1, _), Monomials (m2, _)) -> Monomials ((times m1 m2), polType1)
        | _ -> MonoMul (newE1, newE2, polType1)
      )
  | Div(e1, e2, polType, _, _) -> 
    let newE1 = eval e1 in
    let newE2 = eval e2 in
    let polType1 = get_type newE1 in
    let polType2 = get_type newE2 in
    if polType1 != polType2 then
      raise (Failure "Wrong types of expressions")
    else
      (
      match (newE1, newE2) with
        | (Monomials (m1, _), Monomials (m2, _)) -> 
          if Poly.cardinal m2 = 1 && Poly.mem MultiVarSet.empty m2 then 
            let dividing_poly_expr = Poly.find MultiVarSet.empty m2 in
            Monomials ((div m1 dividing_poly_expr), polType1)
          else 
            MonoDiv (newE1, newE2, polType1)
        | _ -> MonoDiv (newE1, newE2, polType1)
      )
  | Pow(var, multiplicity, polType, varIntv, af2Changed, oldIntv, oldAf2Form) ->
    eval (pow_to_mul (Pow(var, multiplicity, polType, varIntv, af2Changed, oldIntv, oldAf2Form)))
  | _ -> raise (Failure "Unsupported SMT2 function symbols")

(* BatOption.default *) 
and default d = function 
  | None -> d 
  | Some x -> x 

and plus p1 p2 =
  let add_opt _vars c1 c2 = match c1, c2 with
    | None, _ -> c2
    | _, None -> c1
    | Some c1_value, Some c2_value -> 
      let polType = get_type_polyExpr c1_value in
      Some (Add (c1_value, c2_value, polType, inf_I, af2_zero))
    (* MultiVarSet.print_tree print_string _vars;
    print_endline "";
    flush stdout; *)
    (* Some (default 0. c1 +. default 0. c2)  *)
  in
  (* print_endline "\n\nAdding ";
  print_monomials p1;
  print_endline "\nwith ";
  print_monomials p2;
  print_endline "\nResult ";
  print_monomials (Poly.merge add_opt p1 p2 ); *)
  Poly.merge add_opt p1 p2 

and minus p1 p2 =
  let minus_opt _vars c1 c2 = match c1, c2 with
    | None, Some c2_value -> 
      let polType = get_type_polyExpr c2_value in
      let minus_one_cons = 
        Cons(minus_one_num, false, polType, gen_I_cons (-. 1.), af2_zero, false) 
      in
      Some (Mul (minus_one_cons, c2_value, polType, inf_I, af2_zero))
    | _, None -> c1
    | Some c1_value, Some c2_value -> 
      let polType = get_type_polyExpr c1_value in
      Some (Sub (c1_value, c2_value, polType, inf_I, af2_zero))
  in
  Poly.merge minus_opt p1 p2 

and times p1 p2 = (* naive implementation *)  
  let p2_times_monome vars coeff acc = 
    let add_monome v c acc = 
      let polType = get_type_polyExpr c in
      let new_poly_cons_coeff = Mul (c, coeff, polType, inf_I, af2_zero) in
      let monome = Poly.singleton (MultiVarSet.add_sets v vars) new_poly_cons_coeff in 
      (* print_endline "Multiplying";
      MultiVarSet.print_tree print_string v;
      print_endline "";
      MultiVarSet.print_tree print_string vars;
      print_endline "";
      print_endline "Result:";
      MultiVarSet.print_tree print_string (MultiVarSet.add_sets v vars);
      print_endline "";
      flush stdout; *)
      plus monome acc 
    in 
    Poly.fold add_monome p2 acc in 
  Poly.fold p2_times_monome p1 Poly.empty 

and div p dividing_poly_expr = 
  let polType = get_type_polyExpr dividing_poly_expr in
  let mono_divide vars coeff current_poly = 
    Poly.add vars (Div (coeff, dividing_poly_expr, polType, inf_I, af2_zero)) current_poly
  in
  Poly.fold mono_divide p Poly.empty

let show p = Poly.fold (fun vars coeff acc -> (vars, coeff)::acc) p [] 

(* translate values back into expressions *) 
let rec reify variables = function
  | Monomials (p, polType) ->
    let addMonomial vars coefficient currentPolyExpr = 
    let addMonomial_extra () = 
      let createMulExpr currentMulExpr (var, multiplicity) = 
        let tmpVarExpr = 
          let varType = get_var_type var variables in
          if multiplicity = 1 then 
            Var (var, varType, inf_I, af2_zero , false)
          else Pow(var, multiplicity, varType, {low=infinity;high=neg_infinity}, false, {low=neg_infinity;high=infinity}, new IA.af2 0) 
        in
        (match currentMulExpr with
          | Cons (c, _, _, _, _, _) -> 
            begin
              match compare_num c one_num with
              | 0 -> tmpVarExpr
              | _ -> Mul(currentMulExpr, tmpVarExpr, polType, {low=neg_infinity;high=infinity}, new IA.af2 0) 
            end
          | _ -> Mul(currentMulExpr, tmpVarExpr, polType, {low=neg_infinity;high=infinity}, new IA.af2 0) 
        )
      in
      (* MultiVarSet.print_tree print_string vars;
      print_endline "";
      flush stdout; *)
      let newPolyExpr = List.fold_left createMulExpr coefficient 
                                              (MultiVarSet.elements_packed vars) in
      (
      match currentPolyExpr with 
        | Cons (c, _, _, _, _, _) -> 
          begin
            match sign_num c with
            | 0 -> newPolyExpr
            | _ -> Add (currentPolyExpr, newPolyExpr, polType, {low=neg_infinity;high=infinity}, new IA.af2 0)
          end
        | _ -> Add (currentPolyExpr, newPolyExpr, polType, {low=neg_infinity;high=infinity}, new IA.af2 0)
      )
    in
    match coefficient with
    | Cons (c,_,_,_,_, _) -> 
      begin
        match sign_num c with
        | 0 -> currentPolyExpr
        | _ -> addMonomial_extra()
      end
    | _ -> 
      addMonomial_extra()
    in
    Poly.fold addMonomial p 
      (Cons (zero_num, false, polType, {low=0.;high=0.}, new IA.af2 0, false))
  | MonoAdd (poly1, poly2, polType) -> 
    let polyExpr1 = reify variables poly1 in
    let polyExpr2 = reify variables poly2 in
    let polType1 = get_type poly1 in
    let polType2 = get_type poly2 in
    if polType1 != polType2 || polType1 != polType then
      let errorMessage = "Wrong implementation in un-folding polynomials" in
      print_endline errorMessage;
      flush stdout;
      raise (Failure errorMessage)
    else
      Add (polyExpr1, polyExpr2, polType, {low=neg_infinity;high=infinity}, new IA.af2 0)
  | MonoSub (poly1, poly2, polType) -> 
    let polyExpr1 = reify variables poly1 in
    let polyExpr2 = reify variables poly2 in
    let polType1 = get_type poly1 in
    let polType2 = get_type poly2 in
    if polType1 != polType2 || polType1 != polType then
      let errorMessage = "Wrong implementation in un-folding polynomials" in
      print_endline errorMessage;
      flush stdout;
      raise (Failure errorMessage)
    else
      Sub (polyExpr1, polyExpr2, polType, {low=neg_infinity;high=infinity}, new IA.af2 0)
  | MonoMul (poly1, poly2, polType) -> 
    let polyExpr1 = reify variables poly1 in
    let polyExpr2 = reify variables poly2 in
    let polType1 = get_type poly1 in
    let polType2 = get_type poly2 in
    if polType1 != polType2 || polType1 != polType then
      let errorMessage = "Wrong implementation in un-folding polynomials" in
      print_endline errorMessage;
      flush stdout;
      raise (Failure errorMessage)
    else
      Mul (polyExpr1, polyExpr2, polType, {low=neg_infinity;high=infinity}, new IA.af2 0)
  | MonoDiv (poly1, poly2, polType) -> 
    let polyExpr1 = reify variables poly1 in
    let polyExpr2 = reify variables poly2 in
    let polType1 = get_type poly1 in
    let polType2 = get_type poly2 in
    if polType1 != polType2 || polType1 != polType then
      let errorMessage = "Wrong implementation in un-folding polynomials" in
      print_endline errorMessage;
      flush stdout;
      raise (Failure errorMessage)
    else
      Div (polyExpr1, polyExpr2, polType, {low=neg_infinity;high=infinity}, new IA.af2 0)
(*Simplify an expression*)  
let reduce e variables = 
  
  let newE = reify variables (eval e) in 

  let newE = simplify_poly_expr newE in

  (* print_endline ("Simplified " ^ string_infix_of_polyExpr e ^ " to " ^ string_infix_of_polyExpr newE);
  flush stdout; *)
  
  newE
  (* e *)

