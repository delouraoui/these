open Ast
open Decomposer
open Assignments
open EqualitiesHandler
open Testing
open Variable
open PolynomialConstraint
open Interval
open Icp
open Searching_State
open Smtlib2raSAT
open Expr
open Util

(* C interfaces to redlog *)
external redlog_command: string -> unit = "caml_redlog_command"
external init_redlog: unit -> unit = "caml_init_redlog"
external get_redlog_result: unit -> int = "caml_get_redlog_result"
external get_redlog_output: unit -> string = "caml_get_redlog_output"
external get_redlog_unsat_core_ids: unit -> int list = "calm_get_redlog_unsat_core_ids"

(* The logic of the smt problem *)
let logic = ref "" 

(* The list of polynomia constraints whose conjunction is going to be proved *)
let polyConstraints = ref ([]: PolynomialConstraint.polynomialConstraint list)

(* flag to store first iteration of icp *)
let is_icp_first = ref true

(* unknown constraints after first iteration of icp *)
let first_uk = ref ([]: PolynomialConstraint.polynomialConstraint list)

(* contracted box after the first iteration of icp *)
let first_box = ref StringMap.empty

(* unsat_core after the first iteration of icp *)
let first_unsat_core = ref IntSet.empty

let redlog_failed = ref false

(* The priority map, mapping from esl to the map containing intervals of variables *)
(* For example: {0.1 : {x: [1, 2],
            y: [10, 50]
             },
         0.01 : {x: [1, 2],
            y: [10, 50]
             }
        } 

*)
let varsIntvsMapPrioritiesMaps = ref (FloatMap.singleton 0.125 [StringMap.empty])


(* the set containing ids of polynomial constraints that contributes to unsat *)
let unsat_core = ref IntSet.empty

(* the model of equations between variables when sat *)
let model_eq = ref ""


let redlog_check passed_uk passed_box passed_unsat_core change_us_core = 
  (* checking the unknown formulas using redlog *)
  (* let result = 0 in *)
  let pass_to_redlog (passed_polyCons_maps, current_index) polyCons = 
    redlog_command (polyCons#get_smt2);
    (* Printf.printf "Passing: %d\n" current_index;
    flush stdout; *)

    (IntMap.add current_index polyCons passed_polyCons_maps, current_index + 1)
  in

  (* exit 0; *)
  
  (* init redlog *)
  init_redlog();

  redlog_command "(reset)";
  let (passed_polyCons_maps, _) = 
    List.fold_left pass_to_redlog (IntMap.empty, 0) passed_uk
  in 


  (* let get_uk_variables current_uk_variables polyCons = 
    VariablesSet.union current_uk_variables polyCons#get_varsSet
  in
  let uk_variables = 
    List.fold_left get_uk_variables VariablesSet.empty passed_uk
  in *)

  (* passing intervals to redlog *)
  let add_vars_intvs var intv = 
    (* if VariablesSet.mem var uk_variables then ( *)
      if intv.low <> neg_infinity then 
        redlog_command (Printf.sprintf "(assert (>= %s %s) )" var (Util.float_to_string intv.low));
      if intv.high <> infinity then 
        redlog_command (Printf.sprintf "(assert (<= %s %s) )" var (Util.float_to_string intv.high));
    (* ); *)
  in
  StringMap.iter add_vars_intvs passed_box;

  (* redlog_command "(reduce-eval (tr cl_qea))"; *)
  redlog_command "(check-sat)";
  
  (* get the result from redlog *)
  let result = get_redlog_result() in
  (* Printf.printf "Redlog result: %d\n" result;
  flush stdout; *)
  if result = -1 then (

    if change_us_core then 
    begin
    let redlog_unsat_core_ids = get_redlog_unsat_core_ids() in
    
    unsat_core := passed_unsat_core;
    let add_redlog_unsat_core redlog_unsat_core_id =
      (* Printf.printf "unsat core: %d\n" redlog_unsat_core_id;
      flush stdout; *)
      try
        let polyCons = IntMap.find redlog_unsat_core_id passed_polyCons_maps in
        unsat_core := IntSet.add polyCons#get_miniSATCode !unsat_core;
      with _ -> ();
    in
    List.iter add_redlog_unsat_core redlog_unsat_core_ids;
    end;
    result
  )
  else if result = 1 then 
    begin
      redlog_command "(get-model)";    
      model_eq := get_redlog_output();
      result
    end
  else result

let decompose testUNSATPolyConstraints varsIntvsMap uk_cl esl usedVarsSet =
  (*Applied for Dynamic interval decomposition*)
  (*Balance interval decomposition*)
  (*let (sInterval, sLearn, isDecomp) = dynamicDecom assIntv dIntv checkVarID nextMiniSATCode clTest_US esl in*)
  let (decomposedExpr, _) = 
    get_element testUNSATPolyConstraints
  in
  
  (* print_endline "decomposing";
  flush stdout; *)
  (*print_endline(bool_expr_list_to_infix_string decomposedExpr);*)
  
  (* print_endline ("Current Boxes: \n" ^ string_of_varsIntvsPrioritiesMap !varsIntvsMapPrioritiesMaps);
  flush stdout; *)
  
  (*let testUNSATPolyCons = List.hd clTest_US in
  let decomposedPolyConstraints = testUNSATPolyCons :: uk_cl in*)
  let maxDecompose = 1 in (* only $maxDecompose are allowed to decomposed, the priority is based on sensitivity *)
  let (new_unsat_core, new_varsIntvsMapPrioritiesMaps) = 
    (*let (newInterval, newLearn, newBumpVars, isDecomposed) = decompose_unsat_detection (List.hd decomposedExpr) assIntv dIntv checkVarID nextMiniSATCode esl in*)
    (*let (newInterval, newLearn, newBumpVars, isDecomposed) = decompose_list_unsat_detection uk_cl assIntv dIntv checkVarID nextMiniSATCode esl in
    if isDecomposed then 
      (newInterval, newLearn, newBumpVars, isDecomposed)
    else*)
      dynamicDecom varsIntvsMap !unsat_core !varsIntvsMapPrioritiesMaps decomposedExpr
                    uk_cl maxDecompose esl usedVarsSet
  in



  unsat_core := new_unsat_core;

      (* dynamicDecom_noStrategy varsIntvsMap varsIntvsMapPrioritiesMaps (List.hd decomposedExpr) 
                    uk_cl maxDecompose esl (remainingTime -. Sys.time() +. startTime) in *)
  (* print_endline "after decomposed";
  flush stdout;
  print_endline ("New Boxes: \n" ^ string_of_varsIntvsPrioritiesMap new_varsIntvsMapPrioritiesMaps);
  flush stdout; *)

  (* let varsIntvsMapPrioritiesMaps = FloatMap.empty in *)
  varsIntvsMapPrioritiesMaps := new_varsIntvsMapPrioritiesMaps


let gen_model_eq varsIntvsMap =
  let add_var_tc var intv currentMap = 
  let tc = intv.low in
    try
      let currentList = FloatMap.find tc currentMap in
      FloatMap.add tc (var::currentList) currentMap
    with
    | _ -> 
      FloatMap.add tc [var] currentMap
  in
  let tcs_vars_map = 
    StringMap.fold add_var_tc varsIntvsMap FloatMap.empty 
  in
  let rec string_of_vars = function 
  | [] -> ""
  | [var] -> var
  | var::t -> var ^ " " ^ string_of_vars t
  in
  let string_of_tc_vars tc vars current_string = 
    let vars_string = string_of_vars vars in 
    let tc_string = Util.float_to_string tc in
    let vars_tc_string = 
      Printf.sprintf "((%s) %s)" vars_string tc_string 
    in
    current_string ^ vars_tc_string
  in
  model_eq := Printf.sprintf "(%s)" (FloatMap.fold string_of_tc_vars tcs_vars_map "")

let rec check_procedure () =
  if FloatMap.is_empty !varsIntvsMapPrioritiesMaps then
    (* let message = "Finished checking" in
    print_endline message;
    flush stdout; *)
    if !isUnknown then 
      
      (* let a = "Tung" in
      print_endline a;
      flush stdout; *)

      (* redlog_check !first_uk !first_box !first_unsat_core *)
      let add_us_core polyCons = 
        unsat_core := IntSet.add polyCons#get_miniSATCode !unsat_core;
      in
      unsat_core := IntSet.empty;
      List.iter add_us_core !polyConstraints;
      0
    else
      -1
  else
    let startTime = Sys.time() in 
    let (esl, varsIntvsMaps) = FloatMap.max_binding !varsIntvsMapPrioritiesMaps in
    let varsIntvsMap = List.hd varsIntvsMaps in
    
    
    (* print_endline "---------------------------NEW----------------------";
    print_endline ("esl: " ^ string_of_float esl);
    print_endline (Util.log_intervals varsIntvsMap);
    flush stdout; *)
    

    let new_varsIntvsMapPrioritiesMaps = match List.tl varsIntvsMaps with
      | [] -> FloatMap.remove esl !varsIntvsMapPrioritiesMaps
      | _ -> FloatMap.add esl (List.tl varsIntvsMaps) !varsIntvsMapPrioritiesMaps
    in

    varsIntvsMapPrioritiesMaps := new_varsIntvsMapPrioritiesMaps;

    let varsIntvsMap = varsIntvsMap in

    let (res, new_unsat_core, uk_cl, validPolyConstraints, varsIntvsMap, iaTime, usTime) = 
        icp !unsat_core [] [] !polyConstraints varsIntvsMap esl 0.0 0.0 0
    in

    unsat_core := new_unsat_core;

    (* print_endline ("EndICP, result: " ^ string_of_int res);
    flush stdout;

    print_endline (Util.log_intervals varsIntvsMap);
    flush stdout; *)

    (* exit 0; *)

    if (res = -1) then 
      check_procedure()
    else if (res = 1) then (*if all clauses are satisfiable*)
      begin
        gen_model_eq varsIntvsMap;
        res
      end
    else (*if unknown, testing will be implemented here*)(
      (*let uk_cl = List.rev uk_cl in (* reverse the list so that the apis are sorted based on variables dependency *)*)
      (* print_endline("IA Unkown constraints: " ^ string_infix_of_polynomialConstraints uk_cl); string_infix_of_polynomialConstraints is defined in polynomialConstraint.ml
      flush stdout; *)
      assert(uk_cl <> []);

      (* let linear_result = check_linear uk_cl varsIntvsMap in 
      if linear_result = "unsat" then 
        check_procedure()
      else   *)

      if !is_icp_first then 
      begin
        is_icp_first := false;
        first_uk := uk_cl;
        first_box := varsIntvsMap; 
        first_unsat_core := new_unsat_core; 
      end;

      (* print_endline ("unkown constraints: " ^ 
                        string_infix_of_polynomialConstraints uk_cl);
      flush stdout; *)

      (* print_endline "Start Testing";
      flush stdout; *)
      
      let (sTest, testSATPolyConstraints, testUNSATPolyConstraints, satVarsTCsMap, generatedVarsSet) = 
        test uk_cl varsIntvsMap(* test is defined in Testing.ml *)
      in

      let add_var_tc var tc currentMap =
        StringMap.add var {low=tc;high=tc} currentMap
      in

      if (sTest = 1) then
        let varsIntvsMap = StringMap.fold add_var_tc satVarsTCsMap varsIntvsMap in
        gen_model_eq varsIntvsMap;
        
        (* print_endline "SAT by Testing";
        print_endline (Util.log_intervals varsIntvsMap);  
        print_endline (log_assignment satVarsTCsMap);
        flush stdout; *)

        (* let tmp = redlog_check [] varsIntvsMap new_unsat_core false in *)
        
        (* Printf.printf "Verified by reduce : %d" tmp;
        flush stdout; *)

        sTest
      else
      (
       (* If the uk_cl are equalities, then we implement some tricks for solving them. *)
       
       (* print_endline ("Test unknown constraints: " ^ 
                        string_infix_of_polynomialConstraints testUNSATPolyConstraints);
       flush stdout;

       let assignmentsLog = log_assignment satVarsTCsMap in
        print_endline assignmentsLog;
        flush stdout; *)

       (* print_endline (string_of_bool (can_apply_imvt testUNSATPolyConstraints && is_all_equations testUNSATPolyConstraints));
       flush stdout; *)

       (* raise (Failure "Tung"); *)
       let (isEqualitiesSAT, unsatPolyConstraints, usedVarsSet) = 
         if can_apply_imvt testUNSATPolyConstraints && is_all_equations testUNSATPolyConstraints then (* is_all_equalities is defined in ast.ml *)
            let varsIntvsMap = StringMap.fold add_var_tc satVarsTCsMap varsIntvsMap in
            check_equalities testUNSATPolyConstraints varsIntvsMap generatedVarsSet (* check_equalities is defined in Equalities_handler.ml *)
         else (false, testUNSATPolyConstraints, generatedVarsSet)
       in
       if isEqualitiesSAT then 
         (* let intvLog = Util.log_intervals varsIntvsMap in *)
         (* let validPolyConstraints = List.rev validPolyConstraints in *)
         (* let iaLog = log_ia validPolyConstraints in *)
         (* let assignmentsLog = log_assignment satVarsTCsMap in (* log_assignment is in Assignments.ml *) *)
         (* let testLog = log_test testSATPolyConstraints in *)
        begin
          (* print_endline "SAT by IVT";
          print_endline (Util.log_intervals varsIntvsMap);  
          print_endline (log_assignment satVarsTCsMap);
          flush stdout; *)
          (* let varsIntvsMap = StringMap.fold add_var_tc satVarsTCsMap varsIntvsMap in
          redlog_check testUNSATPolyConstraints varsIntvsMap new_unsat_core false *)
          gen_model_eq varsIntvsMap;
          1
        end            
       else 
        (* let usedVarsSet = generatedVarsSet in *)

        (* Printf.printf "U Num: %d\n" unknown_vars_num;
        flush stdout;
        exit 1; *)

        let rec test_by_reduce degree_sorted_vars varsTCsMap times =
          if times > 0 then 0
          else 
            match degree_sorted_vars with
            | [] -> -1
            | h::t -> 
              let (removed_var, _) = h in
              let varsTCsMap = StringMap.remove removed_var varsTCsMap in
              let varsIntvsMap = 
                StringMap.fold add_var_tc varsTCsMap varsIntvsMap 
              in
              let reduce_test_val = 
                redlog_check uk_cl varsIntvsMap new_unsat_core false
              in 
              match reduce_test_val with
              | 1 -> 1
              | _ -> test_by_reduce t varsTCsMap (times + 1)
        in
        let reduce_test = 
          (* if can_apply_imvt testUNSATPolyConstraints && is_all_equations testUNSATPolyConstraints then
            (* calling reduce to solve equations *)
            let varsIntvsMap = StringMap.fold add_var_tc satVarsTCsMap varsIntvsMap in            
            redlog_check uk_cl varsIntvsMap new_unsat_core false
          else  *)
            (* try testing by reduce *)
            (* let (lower_difficult, _) = get_element uk_cl in
            Printf.printf "Easiness: %f\n" lower_difficult#get_easiness;
            flush stdout; *)

            let (varsTCsMap, degree_sorted_vars, unknown_vars_num) = 
              gen_reduce_test testUNSATPolyConstraints satVarsTCsMap varsIntvsMap
            in
            test_by_reduce degree_sorted_vars varsTCsMap unknown_vars_num 
        in

        (* let (lower_difficult, _) = get_element uk_cl in
        let threshold = lower_difficult#get_easiness in *)

        if reduce_test = 1 then 
          reduce_test
         
        (* else if esl >= threshold then *)
        (* else if esl <= epsilon_float then *)
        (* else if esl <= infinity then *)
        else if esl <= ldexp 0.125 (-3) then
          
          (* let assignmentsLog = log_assignment satVarsTCsMap in
          print_endline assignmentsLog;
          flush stdout; *)

          let redlog_result = 
            if not !redlog_failed then 
              (* let (lower_difficult, _) = get_element uk_cl in
              Printf.printf "Easiness: %f\n" lower_difficult#get_easiness;
              flush stdout; *)
              redlog_check !first_uk !first_box !first_unsat_core true
              (* redlog_check !first_uk StringMap.empty !first_unsat_core true *)
              (* 0 *)
            else
              0
              (* redlog_check uk_cl varsIntvsMap new_unsat_core *)
          in match redlog_result with
          | 0 -> 
            begin
              redlog_failed := true;
              decompose testUNSATPolyConstraints varsIntvsMap uk_cl esl usedVarsSet;
              check_procedure()
              (* 0 *)
            end
          | _ -> redlog_result
        else (
          decompose testUNSATPolyConstraints varsIntvsMap uk_cl esl usedVarsSet;
          check_procedure ()
         )
      )
    )
  


let set_logic setLogic = 
  logic := setLogic

let rec insert_polyCons_by_lenth polyCons = function
  | [] -> [polyCons]
  | h::t as input -> 
    if h#get_length < polyCons#get_length then
      h::(insert_polyCons_by_lenth polyCons t)
    else
      polyCons:: input

let add_polyCons_extra id assert_smt2 polyCons = 
  polyCons#set_logic !logic;

  (* Printf.printf "Processed to %s\n" (polyCons#to_string_infix);
  flush stdout; *)

  polyCons#set_miniSATCode id;
  polyCons#set_negated false;

  (* polyCons#set_smt2 assert_smt2; *)
  polyCons#set_smt2 (Printf.sprintf "(assert %s)" polyCons#to_string_prefix);

  (* polyConstraints := insert_polyCons_by_lenth polyCons !polyConstraints; *)
  polyConstraints := polyCons::!polyConstraints;
  ()

(* let gen_mul_for_div e1 e2 polType intv af2 variables = match e2 with
  | Cons(c, isInit, polType,intv, af2) -> 
    let new_e2 = 
      if c > 0. then 
        Cons(1., isInit, polType,intv, af2)
      else if c < 0. then
        Cons(-. 1., isInit, polType,intv, af2)
      else
       e2
    in
    reduce (Mul(e1, new_e2, polType, intv, af2)) variables
  | _ ->
    reduce (Mul(e1, e2, polType, intv, af2)) variables

let gen_polyCons_from_div e1 e2 polType intv af2 variables = function 
  | Eq (_) -> 
    gen_polyCons (Eq e1) variables
  | Neq (_) -> 
    gen_polyCons (Neq e1) variables
  | Geq _ ->
    let mul_expr = gen_mul_for_div e1 e2 polType intv af2 variables in
    gen_polyCons (Geq mul_expr) variables
  | Leq _ ->
    let mul_expr = gen_mul_for_div e1 e2 polType intv af2 variables in
    gen_polyCons (Leq mul_expr)  variables
  | Gr _ ->
    let mul_expr = gen_mul_for_div e1 e2 polType intv af2 variables in
    gen_polyCons (Gr mul_expr) variables
  | Le _ ->
    let mul_expr = gen_mul_for_div e1 e2 polType intv af2 variables in
    gen_polyCons (Le mul_expr) variables

let add_nonzero e id variables = match e with
  | Cons(c, isInit, polType,intv, af2) ->
    if c = 0. then 
      let nonZeroEPolyCons = gen_polyCons (Neq e) variables in
      add_polyCons_extra id nonZeroEPolyCons;    
      ()
  | _ -> 
    let nonZeroEPolyCons = gen_polyCons (Neq e) variables in
    add_polyCons_extra id nonZeroEPolyCons;    
    () *)

let add_polyCons id assert_smt2 polyCons = 
  (* let poly_constraint = polyCons#get_constraint in
  let poly_expr = get_exp poly_constraint in
  match poly_expr with
  Div(e1, e2, polType,intv, af2) ->
    let variables = polyCons#get_variables in
    let reducedE1 = reduce e1 variables in
    let reducedE2 = reduce e2 variables in

    add_nonzero reducedE2 id variables;

    let main_polyCons = 
      gen_polyCons_from_div reducedE1 reducedE2 polType intv af2 variables poly_constraint 
    in
    add_polyCons_extra id main_polyCons
    
  | _ ->  *)

    add_polyCons_extra id assert_smt2 polyCons


let rec add_apc id assert_smt2 = function
  | Single(polyCons) ->

    add_polyCons id assert_smt2 polyCons
  | NSingle(polyCons) -> 

    let polyConstraint = not_of_polyConstraint polyCons#get_constraint in
    let newPolyCons = new polynomialConstraint polyConstraint StringMap.empty in

    add_polyCons id assert_smt2 newPolyCons
  | _ -> raise (Failure "Wrong input in line 202")


let _assert assert_smt2 id = 
  
  (* print_endline assert_smt2;
  flush stdout; *)

  (* let test_intv = pow_I_i {low=2.;high=2.} max_int in
  printf_I "%.324f" test_intv;
  flush stdout;
  failwith "Tung"; *)

  let lexbuf = Lexing.from_string assert_smt2 in  
  let parsed = Smtlib_parse.main Smtlib_lex.token lexbuf in
  
  let constraints = match parsed with
    | None -> []
    | Some(x) -> get_constraints StringMap.empty StringMap.empty StringMap.empty x;
  in
  
  let bool_exp = List.nth constraints 0 in

  add_apc id assert_smt2 bool_exp;

  "sat"

let solve () = 
  (* init_redlog(); *)
  (* print_endline "Start solving";
  flush stdout; *)

  (* exit(0); *)

  let returnSAT = check_procedure() in
  
  (* Printf.printf "Result: %d\n" returnSAT;
  flush stdout; *)

  let result = 
    if returnSAT = 1 then
      "sat"
    else if returnSAT = -1 then 
      "unsat"
    else 
      "unknown"
  in

  (* let result = "sat" in *)
  
  (* print_endline ("Result: " ^ result);
  flush stdout; *)

  result
  (* "unknown" *)

let reset () = 
  (* print_endline "raSAT resetttttttttt";
  flush stdout; *)

  polyConstraints := [];
  varsIntvsMapPrioritiesMaps := FloatMap.singleton 0.125 [StringMap.empty];
  isUnknown := false;

  redlog_failed := false;

  (* factorization_reset(); *)

  (* flag to store first iteration of icp *)
  is_icp_first := true;

  (* unknown constraints after first iteration of icp *)
  first_uk := [];

  (* contracted box after the first iteration of icp *)
  first_box := StringMap.empty;

  first_unsat_core := IntSet.empty;

  unsat_core := IntSet.empty;

  model_eq := ""

let get_unsat_core () =
  let string_of_unsat_core lit current_string =
    string_of_int lit ^ " " ^ current_string
  in
  IntSet.fold string_of_unsat_core !unsat_core ""

let print_unsat_cores () = 
  let eq_lit lit polyCons = 
    lit = polyCons#get_miniSATCode
  in
  let find_and_print lit = 
    let polyCons = List.find (eq_lit lit) !polyConstraints in
    print_endline (string_of_int lit ^ ": " ^ polyCons#to_string_prefix);
    flush stdout;
  in
  IntSet.iter find_and_print !unsat_core

let get_model_eq () = 
  !model_eq

(*===========================================================*)
(* Export those functions to C/C++ *)
(*===========================================================*)
let _ = Callback.register "raSAT_solve" solve;;
let _ = Callback.register "raSAT_set_logic" set_logic;;
let _ = Callback.register "raSAT_assert" _assert;;
let _ = Callback.register "raSAT_reset" reset;;
let _ = Callback.register "raSAT_get_unsat_core" get_unsat_core;;
let _ = Callback.register "raSAT_get_model_eq" get_model_eq;;
let _ = Callback.register "raSAT_print_unsat_cores" print_unsat_cores;;
