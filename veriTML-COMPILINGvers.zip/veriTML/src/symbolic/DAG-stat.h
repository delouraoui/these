#ifndef DAG_STAT_H
#define DAG_STAT_H
#include <stdio.h>
#include "DAG.h"


/**
   \brief DAG size
   \param DAG to be measured
   \return Number of nodes in DAG as a DAG representation */
extern unsigned DAG_count_nodes(TDAG DAG);

/**
   \brief Expanded DAG size
   \param DAG to be measured
   \return Number of nodes in DAG as a tree representation
   \remark returns UINT_MAX for overflow */
extern unsigned DAG_count_nodes_tree(TDAG DAG);

/**
   \brief Expanded DAG boolean size
   \param DAG to be measured
   \return Number of atoms in DAG as a tree representation */
extern unsigned DAG_count_atoms(TDAG DAG);

/**
   \brief Depth of a DAG
   \param DAG to be measured
   \return Depth of a DAG as a tree representation (depth is 1 for leafs) */
extern unsigned DAG_depth(TDAG DAG);

/**
   \brief max Depth of a DAG
   \param DAG to be measured
   \return Depth of a DAG as a tree representation (depth is 1 for leafs) */
extern unsigned DAG_max_depth(TDAG DAG);

extern unsigned DAG_min_depth(TDAG DAG);

extern double DAG_avg_depth(TDAG DAG);

extern unsigned DAG_intersect_symbols(TDAG DAG);

extern unsigned DAG_biggest_intersect_term(TDAG DAG);

extern unsigned DAG_count_differents_atoms(TDAG DAG);

extern unsigned DAG_predicats_appear(TDAG DAG);

extern unsigned DAG_nb_arity_term(TDAG DAG, unsigned arity);

extern void DAG_encode_fea(TDAG DAG);

extern void DAG_translate_fea(TDAG DAG, unsigned shift);

extern void DAG_extra_fea(TDAG DAG, unsigned num);

extern void write_fea(FILE *file_features);

extern void write_instance_fea(FILE *file_features);

extern void write_stats_fea(FILE *file_features, unsigned nb_sk, unsigned nb_skolem_round,
                            unsigned depth, unsigned nb_triggers, unsigned cc_pol, unsigned cc_size,
                            unsigned cc_pred, unsigned nb_terms);

extern float get_prediction(unsigned nb_tree, unsigned param);

extern void init_translate_model(TDAG* PDAG, unsigned size, unsigned shift, unsigned q);

extern void add_to_model(TDAG DAG, unsigned indice, unsigned decal, unsigned qf);

extern void extra_fea_model(unsigned size, unsigned qf);

extern void DAG_custom_fea(unsigned value, unsigned decal);


extern void reset_model();

extern void init_fea();

extern void free_fea();

extern void free_model_stack(void);

extern void init_model_stack(TDAG* PDAG, unsigned size);


#endif
