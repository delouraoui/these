#ifndef XGBOOST_CLASSIFIER2_H
#define XGBOOST_CLASSIFIER2_H

float xgb_classify_2(float *sample, unsigned nb_trees);

extern unsigned features_2[5000];
extern unsigned value_fea_2[5000];

#endif
