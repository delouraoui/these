#include <limits.h>
#include <stdio.h>
#include "veriT-DAG.h"
#include "DAG-tmp.h"
#include "DAG-stat.h"
#include "literal.h"
//#include <openssl/md5.h>

#define FEAT_SIZE 2310705
/* #define FEA_VERBOSE */
extern bool option_learning_native_2;

static bool
contains(Tstack_DAG *stack, TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(*stack); i++)
    if (stack_get(*stack, i) == DAG)
      return true;
  return false;
}


/*
  --------------------------------------------------------------
  Statistics
  --------------------------------------------------------------
*/



Tstack_unsigned depth_DAG;
Tstack_unsigned size_DAG;
Tstack_symb symb_DAG;
Tstack_symb model_symb_DAG;
Tstack_DAG terms_DAG;
Tstack_DAG model_terms_DAG;


static unsigned
DAG_count_nodes_aux(TDAG DAG)
{
  unsigned i, j;
  if (DAG_tmp_unsigned[DAG])
    return 0;
  DAG_tmp_unsigned[DAG] = 1;
  for (i = 0, j = 0; i < DAG_arity(DAG); i++)
    j += DAG_count_nodes_aux(DAG_arg(DAG, i));
  return j + 1;
}

/*--------------------------------------------------------------*/

unsigned
DAG_count_nodes(TDAG DAG)
{
  unsigned res;
  DAG_tmp_reserve();
  res = DAG_count_nodes_aux(DAG);
  DAG_tmp_reset_unsigned(DAG);
  DAG_tmp_release();
  return res;
}

/*--------------------------------------------------------------*/

#define SAFE_ADD(A,B) ((A == UINT_MAX || B == UINT_MAX)?UINT_MAX:((A < UINT_MAX - B)? A+B : UINT_MAX))

static unsigned
DAG_count_nodes_tree_aux(TDAG DAG)
{
  unsigned i;
  if (DAG_tmp_unsigned[DAG])
    return DAG_tmp_unsigned[DAG];
  DAG_tmp_unsigned[DAG] = 1;
  for (i = 0; i < DAG_arity(DAG); i++)
    {
      unsigned k = DAG_count_nodes_tree_aux(DAG_arg(DAG, i));
      DAG_tmp_unsigned[DAG] = SAFE_ADD(DAG_tmp_unsigned[DAG], k);
    }
  return DAG_tmp_unsigned[DAG];
}

/*--------------------------------------------------------------*/

unsigned
DAG_count_nodes_tree(TDAG DAG)
{
  unsigned res;
  DAG_tmp_reserve();
  res = DAG_count_nodes_tree_aux(DAG);
  DAG_tmp_reset_unsigned(DAG);
  DAG_tmp_release();
  return res;
}

/*--------------------------------------------------------------*/

static unsigned
DAG_count_atoms_aux(TDAG DAG)
{
  unsigned i;
  if (DAG_tmp_unsigned[DAG])
    return DAG_tmp_unsigned[DAG];
  if (DAG_symb(DAG) == LET)
    {
      for (i = 1; i < DAG_arity(DAG); i++, i++)
        DAG_tmp_unsigned[DAG] += DAG_count_atoms_aux(DAG_arg(DAG, i));
      DAG_tmp_unsigned[DAG] += DAG_count_atoms_aux(DAG_arg_last(DAG));
    }
  else if (quantifier(DAG_symb(DAG)))
    DAG_tmp_unsigned[DAG] = DAG_count_atoms_aux(DAG_arg_last(DAG));
  else if (boolean_connector(DAG_symb(DAG)))
    for (i = 0; i < DAG_arity(DAG); i++)
      DAG_tmp_unsigned[DAG] += DAG_count_atoms_aux(DAG_arg(DAG, i));
  else
    DAG_tmp_unsigned[DAG] = 1;
  return DAG_tmp_unsigned[DAG];
}

/*--------------------------------------------------------------*/

unsigned
DAG_count_atoms(TDAG DAG)
{
  unsigned res;
  DAG_tmp_reserve();
  res = DAG_count_atoms_aux(DAG);
  DAG_tmp_reset_unsigned(DAG);
  DAG_tmp_release();
  return res;
}

/*--------------------------------------------------------------*/

static unsigned
DAG_depth_aux(TDAG DAG)
{
  unsigned i, j;
  if (!DAG_tmp_unsigned[DAG])
    {
      for (i = 0, j = 0; i < DAG_arity(DAG); i++)
        {
          unsigned k = DAG_depth_aux(DAG_arg(DAG, i));
          if (k > j) j = k;
        }
      DAG_tmp_unsigned[DAG] = j + 1;
    }
  return DAG_tmp_unsigned[DAG];
}

/*--------------------------------------------------------------*/

unsigned
DAG_depth(TDAG DAG)
{
  unsigned res;
  DAG_tmp_reserve();
  res = DAG_depth_aux(DAG);
  DAG_tmp_reset_unsigned(DAG);
  DAG_tmp_release();
  return res;
}


static void
DAG_all_depth_aux(TDAG DAG)
{
  unsigned i;
  if (DAG_symb(DAG) == LET)
    {
      for (i = 1; i < DAG_arity(DAG); i++, i++)
        DAG_all_depth_aux(DAG_arg(DAG, i));
      DAG_all_depth_aux(DAG_arg_last(DAG));
    }
  else if (quantifier(DAG_symb(DAG)))
    DAG_all_depth_aux(DAG_arg_last(DAG));
  else if (boolean_connector(DAG_symb(DAG)))
    for (i = 0; i < DAG_arity(DAG); i++)
      DAG_all_depth_aux(DAG_arg(DAG, i));
  else
    stack_push(depth_DAG, DAG_depth(DAG));
}

/*--------------------------------------------------------------*/

unsigned
DAG_max_depth(TDAG DAG)
{
  unsigned max = 0, i;
  stack_INIT(depth_DAG);
  DAG_all_depth_aux(DAG);
  for (i = 0; i < stack_size(depth_DAG); i++)
    {
      if (stack_get(depth_DAG, i) >= max)
        max = stack_get(depth_DAG, i);
    }
  stack_reset(depth_DAG);
  stack_free(depth_DAG);
  return max;
}

/*--------------------------------------------------------------*/

unsigned
DAG_min_depth(TDAG DAG)
{
  unsigned min = UINT_MAX, i;
  stack_INIT(depth_DAG);
  DAG_all_depth_aux(DAG);
  for (i = 0; i < stack_size(depth_DAG); i++)
    {
      if (stack_get(depth_DAG, i) <= min)
        min = stack_get(depth_DAG, i);
    }
  stack_reset(depth_DAG);
  stack_free(depth_DAG);
  return min;
}

/*--------------------------------------------------------------*/

double
DAG_avg_depth(TDAG DAG)
{
  unsigned sum = 0, i, size;
  stack_INIT(depth_DAG);
  DAG_all_depth_aux(DAG);
  for (i = 0; i < stack_size(depth_DAG); i++)
    sum += stack_get(depth_DAG, i);
  size = stack_size(depth_DAG);
  stack_reset(depth_DAG);
  stack_free(depth_DAG);
  return ((double) sum / (double) size);
}

/*--------------------------------------------------------------*/

static void
DAG_all_symbols_aux(TDAG DAG, bool model)
{
  unsigned i;

  if (DAG_symb(DAG) == LET)
    {
      for (i = 1; i < DAG_arity(DAG); i++, i++)
        DAG_all_symbols_aux(DAG_arg(DAG, i), model);
      DAG_all_symbols_aux(DAG_arg_last(DAG), model);
    }
  else if (quantifier(DAG_symb(DAG)))
    DAG_all_symbols_aux(DAG_arg_last(DAG), model);
  else if (!DAG_arity(DAG) || boolean_connector(DAG_symb(DAG)))
    for (i = 0; i < DAG_arity(DAG); i++)
      DAG_all_symbols_aux(DAG_arg(DAG, i), model);
  if (DAG_symb(DAG) && !model &&
      !contains((Tstack_DAG *)&symb_DAG, (TDAG)DAG_symb(DAG)))
    stack_push(symb_DAG, DAG_symb(DAG));
  else if (model && !contains((Tstack_DAG *)&model_symb_DAG, (TDAG)DAG_symb(DAG)))
    stack_push(model_symb_DAG, DAG_symb(DAG));
}

/*--------------------------------------------------------------*/

static void
DAG_all_term_aux(TDAG DAG, bool model)
{
  unsigned i;
  if (DAG_symb(DAG) == LET)
    {
      for (i = 1; i < DAG_arity(DAG); i++, i++)
        DAG_all_term_aux(DAG_arg(DAG, i), model);
      DAG_all_term_aux(DAG_arg_last(DAG), model);
    }
  else if (quantifier(DAG_symb(DAG)))
    DAG_all_term_aux(DAG_arg_last(DAG), model);
  else if (!DAG_arity(DAG) || boolean_connector(DAG_symb(DAG)))
    for (i = 0; i < DAG_arity(DAG); i++)
      DAG_all_term_aux(DAG_arg(DAG, i), model);
  if (!model && !contains(&terms_DAG, DAG))
    {
      stack_push(terms_DAG, DAG);
    }
  else if (model && !contains(&model_terms_DAG, DAG))
    stack_push(model_terms_DAG, DAG_symb(DAG));
}


static void
DAG_all_sub_term_aux(TDAG DAG, bool model)
{
  unsigned i;
  if (DAG_symb(DAG) == LET)
    {
      for (i = 1; i < DAG_arity(DAG); i++, i++)
        DAG_all_term_aux(DAG_arg(DAG, i), model);
      DAG_all_term_aux(DAG_arg_last(DAG), model);
    }
  else if (quantifier(DAG_symb(DAG)))
    DAG_all_term_aux(DAG_arg_last(DAG), model);
  else if (!DAG_arity(DAG) || boolean_connector(DAG_symb(DAG)))
    for (i = 0; i < DAG_arity(DAG); i++)
      DAG_all_term_aux(DAG_arg(DAG, i), model);

  if (!model && !contains(&terms_DAG, DAG))
    {

      stack_push(terms_DAG, DAG);
    }
  else if (model && !contains(&model_terms_DAG, DAG))
    {
      stack_push(model_terms_DAG, DAG_symb(DAG));
    }
}
/*--------------------------------------------------------------*/

unsigned
DAG_size(TDAG DAG1)
{
  unsigned size;
  stack_INIT(symb_DAG);
  DAG_all_symbols_aux(DAG1, false);
  size = stack_size(symb_DAG);
  stack_reset(symb_DAG);
  stack_free(symb_DAG);
  return size;
}

/*--------------------------------------------------------------*/

unsigned
DAG_intersect_symbols(TDAG DAG)
{
  unsigned i, j, intercect = 0;
  stack_INIT(symb_DAG);
  DAG_all_symbols_aux(DAG, false);
  for (i = 0; i < stack_size(symb_DAG); i++)
    {
      for (j = 0; j < stack_size(model_symb_DAG); j++)
        {
          if (stack_get(model_symb_DAG, j) == stack_get(symb_DAG, i))
            {
              intercect++;
              /* printf("%d ", stack_get(model_symb_DAG, j)); */
            }
        }
    }
  /* printf("[%d] \n", intercect); */
  stack_reset(symb_DAG);
  stack_free(symb_DAG);
  return intercect;
}

/*--------------------------------------------------------------*/

unsigned
DAG_biggest_intersect_term(TDAG DAG)
{
  unsigned i, j, size = 0, max = 0;
  stack_INIT(terms_DAG);
  DAG_all_term_aux(DAG, false);
  for (i = 0; i < stack_size(terms_DAG); i++)
    {
      for (j = 0; j < stack_size(model_terms_DAG); j++)
        {
          if (DAG_symb(stack_get(model_terms_DAG, j)) ==
              DAG_symb(stack_get(terms_DAG, i)))
            {
              size = DAG_size(stack_get(model_terms_DAG, j));
              if (size >= max)
                max = size;
            }
        }
    }
  stack_reset(terms_DAG);
  stack_free(terms_DAG);
  return size;
}

/*--------------------------------------------------------------*/

unsigned
DAG_count_differents_atoms(TDAG DAG)
{
  unsigned res = 0, i, j;
  stack_INIT(terms_DAG);
  DAG_all_term_aux(DAG, false);
  for (i = 0; i < stack_size(terms_DAG); i++)
    {
      for (j = 0; j < stack_size(model_terms_DAG); j++)
        {
          if (DAG_symb(stack_get(model_terms_DAG, j)) ==
              DAG_symb(stack_get(terms_DAG, i)))
            break;
          /* if (DAG_symb(stack_get(model_terms_DAG, j)) != */
          /*     DAG_symb(stack_get(terms_DAG, i))) */
          /* res++; */
        }
      if (j == stack_size(model_terms_DAG))
        res++;
    }
  stack_reset(terms_DAG);
  stack_free(terms_DAG);
  return res;
}


/*--------------------------------------------------------------*/


unsigned
DAG_predicats_appear(TDAG DAG)
{
  unsigned i, j, intercect = 0;
  stack_INIT(terms_DAG);
  DAG_all_term_aux(DAG, false);
  for (i = 0; i < stack_size(terms_DAG); i++)
    {
      for (j = 0; j < stack_size(model_terms_DAG); j++)
        {
          if (DAG_symb(stack_get(terms_DAG, i)) &&
              DAG_symb(stack_get(model_terms_DAG, j)) &&
              DAG_symb(stack_get(model_terms_DAG, j)) ==
              DAG_symb(stack_get(terms_DAG, i)) &&
              DAG_sort(stack_get(terms_DAG, i)) == SORT_BOOLEAN &&
              (DAG_is_lit(stack_get(model_terms_DAG, j))) &&
              (DAG_is_lit(stack_get(terms_DAG, i))) &&
              lit_pol(DAG_to_lit(stack_get(model_terms_DAG, j))) !=
              lit_pol(DAG_to_lit(stack_get(terms_DAG, i))))
            intercect++;
        }
    }
  stack_reset(terms_DAG);
  stack_free(terms_DAG);
  return intercect;
}


/*--------------------------------------------------------------*/

unsigned
DAG_nb_arity_term(TDAG DAG, unsigned arity)
{
  unsigned i, nb = 0;
  stack_INIT(terms_DAG);
  DAG_all_term_aux(DAG, false);
  for (i = 0; i < stack_size(terms_DAG); i++)
    {
      if (DAG_arity(stack_get(terms_DAG, i)) == arity)
        nb++;
    }
  stack_reset(terms_DAG);
  stack_free(terms_DAG);
  return nb++;
}


/*--------------------------------------------------------------*/
/*                    Features computation                      */
/*--------------------------------------------------------------*/


/*
  Informations on features

  number of literals in model 1
  number of term(symbols) in the model 3
  number of quantified formulas 4
  number of term(symbols) in the quantified formulas 5
  size of deepest term in the quantified formulas 6

  For each instance:
  number of instances 7
  number of term(symbols) 8
  max deepth 9
 */

typedef long long int Int64;

typedef struct pair_fea {
  Int64 feature;
  unsigned value;
} pair_fea;

TSstack(_Int64, Int64);
TSstack(_pair_fea, pair_fea);

Tstack_Int64 Symb_fea;
Tstack_pair_fea DAG_walk_fea;
Tstack_pair_fea model_walk_fea;

Int64 prime = 1933;
Int64 features_modulo = 262139;
/** Use random walk **/
/* Int64 prime = 1; */
/* Int64 features_modulo = 70; */

bool model = false;

static void
resize_signature()
{
  unsigned previous_size, i;
  if (stack_is_empty(Symb_fea))
    {
      stack_inc_n(Symb_fea, DAG_symb_stack->size + 1);
      for (i = 0; i < DAG_symb_stack->size + 1; i++)
        stack_set(Symb_fea, i, 0);
    }
  else if (stack_size(Symb_fea) < DAG_symb_stack->size + 1)
    {
      previous_size = stack_size(Symb_fea);
      stack_inc_n(Symb_fea,  (DAG_symb_stack->size + 1 - previous_size));
      for (i = previous_size; i < DAG_symb_stack->size + 1; i++)
        stack_set(Symb_fea, i, 0);
    }
}

Int64 fea_mod(Int64 n)
{
  long long int fea = ((long long int)n % (long long int)features_modulo);
  if (fea < 0)
    return 1 + (fea + features_modulo);
  return 1 + fea;
}

Int64
shift(Int64 fea, unsigned decale)
{
  Int64 r = fea + ((Int64)decale) * features_modulo;
  /* printf("shift(%lld, %d) = %lld fmod(%lld)\n", fea, decale, r, fea_mod(r)); */
  return r;
}

void
uniq(Tstack_pair_fea tmp)
{
  unsigned stack_i = 0, stack_j = 1;
  while (stack_j < (tmp)->size)
    if ((tmp)->data[stack_j].feature == (tmp)->data[stack_i].feature)
      {
        stack_get(tmp, stack_i).value +=
          stack_get(tmp, stack_j).value;
        stack_j++;
      }
    else
      (tmp)->data[++stack_i] = (tmp)->data[stack_j++];
  (tmp)->size = stack_i + 1;
}

static int
compare_by_fea(pair_fea *u, pair_fea *v)
{
  if (u->feature < v->feature)
    return -1;
  else if (u->feature > v->feature)
    return 1;
  return 0;
}


static void
incr_fea(Int64 fea, TDAG DAG, unsigned decale)
{
  pair_fea fea_p;
  Int64 i, fmod_val;

  bool pol;
  /* if (DAG_is_lit(DAG)) */
  /*   { */
  /*     pol = lit_pol(DAG_to_lit(DAG)); */
  /*     if (pol) */
  /*       fmod_val = fea_mod(fea * prime + 2); */
  /*     else */
  /*       fmod_val = fea_mod(fea * prime + 3); */
  /*   } */
  /* else */
  /*   fmod_val = fea_mod(fea * prime + 4); */


  fmod_val = fea_mod(fea);
  fmod_val = shift(fmod_val, decale);
  /* my_DAG_message("%D : %ld %d\n", DAG, fea, fmod_val); */
  if (model)
    {
      for (i = 0; i < stack_size(model_walk_fea); i++)
        {
          if (stack_get(model_walk_fea, i).feature == fmod_val)
            {
              stack_get(model_walk_fea, i).value++;
#ifdef FEA_VERBOSE
              my_DAG_message("[VALUE]%D : {%ld} %d\n", DAG, fea, stack_get(model_walk_fea, i).value);
#endif
              return;
            }
        }
#ifdef FEA_VERBOSE
      my_DAG_message("[VALUE_FIRST] %D : {%ld} 1\n", DAG, fea);
#endif
      fea_p.feature = fmod_val;
      fea_p.value = 1;
      stack_push(model_walk_fea, fea_p);
    }
  else
    {
      for (i = 0; i < stack_size(DAG_walk_fea); i++)
        {
          if (stack_get(DAG_walk_fea, i).feature == fmod_val)
            {
              stack_get(DAG_walk_fea, i).value++;
#ifdef FEA_VERBOSE
              my_DAG_message("[VALUE] %D : {%ld} %d\n", DAG, fea, stack_get(DAG_walk_fea, i).value);
#endif
              return;
            }
        }
#ifdef FEA_VERBOSE
      my_DAG_message("[VALUE_FIRST] %D : {%ld} 1\n", DAG, fea);
#endif
      fea_p.feature = fmod_val;
      fea_p.value = 1;
      stack_push(DAG_walk_fea, fea_p);
    }
}

/*--------------------------------------------------------------*/
Int64
hash(char *str)
{
    unsigned long hash = 5381;
    int c;
    while (c = *str++)
        hash = ((hash << 5) + hash) + c; 

    return hash;
}

/* Int64 str2md5(const char *str, int length) */
/* { */
/*   int n; */
/*   MD5_CTX c; */
/*   unsigned char digest[16]; */
/*   /\* char *out = (char*)malloc(33); *\/ */
/*   char *out = (char*)malloc(9); */

/*   MD5_Init(&c); */
/*   while (length > 0) */
/*     { */
/*       if (length > 512) */
/*         MD5_Update(&c, str, 512); */
/*       else */
/*         MD5_Update(&c, str, length); */
/*       length -= 512; */
/*       str += 512; */
/*     } */

/*   MD5_Final(digest, &c); */

/*   /\* for (n = 0; n < 16; ++n) { *\/ */
/*   /\*   snprintf(&(out[n*2]), 16*2, "%02x", (unsigned int)digest[n]); *\/ */
/*   /\* } *\/ */
/*   /\** encode on 64 bits instead 128bits **\/ */
/*   for (n = 0; n < 4; ++n) */
/*     snprintf(&(out[n*2]), 4*2, "%02x", (unsigned int)digest[n]); */

/*   /\* printf(" %s %lld\n", *\/ */
/*   /\*        out, (long long int)strtoull(out, NULL, 16));  *\/ */
/*   return (Int64)strtoull(out, NULL, 16); */
/* } */

int randint(int n)
{
  if ((n - 1) == RAND_MAX) 
    return rand();
  else
    {
      // Supporting larger values for n would requires an even more
      // elaborate implementation that combines multiple calls to rand()
      assert (n <= RAND_MAX);
      // Chop off all of the values that would cause skew...
      int end = RAND_MAX / n; // truncate skew
      assert (end > 0);
      end *= n;

      // ... and ignore results from rand() that fall above that limit.
      // (Worst case the loop condition should succeed 50% of the time,
      // so we can expect to bail out of this loop pretty quickly.)
      int r;
      while ((r = rand()) >= end);

      return r % n;
    }
}

static void
insert(Tsymb symb)
{
  char *symb_str;
  resize_signature();
  if (!stack_get(Symb_fea, symb))
    {
      if (symb == LET)
        stack_set(Symb_fea, symb, 179);
      else if (symb == CONNECTOR_NOT)
        stack_set(Symb_fea, symb, 1);
      else if (symb == CONNECTOR_OR)
        stack_set(Symb_fea, symb, 2);
      else if (symb == CONNECTOR_XOR)
        stack_set(Symb_fea, symb, 3);
      else if (symb == CONNECTOR_IMPLIES)
        stack_set(Symb_fea, symb, 5);
      else if (symb == FUNCTION_ITE)
        stack_set(Symb_fea, symb, 7);
      else if (symb == PREDICATE_DISTINCT)
        stack_set(Symb_fea, symb, 13);
      else if (symb ==  CONNECTOR_EQUIV)
        stack_set(Symb_fea, symb, 17);
      else if (symb == CONNECTOR_AND)
        stack_set(Symb_fea, symb, 19);
      else if (symb == PREDICATE_EQ)
        stack_set(Symb_fea, symb, 21);
      else if (DAG_symb_type(symb) == SYMB_VARIABLE)
        stack_set(Symb_fea, symb, 153);
      else if (DAG_symb_type(symb) & SYMB_NUMBER ||
               !strncmp(DAG_symb_name2(symb), "@sk", 3))
        stack_set(Symb_fea, symb, 213);
      else if (!strncmp(DAG_symb_name2(symb), "@vr", 3))
        stack_set(Symb_fea, symb, 243);
      else 
        {
          symb_str = strmake(DAG_symb_name2(symb));
          /* printf("md5(%s) = ", symb_str); */
          /* Int64 h = 11 + randint(1000); */
          /* unsigned i = 0; */
          /* while (i < stack_size(Symb_fea)) */
          /*   for (i = 0; i < stack_size(Symb_fea); i++) */
          /*     if (h == stack_get(Symb_fea, i)) */
          /*       h = 11 + randint(10 + h); */
          /* printf("random(%s) = %d\n", symb_str, h); */

          Int64 h = hash(strmake(symb_str));
          /* Int64 h = str2md5(strmake(symb_str), strlen(symb_str)); */
          stack_set(Symb_fea, symb, h);
        }
    }
}

/*--------------------------------------------------------------*/

#include <string.h>

static void
DAG_encode_fea_aux(TDAG DAG)
{
  unsigned i;
  if (DAG_tmp_bool[DAG])
    return;
  if (DAG_symb(DAG) == LET)
    {
      resize_signature();
      if (!stack_get(Symb_fea, LET))
        stack_set(Symb_fea, LET, 179);
      for (i = 1; i < DAG_arity(DAG); i++, i++)
        {
          DAG_encode_fea_aux(DAG_arg(DAG, i));
          DAG_tmp_bool[DAG] = true;
        }
      DAG_tmp_bool[DAG] = true;
    }
  else if (quantifier(DAG_symb(DAG)))
    {
      if (DAG_symb(DAG) == QUANTIFIER_FORALL)
        {
          resize_signature();
          if (!stack_get(Symb_fea, QUANTIFIER_FORALL))
            stack_set(Symb_fea, QUANTIFIER_FORALL, 323);
        }
      else if (DAG_symb(DAG) == QUANTIFIER_EXISTS)
        {
          resize_signature();
          if (!stack_get(Symb_fea, QUANTIFIER_EXISTS))
            stack_set(Symb_fea, QUANTIFIER_EXISTS, 353);
        }
      DAG_encode_fea_aux(DAG_arg_last(DAG));
      DAG_tmp_bool[DAG] = true;
    }
  else if (DAG_arity(DAG))
    {
      insert(DAG_symb(DAG));
      for (i = 0; i < DAG_arity(DAG); i++)
        {
          DAG_encode_fea_aux(DAG_arg(DAG, i));
          DAG_tmp_bool[DAG] = true;
        }
    }
  else if (DAG_symb_type(DAG_symb(DAG)) == SYMB_VARIABLE)
    {
      resize_signature();
      if (!stack_get(Symb_fea, DAG_symb(DAG)))
        stack_set(Symb_fea, DAG_symb(DAG), 153);
      DAG_tmp_bool[DAG] = true;
    }
  else if (DAG)
    {
      insert(DAG_symb(DAG));
      DAG_tmp_bool[DAG] = true;
    }
}

static void
DAG_translate_fea_length_aux(Tstack_DAG *SDAG, TDAG ROOT, Int64 cur, unsigned decal)
{
  unsigned i;
  TDAG DAG;
  int len = 3;
  Int64 fea_prime = prime, current = cur;
#ifdef FEA_VERBOSE
  my_DAG_message("[LOOP]%D\n", ROOT);
#endif
  for (i = 0; i < stack_size(*SDAG); i++)
    {
      DAG = stack_get(*SDAG, stack_size(*SDAG) - i - 1);
      if (len <= 0)
        {
#ifdef FEA_VERBOSE
          my_DAG_message("[FEA_END] %D %ld [%d] {%d}\n", DAG,  current, i+1, len);
#endif
          incr_fea(current, ROOT, decal);
          return;
        }
#ifdef FEA_VERBOSE
      my_DAG_message("[FEA] %D %ld [%d] {%d}\n", DAG,  current, i+1, len);
#endif
      incr_fea(current, ROOT, decal);
      current = fea_mod(current) * fea_prime + stack_get(Symb_fea, DAG_symb(DAG));
      fea_prime = fea_prime * prime;
      len = len - 1;
    }
#ifdef FEA_VERBOSE
  my_DAG_message("[FEA_END] %D %ld [%d] {%d} \n", ROOT,  current, i+1, len);
#endif
  incr_fea(current, ROOT, decal);
}


char *
extract_args(TDAG DAG)
{
  char buffer[5024];
  /* my_DAG_message("%D\n", DAG); */
  if (DAG_sort_name(DAG_symb_sort(DAG_symb(DAG_arg(DAG, 0)))))
    sprintf (buffer, "%s",
             DAG_sort_name(DAG_symb_sort(DAG_symb(DAG_arg(DAG, 0)))));
  else
    sprintf (buffer, "%s", "BOOL");
  for (unsigned i = 1; i < DAG_arity(DAG); i++)
    if (DAG_sort_name(DAG_symb_sort(DAG_symb(DAG_arg(DAG, i)))))
      sprintf (buffer, "%s -> %s",
               buffer, DAG_sort_name(DAG_symb_sort(DAG_symb(DAG_arg(DAG, i)))));
    else
      sprintf (buffer, "%s -> %s",
               buffer, "BOOL");

  /* my_DAG_message("%s\n", buffer); */
  return strmake(buffer);
}


static void
DAG_translate_fea2_length_aux(Tstack_DAG *SDAG, TDAG ROOT, Int64 cur,
                              unsigned decal, unsigned depth)
{
  unsigned i;
  TDAG DAG;
  int len = 3;
  Int64 fea_prime = 23, current = cur;
  char* sort_name, *symb_sort_name;
  /* my_DAG_message("[B TRANSLAT] %D %ld\n", ROOT, current);  */
  for (i = 0; i < stack_size(*SDAG); i++)
    {
      DAG = stack_get(*SDAG, stack_size(*SDAG) - i - 1);
      /* sort_name = DAG_sort_name(DAG_sort(DAG)); */
      /* symb_sort_name = (DAG_sort_name(DAG_symb_sort(DAG_symb(DAG))))? */
      /*   DAG_sort_name(DAG_symb_sort(DAG_symb(DAG))):extract_args(DAG); */
      if (len <= 0)
        {
          incr_fea(current, ROOT, decal);
          return;
        }
      incr_fea(current, ROOT, decal);
      current = fea_mod(current) * fea_prime + (DAG_arity(DAG) + 
                           depth + len +
                           stack_get(Symb_fea, DAG_symb(DAG)) 
                           /* hash(strmake(symb_sort_name)) + */
                           /* hash(strmake(sort_name)) */);
      len = len - 1;
    }
  /* my_DAG_message("[TRANSLAT] %D %ld\n", ROOT, current);  */
  incr_fea(current, ROOT, decal);
}

static void
DAG_translate_fea_aux(TDAG DAG, Tstack_DAG *SDAG, unsigned decal)
{
  unsigned i;

  DAG_translate_fea_length_aux(SDAG, DAG,
                               stack_get(Symb_fea, DAG_symb(DAG)), decal);
  stack_push(*SDAG, DAG);
  for (i = 0; i < DAG_arity(DAG); i++)
    DAG_translate_fea_aux(DAG_arg(DAG, i), SDAG, decal);
  stack_dec(*SDAG);
}

static void
DAG_translate_fea_withdepth_aux(TDAG DAG, Tstack_DAG *SDAG,
                                unsigned decal, unsigned depth)
{
  unsigned i;
  /* char* sort_name = DAG_sort_name(DAG_sort(DAG)); */
  /* char* symb_sort_name = (DAG_sort_name(DAG_symb_sort(DAG_symb(DAG))))? */
  /*   DAG_sort_name(DAG_symb_sort(DAG_symb(DAG))):extract_args(DAG); */
  /* my_DAG_message("[IN (%d)] %s %D %ld\n", */
  /*                stack_size(*SDAG), */
  /*                symb_sort_name, DAG,stack_get(Symb_fea, DAG_symb(DAG)) ); */
  DAG_translate_fea2_length_aux(SDAG, DAG,
                                ((DAG_arity(DAG)) + (depth) +
                                 stack_get(Symb_fea, DAG_symb(DAG)) 
                                 /* hash(strmake(symb_sort_name)) + */
                                 /* hash(strmake(sort_name)) */),
                                decal, depth);
  stack_push(*SDAG, DAG);
  for (i = 0; i < DAG_arity(DAG); i++)
    DAG_translate_fea_withdepth_aux(DAG_arg(DAG, i), SDAG, decal, depth+1);
  stack_dec(*SDAG);
}

/*--------------------------------------------------------------*/

void
DAG_encode_fea(TDAG DAG)
{
  DAG_tmp_reserve();
  DAG_encode_fea_aux(DAG);
  DAG_tmp_reset_bool(DAG);
  DAG_tmp_release();
}


void
DAG_extra_fea(TDAG DAG, unsigned num)
{
  pair_fea fea_depth, fea_size, fea_num;
  fea_depth.feature = shift(fea_mod(7), 5);
  fea_depth.value = DAG_max_depth(DAG);
  fea_size.feature = shift(fea_mod(8), 5);
  fea_size.value = DAG_size(DAG);
  fea_num.feature = shift(fea_mod(9), 5);
  fea_num.value = num;
  stack_push(DAG_walk_fea, fea_depth);
  stack_push(DAG_walk_fea, fea_size);
  stack_push(DAG_walk_fea, fea_num);
}

void
DAG_custom_fea(unsigned value, unsigned decal)
{
  pair_fea fea_custom;
  fea_custom.feature = shift(fea_mod(decal), 5);
  fea_custom.value = value;
  stack_push(DAG_walk_fea, fea_custom);
}


void
DAG_translate_fea(TDAG DAG, unsigned decal)
{
  Tstack_DAG SDAG;
  stack_INIT(SDAG);
  model = false;
  DAG_tmp_reserve();
#ifdef FEA_VERBOSE
  my_DAG_message("[TRANSLATE] %D \n", DAG);
#endif
  /* DAG_translate_fea_withdepth_aux(DAG, &SDAG, decal, 0); */
  DAG_translate_fea_aux(DAG, &SDAG, decal);
  DAG_tmp_reset_bool(DAG);
  DAG_tmp_release();
  stack_reset(SDAG);
  stack_free(SDAG);
}

void
write_fea(FILE *file_features)
{
  unsigned i;
  Tstack_pair_fea tmp;
  stack_INIT(tmp);
  /* printf("[WRITE]%d\n", stack_size(model_walk_fea)); */
  for (i = 0; i < stack_size(model_walk_fea); i++)
    stack_push(tmp, stack_get(model_walk_fea, i));
  for (i = 0; i < stack_size(DAG_walk_fea); i++)
    stack_push(tmp, stack_get(DAG_walk_fea, i));
  stack_sort(tmp, compare_by_fea);
  uniq(tmp);
  if (!stack_size(tmp))
    fprintf(file_features, "\n");
  for (i = 0; i < stack_size(tmp); i++)
    {
      if (i == stack_size(tmp) - 1)
        {
          fprintf(file_features, "%lld:%d\n",
                  stack_get(tmp, i).feature, stack_get(tmp, i).value);
          /* printf("%lld:%d\n", */
          /*        stack_get(tmp, i).feature, stack_get(tmp, i).value); */
        }
      else
        {
          fprintf(file_features, "%lld:%d ",
                  stack_get(tmp, i).feature, stack_get(tmp, i).value);
          /* printf("%lld:%d ", */
          /*        stack_get(tmp, i).feature, stack_get(tmp, i).value); */
        }
    }
  stack_reset(tmp);
  stack_reset(DAG_walk_fea);
  stack_free(tmp);
}

void
write_instance_fea(FILE *file_features)
{
  unsigned i;
  Tstack_pair_fea tmp;
  stack_INIT(tmp);
  fprintf(file_features, "0 ");
  for (i = 0; i < stack_size(model_walk_fea); i++)
    stack_push(tmp, stack_get(model_walk_fea, i));
  for (i = 0; i < stack_size(DAG_walk_fea); i++)
    stack_push(tmp, stack_get(DAG_walk_fea, i));
  stack_sort(tmp, compare_by_fea);
  uniq(tmp);
  if (!stack_size(tmp))
    fprintf(file_features, "\n");
  for (i = 0; i < stack_size(tmp); i++)
    {
      if (i == stack_size(tmp) - 1)
        {
          fprintf(file_features, "%lld:%d\n",
                  stack_get(tmp, i).feature, stack_get(tmp, i).value);
          /* printf("%lld:%d\n", */
          /*        stack_get(tmp, i).feature, stack_get(tmp, i).value); */
        }
      else
        {
          fprintf(file_features, "%lld:%d ",
                  stack_get(tmp, i).feature, stack_get(tmp, i).value);
          /* printf("%lld:%d ", */
          /*        stack_get(tmp, i).feature, stack_get(tmp, i).value); */
        }

    }
  stack_reset(tmp);
  stack_reset(DAG_walk_fea);
  stack_free(tmp);
}

void
write_stats_fea(FILE *file_features,
                unsigned nb_sk, unsigned nb_skolem_round,
                unsigned depth, unsigned nb_triggers, unsigned cc_pol, unsigned cc_size,
                unsigned cc_pred, unsigned nb_terms)
{
  fprintf(file_features, "1:%d 2:%d 3:%d 4:%d 5:%d 6:%d 7:%d 8:%d\n",
          nb_sk, nb_skolem_round, depth, nb_triggers, cc_pol, cc_size, cc_pred, nb_terms);
}



#include <features.h>
#include "xgboost_classifier.h"
#include "xgboost_classifier2.h"
#include <math.h>

float *data;
unsigned *data_imp;
float sigmoid(float x)
{
  float exp_value;
  float return_value;
  /*** Exponential calculation ***/
  exp_value = exp((double) -x);

  /*** Final sigmoid value ***/
  return_value = 1 / (1 + exp_value);

  return return_value;
}

float
predict(float *samples, unsigned nb_tree)
{

  float result;
  if (option_learning_native_2)
    result= xgb_classify_2(samples, nb_tree);
  else
    result= xgb_classify(samples, nb_tree);
  /* printf("[SUM] %f\n", result); */
  return sigmoid(result);
  /* return /\* exp *\/(result); */
}

#include "statistics.h"
extern unsigned timer_predictor;
static unsigned features_importance = 0;
static float threshold = 0.0;

#include <float.h>

#include <math.h>
inline
float root(int input, int n)
{
  return (pow(input, 1./n));
}

bool stats_fea(unsigned fea)
{
  return fea == 1310701 || fea == 1310705 || fea == 1310707
    || fea == 1310717 || fea == 1310713 || fea == 1310709 ||
    fea == 1310703 || fea == 1310704;
}

unsigned max_fea = 0;

float
get_prediction(unsigned nb_tree, unsigned param)
{
  unsigned i, tmp_f_imp, nb_unknown_fea = 0, nb_fea = 0, is_imp = 0, nb_imp = max_fea/5;
  float pred, ratio_unknown = 0.0, ratio_feat_imp = 0.0;
  Tstack_pair_fea tmp;
  bool geom = false, ratio = false;
  stack_INIT(tmp);
  tmp_f_imp = features_importance;
  /** IMPORTANT INITIALISE TO NAN **/
  for (i = 0; i < stack_size(DAG_walk_fea); i++)
    {
      if (stack_get(DAG_walk_fea, i).feature > 2310705)
        {
          printf( "%lld\n", stack_get(DAG_walk_fea, i).feature);
          continue;
        }
      else if (stack_get(DAG_walk_fea, i).feature < 0 )
        {
          printf( "%lld\n", stack_get(DAG_walk_fea, i).feature);
          continue;
        }
      else if (isnan(data[stack_get(DAG_walk_fea, i).feature]))
        {
          data[stack_get(DAG_walk_fea, i).feature] = (float)stack_get(DAG_walk_fea, i).value;
        }
      else
        data[stack_get(DAG_walk_fea, i).feature] += (float)stack_get(DAG_walk_fea, i).value;

      /* my_DAG_message("fea : %d value: %d\n", */
      /*                stack_get(DAG_walk_fea, i).feature, data_imp[stack_get(DAG_walk_fea, i).feature]); */
      if (ratio && !geom)
        {
          if (!stats_fea(stack_get(DAG_walk_fea, i).feature))
            {
              features_importance += data_imp[stack_get(DAG_walk_fea, i).feature];
              if (nb_imp <= data_imp[stack_get(DAG_walk_fea, i).feature])
                is_imp++;
              nb_fea++;
            }
          if (!data_imp[stack_get(DAG_walk_fea, i).feature])
            nb_unknown_fea++;
        }
      else
        features_importance += data_imp[stack_get(DAG_walk_fea, i).feature];
      /* if (i == stack_size(DAG_walk_fea) - 1) */
      /*   { */
      /*     printf("%lld:%d\n", */
      /*            stack_get(DAG_walk_fea, i).feature, stack_get(DAG_walk_fea, i).value); */
      /*   } */
      /* else */
      /*   { */
      /*     printf("%lld:%d ", */
      /*            stack_get(DAG_walk_fea, i).feature, stack_get(DAG_walk_fea, i).value); */
      /*   } */
    }

  /* stats_timer_start(timer_predictor); */
  if (geom)
    ratio_feat_imp = root(features_importance,
                          (stack_size(model_walk_fea) + stack_size(DAG_walk_fea)));
  else
    ratio_feat_imp = (float)features_importance /
      (float)(stack_size(model_walk_fea) + stack_size(DAG_walk_fea));
  ratio_unknown = (float)nb_unknown_fea/(float)nb_fea;
  if ((!ratio && geom && ratio_feat_imp > threshold) ||
      (!ratio && !geom && ratio_feat_imp >  param * 80) ||
      (ratio && !geom &&
       ((ratio_unknown <  0.1 && ratio_feat_imp > threshold) ||
        (is_imp >=  param) )))
    {
      pred =  predict(data, nb_tree);
      /* printf("features_rate %f limit : %f %d %f\n",  ratio_feat_imp, threshold_tmp, */
      /*        (stack_size(model_walk_fea) + stack_size(DAG_walk_fea)), pred); */
    }
  else
    pred = 1;
  /* printf("features_rate %f limit : %f %d nb_fea : %d nb unknown : %d ratio %f %f max :%d imp %d %d\n", */
  /*        ratio_feat_imp, threshold, */
  /*        (stack_size(model_walk_fea) + stack_size(DAG_walk_fea)), */
  /*        nb_fea, nb_unknown_fea, (float)nb_unknown_fea/(float)nb_fea, pred, */
  /*        max_fea, is_imp, nb_imp); */

  /* stats_timer_stop(timer_predictor); */
  features_importance = tmp_f_imp;
  for (i = 0; i < stack_size(DAG_walk_fea); i++)
    {
      if (data[stack_get(DAG_walk_fea, i).feature] - (float)stack_get(DAG_walk_fea, i).value > 0)
        data[stack_get(DAG_walk_fea, i).feature] -= (float)stack_get(DAG_walk_fea, i).value;
      else
        data[stack_get(DAG_walk_fea, i).feature] = NAN;
    }

  stack_reset(tmp);
  stack_reset(DAG_walk_fea);
  stack_free(tmp);
  return pred;
}

void
init_model_stack(TDAG* PDAG, unsigned size)
{
  unsigned i;
  stack_INIT(model_symb_DAG);
  stack_INIT(model_terms_DAG);
  for (i = 0; i < size; i++)
    {
      DAG_all_symbols_aux(PDAG[i], true);
      DAG_all_term_aux(PDAG[i], true);
    }
}




void
reset_model()
{
  stack_reset(model_walk_fea);
}

static unsigned max_depth_m = 0;
static unsigned size_term_m = 0;
static unsigned backtrack_q = 0;
static unsigned id_depth, id_size, id_nblits;
/* static unsigned id_depth_q, id_size_q, id_nblits_q; */

void
add_to_model(TDAG DAG, unsigned indice, unsigned decal, unsigned qf)
{
  unsigned tmp;
  Tstack_DAG SDAG;
  stack_INIT(SDAG);
  model = true;
  if (!indice && !decal && backtrack_q)
    stack_dec_n(model_walk_fea, backtrack_q);
  /* DAG_encode_fea(DAG); */
  DAG_tmp_reserve();
  DAG_translate_fea_aux(DAG, &SDAG, decal);
  DAG_tmp_reset_bool(DAG);
  DAG_tmp_release();
  stack_reset(SDAG);
  if (!indice && !decal)
    {
      pair_fea fea_depth, fea_size, fea_nblits;
      tmp = DAG_max_depth(DAG);
      max_depth_m = (max_depth_m < tmp)?tmp:max_depth_m;
      size_term_m += DAG_size(DAG);

      fea_depth.feature = shift(fea_mod(1*qf), 5);
      fea_depth.value =  max_depth_m;
      fea_size.feature = shift(fea_mod(2*qf), 5);
      fea_size.value = size_term_m;
      fea_nblits.feature = shift(fea_mod(3*qf), 5);
      fea_nblits.value = 1;

      stack_push(model_walk_fea, fea_depth);
      id_depth = stack_size(model_walk_fea) - 1;
      stack_push(model_walk_fea, fea_size);
      id_size = stack_size(model_walk_fea) - 1;
      stack_push(model_walk_fea, fea_nblits);
      id_nblits = stack_size(model_walk_fea) - 1;
    }
  else
    {
      tmp = DAG_max_depth(DAG);
      max_depth_m = (max_depth_m < tmp)?tmp:max_depth_m;
      size_term_m += DAG_size(DAG);
      stack_get(model_walk_fea, id_depth).value =  max_depth_m;
      stack_get(model_walk_fea, id_size).value = size_term_m;
      stack_get(model_walk_fea, id_nblits).value++;
    }
  model = false;
  stack_free(SDAG);
}

void
extra_fea_model(unsigned size, unsigned qf)
{
  pair_fea fea_depth, fea_size, fea_nblits;
  fea_depth.feature = shift(fea_mod(1*qf), 5);
  fea_depth.value =  max_depth_m;
  fea_size.feature = shift(fea_mod(2*qf), 5);
  fea_size.value = size_term_m;
  fea_nblits.feature = shift(fea_mod(3*qf), 5);
  fea_nblits.value = size;

  stack_push(model_walk_fea, fea_depth);
  stack_push(model_walk_fea, fea_size);
  stack_push(model_walk_fea, fea_nblits);
}

void
init_translate_model(TDAG* PDAG, unsigned size, unsigned decal, unsigned qf)
{
  unsigned i, max = 0, tmp, size_term = 0;
  pair_fea fea_depth, fea_size, fea_nblits;
  Tstack_DAG SDAG;
  stack_INIT(SDAG);
  model = true;
  backtrack_q = size;
  for (i = 0; i < size; i++)
    {
      /* DAG_encode_fea(PDAG[i]); */
      DAG_tmp_reserve();

      /* stats_timer_start(timer_predictor); */
      DAG_translate_fea_aux(PDAG[i], &SDAG, decal);
      /* stats_timer_stop(timer_predictor); */
      DAG_tmp_reset_bool(PDAG[i]);
      DAG_tmp_release();

      stack_reset(SDAG);

      tmp = DAG_max_depth(PDAG[i]);
      max = (max < tmp)?tmp:max;
      size_term += DAG_size(PDAG[i]);
    }
  /* max_depth_q = (max_depth_q < max)?tmp:max_depth_q; */
  /* size_term_q += size_term; */
  fea_depth.feature = shift(fea_mod(1*qf), 5);
  fea_depth.value = max;
  fea_size.feature = shift(fea_mod(2*qf), 5);
  fea_size.value = size_term;
  fea_nblits.feature = shift(fea_mod(3*qf), 5);
  fea_nblits.value = size;
  
  stack_push(model_walk_fea, fea_depth);
  stack_push(model_walk_fea, fea_size); 
  stack_push(model_walk_fea, fea_nblits);
  features_importance = 0;
  for (i = 0; i < stack_size(model_walk_fea); i++)
    {
      if (stack_get(model_walk_fea, i).feature > 2310705)
        {
          printf( "%lld\n", stack_get(model_walk_fea, i).feature);
          continue;
        }
      else if (stack_get(model_walk_fea, i).feature < 0 )
        {
          printf( "%lld\n", stack_get(model_walk_fea, i).feature);
          continue;
        }
      else if (isnan(data[stack_get(model_walk_fea, i).feature]))
        {
          data[stack_get(model_walk_fea, i).feature] = (float)stack_get(model_walk_fea, i).value;
        }
      else
        data[stack_get(model_walk_fea, i).feature] += (float)stack_get(model_walk_fea, i).value;
      features_importance += data_imp[stack_get(model_walk_fea, i).feature];
      /* if (i == stack_size(model_walk_fea) - 1) */
      /*   { */
      /*     printf("%lld:%d\n", */
      /*            stack_get(model_walk_fea, i).feature, stack_get(model_walk_fea, i).value); */
      /*   } */
      /* else */
      /*   { */
      /*     printf("%lld:%d ", */
      /*            stack_get(model_walk_fea, i).feature, stack_get(model_walk_fea, i).value); */
      /*   } */
    }

  model = false;
  stack_free(SDAG);
}


void
init_fea()
{
  unsigned i, nb_zero = 0;
  MY_MALLOC(data, sizeof(float) * FEAT_SIZE);
  MY_MALLOC(data_imp, sizeof(unsigned) * FEAT_SIZE);
  stack_INIT(Symb_fea);
  stack_INIT(DAG_walk_fea);
  stack_INIT(model_walk_fea);
  for (i = 0; i < FEAT_SIZE; i++)
    {
      data[i] = NAN;
      data_imp[i] = 0;
    }

  for (i = 0; i < 5000; i++)
    {
      if (option_learning_native_2)
        {

          data_imp[features_2[i]] = value_fea_2[i];
          if (!stats_fea(features_2[i]))
            threshold += value_fea_2[i];
          if (value_fea_2[i] > 10)
            nb_zero++;
          if (!stats_fea(features_2[i]) && value_fea_2[i] > max_fea)
            max_fea = value_fea_2[i];
        }
      else
        {
          data_imp[features[i]] = value_fea[i];
          if (!stats_fea(features[i]))
            threshold += value_fea[i];
          if (value_fea[i] > 10)
            nb_zero++;
          if (!stats_fea(features[i]) && value_fea[i] > max_fea)
            max_fea = value_fea[i];
        }
    }
  threshold = threshold / (5000.0 - 8 - nb_zero);
}

void
free_fea()
{
  free(data);
  stack_reset(Symb_fea);
  stack_reset(DAG_walk_fea);
  stack_reset(model_walk_fea);
  stack_free(Symb_fea);
  stack_free(DAG_walk_fea);
  stack_free(model_walk_fea);
}


void
free_model_stack()
{
  stack_reset(model_terms_DAG);
  stack_reset(model_symb_DAG);
  free(model_terms_DAG);
  free(model_symb_DAG);

}

