#ifndef XGBOOST_CLASSIFIER_H
#define XGBOOST_CLASSIFIER_H

float xgb_classify(float *sample, unsigned nb_trees);
extern unsigned features[5000];
extern unsigned value_fea[5000];
#endif
