#include "context-handling.h"

Tcontext context = {NULL, 0, NULL};
