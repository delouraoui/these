#ifndef __ML_H
#define __ML_H

#include "unify.h"

/** \brief options to print statistics report on exit */
extern char *direname;
extern char *resname;
extern unsigned roundi;
extern unsigned model_ni;
extern long long nb_instances;
extern long long nb_instances_conflict;
extern long long nb_instances_gen;
extern unsigned nb_edges;
extern unsigned nb_nodes;
extern char file_results[512];
extern unsigned timer_predictor;
extern unsigned nb_skolem;
extern Tstack_instance_round conflicting_instances;
extern Tstack_instance_round delay_round_unifier;
extern Tstack_instance_round delay_analyse_round_unifier;
extern unsigned strategie;

void veriT_learning(void);
void stat_learn_instances_print();
void veriT_init_file(char * filename);
void veriT_extract_features_to_xgb_v2(void);
void veriT_extract_conflicting_instances(void);
void ml_init(void);
void ml_done(void);

#endif /* __ML_H */
