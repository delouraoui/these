
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "config.h"

#include "general.h"
#include "h-util.h"
#include "hashmap.h"
#include "options.h"
#include "stack.h"
#include "statistics.h"
#include "response.h"

#include "smtfun.h"

#include "DAG.h"
#include "DAG-arith.h"
#include "DAG-ptr.h"
#include "DAG-prop.h"
#include "DAG-print.h"
#include "DAG-symb-DAG.h"
#include "HOL.h"
#include "proof.h"
#include "simplify.h"
#include "veriT.h"
#include "veriT-state.h"
#include "output-infos.h"

#include "dbg-trigger.h"
#include "HOL.h"
#include "DAG-subst.h"
#define yylineno yy2lineno

extern int yylineno;

#define ptr_of_sort(s) DAG_ptr_of_sort(s)
#define sort_of_ptr(s) DAG_sort_of_ptr(s)

enum Tkw {
  KW_NONE = 0,
  /* SMT-LIB 2.0 options and info keywords */
  KW_ALL_STATISTICS,
  KW_AUTHORS,
  KW_CATEGORY,
  KW_DIAGNOSTIC_OUTPUT_CHANNEL,
  KW_ERROR_BEHAVIOR,
  KW_EXPAND_DEFINITIONS,
  KW_INTERACTIVE_MODE,
  KW_LICENSE,
  KW_NAME,
  KW_NOTES,
  KW_PRINT_SUCCESS,
  KW_PRODUCE_ASSIGNMENTS,
  KW_PRODUCE_MODELS,
  KW_PRODUCE_PROOFS,
  KW_PRODUCE_UNSAT_CORES,
  KW_RANDOM_SEED,
  KW_REASON_UNKNOWN,
  KW_REGULAR_OUTPUT_CHANNEL,
  KW_SMT_LIB_VERSION,
  KW_SOURCE,
  KW_STATUS,
  KW_VERBOSITY,
  KW_VERSION,
  /* veriT own options */
  KW_PRINT_REPORT,
  KW_VERIT_PROOF_FORMAT,
  /* dummy value */
  KW_SIZE
};

struct kw_name {
  enum Tkw kw;
  char * name;
};

struct kw_name kw_name_table [] =
  {
    /* standard SMT2 identifiers */
    {KW_NONE, "none"},
    {KW_ALL_STATISTICS, ":all-statistics"},
    {KW_AUTHORS, ":authors"},
    {KW_CATEGORY, ":category"},
    {KW_DIAGNOSTIC_OUTPUT_CHANNEL, ":diagnostic-output-channel"},
    {KW_ERROR_BEHAVIOR, ":error-behavior"},
    {KW_EXPAND_DEFINITIONS, ":expand-definitions"},
    {KW_INTERACTIVE_MODE, ":interactive-mode"},
    {KW_NAME, ":name"},
    {KW_LICENSE, ":license"},
    {KW_NOTES, ":notes"},
    {KW_PRINT_SUCCESS, ":print-success"},
    {KW_PRODUCE_ASSIGNMENTS, ":produce-assignments"},
    {KW_PRODUCE_MODELS, ":produce-models"},
    {KW_PRODUCE_PROOFS, ":produce-proofs"},
    {KW_PRODUCE_UNSAT_CORES, ":produce-unsat-cores"},
    {KW_RANDOM_SEED, ":random-seed"},
    {KW_REASON_UNKNOWN, ":reason-unknown"},
    {KW_REGULAR_OUTPUT_CHANNEL, ":regular-output-channel"},
    {KW_SMT_LIB_VERSION, ":smt-lib-version"},
    {KW_SOURCE, ":source"},
    {KW_STATUS, ":status"},
    {KW_VERBOSITY, ":verbosity"},
    {KW_VERSION, ":version"},

    /* specific to veriT */
    {KW_PRINT_REPORT, ":print-report"},
    {KW_VERIT_PROOF_FORMAT, ":veriT-proof-format"}

  };

Tstatus smt2_status = UNDEF; /**< status as given in the input */

/* ------------------------------------------------------- */
/*                      SMT2 solver state                  */
/* ------------------------------------------------------- */

bool smt2_check_sat_done = false;
bool smt2_logic_set = false;


/* ------------------------------------------------------- */
/*                      SMT2 solver options                */
/* ------------------------------------------------------- */

bool   smt2_print_success;                /**< required SMT2 option */
char * smt2_diagnostic_output_channel;    /**< required SMT2 option */
char * smt2_regular_output_channel;       /**< required SMT2 option */
bool   smt2_interactive_mode;             /**< optional SMT2 option */
#ifdef PROOF
bool   smt2_produce_proofs = false;       /**< optional SMT2 option */
bool   smt2_produce_unsat_cores = false;  /**< optional SMT2 option */
#endif

#if STATS_LEVEL > 1
static unsigned stat_nb_nodes, stat_nb_nodes_tree, stat_nb_atoms;
#endif
extern bool DT_active;
static unsigned stat_result;

extern bool full_app;
extern bool lazy_app;
Tlist constraintes = NULL;
/*
  --------------------------------------------------------------
  help functions
  --------------------------------------------------------------
*/

static enum Tkw
defstring(char * str)
{
  int i;
  for (i = 1; i < KW_SIZE; ++i)
    if (!strcmp(kw_name_table[i].name, str))
      return kw_name_table[i].kw;
  return KW_NONE;
}

static char *
smt2_status_str(int status)
{
  switch (status)
    {
    case UNDEF: return "unknown";
    case SAT: return "sat";
    case UNSAT: return "unsat";
    default:
      veriT_error("unknown status %i", status);
      return "";
    }
}

/*--------------------------------------------------------------*/

/* PF returns 1 if a decimal, 0 if integer, error if none of both */
static int
check_decimal(char * str)
{
  if (!isdigit(*str))
    veriT_error("ill-formed on line %d", yylineno);
  ++str;
  while (isdigit(*str)) ++str;
  if (*str == 0)
    return 0;
  if (*str != '.')
    veriT_error("ill-formed decimal on line %d", yylineno);
  ++str;
  if (!isdigit(*str))
    veriT_error("ill-formed decimal on line %d", yylineno);
  ++str;
  while (isdigit(*str)) ++str;
  if (*str == 0)
    return 1;
  veriT_error("ill-formed decimal on line %d", yylineno);
  return 0;
}

/*--------------------------------------------------------------*/

static int
check_binary(char * str)
{
  while (*str == '0' || *str == '1') str++;
  if (*str == 0)
    return 1;
  veriT_error("ill-formed binary on line %d", yylineno);
  return 0;
}

/*--------------------------------------------------------------*/

static int
check_hex(char * str)
{
  while (isxdigit(*str)) str++;
  if (*str == 0)
    return 1;
  veriT_error("ill-formed hexadecimal on line %d", yylineno);
  return 0;
}

/*--------------------------------------------------------------*/

static int
check_str(char * str)
{
  while (*str != '\0' && *str != '"')
    if (*str == '\\')
      str += 2;
    else
      str++;
  if (*str == '"' && *(str + 1) == '\0')
    return 1;
  veriT_error("ill-formed string on line %d", yylineno);
  return 0;
}

/*--------------------------------------------------------------*/

static void
check_protected_symbol(char * str)
{
  if (!strncmp(str, "veriT__", 7) ||
      !strncmp(str, "?veriT__", 8))
    veriT_error("reserved symbol used on line %d", yylineno);
}

/*--------------------------------------------------------------*/
int
arity_of_sort(char *name)
{
  int arity = 0,level = 0,i = 0;
  for(i=1; i <= strlen(name); i++ )
    {
      if(name[i] == '(') level = level + 1;
      if(name[i] == ')') level = level - 1;
      if(name[i]=='>' && level == 0)
        arity = arity + 1;
    }
  if (!arity)
    return arity;
  return arity+1;
}

/*
  --------------------------------------------------------------
  symbol finding functions
  --------------------------------------------------------------
*/

/* PF this section is necessary because quantifiers and let may
   define atomic terms */

Thashmap hashmap_str = NULL;

static unsigned
hash_function(char * str)
{
  unsigned hash = hash_one_at_a_time(str);
  return hash_one_at_a_time_inc_end(hash);
}

/*--------------------------------------------------------------*/

static Tsigned
hash_str_equal(char * str1, char * str2)
{
  return !strcmp(str1, str2);
}

/*--------------------------------------------------------------*/

static void
hash_key_free(char * str)
{
  /* free(str); */
#ifdef PEDANTIC
  printf("%p\n", str);
#endif
}

/*--------------------------------------------------------------*/

static void
hash_value_free(Tstack_symb stack_symb)
{
  if (stack_symb)
    stack_free(stack_symb);
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine
   add a link for str to symb in LIFO style
   \param str a string for the symbol
   \param symb the symbol to link to str
*/
static void
declare_str(char * str, Tsymb symb)
{
  Tstack_symb stack_symb;
  Tstack_symb *Pstack_symb = (Tstack_symb *) hashmap_lookup(hashmap_str, str);
  if (Pstack_symb)
    {
      assert(*Pstack_symb);
      stack_push(*Pstack_symb, symb);
      return;
    }
  stack_INIT_s(stack_symb, 1);
  stack_push(stack_symb, symb);
  hashmap_insert(hashmap_str, str, stack_symb);
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine
   remove up link for str (should be to symb)
   \param str a string for the symbol
   \param symb the symbol to unlink to str */
static void
undeclare_str(char * str, Tsymb symb)
{
  Tstack_symb *Pstack_symb = (Tstack_symb *) hashmap_lookup(hashmap_str, str);
  assert(Pstack_symb && *Pstack_symb && stack_size(*Pstack_symb) &&
         stack_top(*Pstack_symb) == symb);
  stack_dec(*Pstack_symb);
  if (!stack_size(*Pstack_symb))
    hashmap_remove(hashmap_str, str);
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine
   \brief find symbol linked to str
   \param str a string for the symbol
   \return the symbol linked to str */
static Tsymb
lookup_str(char * str)
{
  Tstack_symb *Pstack_symb = (Tstack_symb *) hashmap_lookup(hashmap_str, str);
  if (!Pstack_symb)
    return DAG_SYMB_NULL;
  assert(*Pstack_symb && stack_size(*Pstack_symb));
  return stack_top(*Pstack_symb);
}

/*
  --------------------------------------------------------------
  Commands
  --------------------------------------------------------------
*/

/**
   \brief macro responsible for emitting an error message and exiting the
   program if the command (check-sat) has been previously issued.
*/

#define VERIFY_CHECK_SAT                        \
  if (smt2_check_sat_done)                      \
    veriT_error("unsupported");

#define VERIFY_LOGIC_NOT_SET                    \
  if (!smt2_logic_set)                          \
    veriT_error("set-logic not issued");

#define VERIFY_LOGIC_SET                        \
  if (smt2_logic_set)                           \
    veriT_error("set-logic already issued");

#define PRINT_SUCCESS                           \
  if (smt2_print_success)                       \
    veriT_out("success");
#define PRINT_UNSUPPORTED                       \
  veriT_out("unsupported");

void
smt2_set_logic(char * symbol)
{
  VERIFY_LOGIC_SET;
  VERIFY_CHECK_SAT;
  veriT_logic(symbol);
  free(symbol);
  smt2_logic_set = true;
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

/* PF (declare-sort Array 2) */
void
smt2_declare_sort(char * symbol, char * numeral)
{
  unsigned arity;
  long int tmp;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  check_protected_symbol(symbol);
  tmp = strtol(numeral, NULL, 10);
  if (tmp > UINT_MAX)
    veriT_error("smt2_declare_sort: arity too large\n");
  arity = (unsigned) tmp;
  if (DAG_sort_lookup(symbol))
    veriT_error("line %d: redefining sort %s\n", yylineno, symbol);
  if (arity > 0)
    DAG_sort_new_param(symbol, arity);
  else
    DAG_sort_new(symbol, 0, NULL);
  free(symbol);
  free(numeral);
  PRINT_SUCCESS;
}

void
smt2_declare_sort_s(char * symbol, char * numeral)
{
  unsigned arity;
  long int tmp;
  Tsort s;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  check_protected_symbol(symbol);
  tmp = strtol(numeral, NULL, 10);
  if (tmp > UINT_MAX)
    veriT_error("smt2_declare_sort: arity too large\n");
  arity = (unsigned) tmp;
  if (DAG_sort_lookup(symbol))
    veriT_error("line %d: redefining sort %s\n", yylineno, symbol);
  if (arity > 0)
    s = DAG_sort_new_param(symbol, arity);
  else
    s = DAG_sort_new(symbol, 0, NULL);
  /* my_DAG_message("sort %S \n", s); */
  DAG_sort_stack->data[s].polymorphic = true;
  DAG_sort_stack->data[s].datatype = true;
  /* free(symbol); */
  free(numeral);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_declare_zero_sort(char * symbol)
{
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  check_protected_symbol(symbol);
  if (DAG_sort_lookup(symbol))
    veriT_error("line %d: redefining sort %s\n", yylineno, symbol);
  DAG_sort_new(symbol, 0, NULL);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

/* PF (define-sort Integer_Array_of_List (Integer List) Array) */
void
smt2_define_sort(char * symbol, Tlist symbol_list, Tsort sort)
{
  unsigned i, arity;
  Tsort * sub;
  size_t arity_alloc;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  check_protected_symbol(symbol);
  arity = list_length(symbol_list);
  arity_alloc =  arity * sizeof(Tsort);
  MY_MALLOC(sub,arity_alloc);
  for (i = 0; i < arity; ++i, symbol_list = list_cdr(symbol_list))
    {
      char * symbol = (char *) list_car(symbol_list);
      Tsort sort2 = DAG_sort_lookup(symbol);
      if (!sort2)
        veriT_error("unknown sort %s on line %d.", symbol, yylineno);
      sub[i] = sort2;
    }
  DAG_sort_new_inst(symbol, sort, arity, sub);
  list_apply(symbol_list, free);
  list_free(&symbol_list);
  free(symbol);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_declare_poly_fun(char * symbol, Tlist sort_list1,
                      Tlist sort_list2, Tsort sort)
{
  unsigned i, arity, type;
  Tsort *sub;
  size_t arity_alloc;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  type = (sort == SORT_BOOLEAN) ? SYMB_PREDICATE : 0;
  check_protected_symbol(symbol);
  if (!sort_list2)
    {
      DAG_symb_new(symbol, type, sort);
      free(symbol);
      return;
    }
  arity = list_length(sort_list2);
  arity_alloc = (arity + 1) * sizeof(Tsort);
  MY_MALLOC(sub, arity_alloc);
  for (i = 0; i < arity; i++, sort_list2 = list_cdr(sort_list2))
    sub[i] = sort_of_ptr(list_car(sort_list2));
  sub[i] = sort;
  DAG_symb_new(symbol, type, DAG_sort_new(NULL, arity + 1, sub));
  free(symbol);
  list_free(&sort_list1);
  list_free(&sort_list2);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

size_t
size_of_sort_str(Tsort *sub,int arity,int is_decl)
{
  size_t size = 0;
  int i, j;
  char *currentType;
  Tsort pending_type;
  Tstack_DAG stack_sort;
  stack_INIT(stack_sort);

  for (i= 0;  i <= arity; i++){
    if(is_decl == 1 || i < arity)
      {
        currentType = DAG_sort_name(sub[i]);
        if(!currentType)
          {
            stack_push(stack_sort, sub[i]);
            while(stack_size(stack_sort))
              {
                pending_type = stack_pop(stack_sort);
                if(DAG_sort_name(pending_type))
                  {
                    size +=  strlen(DAG_sort_name(pending_type));
                  }
                else
                  {
                    for(j = 0; j < DAG_sort_arity(pending_type); j++)
                      stack_push(stack_sort , DAG_sort_sub(pending_type, j));
                  }
              }
          }
        if(currentType && strstr(currentType,"->"))
          size +=  strlen(currentType) + 2;
        else if(currentType)
          size +=  strlen(currentType);
      }
  }
  stack_free(stack_sort);
  return size;
}

/*--------------------------------------------------------------*/

size_t
size_of_sort_str_param(Tsort *sub, Tsort sort, int arity)
{
  size_t size = 0;
  int i;
  char *currentType;
  for (i= 0;  i < arity; i++)
    {
      currentType = DAG_sort_name(sub[i]);
      size +=  strlen(currentType);
    }
  size +=  strlen(DAG_sort_name(sort));
  return size;
}

/*--------------------------------------------------------------*/

bool
is_functional_argument(char *name, int i, int size)
{
  int open = 1;
  for(i = i; i <= size;i++ )
    {
      if(name[i] == '(') open = open + 1;
      if(name[i] == ')') open = open - 1;
      if(open == 0) break;
    }
  if(i+2 < size)
    {
      if(name[i+2] == '-') return true;
      return false;
    }
  return false;
}

/*--------------------------------------------------------------*/

bool
not_covered(char *name, int size)
{
  int open = 0, i;
  for(i = 0; i < size; i++ )
    {
      if(name[i] == '(') open = open + 1;
      if(name[i] == ')') open = open - 1;
      /* printf("%c %d\n", name[i], open); */
      if (!open && i < size - 1)
        {
          open = - 1;
          break;
        }
    }
  if (open == - 1)
    return true;
  return false;
  /* printf("{not covered} %s [%d]\n", name, open); */
  /* if(name[0] == '(' && name[size-1] == ')') */
  /*   return false; */
  /* return true; */
}

/*--------------------------------------------------------------*/

bool
is_return(char *name, int i, int size)
{
  int open = 1;
  for(i = i; i <= size;i++ )
    {
      if(name[i] == '(') open = open + 1;
      if(name[i] == ')') open = open - 1;
      if(open == 0) break;
    }
  for(i = i; i <= size;i++ )
    if(name[i] == '-') return false;
  return true;
}

/*--------------------------------------------------------------*/
/** flattening Type **/
void
flatting_functional_sort(char *nameP)
{
  char *tmp = NULL,*name = NULL;
  int k, i = 0, j,pos = 0, contnu = 1, erease = 0 ;
  size_t str_size = (strlen(nameP)+1) * sizeof(char);
  MY_MALLOC(tmp, str_size);
  MY_MALLOC(name, str_size);
  strcpy(name,nameP);
  while(contnu)
    {
      contnu = 0;
      while(i <= strlen(name))
        {
          tmp[pos] = name[i];
          if(name[i]=='>')
            {
              if(name[i + 2] == '(' &&
                 name[i + 3] != '(' &&
                 !is_functional_argument(name, i + 3, strlen(name)))
                {
                  /* printf("[NOFLAT] %s\n", name); */
                  contnu = 1;
                  /** We retake the space **/
                  pos = pos + 1;
                  tmp[pos] = name[i+1];
                  pos = pos + 1;
                  int open = 1;
                  for(j=i+3; j < strlen(name); j++)
                    {
                      if(name[j] == '(') open = open + 1;
                      if(name[j] == ')') open = open - 1;
                      if(open == 0) break;
                      tmp[pos] = name[j];
                      pos = pos + 1;
                    }
                  i = j + 1;
                }
              /** ( Int -> ... ((Int -> ...) ->  )**/
              else if(name[i+2] == '(' &&
                      name[i+3] == '(' &&
                      is_return(name,i+3,strlen(name)))
                {
                  /* printf("[FLAT] %s %d\n", name, i); */
                  erease = erease + 1;
                  pos = pos + 1;
                  i = i + 1;
                }
              else
                {
                  pos = pos + 1;
                  i = i + 1;
                }
            }
          else
            {
              pos = pos + 1;
              i = i + 1;
            }
        }
      /* printf("===> %s \n",tmp); */
      if(contnu)
        {
          i = 0;
          pos = 0;
          strcpy(name,tmp);
          strcpy(tmp,"");
        }
    }
  /* printf("*==* %s \n",tmp); */
  strcpy(name,tmp);
  strcpy(tmp,"");
  pos = 0;
  i = 0;
  /** Clean **/
  for(k = 0; k < erease; k++)
    {
      while(i <= strlen(name))
        { 
          if(name[i]=='>' &&
             name[i+2] == '('   &&
             name[i+3] == '(' &&
             is_return(name,i+3,strlen(name)) )
            {
              /* printf("[FLAT PROCESS] %s %d %s\n", name, i, tmp); */
              i = i + 3;
              int open = 1;
              tmp[pos++] = '>';
              tmp[pos++] = ' ';
              for(j=i; j < strlen(name); j++)
                {
                  if(name[j] == '(') open = open + 1;
                  if(name[j] == ')') open = open - 1;
                  if(open == 0) break;
                  tmp[pos++] = name[j];
                }
              i = j+1;
            }
          else
            {
              tmp[pos++] = name[i];
              i = i + 1;
            }
        }
      /* printf("\n"); */
      /* printf("===> %s \n",tmp); */
      i = 0; pos = 0;
      strcpy(name,tmp);
      strcpy(tmp,"");
    }
  /* printf("===> %s - %s \n",nameP, name); */
  strcpy(nameP,name);
  free(tmp);
  free(name);
}

/*--------------------------------------------------------------*/
/** NEw with flattening for declare fun **/
void
name_of_functional_sort(Tsort *sub,int arity,int is_decl,char *name)
{
  int j, i = 0, k = 0;
  char *currentType,*isFunType;
  Tsort pending_type;
  Tstack_DAG stack_sort;
  stack_INIT(stack_sort);
  strcpy(name,"");
  if(arity > 0)
    strcat(name,"(");
  for (i= 0;  i <= arity; i++)
    {
      if(is_decl == 1 || i < arity)
        {
          currentType = DAG_sort_name(sub[i]);
          if(!currentType)
            {
              stack_push(stack_sort, sub[i]);
              while(k < stack_size(stack_sort))
                {
                  pending_type = stack_get(stack_sort, k);
                  k++;
                  if(DAG_sort_name(pending_type))
                      strcat(name, DAG_sort_name(pending_type));
                  else
                    {
                      for(j = 0; j < DAG_sort_arity(pending_type); j++)
                        stack_push(stack_sort, DAG_sort_sub(pending_type, j));
                    }
                }
            }
          else
            {
              /* printf("{{A}}%s\n", name); */
              isFunType = strstr(currentType, "->") ;
              if(isFunType && not_covered(currentType, strlen(currentType)))
                strcat(name,"(");
              strcat(name,currentType);
              if(isFunType && not_covered(currentType, strlen(currentType)))
                strcat(name,")");
              /* printf("{{B}}%s\n", name); */
            }
          if(i < arity && is_decl == 1)
            strcat(name," -> ");
          if(i < (arity-1) && is_decl == 0)
            strcat(name," -> ");
        }
    }
  if(arity > 0)
    strcat(name,")");
  /* printf("[FBE] %s\n", name); */
  if(arity > 0)
    flatting_functional_sort(name);
  /* printf("[IOP] %s\n", name); */
  stack_reset(stack_sort);
  stack_free(stack_sort);

  /* printf("After %s\n",name ); */
}

/*--------------------------------------------------------------*/
/**  for sort_functional  declaration **/
void
name_of_functional_sort2(Tsort *sub,int arity,int is_decl,char *name)
{
  int i = 0, j, k = 0;
  Tsort pending_type;
  char *currentType,*isFunType;
  Tstack_DAG stack_sort;
  stack_INIT(stack_sort);

  strcpy(name,"");
  if(arity > 0)
    strcat(name,"(");
  for (i= 0;  i <= arity; i++)
    {
      if(is_decl == 1 || i < arity)
        {
          currentType = DAG_sort_name(sub[i]);
          if(!currentType)
            {
              stack_push(stack_sort, sub[i]);
              while(k < stack_size(stack_sort))
                {
                  pending_type = stack_get(stack_sort, k);
                  k++;
                  if(DAG_sort_name(pending_type))
                    strcat(name, DAG_sort_name(pending_type));
                  else
                    {
                      for(j = 0; j < DAG_sort_arity(pending_type); j++)
                        stack_push(stack_sort, DAG_sort_sub(pending_type, j));
                    }
                }
            }
          else
            {
              isFunType = strstr(currentType,"->");
              if(isFunType && not_covered(currentType, strlen(currentType)))
                strcat(name,"(");
              strcat(name,currentType);
              if(isFunType && not_covered(currentType, strlen(currentType)))
                strcat(name,")");
            }
          if(i < arity && is_decl == 1)
            strcat(name," -> ");
          if(i < (arity-1) && is_decl == 0)
            strcat(name," -> ");
        }
    }
  if(arity > 0)
    strcat(name,")");
  stack_reset(stack_sort);
  stack_free(stack_sort);
  /* printf("%s\n",name); */
}



/*--------------------------------------------------------------*/

void
name_of_param_sort(Tsort sort, Tsort *sub, int arity, char *name)
{
  int i = 0;
  char *currentType;
  strcpy(name,"");
  if(arity > 0)
    strcat(name,"(");
  strcat(name, DAG_sort_name(sort));
  strcat(name," ");
  for (i = 0;  i < arity; i++)
    {
      currentType = DAG_sort_name(sub[i]);
      strcat(name,currentType);
      if(i < (arity-1))
        strcat(name," ");
    }
  if(arity > 0)
    strcat(name,")");
}

/*--------------------------------------------------------------*/
void
get_sub_sort(Tsort *sub, Tsort output, Tsort *dest, int oldarity, int updarity)
{
  int i, j, subarity;
  Tsort cur = output;
  for (i = 0; i < oldarity; i++)
    dest[i] = sub[i];
  /* my_DAG_message("[SNATCH] %S %d %d %S\n", cur, oldarity, updarity, dest[0]); */
  while(i < updarity)
    {
      subarity = DAG_sort_arity(cur);
      if(subarity > 0 &&
         DAG_sort_functional(cur) )
        {
          /* my_DAG_message("[SNATCH] %S\n", cur); */
          for(j=0; j < subarity - 1; j++)
            {
              dest[i + j] =  DAG_sort_sub(cur, j);
            }
          i = i + j;
          cur = DAG_sort_sub(cur, j);
          /* my_DAG_message("[SNATCH OP] %S\n", cur); */
        }
      else if(subarity == 1 &&
              DAG_sort_functional(cur))
        {
          dest[i] = cur;
          cur = DAG_sort_sub(cur, 1);
          i = i + 1;
        }
      else
        {
          dest[i] = cur;
          i = i + 1;
        }
    }
}

/*--------------------------------------------------------------*/

void
re_build_sort(const Tsort output, Tsort *dest, int updarity)
{
  int i=0, j=0;
  Tsort cur = output;
  while(i < updarity)
    {
      int subarity = DAG_sort_arity(cur);
      if(subarity > 0)
        {
          for(j=0; j < subarity - 1; j++)
            dest[i+j] =  DAG_sort_sub(cur, j);
          i = i + j;
          cur = DAG_sort_sub(cur, j);
        }
      else if(subarity == 1)
        {
          dest[i] = cur;
          cur = DAG_sort_sub(cur, 1);
          i = i + 1;
        }
      else
        {
          dest[i] = cur;
          i = i + 1;
        }
    }
}

/*--------------------------------------------------------------*/
/** The new version of declare fun with flattening of sort.
    If we have a sort of the shape (-> Int (-> Int (-> ... Int)))
    it will automatically flatten in (-> Int Int ... Int).
    This is manage by get_sub_sort which take a sort
    and extract all sort one by one in the new array
    updsub.
**/
void
smt2_declare_fun(char * symbol, Tlist sort_list, Tsort sort)
{
  Tsymb_type type;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  type = (sort == SORT_BOOLEAN) ? SYMB_PREDICATE : 0;
  check_protected_symbol(symbol);
  if (!sort_list)
    {
      DAG_symb_new(symbol, type, sort);
      free(symbol);
    }
  else
    {
      size_t size, arity_alloc;
      unsigned i, arity,updarity;
      Tsort *sub,*updsub;
      Tsort newsort;
      char *name;

      arity = list_length(sort_list);
      arity_alloc = (arity + 1) * sizeof(Tsort);
      MY_MALLOC(sub, arity_alloc);
      /* Here we define the type of the function where in sub we
         have tau1 -> .. -> taun -> tau*/
      for (i = 0; i < arity; i++, sort_list = list_cdr(sort_list))
        sub[i] = sort_of_ptr(list_car(sort_list));
      sub[i] = sort;

      /* extention for get the name of the sort when we have functional sort*/
      size = (size_of_sort_str(sub, arity, 1) + 1) * (sizeof(char));
      size = ((4 * (sizeof(char))) * arity) + size;
      /** The last parenthes **/
      size = (2 * (sizeof(char))) + size;
      MY_MALLOC(name,size);
      name_of_functional_sort(sub, arity, 1, name);
      updarity = arity_of_sort(name);
      /** we have now the flattening name and the real
          arity of the symbol. We will now build
          a new array with the missed sort which are
          in the return type. For example if
          we get (define-fun f (Int) (-> Int Int))
          the value of the variable arity is 2 and
          and sub contain sub[0] = (Int) and
          sub[1] = (-> Int Int). Then we will
          destruct sub[1] to get Int and build
          the flatten type (-> Int Int Int) in
          the variable updsub. For summary
          updsub = (-> Int Int Int) now and
          updarity = 3.
          Now the type, the arity and the names
          are coherent that permit us to build
          the new unique sort (-> Int Int Int).
      **/
      arity_alloc = updarity * sizeof(Tsort);
      MY_MALLOC(updsub, arity_alloc);
      get_sub_sort(sub, sort, updsub, arity, updarity);

      newsort = DAG_sort_new(name, updarity, updsub);
      DAG_symb_new(symbol, type, newsort);

      free(symbol);
      free(name);
      free(sub);
      list_free(&sort_list);
    }
  PRINT_SUCCESS;
}

void
smt2_declare_fun_sel(char * symbol, Tlist sort_list, Tsort sort)
{
  Tsymb_type type;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  type = SYMB_SELECTOR;
  check_protected_symbol(symbol);
  if (!sort_list)
    {
      DAG_symb_new(symbol, type, sort);
      free(symbol);
    }
  else
    {
      size_t size, arity_alloc;
      unsigned i, arity,updarity;
      Tsort *sub,*updsub;
      Tsort newsort;
      char *name;

      arity = list_length(sort_list);
      arity_alloc = (arity + 1) * sizeof(Tsort);
      MY_MALLOC(sub, arity_alloc);
      for (i = 0; i < arity; i++, sort_list = list_cdr(sort_list))
        sub[i] = sort_of_ptr(list_car(sort_list));
      sub[i] = sort;
      /* extention for get the name of the sort when we have functional sort*/
      size = (size_of_sort_str(sub, arity, 1) + 1) * (sizeof(char));
      size = ((4 * (sizeof(char))) * arity) + size;
      /** The last parenthes **/
      size = (2 * (sizeof(char))) + size;
      MY_MALLOC(name,size);
      name_of_functional_sort(sub, arity, 1, name);
      updarity = arity_of_sort(name);
      arity_alloc = updarity * sizeof(Tsort);
      MY_MALLOC(updsub, arity_alloc);
      get_sub_sort(sub, sort, updsub, arity, updarity);
      newsort = DAG_sort_new(name, updarity, updsub);
      DAG_symb_new(symbol, type, newsort);
      free(symbol);
      free(name);
      free(sub);
      list_free(&sort_list);
    }
  PRINT_SUCCESS;
}

Tsort
smt2_var_fun(Tsort sort, Tsort sort_ret)
{
  size_t size, arity_alloc;
  unsigned i, arity,updarity,nbargs;
  Tsort *sub,*updsub;
  Tsort newsort;
  char *name;
  arity = DAG_sort_arity(sort);
  nbargs = DAG_sort_arity(sort) - 1;
  /* my_DAG_message("[BGIN] %S %d\n", sort, arity); */

  arity_alloc = (arity) * sizeof(Tsort);
  MY_MALLOC(sub, arity_alloc);
  for (i = 0; i < nbargs; i++)
    {
      sub[i] = DAG_sort_sub(sort, i);
      /* my_DAG_message("[INSIDE] %d %S\n", i, sub[i]); */
    }
  sub[i] = sort_ret;
  /* my_DAG_message("[INSIDE] %d %S\n", i, sub[i]); */

  /* extention for get the name of the sort when we have functional sort*/
  size = (size_of_sort_str(sub, nbargs, 1) + 1) * (sizeof(char));
  size = ((4 * (sizeof(char))) * nbargs) + size;
  /** The last parenthes **/
  size = (2 * (sizeof(char))) + size;
  MY_MALLOC(name, size);
  name_of_functional_sort(sub, nbargs, 1, name);
  updarity = arity_of_sort(name);
  arity_alloc = updarity * sizeof(Tsort);
  MY_MALLOC(updsub, arity_alloc);
  get_sub_sort(sub, sort_ret, updsub, nbargs, updarity);
  /* for (i = 0; i < updarity; i++) */
  /*   my_DAG_message("[INSIDE_2] %d %S %s %d = %d\n", i, updsub[i], name, updarity, arity); */
  newsort = DAG_sort_new(name, updarity, updsub);
  free(sub);
  free(name);
  return newsort;
}

Tsort
sort_of_lam(Tsort *sort, unsigned nbargs, Tsort sort_ret)
{
  size_t size, arity_alloc;
  unsigned i, updarity;
  Tsort *sub,*updsub;
  Tsort newsort;
  char *name;
  arity_alloc = (nbargs + 1) * sizeof(Tsort);
  MY_MALLOC(sub, arity_alloc);
  for (i = 0; i < nbargs; i++)
    {
      sub[i] = sort[i];
      /* my_DAG_message("[INSIDE] %d %S\n", i, sub[i]); */
    }
  sub[i] = sort_ret;
  /* my_DAG_message("[INSIDE] %d %S\n", i, sub[i]); */

  /* extention for get the name of the sort when we have functional sort*/
  size = (size_of_sort_str(sub, nbargs, 1) + 1) * (sizeof(char));
  size = ((4 * (sizeof(char))) * nbargs) + size;
  /** The last parenthes **/
  size = (2 * (sizeof(char))) + size;
  MY_MALLOC(name, size);
  name_of_functional_sort(sub, nbargs, 1, name);
  updarity = arity_of_sort(name);
  arity_alloc = updarity * sizeof(Tsort);
  MY_MALLOC(updsub, arity_alloc);
  get_sub_sort(sub, sort_ret, updsub, nbargs, updarity);
  newsort = DAG_sort_new(name, updarity, updsub);
  free(sub);
  free(name);
  return newsort;
}

/*--------------------------------------------------------------*/

void
smt2_define_fun(char * symbol, Tstack_symb stack_var, Tsort sort, TDAG term)
{
  unsigned i;
  Tsymb symb;
  TDAG DAG;
  Tstack_DAG stack_arg;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  stack_INIT(stack_arg);
  check_protected_symbol(symbol);
  for (i = 0; i < stack_var->size; i++)
    stack_push(stack_arg, DAG_new_nullary(stack_var->data[i]));
  stack_push(stack_arg, term);
  DAG = DAG_dup(DAG_new_stack(LAMBDA, stack_arg));
  if (DAG_sort(term) != sort)
    veriT_error("smt2_define_fun: sort mismatch\n");
  symb = DAG_symb_new(symbol, SYMB_MACRO, DAG_sort(DAG));
  DAG_symb_macro(symb, DAG);
  stack_free(stack_arg);
  DAG_free(term);
  free(symbol);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_define_poly_fun(char * symbol, /*T_SORT_LIST sort_list,*/
                     Tstack_symb stack_var, /*T_SORT Tsort,*/ T_TERM term)
{
  unsigned i;
  Tsymb symb;
  TDAG DAG;
  Tstack_DAG stack_arg;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  stack_INIT(stack_arg);
  check_protected_symbol(symbol);
  for (i = 0; i < stack_var->size; i++)
    stack_push(stack_arg, DAG_new_nullary(stack_var->data[i]));
  stack_push(stack_arg, term);
  DAG = DAG_dup(DAG_new_stack(LAMBDA, stack_arg));
  symb = DAG_symb_new(symbol, SYMB_MACRO, DAG_sort(DAG));
  DAG_symb_macro(symb, DAG);
  stack_free(stack_arg);
  DAG_free(term);
  free(symbol);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_define_fun_short(char * symbol, TDAG term)
{
  Tsymb symb;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  check_protected_symbol(symbol);
  symb = DAG_symb_new(symbol, SYMB_MACRO, DAG_sort(term));
  DAG_symb_macro(symb, term);
  free(symbol);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_push(char * numeral)
{
  unsigned n;
  char * tmp;
  long l;

  VERIFY_LOGIC_NOT_SET;
  veriT_error("unsupported");

  l = strtol(numeral, &tmp, 10);
  if (l < 0 || l > UINT_MAX)
    veriT_error("push: range");
  n = (unsigned) l;
  if (*tmp != '\0')
    veriT_error("smt2_push: internal error");
  if ((errno == ERANGE && n == UINT_MAX)
      || (errno != 0 && n == 0))
    veriT_error("push: range");
  veriT_push(n);
  free(numeral);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_pop(char * numeral)
{
  unsigned n;
  char * tmp;
  long l;

  VERIFY_LOGIC_NOT_SET;
  veriT_error("unsupported");

  l = strtol(numeral, &tmp, 10);
  if (l < 0 || l > UINT_MAX)
    veriT_error("push: range");
  n = (unsigned) l;
  if (*tmp != '\0')
    veriT_error("smt2_push: internal error");
  if ((errno == ERANGE && n == UINT_MAX)
      || (errno != 0 && n == 0))
    veriT_error("push: range");
  veriT_pop(n);
  free(numeral);
}

/*--------------------------------------------------------------*/
Tstack_DAG in_proceding, ind_conjecture;
extern Tstack_DAG veriT_lemmas;
extern TDAG uncurry(TDAG);
Tstack_DAG in_proceding_app, lazy_app_dags;
Tstack_sort ext_sorts;

void
smt2_assert(TDAG term)
{
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  if (!stack_is_empty(in_proceding))
    {
      while (!stack_is_empty(in_proceding))
        stack_push(veriT_lemmas, stack_pop(in_proceding));
    }
  if (lazy_app && !stack_is_empty(in_proceding_app))
    {
      while (!stack_is_empty(in_proceding_app))
        stack_push(veriT_lemmas, stack_pop(in_proceding_app));
    }
  if (DAG_sort(term) != SORT_BOOLEAN)
    veriT_error("asserting a non Boolean term on line %d", yylineno);
  veriT_assert(term);
#if STATS_LEVEL > 1
  stats_counter_add(stat_nb_nodes, DAG_count_nodes(term));
  stats_counter_add(stat_nb_nodes_tree, DAG_count_nodes_tree(term));
  stats_counter_add(stat_nb_atoms, DAG_count_atoms(term));
#endif
  DAG_free(term);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/
TDAG smt2_sub_app(char * str, Tlist term_list);


static bool
is_in(Tstack_DAG *stack, TDAG u)
{
  unsigned i;
  for (i = 0; i < stack_size(*stack); i++)
    if (stack_get(*stack, i) == u)
      return true;
  return false;
}

static bool
symb_is_in(Tstack_symb *stack, Tsymb u)
{
  unsigned i;
  for (i = 0; i < stack_size(*stack); i++)
    if (stack_get(*stack, i) == u)
      return true;
  return false;
}

Tstack_stack_constructor datatype_hash;
Tstack_symb splited;

static bool
is_constructor(Tsymb symb)
{
  unsigned i;
  if (!(DAG_symb_type(symb) & SYMB_CONSTRUCTOR)) return false;
  Tstack_constructor constr = stack_get(datatype_hash,
                                   (unsigned)DAG_symb_sort(symb));
  if (!constr) return false;
  for (i = 0; i < stack_size(constr); i++)
    if (!strcmp(stack_get(constr, i)->symb, DAG_symb_name2(symb)))
      return true;
  return false;
}

static bool
is_constructor_of_sort(Tsort sort, Tsymb symb)
{
  unsigned i;
  if (!(DAG_symb_type(symb) & SYMB_CONSTRUCTOR)) return false;
  Tstack_constructor constr = stack_get(datatype_hash,
                                   (unsigned)sort);
  if (!constr) return false;
  for (i = 0; i < stack_size(constr); i++)
    if (!strcmp(stack_get(constr, i)->symb, DAG_symb_name2(symb)))
      return true;
  return false;
}

static bool
is_datatype(Tsymb symb)
{
  Tstack_constructor constr =
    (DAG_symb_sort(symb) < stack_size(datatype_hash))?
    stack_get(datatype_hash, (unsigned)DAG_symb_sort(symb)):NULL;
  if (!constr)
    return false;
  return true;
}

static TDAG
build_eq(TDAG u, TDAG v)
{
  return smt2_sub_app(strmake("="),
               smt2_term_list_add(smt2_term_list_one(u), v));
}

static inline bool
is_datatype_constante(Tsymb symb)
{
  return is_datatype(symb) && !(DAG_symb_type(symb) & SYMB_CONSTRUCTOR) &&
    !DAG_sort_arity(DAG_symb_sort(symb)) &&
    !is_constructor(symb);
}

static inline bool
sel_applied_to_constante(TDAG DAG)
{
  TDAG current;
  Tstack_DAG travers;
  stack_INIT(travers);
  stack_push(travers, DAG);
  while (!stack_is_empty(travers))
    {
      current = stack_pop(travers);
      if (is_datatype_constante(DAG_symb(current)))
        {
          stack_reset(travers);
          stack_free(travers);
          return true;
        }
      else if (DAG_symb_type(DAG_symb(current)) & SYMB_SELECTOR)
        stack_push(travers, DAG_arg0(current));
      else
        break;
    }
  stack_reset(travers);
  stack_free(travers);
  return false;
}

void
unfold_selector(TDAG term, TDAG selector_term, unsigned i)
{
  TDAG equality;
  if (is_constructor_of_sort(DAG_sort(term), DAG_symb(term)) &&
      /** check that is the rigth selector for the right constructor **/
      DAG_sort(selector_term) == DAG_sort(DAG_arg(term, i)))
    {
      equality = build_eq(DAG_arg(term, i), selector_term);
      /* printf("[UNFOLD_SEL]: "); */
      /* DAG_print(selector_term); printf(" --> "); */
      /* DAG_print(equality); printf("\n"); */
      stack_push(in_proceding, DAG_dup(equality));
    }
}

TDAG
get_DAG_constructor(char *str)
{
  Tsymb symb = DAG_symb_lookup(str, 0, NULL, DAG_SORT_NULL);
  return DAG_dup(DAG_new_nullary(symb));
}

Tlist
add_list_term(Tlist list, TDAG term, int first)
{
  if (!first)
    list = smt2_term_list_one(term);
  else
    list = smt2_term_list_add(list, term);
  return list;
}

void static
smt2_exhaustiveness(Tsymb symb, TDAG term)
{
  unsigned i, j;
  char *sel_name;
  Tlist split = NULL, args = NULL;
  TDAG /* term = DAG_dup(DAG_new_nullary(symb)), */
    applied_sel, applied_cons, constrainte;
  Tstack_sel stack_sel;
  Tstack_constructor stack_constructors =
    stack_get(datatype_hash, (unsigned)DAG_symb_sort(symb));
  stack_push(splited, symb);
  for (i = 0; i < stack_size(stack_constructors); i++)
    {
      args = NULL;
      applied_cons = get_DAG_constructor(stack_get(stack_constructors, i)->symb);
      stack_sel = stack_get(stack_constructors, i)->selectors;
      for (j = 0; stack_sel && j < stack_size(stack_sel); j++)
        {
          sel_name = stack_get(stack_sel, j)->symb;
          applied_sel =
            smt2_sub_app(strmake(sel_name), smt2_term_list_one(term));
          if (DAG_arity(term) == stack_size(stack_sel))
            unfold_selector(term, applied_sel, j);
          args = add_list_term(args, applied_sel, j);
        }
      if (args)
        applied_cons =
          smt2_sub_app(strmake(stack_get(stack_constructors, i)->symb), args);
      constrainte = build_eq(applied_cons, term);
      if (!split)
        split = smt2_term_list_one(constrainte);
      else
        split = smt2_term_list_add(split, constrainte);
    }
  if (split)
    {
      constrainte = smt2_sub_app(strmake("or"), split);
      /* my_DAG_message("[EXHAUSTIVENESS]%D \n",  constrainte); */
      stack_push(in_proceding, DAG_dup(constrainte));
    }
}

Tstack_DAG
get_var_of_cons(Tsort datatype_sort, char *constructor)
{
  unsigned i, hash_key = (unsigned)datatype_sort;
  for (i = 0; i < stack_size(stack_get(datatype_hash, hash_key)); i++)
    if (!strcmp(stack_get(stack_get(datatype_hash, hash_key), i)->symb, constructor))
      return stack_get(stack_get(datatype_hash, hash_key), i)->args;
  return NULL;
}

Tstack_sel
get_selectors(Tsort datatype_sort, char *constructor)
{
  unsigned i, hash_key = (unsigned)datatype_sort;
  for (i = 0; i < stack_size(stack_get(datatype_hash, hash_key)); i++)
    if (!strcmp(stack_get(stack_get(datatype_hash, hash_key), i)->symb, constructor)) 
      return stack_get(stack_get(datatype_hash, hash_key), i)->selectors;
  return NULL;
}


void static
smt2_split_datatype(TDAG DAG)
{
  unsigned i, j;
  Tlist split = NULL, args = NULL;
  TDAG applied_cons, applied_sel, constrainte, explicit_split;
  char *sel_name, *str = DAG_symb_name2(DAG_symb(DAG));
  Tstack_sel stack_sel;
  Tstack_constructor stack_constructors =
    stack_get(datatype_hash, (unsigned)DAG_sort(DAG_arg0(DAG)));
  /* printf("SPLIT_RULE"); DAG_print(DAG); printf("[\n"); */
  for (i = 0; i < stack_size(stack_constructors); i++)
    {
      args = NULL;
      stack_sel = stack_get(stack_constructors, i)->selectors;
      for (j = 0; stack_sel && j < stack_size(stack_sel); j++)
        {
          sel_name = stack_get(stack_sel, j)->symb;
          if (strcmp(sel_name, str))
            applied_sel = smt2_sub_app(strmake(sel_name),
                                       smt2_term_list_one(DAG_arg0(DAG)));
          else
            applied_sel = DAG;
          if (DAG_arity(DAG_arg0(DAG)) == stack_size(stack_sel))
            unfold_selector(DAG_arg0(DAG), applied_sel, j);
          args = add_list_term(args, applied_sel, j);
        }

      applied_cons =
        smt2_sub_app(strmake(stack_get(stack_constructors, i)->symb), args);
      constrainte = build_eq(DAG_arg0(DAG), applied_cons);
      if (!i || !split)
        split = smt2_term_list_one(constrainte);
      else
        split = smt2_term_list_add(split, constrainte);
    }
  if (split)
    {
      explicit_split = smt2_sub_app(strmake("or"), split);
      /* printf("[SPLIT] "); DAG_print(explicit_split);printf("]\n"); */
      stack_push(in_proceding, DAG_dup(explicit_split));
      split = NULL;
    }
  /**< here Check for optimisation **/
  /* if (sel_applied_to_constante(DAG)) */
    {
      stack_constructors = /**< reload the coresponding set of
                              constructors of the term sel(x1)**/
        stack_get(datatype_hash, (unsigned)DAG_sort(DAG));
      for (i = 0; stack_constructors && i < stack_size(stack_constructors); i++)
        {
          args = NULL;
          applied_cons = get_DAG_constructor(stack_get(stack_constructors, i)->symb);
          stack_sel = stack_get(stack_constructors, i)->selectors;
          for (j = 0; stack_sel && j < stack_size(stack_sel); j++)
            {
              sel_name = stack_get(stack_sel, j)->symb;
              applied_sel =
                smt2_sub_app(strmake(sel_name), smt2_term_list_one(DAG));
              args = add_list_term(args, applied_sel, j);
            }
          if (args)
            applied_cons =
              smt2_sub_app(strmake(stack_get(stack_constructors, i)->symb), args);

          constrainte = build_eq(applied_cons, DAG);
          if (!split)
            split = smt2_term_list_one(constrainte);
          else
            split = smt2_term_list_add(split, constrainte);
        }
      if (split)
        {
          constrainte = smt2_sub_app(strmake("or"), split);
          /* my_DAG_message("[EXHAUSTIVENESS_FOR_CONST]%D \n",  constrainte); */
          stack_push(in_proceding, DAG_dup(constrainte));
        }
    }
}

void
smt2_check_sat(void)
{
  Tstatus status;
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  /* my_DAG_message("[CHECK] \n"); */
  status = veriT_check_sat();
  smt2_check_sat_done = true;
  switch (status)
    {
    case UNSAT :
      veriT_out("unsat");
      stats_counter_set(stat_result, 0);
      break;
    case SAT   :
      veriT_out("sat");
      stats_counter_set(stat_result, 1);
      break;
    case UNDEF :
      veriT_out("unknown");
      stats_counter_set(stat_result, -1);
      /* TODO here include completion test */
      break;
    default : veriT_error("strange returned status");
    }
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_get_assertions(void)
{
  unsigned i;
  if (!smt2_interactive_mode)
    veriT_error("get-assertions only available in interactive mode");
  /* TODO */
  veriT_out("(");
  for (i = 0; i < stack_size(veriT_assertion_set_stack); ++i)
    {
      Tassertion_set assertion_set = stack_get(veriT_assertion_set_stack, i);
      unsigned j;
      veriT_out(";; assertions at level %i", i);
      for (j = 0; j < stack_size(assertion_set.DAG_stack); ++j)
        {
          if (j > 0)
            veriT_out("");
          DAG_fprint(veriT_out_file, stack_get(assertion_set.DAG_stack, j));
        }
    }
  veriT_out("\n)");
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

#ifdef PROOF
void
smt2_get_proof(void)
{
  if (!smt2_produce_proofs)
    veriT_error("option :produce-proofs has not been set.");
  if (veriT_status() != UNSAT)
    veriT_error("status is not unsat.");
  veriT_get_proof();
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_get_unsat_core(void)
{
  if (!smt2_produce_unsat_cores)
    veriT_error("option :produce-unsat-core has not been set.");
  if (veriT_status() != UNSAT)
    veriT_error("status is not unsat.");
  veriT_get_unsat_core();
  PRINT_SUCCESS;
}
#endif

/*--------------------------------------------------------------*/

void
smt2_get_model(void)
{
  veriT_model();
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_echo(char * str)
{
  veriT_out("%s", str);
  free(str);
}

/*--------------------------------------------------------------*/

void
smt2_get_value(Tlist term_list)
{
  /* TODO */
  PRINT_UNSUPPORTED;
  list_free(&term_list);
}

/*--------------------------------------------------------------*/

void
smt2_get_assignment(void)
{
  /* TODO */
  PRINT_UNSUPPORTED;
}

/*--------------------------------------------------------------*/
static bool smt2_exited = false;
void
smt2_get_info(char * keyword)
{
  switch (defstring(keyword))
    {
    case KW_ERROR_BEHAVIOR:
      veriT_out("(%s %s)", keyword, "immediate-exit");
      PRINT_SUCCESS;
      break;
    case KW_NAME:
      veriT_out("(%s \"%s\")", keyword, "veriT");
      PRINT_SUCCESS;
      break;
    case KW_VERSION:
      /* TODO make-distrib script should fill this automatically */
      veriT_out("(%s \"%s\")", keyword, PROGRAM_VERSION);
      PRINT_SUCCESS;
      break;
    case KW_AUTHORS:
      veriT_out("(%s \"%s\")", keyword,
                "main developers: P. Fontaine, D. Deharbe");
      PRINT_SUCCESS;
      break;
    case KW_STATUS:
      veriT_out("(%s \"%s\")", keyword, smt2_status_str(veriT_status()));
      PRINT_SUCCESS;
      break;
    default:
      PRINT_UNSUPPORTED;
      break;
    }
  free(keyword);
}

/*--------------------------------------------------------------*/

void
smt2_get_option(char * keyword)
{
  switch (defstring(keyword))
    {
    case KW_PRINT_SUCCESS:
      veriT_out("%s", smt2_print_success ? "true" : "false");
      PRINT_SUCCESS;
      break;
    case KW_DIAGNOSTIC_OUTPUT_CHANNEL:
      veriT_out("\"%s\"", smt2_diagnostic_output_channel);
      PRINT_SUCCESS;
      break;
    case KW_REGULAR_OUTPUT_CHANNEL:
      veriT_out("\"%s\"", smt2_regular_output_channel);
      PRINT_SUCCESS;
      break;
    case KW_INTERACTIVE_MODE:
      veriT_out(smt2_interactive_mode?"true":"false");
      PRINT_SUCCESS;
      break;
    default:
      PRINT_UNSUPPORTED;
      break;
    }
  free(keyword);
}

/*--------------------------------------------------------------*/
static bool start_status = false;

void
smt2_exit(void)
{
  Tstatus status = veriT_status();
  if (smt2_status != UNDEF && status != UNDEF &&
      smt2_status != status)
    veriT_error("soundness error");
  /*  veriT_exit(0); */
  smt2_exited = true;
  PRINT_SUCCESS;
}

bool
smt2_to_check(void)
{
  return start_status;
}

/*--------------------------------------------------------------*/


void
smt2_set_option(char * keyword)
{
  smt2_set_option_bool(keyword, true);
}

/*--------------------------------------------------------------*/

void
smt2_set_option_num(char * keyword, char * str)
{
  unsigned num;
  sscanf(str, "%u", &num);
  free(str);
  switch (defstring(keyword))
    {
#ifdef PROOF
    case KW_VERIT_PROOF_FORMAT:
      if (num <= 2)
        {
          proof_version = (int) num;
          PRINT_SUCCESS;
        }
      else
        {
          veriT_error("valid values for :veriT-proof-format: 0, 1, 2.");
        }
      break;
#endif
    default:
      PRINT_UNSUPPORTED;
    }
  free(keyword);
}

/*--------------------------------------------------------------*/

void
smt2_set_option_str(char * keyword, char * str)
{
  size_t len_alloc;
  char * str_no_quotes;
  size_t len = strlen(str)-2;
  len_alloc = sizeof(char) * (len+1);
  MY_MALLOC(str_no_quotes, len_alloc);
  strncpy(str_no_quotes, str+1, len);
  str_no_quotes[len] = (char) 0;
  free(str);
  switch (defstring(keyword))
    {
    case KW_DIAGNOSTIC_OUTPUT_CHANNEL:
      if (strcmp(str_no_quotes, smt2_diagnostic_output_channel) != 0)
        {
          free(smt2_diagnostic_output_channel);
          smt2_diagnostic_output_channel = str_no_quotes;
          veriT_set_err_file(str_no_quotes);
        }
      PRINT_SUCCESS;
      break;
    case KW_REGULAR_OUTPUT_CHANNEL:
      if (strcmp(str_no_quotes, smt2_regular_output_channel) != 0)
        {
          free(smt2_regular_output_channel);
          smt2_regular_output_channel = str_no_quotes;
          veriT_set_out_file(str_no_quotes);
        }
      PRINT_SUCCESS;
      break;
    default:
      free(str_no_quotes);
      PRINT_UNSUPPORTED;
    }
  free(keyword);
}

/*--------------------------------------------------------------*/

void
smt2_set_option_bool(char * keyword, const bool value)
{
  switch (defstring(keyword)) {
  case KW_INTERACTIVE_MODE:
    VERIFY_LOGIC_SET;
    smt2_interactive_mode = true;
    PRINT_SUCCESS;
    break;
  case KW_PRODUCE_PROOFS:
    VERIFY_LOGIC_SET;
#ifdef PROOF
    smt2_produce_proofs = value;
    if (value)
      {
        proof_on = true;
        option_proof_merge = true;
        option_proof_prune = true;
      }
    else
      {
        proof_on = false;
      }
    PRINT_SUCCESS;
#else
    PRINT_UNSUPPORTED;
#endif
    break;
  case KW_PRODUCE_UNSAT_CORES:
    VERIFY_LOGIC_SET;
#ifdef PROOF
    smt2_produce_unsat_cores = value;
    if (value)
      {
        proof_on = true;
        option_proof_merge = true;
        option_proof_prune = true;
      }
    else
      {
        proof_on = false;
      }
    PRINT_SUCCESS;
#else
    PRINT_UNSUPPORTED;
#endif
    break;
  case KW_PRODUCE_MODELS:
  case KW_PRODUCE_ASSIGNMENTS:
    VERIFY_LOGIC_SET;
    PRINT_UNSUPPORTED;
    break;
  case KW_PRINT_SUCCESS:
    smt2_print_success = value;
    PRINT_SUCCESS;
    break;
  case KW_PRINT_REPORT:
    veriT_print_report = value;
    PRINT_SUCCESS;
    break;
  default:
    PRINT_UNSUPPORTED;
    break;
  }
  /* TODO */
  free(keyword);
}

/*--------------------------------------------------------------*/


void
smt2_set_info(char * keyword)
{
  free(keyword);
  PRINT_UNSUPPORTED;
}

/*--------------------------------------------------------------*/

void
smt2_set_info_str(char * keyword, char * str)
{
  switch (defstring(keyword))
    {
    case KW_CATEGORY :
      PRINT_SUCCESS;
      break;
    case KW_NOTES :
      PRINT_SUCCESS;
      break;
    case KW_STATUS :
      if (!strcmp(str,"sat"))
        smt2_status = SAT;
      else if (!strcmp(str,"unsat"))
        smt2_status = UNSAT;
      else if (!strcmp(str,"unknown"))
        smt2_status = UNDEF;
      if (smt2_status == UNDEF || smt2_status == UNSAT)
        start_status = true;
      else
        start_status = false;
      PRINT_SUCCESS;
      break;
    case KW_SMT_LIB_VERSION :
      if (strcmp(str,"2.0") && strcmp(str,"2.5") && strcmp(str,"2.6"))
        veriT_err("unknown SMT-LIB version");
      PRINT_SUCCESS;
      break;
    case KW_SOURCE :
      PRINT_SUCCESS;
      break;
    case KW_LICENSE :
      PRINT_SUCCESS;
      break;
    default :
      PRINT_UNSUPPORTED;
    }
  free(keyword);
  free(str);
}

/*
  --------------------------------------------------------------
  TDAG
  --------------------------------------------------------------
*/

TDAG
smt2_term_const(char * str)
{
  TDAG DAG = DAG_NULL;
  /* PF string may be:
     NUMERAL
     DECIMAL
     HEXADECIMAL
     BINARY
     STRING
  */
  if (str[0] == 0)
    veriT_error("unexpected constant on line %d", yylineno);
  else if (isdigit(str[0]))
    {
      if (check_decimal(str))
        DAG = DAG_new_decimal_str(str);
      else
        DAG = DAG_new_integer_str(str);
    }
  else if (str[1] == 0)
    veriT_error("unexpected constant on line %d", yylineno);
  else if (str[0] == '#')
    {
      if (str[1] == 'b')
        {
          check_binary(str + 2);
          DAG = DAG_new_binary_str(str);
        }
      else if (str[1] == 'x')
        {
          check_hex(str + 2);
          DAG = DAG_new_hex_str(str);
        }
      else
        veriT_error("unexpected constant on line %d", yylineno);
    }
  else if (str[0] == '"')
    {
      check_str(str + 2);
      DAG = DAG_new_str(str);
    }
  else
    veriT_error("unexpected constant on line %d", yylineno);
  free(str);
  return DAG_dup(DAG);
}

/*--------------------------------------------------------------*/

TDAG
smt2_term(char * str)
{
  Tsymb symb = lookup_str(str);
  if (!symb)
    symb = DAG_symb_lookup(str, 0, NULL, DAG_SORT_NULL);
  if (!symb)
    veriT_error("smt2_term: unresolved symbol %s on line %d", str, yylineno);
  if (is_datatype_constante(symb) &&
      !symb_is_in(&splited, symb))
    smt2_exhaustiveness(symb, DAG_dup(DAG_new_nullary(symb)));
  free(str);
  if (DAG_symb_type(symb) & SYMB_MACRO)
    {
      TDAG DAG = DAG_symb_DAG[symb];
      if (DAG_symb(DAG) == LAMBDA && DAG_arity(DAG) == 1)
        return DAG_dup(DAG_arg0(DAG));
    }

  return DAG_dup(DAG_new_nullary(symb));
}

/*--------------------------------------------------------------*/

TDAG
smt2_sub_app(char * str, Tlist term_list)
{
  size_t arity_alloc;
  unsigned i, arity = list_length(term_list);
  Tsymb symb = DAG_SYMB_NULL;
  TDAG *sub, DAG;
  arity_alloc = arity * sizeof(TDAG);
  MY_MALLOC(sub, arity_alloc);
  for (i = 0; i < arity; i++, term_list = list_cdr(term_list))
    sub[i] = DAG_of_ptr(list_car(term_list));

  assert(!(strcmp(str, "=") == 0) || arity >= 2);
  if (strcmp(str, "=") == 0)
    {
      if (DAG_sort(sub[0]) == SORT_BOOLEAN)
        symb = CONNECTOR_EQUIV;
      else
        symb = PREDICATE_EQ;
    }
  else if (strcmp(str, "ite") == 0)
    {
      if (arity != 3)
        veriT_error("smt2_term_app: wrong arity for ITE symbol on line %d.", yylineno);
      if (DAG_sort(sub[0]) != SORT_BOOLEAN ||
          DAG_sort(sub[1]) != DAG_sort(sub[2]))
        veriT_error("smt2_term_app: typing error in ite application on line %d.",
                    yylineno);
      else if (DAG_sort(sub[1]) == SORT_BOOLEAN)
        symb = CONNECTOR_ITE;
      else
        symb = FUNCTION_ITE;
    }
  else
    {
      Tsort * Psort;
      arity_alloc = arity * sizeof(Tsort);
      MY_MALLOC(Psort, arity_alloc);
      for (i = 0; i < arity; i++)
        Psort[i] = DAG_sort(sub[i]);
      symb = DAG_symb_lookup(str, arity, Psort, DAG_SORT_NULL);
      free(Psort);
    }
  if (!symb)
    veriT_error("smt2_term_app: unresolved symbol %s on line %d.", str, yylineno);
  DAG = DAG_dup(DAG_new(symb, arity, sub));
  /* for (i = 0; i < arity; i++) */
  /*   DAG_free(DAG_arg(DAG, i)); */
  free(str);
  list_free(&term_list);
  return DAG;
}

TDAG
smt2_lambda_app_fun(TDAG lambda, Tlist term_list)
{
  size_t arity_alloc;
  unsigned i, arity = list_length(term_list);
  TDAG *sub, DAG;
  arity_alloc = (arity + 1) * sizeof(TDAG);
  MY_MALLOC(sub, arity_alloc);
  /* my_DAG_message("%d %D : %S {%S}\n", */
  /*                arity, */
  /*                lambda, DAG_sort(lambda), */
  /*                DAG_sort_sub(DAG_sort(lambda), arity)); */
  /* for (i = 0; i <= arity; i++) */
  /*   { */
  /*     my_DAG_message("{%S}\n", */
  /*                    DAG_sort_sub(DAG_sort(lambda), i)); */
  /*   } */
  sub[0] = lambda;
  for (i = 0; i < arity; i++, term_list = list_cdr(term_list))
    {
      sub[i + 1] = DAG_of_ptr(list_car(term_list));
      /* my_DAG_message("%D : %S\n", sub[i +1], DAG_sort(sub[i + 1])); */
    }
  /* if (DAG_sort_arity(DAG_sort(lambda)) - (arity + 1) == 0 && */
  /*     DAG_sort_sub(DAG_sort(lambda), arity) == SORT_BOOLEAN) */
  /*   DAG = DAG_dup(DAG_new(APPLY_P, arity + 1, sub)); */
  /* else */
  DAG = DAG_dup(DAG_new(APPLY, arity + 1, sub));
  /* my_DAG_message("[RES]%D:%S\n", DAG, DAG_sort(DAG)); */
  /* if (DAG_sort_arity(DAG_sort(lambda)) - (arity + 1) == 0 && */
  /*     DAG_sort_sub(DAG_sort(lambda), arity) == SORT_BOOLEAN) */
    /* my_DAG_message("RES %d {%d} (%d) %D : %S == %S\n", */
    /*                arity, DAG_sort_arity(DAG_sort(lambda)), DAG_arity(lambda), */
    /*                DAG, DAG_sort(DAG), */
    /*                DAG_sort_sub(DAG_sort(lambda), arity )); */

  for (i = 0; i < DAG_arity(DAG); i++)
    DAG_free(DAG_arg(DAG, i));
  list_free(&term_list);
  /* my_DAG_message("[LAMBDA]%D \n", DAG); */
  return DAG;
}

/*--------------------------------------------------------------*/

TDAG
smt2_lambda_app(TDAG lambda, Tlist term_list)
{
  size_t arity_alloc;
  unsigned i, arity = list_length(term_list), arity_lam = DAG_arity(lambda);
  TDAG *sub, DAG;
  arity_alloc = (arity + 1) * sizeof(TDAG);
  MY_MALLOC(sub, arity_alloc + arity_lam);
  for (i = 0; i < arity_lam; i++)
    sub[i] = DAG_arg(lambda, i);
  /* my_DAG_message("%D\n", DAG_arg(lambda, i)); */
  for (i = 0; i < arity; i++, term_list = list_cdr(term_list))
    sub[i + arity_lam] = DAG_of_ptr(list_car(term_list));
  DAG = DAG_dup(DAG_new(DAG_symb(lambda), arity + arity_lam, sub));
  /* DAG_free(lambda); */
  for (i = 0; i < DAG_arity(DAG); i++)
    DAG_free(DAG_arg(DAG, i));
  list_free(&term_list);
  /* my_DAG_message("[LAMBDA]%D %D\n", DAG, lambda); */
  return DAG;
}



/*--------------------------------------------------------------*/

static bool
pre_def_symb(Tsymb src){
  return (src == LET ||
          src == CONNECTOR_NOT ||
          src == CONNECTOR_OR ||
          src == CONNECTOR_XOR ||
          src == CONNECTOR_IMPLIES ||
          src ==  FUNCTION_ITE ||
          src == CONNECTOR_ITE ||
          src == PREDICATE_LESS ||
          src == PREDICATE_LEQ ||
          src == PREDICATE_GREATER ||
          src == PREDICATE_GREATEREQ ||
          src == PREDICATE_DISTINCT ||
          quantifier(src) ||
          src == FUNCTION_MINUS ||
          src == FUNCTION_SUM ||
          src == FUNCTION_MOD ||
          src == FUNCTION_PROD ||
          src == FUNCTION_UNARY_MINUS ||
          src == FUNCTION_UNARY_MINUS_ALT ||  
          src ==  FUNCTION_DIV ||
          unary_minus(src) ||
          src == CONNECTOR_EQUIV ||
          src == PREDICATE_EQ ||
          src ==  CONNECTOR_AND);
}

static bool
is_predicate_app(Tsymb symb, unsigned arity)
{
  return pre_def_symb(symb) || !DAG_symb_sort(symb);
}

static bool
is_predicate(char *str, Tsymb symb, unsigned arity)
{

  return
    (strcmp(str, "not") == 0 || strcmp(str, "and") == 0 ||
     strcmp(str, "or") == 0 || strcmp(str, "=>") == 0 ||
     strcmp(str, "+") == 0 || strcmp(str, "-") == 0 ||
     strcmp(str, "*") == 0 || strcmp(str, "<=") == 0 ||
     strcmp(str, "<") == 0 || strcmp(str, ">=") == 0 ||
     strcmp(str, "distinct") == 0 || strcmp(str, ">") == 0 ||
     !DAG_symb_sort(symb) ||
     DAG_sort_sub(DAG_symb_sort(symb), arity) == SORT_BOOLEAN)
    &&
    !(DAG_symb_type(symb) & SYMB_VARIABLE);
}

static TDAG
app_term(TDAG lambda, Tstack_symb term_list)
{
  unsigned i, arity_lam = DAG_arity(lambda);
  TDAG DAG;
  Tstack_DAG fun_args;
  stack_INIT(fun_args);
  for (i = 0; i < arity_lam; i++)
    stack_push(fun_args, DAG_arg(lambda, i));
  for (i = 0; i < stack_size(term_list); i++)
    {
      TDAG arg = DAG_dup(DAG_new_nullary(stack_get(term_list, i)));
      stack_push(fun_args, arg);
    }
  DAG = DAG_dup(DAG_new_stack(DAG_symb(lambda), fun_args));
  stack_reset(fun_args);
  stack_free(fun_args);
  return DAG;
}

static TDAG
app_symb_term(Tsymb symb, Tstack_symb term_list)
{
  unsigned i;
  TDAG DAG;
  Tstack_DAG fun_args;
  stack_INIT(fun_args);
  for (i = 0; i < stack_size(term_list); i++)
    {
      TDAG arg = DAG_dup(DAG_new_nullary(stack_get(term_list, i)));
      stack_push(fun_args, arg);
    }
  DAG = DAG_dup(DAG_new_stack(symb, fun_args));
  stack_reset(fun_args);
  stack_free(fun_args);
  return DAG;
}

static bool
contains_sort(Tsort sort)
{
  unsigned i;
  for (i = 0; i < stack_size(ext_sorts); i++)
    if (sort == stack_get(ext_sorts, i))
      return true;
  return false;
}

static bool
contains_DAG(TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(lazy_app_dags); i++)
    if (DAG == stack_get(lazy_app_dags, i))
      return true;
  return false;
}

void
lazy_axiom(TDAG APP_DAG, TDAG DAG, Tstack_DAG *lemmas)
{
  unsigned i;
  int arity_sort = DAG_sort_arity(DAG_sort(DAG));
  TDAG eq, eq_forall, left, right;
  Tstack_symb fun_args;
  Tsymb symb_fun_arg;
  /* my_DAG_message("[LAZY_AXIOM] %D %D %d %S\n", */
  /*                APP_DAG, DAG, contains_DAG(APP_DAG), DAG_sort(DAG)); */
  if (contains_DAG(APP_DAG))
    return;
  stack_push(lazy_app_dags, APP_DAG);
  if (arity_sort)
    {
      stack_INIT(fun_args);
      for (i = 0; i < arity_sort - 1; i++)
        {
          /* my_DAG_message("[SORT] %S \n", DAG_sort_sub(DAG_sort(APP_DAG), i)); */
          symb_fun_arg = DAG_symb_variable(DAG_sort_sub(DAG_sort(APP_DAG), i));
          stack_push(fun_args, symb_fun_arg);
        }
      /* my_DAG_message("[PRE_LAZY_AXIOM] %D %D %S %d \n", */
      /*                APP_DAG, DAG, DAG_sort(DAG), DAG_sort_arity(DAG_sort(DAG))); */
      if (DAG_symb(APP_DAG) == DAG_symb(DAG) && DAG_symb(DAG) != APPLY)
        {
          stack_insert(fun_args, DAG_symb(DAG), 0);
          left = curry(app_symb_term(APPLY, fun_args));
          stack_delete(fun_args, 0);
          right = app_symb_term(DAG_symb(DAG), fun_args);
        }
      else
        {
          left = app_term(APP_DAG, fun_args);
          right = app_term(DAG, fun_args);
        }
      if (DAG_sort(left) == SORT_BOOLEAN)
        {
          eq = DAG_dup(DAG_equiv(left, right));
          /* my_DAG_message("[LAZY_AXIOM] %D %D\n", eq, DAG); */
        }
      else
        eq = DAG_dup(DAG_eq(left, right));
      eq_forall = smt2_term_forall(fun_args, eq);
      stack_reset(fun_args);
      stack_free(fun_args);
    }
  else
    {
      if (DAG_sort(DAG) == SORT_BOOLEAN)
        {
          eq = DAG_dup(DAG_equiv(APP_DAG, DAG));
          /* my_DAG_message("[LAZY_AXIOM] %D %D\n", eq, DAG); */
        }
      else
        eq = DAG_dup(DAG_eq(APP_DAG, DAG));
    }
  if (lemmas)
    stack_push(*lemmas, (arity_sort)?eq_forall:eq);
  else
    stack_push(in_proceding_app, (arity_sort)?eq_forall:eq);
}

void
extensionality_axiom(Tsort sort, Tstack_DAG *lemmas)
{
  unsigned i;
  int arity_sort = DAG_sort_arity(sort);
  TDAG f, g, eq, eq_left, eq_right, axiom, left, right;
  Tstack_symb fun_args;
  Tsymb symb_fun_arg;
  if (contains_sort(sort) || !arity_sort)
    return;
  stack_push(ext_sorts, sort);
  stack_INIT(fun_args);
  symb_fun_arg = DAG_symb_variable(sort);
  f = DAG_dup(DAG_new_nullary(symb_fun_arg));
  symb_fun_arg = DAG_symb_variable(sort);
  g = DAG_dup(DAG_new_nullary(symb_fun_arg));
  eq_left = DAG_dup(DAG_neq(f, g));
  /* my_DAG_message("[LEFT_HYP] %D %d %S\n", eq_left, arity_sort, sort); */
  stack_push(fun_args, DAG_symb(f));
  for (i = 0; i < arity_sort - 1; i++)
    {
      symb_fun_arg = DAG_symb_skolem(DAG_sort_sub(sort, i));
      stack_push(fun_args, symb_fun_arg);
    }
  left = app_symb_term(APPLY, fun_args);
  stack_set(fun_args, 0, DAG_symb(g));
  right = app_symb_term(APPLY, fun_args);
  if (DAG_sort(left) == SORT_BOOLEAN)
    eq_right = DAG_dup(DAG_not(DAG_equiv(left, right)));
  else
    eq_right = DAG_dup(DAG_neq(left, right));
  stack_delete(fun_args, 0);
  /* my_DAG_message("[CONCLUSION] %D\n", eq_forall); */
  axiom = DAG_dup(DAG_implies(eq_left, eq_right));
  /* my_DAG_message("[AXIOM_HYP] %D\n", axiom); */
  stack_reset(fun_args);
  stack_push(fun_args, DAG_symb(f));
  stack_push(fun_args, DAG_symb(g));
  eq = smt2_term_forall(fun_args, axiom);
  /* my_DAG_message("[AXIOM_EXT] %D\n", eq); */
  if (lemmas)
    stack_push(*lemmas, eq);
  else
    stack_push(in_proceding_app, eq);
  stack_reset(fun_args);
  stack_free(fun_args);
}
void
smt2_constraint_constructor(char *constructor, TDAG term)
{
  unsigned i;
  TDAG applied_sel;
  Tstack_sel selectors_stack = get_selectors(DAG_sort(term), constructor);
  for (i = 0; selectors_stack && i < stack_size(selectors_stack); i++)
    {
      char *sel_name = stack_get(selectors_stack, i)->symb;
      applied_sel = smt2_sub_app(strmake(sel_name), smt2_term_list_one(term));
      /* my_DAG_message("[SELECTION] : "); */
      unfold_selector(term, applied_sel, i);
    }
}

TDAG
smt2_strengthening(TDAG DAG, TDAG IND_DAG)
{
  unsigned i, j;
  Tlist split = NULL, args = NULL;
  TDAG applied_cons, applied_sel, constrainte, explicit_split = DAG_NULL;
  char *sel_name;
  Tstack_sel stack_sel;
  Tstack_DAG stack_DAG;
  Tstack_constructor stack_constructors =
    stack_get(datatype_hash, (unsigned)DAG_sort(DAG));
  stack_INIT(stack_DAG);
  /* printf("SPLIT_RULE"); DAG_print(DAG); printf("[\n"); */
  for (i = 0; i < stack_size(stack_constructors); i++)
    {
      args = NULL;
      stack_sel = stack_get(stack_constructors, i)->selectors;
      for (j = 0; stack_sel && j < stack_size(stack_sel); j++)
        {
          sel_name = stack_get(stack_sel, j)->symb;
          applied_sel = smt2_sub_app(strmake(sel_name),
                                     smt2_term_list_one(DAG));
          /* printf("[DECOMP] ");DAG_print( applied_sel);printf("\n"); */
          if (DAG_arity(DAG) == stack_size(stack_sel))
            unfold_selector(DAG, applied_sel, j);
          args = add_list_term(args, applied_sel, j);
          if (DAG_sort(applied_sel) == DAG_sort(IND_DAG))
            {
              unsigned l;
              for (l = 0; l < stack_size(stack_DAG); l++)
                if (stack_get(stack_DAG, l) == applied_sel)
                  break;
              if (l == stack_size(stack_DAG))
                stack_push(stack_DAG, applied_sel);
            }
        }
      if (!j)
        continue;
      applied_cons =
        smt2_sub_app(strmake(stack_get(stack_constructors, i)->symb), args);
      constrainte = build_eq(DAG, applied_cons);
      if (!i || !split)
        split = smt2_term_list_one(constrainte);
      else
        split = smt2_term_list_add(split, constrainte);
    }
  for (i = 0; i < stack_size(stack_DAG); i++)
    {
      constrainte = build_eq(IND_DAG, stack_get(stack_DAG, i));
      split = smt2_term_list_add(split, constrainte);
    }
  if (split)
    {
      explicit_split = smt2_sub_app(strmake("and"), split);
      /* printf("[STRENGTHENING] "); DAG_print(explicit_split);printf("]\n"); */
      split = NULL;
    }

  stack_reset(stack_DAG);
  stack_free(stack_DAG);
  return explicit_split;
}

extern TDAG rename_all(TDAG src);

extern bool option_learning_native;
extern bool option_extract_features;
extern bool no_rename;
extern bool compare_ml;
TDAG
smt2_term_app(char * str, Tlist term_list)
{
  bool strengthening = false;  size_t arity_alloc;
  unsigned i, arity = list_length(term_list);
    Tsymb symb = DAG_SYMB_NULL, qind_var = DAG_SYMB_NULL;
  TDAG *sub, DAG, streng = DAG_NULL, qind_DAG;
  Tstack_symb ind_vars;

  arity_alloc = arity * sizeof(TDAG);
  MY_MALLOC(sub, arity_alloc);
  for (i = 0; i < arity; i++, term_list = list_cdr(term_list))
    sub[i] = DAG_of_ptr(list_car(term_list));
  assert(!(strcmp(str, "=") == 0) || arity >= 2);
  if (strcmp(str, "=") == 0)
    {
      if (DAG_sort(sub[0]) == SORT_BOOLEAN)
        symb = CONNECTOR_EQUIV;
      else
        symb = PREDICATE_EQ;
    }
  else if (strcmp(str, "ite") == 0)
    {
      if (arity != 3)
        veriT_error("smt2_term_app: wrong arity for ITE symbol on line %d.", yylineno);
      if (DAG_sort(sub[0]) != SORT_BOOLEAN ||
          DAG_sort(sub[1]) != DAG_sort(sub[2]))
        veriT_error("smt2_term_app: typing error in ite application on line %d.", yylineno);
      else if (DAG_sort(sub[1]) == SORT_BOOLEAN)
        symb = CONNECTOR_ITE;
      else
        symb = FUNCTION_ITE;
    }
  else
    {
      Tsort * Psort;
      arity_alloc = arity * sizeof(Tsort);
      MY_MALLOC(Psort, arity_alloc);
      for (i = 0; i < arity; i++)
        Psort[i] = DAG_sort(sub[i]);
      symb = DAG_symb_lookup(str, arity, Psort, DAG_SORT_NULL);
      if (DT_active)
        {
          if (strcmp(str, "not") == 0 && DAG_symb(sub[0]) == QUANTIFIER_FORALL)
            {
              stack_INIT(ind_vars);
              if (is_datatype(DAG_symb(DAG_arg(sub[0], 0))) && DAG_arity(sub[0]) >= 2)
                {
                  i = 0;
                  qind_var = DAG_symb_variable(DAG_sort(DAG_arg(sub[0], i)));
                  qind_DAG = DAG_dup(DAG_new_nullary(qind_var));
                  TDAG ind_hyp = smt2_strengthening(DAG_arg(sub[0], i), qind_DAG);
                  TDAG ind_goal = DAG_subst(DAG_arg(sub[0], DAG_arity(sub[0]) - 1),
                                            DAG_arg(sub[0], i), qind_DAG);

                  streng = DAG_implies(ind_hyp, ind_goal);
                  streng = DAG_or2(DAG_arg(sub[0], DAG_arity(sub[0]) - 1), streng);
                  sub[0] = DAG_subst(sub[0], DAG_arg(sub[0], DAG_arity(sub[0]) - 1), streng);
                  strengthening = true;
                }
              else if (DAG_sort(DAG_arg(sub[0], 0)) == SORT_INTEGER && DAG_arity(sub[0]) >= 2)
                {
                  qind_var = DAG_symb_variable(DAG_sort(DAG_arg(sub[0], 0)));
                  qind_DAG = /* DAG_dup */(DAG_new_nullary(qind_var));
                  TDAG ind_hyp_1 = DAG_new_binary(PREDICATE_LEQ,
                                                  smt2_term_const("0"), qind_DAG);
                  TDAG ind_hyp_2 = DAG_new_binary(PREDICATE_LEQ,
                                                  qind_DAG, DAG_arg(sub[0], 0));
                  TDAG ind_hyp = DAG_and2(ind_hyp_1, ind_hyp_2);
                  TDAG ind_goal = DAG_subst(DAG_arg(sub[0], DAG_arity(sub[0]) - 1),
                                            DAG_arg(sub[0], 0), qind_DAG);
                  streng = DAG_implies(ind_hyp, ind_goal);
                  streng = DAG_or2(DAG_arg(sub[0], DAG_arity(sub[0]) - 1), streng);
                  sub[0] = DAG_subst(sub[0], DAG_arg(sub[0], DAG_arity(sub[0]) - 1), streng);
                  strengthening = true;
                }
            }
          else if (symb == QUANTIFIER_EXISTS)
            {
              if (is_datatype(DAG_symb(sub[0])) && arity == 2)
                {
                  qind_var = DAG_symb_variable(DAG_sort(sub[0]));
                  qind_DAG = DAG_dup(DAG_new_nullary(qind_var));
                  TDAG ind_hyp = smt2_strengthening(sub[0], qind_DAG);
                  TDAG ind_goal = DAG_subst(sub[1], sub[0], qind_DAG);
                  streng = DAG_implies(ind_hyp, ind_goal);
                  streng = DAG_or2(sub[1], streng);
                  strengthening = true;
                }
            }
          else
            strengthening = false;
        }
      if ((!is_predicate_app(symb, arity) && full_app) ||
          (!is_predicate(str, symb, arity) && (DAG_symb_type(symb) & SYMB_VARIABLE)))
        {
          TDAG new_term = smt2_term(strmake(str));
          DAG = smt2_lambda_app_fun(new_term, term_list);
          if (strengthening)
            DAG = smt2_term_forall(smt2_stack_var_one(qind_var), DAG);
          if (DAG_symb_type(DAG_symb(DAG)) & SYMB_SELECTOR)
            smt2_split_datatype(DAG);
          else if (DAG_symb_type(DAG_symb(DAG)) & SYMB_CONSTRUCTOR)
            smt2_constraint_constructor(str, DAG);
          if (!full_app)
            free(sub);
          if ((!option_learning_native && !compare_ml && !option_extract_features) || !no_rename)
            return DAG;
          TDAG tmp = rename_all(DAG);
          DAG = tmp;
          return DAG;
        }
       if (!symb)
         veriT_error("smt2_term_app: unresolved symbol %s on line %d.", str, yylineno);
      DAG = DAG_dup(DAG_new(symb, arity, sub));
      if (strengthening)
        DAG = smt2_term_forall(smt2_stack_var_one(qind_var), DAG);
      if (DAG_symb_type(DAG_symb(DAG)) & SYMB_SELECTOR)
        smt2_split_datatype(DAG);
      else if (DAG_symb_type(DAG_symb(DAG)) & SYMB_CONSTRUCTOR)
        smt2_constraint_constructor(str, DAG);
      if (lazy_app && DAG_sort_arity(DAG_sort(DAG)) > 0 &&
          !smt2_sort_parametric(DAG_sort(DAG)) &&
          !is_predicate_app(symb, arity))
        {
          TDAG new_term = smt2_term(strmake(str));
          TDAG DAG0 = smt2_lambda_app_fun(new_term, term_list);
          DAG_free(DAG);
          if ((!option_learning_native && !compare_ml && !option_extract_features) || !no_rename)
            return DAG0;
          TDAG tmp = rename_all(DAG0);
          DAG0 = tmp;
          return DAG0;
        }
      else
        {
          for (i = 0; i < arity; i++)
            DAG_free(DAG_arg(DAG, i));
          free(str);
          list_free(&term_list);
          if ((!option_learning_native && !compare_ml && !option_extract_features) || !no_rename)
            return DAG;
          TDAG tmp = rename_all(DAG);
          DAG = tmp;
          return DAG;
        }
    }
  if (!symb)
    veriT_error("smt2_term_app: unresolved symbol %s on line %d.", str, yylineno);
  DAG = DAG_dup(DAG_new(symb, arity, sub));
  for (i = 0; i < arity; i++)
    DAG_free(DAG_arg(DAG, i));
  list_free(&term_list);
  free(str);
  if ((!option_learning_native && !compare_ml && !option_extract_features) || !no_rename)
    return DAG;
  TDAG tmp = rename_all(DAG);
  DAG = tmp;
  return DAG;
}

/*--------------------------------------------------------------*/

TDAG
smt2_iterm(char * str, Tlist numeral_list)
{
  veriT_error("unimplemented indexed symbol on line %d", yylineno);
  list_free(&numeral_list);
  free(str);
  /* should certainly free elements in numeral_list */
  return DAG_NULL;
}

/*--------------------------------------------------------------*/

TDAG
smt2_iterm_app(char * str, Tlist term_list, Tlist numeral_list)
{
  veriT_error("unimplemented indexed symbol on line %d", yylineno);
  /*
    for (i = 0; i < arity; i++)
    DAG_free(DAG_arg(DAG, i));
  */
  list_free(&term_list);
  list_free(&numeral_list);
  free(str);
  /* should certainly free elements in numeral_list */
  return DAG_NULL;
}

/*--------------------------------------------------------------*/

static Tsymb
qualified_symb(char * str, Tsort sort)
{
  Tsymb symb;
  symb = DAG_symb_lookup_sort(str, sort);
  if (symb == DAG_SYMB_NULL)
    veriT_error("unresolved qualified symbol %s on line %d.",
                str, yylineno);
  free(str);
  return symb;
}

/*--------------------------------------------------------------*/

TDAG
smt2_term_s(char * str, Tsort sort)
{
  Tsymb symb;
  symb = qualified_symb(str, sort);
  if (symb == DAG_SYMB_NULL)
    return DAG_NULL;
  return DAG_dup(DAG_new_nullary(symb));
}

/*--------------------------------------------------------------*/

TDAG
smt2_term_app_s(char * str, Tlist term_list, Tsort sort)
{
  size_t arity_alloc;
  unsigned i, arity;
  Tsymb symb;
  TDAG *sub, DAG;
  symb = qualified_symb(str, sort);
  if (symb == DAG_SYMB_NULL)
    return DAG_NULL;
  arity = list_length(term_list);
  arity_alloc = arity * sizeof(TDAG);
  MY_MALLOC(sub, arity_alloc );
  for (i = 0; i < arity; i++, term_list = list_cdr(term_list))
    sub[i] = DAG_of_ptr(list_car(term_list));
  DAG = DAG_dup(DAG_new(symb, arity, sub));
  for (i = 0; i < arity; i++)
    DAG_free(DAG_arg(DAG, i));
  list_free(&term_list);
  return DAG;
}

/*--------------------------------------------------------------*/

TDAG
smt2_iterm_s(char * str, Tlist numeral_list, Tsort sort)
{
  veriT_error("unimplemented indexed identifier on line %d", yylineno);
  list_free(&numeral_list);
  free(str);
#ifdef PEDANTIC
  printf("%d\n", sort);
#endif
  /* should certainly free elements in numeral_list */
  return DAG_NULL;
}

/*--------------------------------------------------------------*/

TDAG
smt2_iterm_app_s(char * str, Tlist term_list, Tlist numeral_list, Tsort sort)
{
  veriT_error("unimplemented indexed identifier on line %d", yylineno);
  /*
    for (i = 0; i < arity; i++)
    DAG_free(DAG_arg(DAG, i));
  */
  list_free(&term_list);
  list_free(&numeral_list);
  /* should certainly free elements in numeral_list */
  free(str);
#ifdef PEDANTIC
  printf("%d\n", sort);
#endif
  return DAG_NULL;
}

/*--------------------------------------------------------------*/

TDAG
smt2_let(Tlist bind_list, TDAG term)
{
  TDAG DAG;
  Tstack_DAG stack_DAG = NULL;
  stack_INIT(stack_DAG);
  if (!bind_list)
    veriT_error("ill-formed let on line %d", yylineno);
  LIST_LOOP_BEGIN(bind_list, Tbind, bind);
  stack_push(stack_DAG, DAG_dup(DAG_new_nullary(bind->symb)));
  stack_push(stack_DAG, bind->DAG);
  LIST_LOOP_END(bind_list);
  stack_push(stack_DAG, term);
  DAG = DAG_dup(DAG_new_stack(LET, stack_DAG));
  stack_apply(stack_DAG, DAG_free);
  stack_free(stack_DAG);
  /* PF bind list will be freed in smt2_undeclare_bind_list */
  return DAG;
}

/*--------------------------------------------------------------*/

static TDAG
smt2_term_binder(Tsymb binder, Tstack_symb stack_var, TDAG term,
                 const char * str)
{
  unsigned i;
  TDAG DAG;
  Tstack_DAG stack_arg;
  stack_INIT(stack_arg);
  if (!stack_var || !stack_var->size)
    veriT_error("ill-formed %s on line %d", str, yylineno);
  for (i = 0; i < stack_var->size; i++)
    stack_push(stack_arg, DAG_new_nullary(stack_var->data[i]));
  stack_push(stack_arg, term);
  DAG = DAG_dup(DAG_new_stack(binder, stack_arg));
  stack_free(stack_arg);
  DAG_free(term);
  return DAG;
}

/*--------------------------------------------------------------*/

TDAG
smt2_term_forall(Tstack_symb stack_var, TDAG term)
{
  if (lazy_app && !stack_is_empty(in_proceding_app))
    {
      Tlist arguments = NULL;
      arguments = add_list_term(arguments, term, 0);
      while (!stack_is_empty(in_proceding_app))
        arguments = add_list_term(arguments, stack_pop(in_proceding_app), 1);
      term = smt2_term_app(strmake("and"), arguments);
    }
  if (!stack_is_empty(in_proceding))
    {
      Tlist arguments = NULL;
      arguments = add_list_term(arguments, term, 0);
      while (!stack_is_empty(in_proceding))
        arguments = add_list_term(arguments, stack_pop(in_proceding), 1);
      my_DAG_message("FOR %D\n", term);
      term = smt2_sub_app(strmake("and"), arguments);
    }
  return smt2_term_binder(QUANTIFIER_FORALL, stack_var, term,
                          "quantified formula");
}

/*--------------------------------------------------------------*/

TDAG
smt2_term_exists(Tstack_symb stack_var, TDAG term)
{
  if (lazy_app && !stack_is_empty(in_proceding_app))
    {
      Tlist arguments = NULL;
      arguments = add_list_term(arguments, term, 0);
      while (!stack_is_empty(in_proceding_app))
        arguments = add_list_term(arguments, stack_pop(in_proceding_app), 1);
      term = smt2_term_app(strmake("and"), arguments);
    }
  if (!stack_is_empty(in_proceding))
    {
      Tlist arguments = NULL;
      arguments = add_list_term(arguments, term, 0);
      while (!stack_is_empty(in_proceding))
        arguments = add_list_term(arguments, stack_pop(in_proceding), 1);
      term = smt2_sub_app(strmake("and"), arguments);
    }
  return smt2_term_binder(QUANTIFIER_EXISTS, stack_var, term,
                          "quantified formula");
}

/*--------------------------------------------------------------*/

TDAG
smt2_term_lambda(Tstack_symb stack_var, TDAG term)
{
  return smt2_term_binder(LAMBDA, stack_var, term, "lambda term");
}

/*--------------------------------------------------------------*/


TDAG
smt2_term_attr(TDAG term, char * keyword)
{
  veriT_error("unimplemented attributed term on line %d", yylineno);
  free(keyword);
  return term;
}

/*--------------------------------------------------------------*/

TDAG
smt2_term_attr_str(TDAG term, char * keyword, char * str)
{
  if (keyword && !strcmp(keyword, ":named"))
    {
      char * name = strmake(str);
      DAG_prop_set(term, DAG_PROP_NAMED, &name);
    }
  else
    veriT_error("unimplemented attributed term on line %d", yylineno);
  free(keyword);
  free(str);
  return term;
}

/*--------------------------------------------------------------*/

#if 0
TDAG
smt2_term_attr_value(TDAG term, char * keyword, void * value)
{
  veriT_error("unimplemented attributed term on line %d", yylineno);
  free(keyword);
#ifdef PEDANTIC
  printf("%p\n", value);
#endif
  return term;
}
#endif

/*--------------------------------------------------------------*/

TDAG
smt2_term_attr_named(TDAG term, char * str)
{
  DAG_prop_set(term, DAG_PROP_NAMED, &str);
  return term;
}

/*--------------------------------------------------------------*/


/*
  DAG_PROP_TRIGGER is a list of lists of DAGs.
  Each time a term_list has been parsed as the value of
  the :pattern keyword, it is added to the property
  value.
*/
TDAG
smt2_term_attr_pattern(TDAG formula, Tlist term_list)
{
  Tstack_DAGstack *Pannot = DAG_prop_get(formula, DAG_PROP_TRIGGER);
  Tstack_DAG trigger;
  stack_INIT_s(trigger, list_length(term_list));
  /* PF terms in term_list already have been DAG_dupped */
  while (term_list)
    {
      stack_push(trigger, DAG_of_ptr(list_car(term_list)));
      term_list = list_remove(term_list);
    }
  if (!Pannot)
    {
      Tstack_DAGstack annot;
      stack_INIT(annot);
      stack_push(annot, trigger);
      DAG_prop_set(formula, DAG_PROP_TRIGGER, &annot);
    }
  else
    stack_push(*Pannot, trigger);
  /* veriT_error("FINISH %d", yylineno); */
  return formula;
}

/*--------------------------------------------------------------*/

Tbind
smt2_bind(char * symbol, TDAG term)
{
  Tbind bind;
  MY_MALLOC(bind, sizeof(struct TSbind));
  bind->symb = DAG_symb_new(symbol, SYMB_VARIABLE, DAG_sort(term));
  free(symbol);
  bind->DAG = term;
  return bind;
}

/*
  --------------------------------------------------------------
  Binders
  --------------------------------------------------------------
*/

void
smt2_declare_bind_list(Tlist bind_list)
{
  LIST_LOOP_BEGIN(bind_list, Tbind, bind);
  assert(DAG_symb_type(bind->symb) & SYMB_NAMED);
  declare_str(DAG_symb_name2(bind->symb), bind->symb);
  LIST_LOOP_END(bind_list);
}

/*--------------------------------------------------------------*/

void
smt2_undeclare_bind_list(Tlist bind_list)
{
  LIST_REVLOOP_BEGIN(bind_list, Tbind, bind);
  assert(DAG_symb_type(bind->symb) & SYMB_NAMED);
  undeclare_str(DAG_symb_name2(bind->symb), bind->symb);
  free(bind);
  LIST_REVLOOP_END(bind_list);
  list_free(&bind_list);
}

/*--------------------------------------------------------------*/

void
smt2_declare_stack_var(Tstack_symb stack_var)
{
  unsigned i;
  for (i = 0; i < stack_var->size; i++)
    declare_str(DAG_symb_name2(stack_var->data[i]), stack_var->data[i]);
}

/*--------------------------------------------------------------*/

void
smt2_undeclare_stack_var(Tstack_symb stack_var)
{
  unsigned i;
  for (i = stack_var->size; i-- > 0;)
    undeclare_str(DAG_symb_name2(stack_var->data[i]), stack_var->data[i]);
  /* PF Should we do this? free(symb); */
  stack_free(stack_var);
}

/*
  --------------------------------------------------------------
  Tsymb
  --------------------------------------------------------------
*/

Tsymb
smt2_var(char * symbol, Tsort sort)
{
  Tsymb symb = DAG_symb_new(symbol, SYMB_VARIABLE, sort);
  if (!symb)
    veriT_error("unable to create variable %s on line", symbol, yylineno);
  free(symbol);
  return symb;
}


/*
  --------------------------------------------------------------
  Extension of SMT-LIB2.6 with data-types
  --------------------------------------------------------------
*/

Tsel
smt2_selector(char * symbol, Tsort sort)
{
  Tsel selector;
  /* my_DAG_message("SEL : %s %S\n", symbol, sort); */
  MY_MALLOC(selector, sizeof(struct Tsel));
  selector->symb = strmake(symbol);
  free(symbol);
  selector->sort = sort;
  return selector;
}

/*--------------------------------------------------------------*/

Tstack_sel
smt2_stack_sel_new(void)
{
  return NULL;
}

Tstack_sel
smt2_stack_sel_one(Tsel sel)
{
  Tstack_sel stack_sel;
  stack_INIT(stack_sel);
  stack_push(stack_sel, sel);
  return stack_sel;
}

/*--------------------------------------------------------------*/

Tstack_sel
smt2_stack_sel_add(Tsel sel, Tstack_sel stack_sel)
{
  if (!stack_sel)
    return smt2_stack_sel_one(sel);
  stack_push(stack_sel, sel);
  return stack_sel;
}


/*--------------------------------------------------------------*/

Tconstructor
smt2_constructor(char * symbol, Tstack_sel selectors)
{
  Tsort const_sort;
  unsigned i;
  Tconstructor constructor;
  MY_MALLOC(constructor, sizeof(struct Tconstructor));
  constructor->symb = strmake(symbol);
  constructor->selectors = selectors;
  stack_INIT(constructor->args);
  if (selectors)
    {
      for (i = 0; i < stack_size(selectors); i++)
        {
          const_sort = stack_get(selectors, i)->sort;
          stack_push(constructor->args,
                     DAG_dup(DAG_new_nullary(DAG_symb_const_data(const_sort))));
        }
    }
  free(symbol);
  return constructor;
}

/*--------------------------------------------------------------*/


Tstack_constructor
smt2_stack_constructor_one(Tconstructor constr)
{
  Tstack_constructor constructors;
  stack_INIT(constructors);
  stack_push(constructors, constr);
  return constructors;
}

/*--------------------------------------------------------------*/

Tstack_constructor
smt2_stack_constructor_add(Tconstructor constr, Tstack_constructor stack)
{
  stack_push(stack, constr);
  return stack;
}

/*--------------------------------------------------------------*/

Tdatatype
smt2_stack_data_one_par(Tstack_constructor constr, T_SORT_LIST sort_list)
{
  Tdatatype datatype;
  MY_MALLOC(datatype, sizeof(struct Tdatatype));
  stack_INIT(datatype->constructors);
  stack_INIT(datatype->sort_list);
  stack_push(datatype->constructors, constr);
  stack_push(datatype->sort_list, sort_list);
  return datatype;
}

/*--------------------------------------------------------------*/

Tdatatype
smt2_stack_data_add_par(Tstack_constructor constr, T_SORT_LIST sort_list,
                    Tdatatype data)
{
  stack_push(data->constructors, constr);
  stack_push(data->sort_list, sort_list);
  return data;
}

Tdatatype
smt2_stack_data_one(Tstack_constructor constr)
{
  Tdatatype datatype;
  MY_MALLOC(datatype, sizeof(struct Tdatatype));
  stack_INIT(datatype->constructors);
  stack_INIT(datatype->sort_list);
  stack_push(datatype->constructors, constr);
  stack_push(datatype->sort_list, NULL);
  return datatype;
}

/*--------------------------------------------------------------*/

Tdatatype
smt2_stack_data_add(Tstack_constructor constr, Tdatatype data)
{
  stack_push(data->constructors, constr);
  stack_push(data->sort_list, NULL);
  return data;
}

/*--------------------------------------------------------------*/
Tstack_stack_sel get_sel;
Tstack_DAG constr_hash;


static void
resize_stack(unsigned size)
{
  unsigned previous_size, i;
  if (stack_is_empty(datatype_hash))
    {
      stack_inc_n(datatype_hash,  size);
      for (i = 0; i < size; i++)
        stack_set(datatype_hash, i, 0);
    }
  else if (stack_size(datatype_hash) < size)
    {
      previous_size = stack_size(datatype_hash);
      stack_inc_n(datatype_hash,  (size - previous_size));
      for (i = previous_size; i < size; i++)
        stack_set(datatype_hash, i, 0);
    }
}

void
smt2_declare_constructor(char * symbol, Tstack_sel selectors, Tsort sort)
{
  VERIFY_LOGIC_NOT_SET;
  VERIFY_CHECK_SAT;
  check_protected_symbol(symbol);
  if (!selectors || stack_size(selectors) == 0)
    {
      Tsymb symb = DAG_symb_new(symbol, SYMB_CONSTRUCTOR, sort);
      stack_push(constr_hash, symb);
      stack_push(get_sel, NULL);
      /* free(symbol); */
    }
  else
    {
      size_t arity_alloc;
      unsigned i, arity;
      Tsort *sub;
      arity = stack_size(selectors);
      arity_alloc = (arity + 1) * sizeof(Tsort);
      MY_MALLOC(sub, arity_alloc);
      for (i = 0; i < stack_size(selectors); i++)
        {
          smt2_declare_fun_sel(strmake(stack_get(selectors, i)->symb),
                           smt2_sort_var_list_one(sort),
                           stack_get(selectors, i)->sort);
          sub[i] = stack_get(selectors, i)->sort;
        }
      sub[i] = sort;
      Tsort s = DAG_sort_new(NULL, arity + 1, sub);
      Tsymb symb = DAG_symb_new(symbol, SYMB_CONSTRUCTOR, s);
      if (!symb)
        veriT_error("unable to create variable %s on line", symbol, yylineno);
      /** store for each constructors the list of selectors**/
      stack_push(constr_hash, symb); /**< hash table to find selectors
                                        SYMB -> IDconstr */
      stack_push(get_sel, selectors); /**< store the selectors of the constructor **/
      free(symbol);
      /* free(name); */
      /* free(sub); */
    }
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_declare_datatype(Tstack_constructor constructors,
                      T_SORT_LIST sort_list, char * symbol)
{
  int i;
  Tsort sort = DAG_sort_lookup(symbol);
  if (!sort_list)
    sort = smt2_sort_apply(sort, sort_list);
  if (!sort)
    veriT_error("undefined sort %s on line %d", symbol, yylineno);
  resize_stack(sort +  1);
  stack_set(datatype_hash, sort, constructors);
  for (i = 0; i < stack_size(constructors); i++)
    smt2_declare_constructor(strmake(stack_get(constructors, i)->symb),
                             stack_get(constructors, i)->selectors, sort);
  PRINT_SUCCESS;
}

/*--------------------------------------------------------------*/

void
smt2_declare_datatypes(Tdatatype datatypes, Tlist symbols)
{
  unsigned i;
  for (i = 0; i < list_length(symbols); i++, symbols = list_cdr(symbols))
      smt2_declare_datatype(stack_get(datatypes->constructors, i),
                            stack_get(datatypes->sort_list, i),
                            ((char *) list_car(symbols)));
  stack_reset(datatypes->constructors);
  stack_reset(datatypes->sort_list);
  stack_free(datatypes->constructors);
  stack_free(datatypes->sort_list);
  free(datatypes);
  list_free(&symbols);
  PRINT_SUCCESS;
}


/*
  --------------------------------------------------------------
  Sorts
  --------------------------------------------------------------
*/

/**
   \author David Deharbe
   \brief Creates a sort variable
   \param str The name of the sort variable */
Tsort
smt2_sort_var(char * str)
{
  Tsort sort = DAG_sort_new_var(str);
  free(str);
  return sort;
}

/*--------------------------------------------------------------*/

Tlist
smt2_sort_var_list_one(Tsort sort)
{
  return list_add(NULL, ptr_of_sort(sort));
}

/*--------------------------------------------------------------*/

Tlist
smt2_sort_var_list_add(Tlist sort_var_list, Tsort sort)
{
  return list_add(sort_var_list, ptr_of_sort(sort));
}

/*--------------------------------------------------------------*/

void
smt2_declare_sort_var_list(T_SORT_LIST sort_list)
{
#ifdef PEDANTIC
  printf("%p\n", (void *) sort_list);
#endif
}

/*--------------------------------------------------------------*/

void
smt2_undeclare_sort_var_list(T_SORT_LIST sort_list)
{
 list_free(&sort_list);
#ifdef PEDANTIC
  printf("%p\n", (void *) sort_list);
#endif
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine
   \brief check if the sort is parametric
   \param sort the sort to check
*/
int
smt2_sort_parametric(Tsort sort)
{
  return DAG_sort_parametric(sort);
}

/*--------------------------------------------------------------*/

Tsort
smt2_sort_lookup(char * symbol)
{
  Tsort sort = DAG_sort_lookup(symbol);
  if (!sort)
    veriT_error("undefined sort %s on line %d", symbol, yylineno);
  free(symbol);
  return sort;
}

/*--------------------------------------------------------------*/

Tsort
smt2_sort_lookup_index(char * symbol, Tlist sort_list)
{
  veriT_error("unimplemented");
  list_free(&sort_list);
#ifdef PEDANTIC
  printf("%s\n", symbol);
  printf("%p\n", (void *) sort_list);
#endif
  return DAG_SORT_NULL;
}


/*--------------------------------------------------------------*/

Tsort
smt2_sort_functional(Tlist sort_list)
{
  size_t size, arity_alloc;
  unsigned i, updarity, arity = list_length(sort_list);
  Tsort *sub, *updsub ;
  Tsort sort;
  char *name, *updname;
  arity_alloc = arity * sizeof(Tsort);
  MY_MALLOC(sub, arity_alloc);
  for (i = 0; i < arity; i++, sort_list = list_cdr(sort_list))
    sub[i] = sort_of_ptr(list_car(sort_list));

  list_free(&sort_list);
  /* extention we add name */
  size = (size_of_sort_str(sub, arity, 0)+1) * (sizeof(char));
  size = ((4 *(sizeof(char))) * (arity-1)) + size;
  size = (2 *(sizeof(char))) + size;
  MY_MALLOC(name,size);
  MY_MALLOC(updname,size);
  /** First we build the type in classical way **/
  name_of_functional_sort2(sub,arity,0,name);
  /** We get his flatten version  **/
  name_of_functional_sort(sub,arity,0,updname);
  /** We build the naive version **/
  sort = DAG_sort_new(name, arity , sub);
  /** Now we rebuild in flatten way **/
  updarity = arity_of_sort(updname);
  arity_alloc = updarity * sizeof(Tsort);
  MY_MALLOC(updsub , arity_alloc);
  re_build_sort(sort, updsub, updarity);
  sort = DAG_sort_new(updname,  updarity , updsub);
  free(updname);
  free(name);
  return sort;
}

/*--------------------------------------------------------------*/

Tsort
smt2_sort_apply(Tsort sort, Tlist sort_list)
{
  unsigned i, arity;
  Tsort *sub, result;
  arity = list_length(sort_list);
  MY_MALLOC(sub, arity*sizeof(Tsort));
  for (i = 0; i < arity; ++i, sort_list = list_cdr(sort_list))
    {
      Tsort sort2 = DAG_sort_of_ptr(list_car(sort_list));
      if (!sort2)
        my_error("line %d: unknown sort %s.", yylineno, DAG_sort_name(sort2));
      sub[i] = sort2;
    }
  result = DAG_sort_new_inst(NULL, sort, arity, sub);
  list_free(&sort_list);
  return result;
}



/*
  --------------------------------------------------------------
  List building functions
  --------------------------------------------------------------
*/

Tlist
smt2_term_list_one(TDAG term)
{
  return list_add(NULL, DAG_ptr_of(term));
}

/*--------------------------------------------------------------*/

Tlist
smt2_term_list_add(Tlist term_list, TDAG term)
{
  return list_add(term_list, DAG_ptr_of(term));
}

/*--------------------------------------------------------------*/

Tlist
smt2_numeral_list_one(char * numeral)
{
  return list_add(NULL, (void *) numeral);
}

/*--------------------------------------------------------------*/

Tlist
smt2_numeral_list_add(Tlist numeral_list, char * numeral)
{
  return list_add(numeral_list, (void *) numeral);
}

/*--------------------------------------------------------------*/

Tlist
smt2_bind_list_new(void)
{
  return NULL;
}

/*--------------------------------------------------------------*/

Tlist
smt2_bind_list_one(Tbind bind)
{
  return list_add(NULL, (void *) bind);
}

/*--------------------------------------------------------------*/

Tlist
smt2_bind_list_add(Tlist bind_list, Tbind bind)
{
  return list_add(bind_list, (void *) bind);
}

/*--------------------------------------------------------------*/

Tstack_symb
smt2_stack_var_new(void)
{
  Tstack_symb stack_var;
  stack_INIT(stack_var);
  return stack_var;
}

/*--------------------------------------------------------------*/

Tstack_symb
smt2_stack_var_one(Tsymb var)
{
  Tstack_symb stack_var;
  stack_INIT(stack_var);
  stack_push(stack_var, var);
  return stack_var;
}

/*--------------------------------------------------------------*/

Tstack_symb
smt2_stack_var_add(Tstack_symb stack_var, Tsymb var)
{
  stack_push(stack_var, var);
  return stack_var;
}

/*--------------------------------------------------------------*/

Tlist
smt2_sort_list_new(void)
{
  return NULL;
}

/*--------------------------------------------------------------*/

Tlist
smt2_sort_list_one(Tsort sort)
{
  return list_add(NULL, DAG_ptr_of_sort(sort));
}

/*--------------------------------------------------------------*/

Tlist
smt2_sort_list_add(Tlist sort_list, Tsort sort)
{
  return list_add(sort_list, DAG_ptr_of_sort(sort));
}

/*--------------------------------------------------------------*/

Tlist
smt2_symbol_list_new(void)
{
  return NULL;
}

/*--------------------------------------------------------------*/

Tlist
smt2_symbol_list_one(char * symbol)
{
  return list_add(NULL, (void *) symbol);
}


/*--------------------------------------------------------------*/

Tlist
smt2_symbol_list_add(Tlist symbol_list, char * symbol)
{
  return list_add(symbol_list, (void *) symbol);
}

/*--------------------------------------------------------------*/

TDAG
smt2_match(TDAG term, Tstack_case match_cases)
{
  int i;
  TDAG f_case = DAG_NULL, eq;
  Tstack_DAG conditions;
  Tlist pattern, case_term;
  stack_INIT(conditions);
  /* my_DAG_message("TERM %D\n", term); */
  for (i = 0; i < stack_size(match_cases); i++)
    {
      pattern = smt2_term_list_one(stack_get(match_cases, i)->pattern->cons);
      /* printf("pre_cond_%d: ", i); DAG_print(stack_get(match_cases, i)->pattern->cons); */
      /* printf("\n"); */
      eq = smt2_term_app(strmake("="), smt2_term_list_add(pattern, term));
      /* printf("cond_%d: ", i); DAG_print(eq); printf("\n"); */
      stack_push(conditions, eq);
      /* list_free(&pattern); */
    }
  for (i = stack_size(match_cases) - 1; i >= 0 ; i--)
    {
      case_term = smt2_term_list_one(stack_get(conditions, i));
      case_term = smt2_term_list_add(case_term,
                                     stack_get(match_cases, i)->case_term);
      if (i == stack_size(match_cases) - 1)
        case_term = smt2_term_list_add(case_term,
                                       stack_get(match_cases, i)->case_term);
      else
        case_term = smt2_term_list_add(case_term, f_case);
      f_case = smt2_term_app(strmake("ite"), case_term);
      /* printf("result "); DAG_print(f_case); printf("\n"); */
      /* list_free(&case_term); */
    }
  return f_case;
}

/*--------------------------------------------------------------*/


TDAG
smt2_tester(char *constructor, TDAG term)
{
  unsigned i;
  TDAG applied_cons, applied_sel, result;
  Tlist constructors_args = NULL;
  Tstack_sel selectors_stack = get_selectors(DAG_sort(term), constructor);
  for (i = 0; selectors_stack && i < stack_size(selectors_stack); i++)
    {
      char *sel_name = stack_get(selectors_stack, i)->symb;
      applied_sel = smt2_sub_app(strmake(sel_name), smt2_term_list_one(term));
      if (DAG_arity(term) == stack_size(selectors_stack))
        unfold_selector(term, applied_sel, i);
      constructors_args = add_list_term(constructors_args, applied_sel, i);
    }
  if (constructors_args)
    applied_cons = smt2_sub_app(strmake(constructor), constructors_args);
  else
    applied_cons = smt2_term(strmake(constructor));
  result = build_eq(term, applied_cons);
  /* my_DAG_message("TESTER %D \n", result); */
  return result;
}

Tpattern
smt2_pattern(TDAG cons, Tlist term_list)
{
  unsigned i;
  Tpattern pattern;
  Tstack_DAG terms;
  stack_INIT(terms);
  for (i = 0; i < stack_size(constr_hash) &&
         stack_get(constr_hash, i) != DAG_symb(cons); i++);
  /* my_DAG_message("%D %d \n", cons, i); */
  Tstack_sel sel = stack_get(get_sel, i);
  if (sel)
    {
      /* my_DAG_message("%D %s\n", cons, stack_get(sel, 0)->symb); */
      Tlist args;
      args = NULL;
      for (i = 0; i < list_length(term_list); i++, term_list = list_cdr(term_list))
        {
          char *tmp = ((char *) list_car(term_list));
          smt2_declare_fun(strmake(tmp), NULL, stack_get(sel, i)->sort);
          TDAG argi =
            DAG_dup(DAG_new_nullary(DAG_symb_lookup(tmp, 0, NULL, DAG_SORT_NULL)));
          if (!i)
            args = smt2_term_list_one(argi);
          else args = smt2_term_list_add(args, argi);
          stack_push(terms, argi);
        }
      /* my_DAG_message("RES_symb %s \n", DAG_symb_name2(DAG_symb(cons))); */
      cons = smt2_term_app(strmake(DAG_symb_name2(DAG_symb(cons))), args);
      /* my_DAG_message("RES %D \n", cons); */
    }
  MY_MALLOC(pattern, sizeof(struct Tpattern));
  pattern->cons = cons;
  pattern->bind_list = terms;
  return pattern;
}


T_MATCH
smt2_match_case(Tpattern pattern, TDAG term)
{
  Tcase match_case;
  MY_MALLOC(match_case, sizeof(struct Tcase));
  match_case->pattern = pattern;
  match_case->case_term = term;
  return match_case;
}

/*--------------------------------------------------------------*/

T_MATCH_LIST
smt2_match_cases_one(T_MATCH match_case)
{
  Tstack_case cases;
  stack_INIT(cases);
  stack_push(cases, match_case);
  return cases;
}

/*--------------------------------------------------------------*/

T_MATCH_LIST
smt2_match_cases_list_add(T_MATCH_LIST match_cases, T_MATCH match_case)
{
  stack_push(match_cases, match_case);
  return match_cases;
}

/*--------------------------------------------------------------*/

void
smt2_command(void)
{
}

/*
  --------------------------------------------------------------
  module init and done
  --------------------------------------------------------------
*/

void
smt2_init(bool option_disable_print_success)
{
  hashmap_str = hashmap_new(200, (TFhash)hash_function,
                            (TFequal)hash_str_equal,
                            (TFfree)hash_key_free,
                            (TFfree)hash_value_free);
  stat_result = stats_counter_new("res", "0 (UNSAT), 1 (SAT), -1 (UNKNOWN)",
                                  "%5d");
  stats_counter_set(stat_result, -1);
  smt2_print_success = !option_disable_print_success;
  smt2_diagnostic_output_channel = strmake("stderr");
  smt2_regular_output_channel = strmake("stdout");
  stack_INIT(get_sel);
  stack_INIT(splited);
  stack_INIT(in_proceding);
  stack_INIT(get_sel);
  stack_INIT(splited);
  stack_INIT(in_proceding_app);
  stack_INIT(ext_sorts);
  stack_INIT(lazy_app_dags);
  stack_INIT(ind_conjecture);
  stack_INIT(constr_hash);
  stack_INIT(datatype_hash);
  constraintes = NULL;
#if STATS_LEVEL > 1
  stat_nb_nodes = stats_counter_new("nodes",
                                    "Number of nodes in the input formula"
                                    " as a DAG representation", "%6d");
  stat_nb_nodes_tree = stats_counter_new("nodes_tree",
                                         "Number of nodes in the input"
                                         " formula as a tree"
                                         " representation",
                                         "%6d");
  stat_nb_atoms = stats_counter_new("atoms",
                                    "Number of atoms in the input"
                                    " formula as a tree representation",
                                    "%6d");
#endif
}

/*--------------------------------------------------------------*/

void
smt2_done(void)
{
  if (!smt2_exited)
    smt2_exit();
  stack_reset(splited);
  stack_reset(in_proceding);
  stack_reset(get_sel);
  stack_reset(constr_hash);
  stack_free(get_sel);
  stack_free(constr_hash);
  stack_free(splited);
  stack_free(in_proceding);
  stack_free(ind_conjecture);
  free(smt2_regular_output_channel);
  free(smt2_diagnostic_output_channel);
  hashmap_free(&hashmap_str);
  stack_reset(in_proceding_app);
  stack_free(in_proceding_app);
  stack_reset(ext_sorts);
  stack_free(ext_sorts);
  stack_reset(lazy_app_dags);
  stack_free(lazy_app_dags);
}
