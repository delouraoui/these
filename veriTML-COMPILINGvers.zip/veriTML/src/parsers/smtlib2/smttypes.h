#ifndef SMTTYPES_H
#define SMTTYPES_H

#include "veriT-DAG.h"
#include "list.h"
#include "stack.h"

typedef struct TSbind
{
  Tsymb symb;
  TDAG DAG;
} * Tbind;

typedef struct Tsel
{
  char *symb;
  Tsort sort;
} * Tsel;

TSstack(_sel, Tsel);

typedef struct Tconstructor
{
  char *symb;
  Tstack_DAG args;
  Tstack_symb stack_vars;
  Tstack_sel selectors;
} * Tconstructor;

typedef struct Tpattern
{
  TDAG cons;
  Tstack_DAG bind_list;
} * Tpattern;

typedef struct Tcase
{
  Tpattern pattern;
  TDAG case_term;
} * Tcase;

TSstack(_constructor, Tconstructor);
TSstack(_case, Tcase);
TSstack(_stack_constructor, Tstack_constructor);
TSstack(_stack_sel, Tstack_sel);


extern Tstack_stack_sel get_sel;
extern Tstack_DAG constr_hash;

#define T_BIND Tbind
#define T_BIND_LIST Tlist
#define T_FUNCTION_ID Tsymb
#define T_NUMERAL_LIST Tlist
#define T_SORT Tsort
#define T_SORT_LIST Tlist
#define T_VAR Tsymb
#define T_STACK_VAR Tstack_symb
#define T_SYMBOL_LIST Tlist
#define T_TERM TDAG
#define T_MATCH Tcase
#define T_MATCH_LIST Tstack_case
#define T_TERM_LIST Tlist
#define T_ATTR Tassoc
#define T_ATTR_LIST Tlist

/** \brief extends SMT-LIB2 with macros */
#define T_MACRO struct Tbind *


TSstack(_T_SORT_LIST, T_SORT_LIST);

typedef struct Tdatatype
{
  Tstack_stack_constructor constructors;
  Tstack_T_SORT_LIST sort_list;
} * Tdatatype;

#endif
