#include <stdlib.h>
#include <stdio.h>
#include "DAG-print.h"
#include "DAG.h"
#include "veriT-state.h"
void
veriT_print_literals(TDAG * literals, unsigned nb,
                     char * filename, char * status)
{
  FILE * file = fopen(filename, "w");
  DAG_fprint_smt2_set(file, literals, nb, status);
  fprintf(stderr, "File %s written.\n", filename);
  fclose(file);
}

/*--------------------------------------------------------------*/

void
veriT_dump_literals_and_CIs(char * status, Tstack_DAG conf_instances)
{
  unsigned i;
  TDAG * PDAG;
  char filename[128];
  static unsigned ci_count = 0;
  MY_MALLOC(PDAG, (SAT_literal_stack_n + 1) * sizeof (TDAG));
  for (i = 0; i < SAT_literal_stack_n; i++)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      assert(DAG);
      PDAG[i] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
    }
  for (i = 0; i < stack_size(conf_instances); ++i)
    {
      sprintf(filename, "ci-%02u.smt2", ++ci_count);
      TDAG CI = DAG_dup(DAG_arg1(stack_get(conf_instances, i)));
      FILE * file = fopen(filename, "w");
      DAG_fprint_smt2_set_gr_DAG(file, PDAG, SAT_literal_stack_n, CI, status);
      fprintf(stderr, "File %s written.\n", filename);
      fclose(file);
      DAG_free(CI);
    }
  for (i = 0; i < SAT_literal_stack_n; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
}

/**
   \brief prints the stack of literals in dump-**.smt2
   \param status: the status to add to file */
void
veriT_dump_literals(char * status)
{
  unsigned i;
  TDAG * PDAG;
  char filename[128];
  static unsigned count = 0;
  sprintf(filename, "dump-%u.smt2", ++count);
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof (TDAG));
  for (i = 0; i < SAT_literal_stack_n; i++)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      assert(DAG);
      PDAG[i] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
    }
  veriT_print_literals(PDAG, SAT_literal_stack_n, filename, status);
  for (i = 0; i < SAT_literal_stack_n; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
}


/*--------------------------------------------------------------*/

/**
   \brief prints the stack of literals in model-**.smt2 */
void
veriT_output_model(void)
{
  unsigned i, j;
  TDAG * PDAG;
  char filename[128];
  static unsigned model_n = 0;
  sprintf(filename, "model-%05d.smt2", ++model_n);
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG));
  for (i = 0, j = 0; i < SAT_literal_stack_n; ++i)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      if (boolean_connector(DAG_symb(DAG)))
        continue;
      PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
    }
  MY_REALLOC(PDAG, j * sizeof(*PDAG));
  if (!j)
    veriT_print_literals(&DAG_TRUE, 1, filename, "sat");
  else
    veriT_print_literals(PDAG, j, filename, "sat");
  for (i = 0; i < j; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
}

/*--------------------------------------------------------------*/

void
veriT_print_lemmas(Tstack_DAG lemmas)
{
  unsigned i;
  static int lemma_no = 0;
  for (i = 0; i < stack_size(lemmas); i++)
    {
      FILE *file;
      char filename[128];
      TDAG DAG = stack_get(lemmas, i);
      TDAG DAG2 = DAG_dup(DAG_not(DAG));
      sprintf(filename, "lemma-%d.smt2", ++lemma_no);
      file = fopen(filename, "w");
      DAG_fprint_smt2_bench(file, DAG2, "unsat");
      fprintf(stderr, "File %s written.\n", filename);
      DAG_free(DAG2);
      fclose(file);
    }
}
