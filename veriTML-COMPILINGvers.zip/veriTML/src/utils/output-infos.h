#ifndef __OUTPUT_INFOS_H
#define __OUTPUT_INFOS_H

void
veriT_output_model(void);

void
veriT_print_lemmas(Tstack_DAG lemmas);


void
veriT_dump_literals(char * status);

void
veriT_dump_literals_and_CIs(char * status, Tstack_DAG conf_instances);

void
veriT_print_literals(TDAG * literals, unsigned nb,
                     char * filename, char * status);

#endif /* __OUTPUT_INFOS_H */


