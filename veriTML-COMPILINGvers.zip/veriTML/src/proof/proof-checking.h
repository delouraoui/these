#ifndef __PROOF_CHECKING_H
#define __PROOF_CHECKING_H

#include "proof-step.h"

extern void proof_error(char * str, Tproof_step proof_step);

/*
  --------------------------------------------------------------
  Congruence checking
  --------------------------------------------------------------
*/

extern void proof_check_eq_congruent_pred(Tproof_step proof_step);
extern void proof_check_eq_congruent(Tproof_step proof_step);
extern void proof_check_eq_reflexive(Tproof_step proof_step);
extern void proof_check_eq_transitive(Tproof_step proof_step);

#endif
