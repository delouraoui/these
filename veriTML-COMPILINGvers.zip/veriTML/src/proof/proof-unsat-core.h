#ifndef __PROOF_UNSAT_CORE_H
#define __PROOF_UNSAT_CORE_H

#include <stdarg.h>
#include <stdio.h>

extern void proof_hyp(FILE * file);

#endif
