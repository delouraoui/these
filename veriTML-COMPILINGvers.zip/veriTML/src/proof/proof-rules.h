#ifndef __PROOF_RULES_H
#define __PROOF_RULES_H

#include "proof-step-table.h"

/*
  --------------------------------------------------------------
  [Context dependent] Transformations
  --------------------------------------------------------------
*/

/**
   \author Haniel Barbosa
   \brief adds a proof step with premisses and a single conclusion
   \param type rule type
   \param DAG the equivalence or equality
   \param reasons the set of premisses
   \return proof id of built step
   \remark set of premisses may be empty */
extern Tproof proof_step_conclusion(Tproof_type type,
                                    TDAG conclusion, Tstack_proof reasons);


/* [TODO] update documentation */
/**
   \author Haniel Barbosa
   \brief creates proof of transformation from src into dest
   \param src a DAG
   \param dest a DAG and its proof
   \param lits all literals as premisses for the conclusion
   \param type a proof rule
   \param context the recursion context
   \param reasons a list of proof steps leading to the proof
   \remark if the proof contains free variables, they must be among the the
   variables in the context, which are used to build an outer universal
   quantifier bounding them all */
extern Tproof proof_transformation(Tproof_type type, TDAG src, TDAG dest,
                                   Tstack_proof reasons);


/*
  --------------------------------------------------------------
  Signature extension transformations
  --------------------------------------------------------------
*/

extern void set_sko_terms(Tstack_DAG DAGs);
extern void build_choices(TDAG src);

extern void notify_ites(Tstack_DAG_assoc ite_terms, unsigned n);
extern Tproof proof_ite_intro(TDAG src, TDAG dest, Tproof id);

/*
  --------------------------------------------------------------
  Resolution
  --------------------------------------------------------------
*/

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief computes the clause from resolution of both first arguments
   \param proof_step1 first proof step
   \param proof_step2 second proof step
   \param DAG resolvent */
extern Tproof_step proof_step_resolve(Tproof_step proof_step1,
                                      Tproof_step proof_step2,
                                      TDAG DAG);

/* PF add a clause resolved from others, and returns its context id */
extern Tproof proof_resolve(unsigned nb_clauses, ...);
extern Tproof proof_resolve_array(unsigned nb_clauses, Tproof *clauses);

/**
   \author David Deharbe
   \brief adds an equisatisfiable formula, and return its context id
   \param DAG the resulting formula
   \param formula the id of the derivation to a formula
   \param table contains the id of binary clauses corresponding to
   individual subformulas that are substituted in orig
   \return the id of the rewritten formula */
extern Tproof proof_deep_res(TDAG DAG, Tproof formula, Tstack_proof table);

/**
   \author Pascal Fontaine
   \brief computes the resolution of two clauses, and returns its context id
   \param i_clause1 first clause id
   \param i_clause2 second clause id
   \return id of resolved clause
   \remark restricted version of resolution:
   a OR a OR b   resolved with c OR \neg a
   gives a OR b OR c */
extern Tproof proof_bin_resolve(Tproof i_clause1, Tproof i_clause2);


/*
  --------------------------------------------------------------
  SAT, UNSAT, Input and Lemmas
  --------------------------------------------------------------
*/

/**
   \author Pascal Fontaine
   \brief notify the module of the satisfiability of the formula */
extern void proof_satisfiable(void);

/**
   \author Pascal Fontaine
   \brief notify the module of the unsatisfiability of the formula
   \remark fails if no empty clause has been derived, an error (a
   warning at the present time) is issued */
extern void proof_unsatisfiable(void);

/**
   \author Pascal Fontaine
   \brief adds a formula as input in the proof
   \param DAG is the formula to add
   \remark the formula either comes from the user input or
   is an hypothesis (for subproofs)
   \return the id of the formula in the proof
   \remark The formula is not checked, and not deduced */
extern Tproof proof_add_input(TDAG DAG);

/**
   \author Pascal Fontaine
   \brief adds a formula (a disequality lemma) in the context
   \param DAG is the formula to add
   \return the id of the formula in the proof
   \attention The formula is not checked, and not deduced */
/* TODO CHECK!!!!! */
extern Tproof proof_add_disequality_lemma(TDAG DAG);

/**
   \author David Deharbe
   \brief adds a formula (a totality lemma) in the context
   \param DAG is the formula to add
   \return the id of the formula in the proof
   \attention The formula is not checked, and not deduced */
/* TODO CHECK!!!!! */
extern Tproof proof_add_totality_lemma(TDAG DAG);

/**
   \author Pascal Fontaine
   \brief adds a formula (an arithmetical tautology) in the context
   \param DAG is the formula to add
   \return the id of the formula in the proof
   \attention The formula is not checked, and not deduced */
/* TODO CHECK!!!!! */
extern Tproof proof_add_arith_lemma(TDAG DAG);

/**
   \author David Deharbe
   \brief adds a formula (a universal instantiation lemma) in the context
   \param DAG is the formula to add
   \param n is the number of instantiated variables
   \param PDAG is the array of instance terms
   \return the id of the formula in the proof
   \note an instance lemma is \f$ \forall X . A(X) \rightarrow A(X \ t) \f$
*/
/* TODO CHECK!!! */
extern Tproof proof_add_forall_inst_lemma(TDAG DAG, unsigned n, TDAG * PDAG);

/**
   \author David Deharbe
   \brief adds a formula (an existential instantiation lemma) in the context
   \param DAG is the formula to add
   \param n is the number of instantiated variables
   \param PDAG is the array of instance terms
   \return the id of the formula in the proof
   \note an instance lemma is \f$ A(t) \rightarrow \exists X . A(t \ X) \f$
*/
/* TODO CHECK!!! */
extern Tproof proof_add_exists_inst_lemma(TDAG DAG, unsigned n, TDAG * PDAG);

/**
   \author David Deharbe
   \brief adds an instance of Skolemization of an existential quantifier with
   positive polarity as a binary clause in the context
   \param DAG1 the quantified formula
   \param DAG2 the Skolemized formula
   \return the id of the proof
   \note a Skolem lemma is \f$ \{ \neg \exists X . A(X), A(X \ sk) \} \f$,
   where \f$ sk \f$ is a fresh constant symbol. */
extern Tproof proof_add_skolem_ex_lemma(TDAG DAG1, TDAG DAG2);

/**
   \author David Deharbe
   \brief adds an instance of Skolemization of a universal quantifier with negative
   polarity as a binary clause in the context
   \param DAG1 the quantified formula
   \param DAG2 the Skolemized formula
   \return the id of the proof
   \note a Skolem lemma is \f$ \{ \forall X . A(X), (not A(X \ sk)) \} \f$,
   where \f$ sk \f$ is a fresh constant symbol. */
extern Tproof proof_add_skolem_all_lemma(TDAG DAG1, TDAG DAG2);

/**
   \author David Deharbe
   \brief Adds a binary clause for quantifier simplification (alpha conversion
   and elimination of unused variables) in the context.
   \param DAG1 the original formula
   \param DAG2 the result formula
   \return the id of the proof */
extern Tproof proof_add_qnt_simp_lemma(TDAG DAG1, TDAG DAG2);

extern Tproof proof_add_fol_lemma(TDAG DAG);

/**
   \author Pascal Fontaine
   \brief get the id associated with the lemma
   \param DAG is the lemma
   \return the id of the lemma in the proof */
extern Tproof proof_get_lemma_id(TDAG DAG);
/**
   \author Pascal Fontaine
   \brief link a DAG and a proof_id for later lemma addition
   \param DAG the formula
   \param id the proof id of the unit clause with DAG */
extern void proof_set_lemma_id(TDAG DAG, Tproof id);

/*
  --------------------------------------------------------------
  TMP proofs
  --------------------------------------------------------------
*/

/**
   \author David Deharbe
   \brief adds an instance of alpha conversion as a unary clause in the context
   \param id is the original formula
   \parm DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule
*/
extern Tproof  proof_tmp_alphaconv(Tproof id, TDAG DAG);
extern Tproof proof_tmp_qnt_tidy(Tproof id, TDAG DAG);
extern Tproof proof_tmp_qnt_simplify(Tproof id, TDAG DAG);

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine
   \brief deduce a formula through elimination of n-ary operators
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_nary_elim(Tproof id, TDAG DAG);

extern Tproof proof_tmp_eq_norm(Tproof id, TDAG DAG);

extern Tproof proof_tmp_AC_simp(Tproof id, TDAG DAG);

extern Tproof proof_tmp_skolemize(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief deduce a formula through normalization of arithmetic
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_simp_arith(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief deduce a formula through ite elimination
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_ite_elim(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief deduce a formula through macro substitution
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_macrosubst(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief deduce a formula through beta reduction
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_betared(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief deduce formula through elimination of functions with Boolean argument
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_bfun_elim(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief deduce a formula through polymorphism elimination
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_pm_process(Tproof id, TDAG DAG);

/**
   \author Pascal Fontaine
   \brief formula transformation for linear arithmetic
   \param id is the original formula
   \param DAG the result formula
   \return the id of the proof
   \remark this is a temporary, high level, proof rule */
extern Tproof proof_tmp_LA_pre(Tproof id, TDAG DAG);

#endif
