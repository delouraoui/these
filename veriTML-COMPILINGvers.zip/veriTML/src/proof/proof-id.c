#ifdef PROOF

#include "proof-id.h"

Tstatus proof_status;
Tproof empty_clause;

#endif
