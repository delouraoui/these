#ifdef PROOF

#include "DAG-tmp.h"
#include "DAG-print.h"
#include "DAG-prop.h"
#include "proof-output.h"
#include "veriT.h"

#include "unify.h"
/* [TODO] avoid this workaround */
extern bool proof_with_sharing;
extern bool option_proof_prune;
extern bool option_proof_merge;
extern unsigned proof_version;
extern bool option_dumper_data;
extern bool option_extract_features;
extern bool option_learn_extract_features;
extern Tstack_instance_round conflicting_instances;
extern Tstack_instance_round delay_round_unifier;
extern Tstack_instance_round delay_analyse_round_unifier;

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief resets DAG_tmp of all DAGs used during printing */
static void
proof_reset_DAG_tmp(Tproof_step proof_step)
{
  unsigned i, nb_bound_vars = 0;
  for (i = 0; i < stack_size(proof_step->DAGs); ++i)
    DAG_tmp_reset_unsigned(stack_get(proof_step->DAGs, i));
  if (proof_step->args)
    for (i = 0; i < stack_size(proof_step->args); ++i)
      DAG_tmp_reset_unsigned(stack_get(proof_step->args, i));
  if (proof_step->type < ps_type_subproof)
    return;
  for (i = 1; i < stack_size(proof_step->subproof_steps); ++i)
    proof_reset_DAG_tmp(stack_get(proof_step->subproof_steps, i));
  if (proof_step->args)
    {
      nb_bound_vars = stack_top(proof_step->args);
#ifdef DEBUG
      for (i = 0; i < nb_bound_vars; ++i)
        assert(!DAG_tmp_unsigned[stack_get(proof_step->args, i)]);
#endif
      for (i = nb_bound_vars; i < stack_size(proof_step->args) - 1u; i += 2)
        {
          assert(!DAG_tmp_unsigned[stack_get(proof_step->args, i)]);
          DAG_tmp_reset_unsigned(stack_get(proof_step->args, i + 1));
        }
    }
}

/*--------------------------------------------------------------*/

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief prints proof step (for outputting the proof and debugging purposes)
   \param proof_step the proof step
   \param id the proof step id
   \param file the file to write to */
void
proof_step_print_older(Tproof_step proof_step, Tstack_proof_step steps,
                       Tproof id, FILE * file)
{
  unsigned i;
  Tproof_type type = type;
  fprintf(file, "%d:(%s (", id, ps_type_desc[type].name);
  if (type >= ps_type_subproof)
    {
      fprintf(file, "\n");
      for (i = 1; i < stack_size(proof_step->subproof_steps); ++i)
        proof_step_print_older(stack_get(proof_step->subproof_steps, i),
                               proof_step->subproof_steps, i, file);
    }
  /* gen_clause */
  else
    for (i = 0; i < stack_size(proof_step->DAGs); ++i)
      {
        if (i) fprintf(file, " ");
        DAG_proof_print(file, stack_get(proof_step->DAGs, i));
      }
  fprintf(file, ")");
  /* gen reasons/params */
  if (proof_step->reasons && !stack_is_empty(proof_step->reasons))
    for (i = 0; i < stack_size(proof_step->reasons); ++i)
      fprintf(file, " %d", stack_get(proof_step->reasons, i));
  fprintf(file, ")\n");
}

/*--------------------------------------------------------------*/
extern char *direname;
extern char file_results[512];
static Tstack_DAG Q_FORMULA;
Tstack_DAG DAG_FORMULA;
TSstack(_stack_DAG, Tstack_DAG);
static Tstack_stack_DAG ID_VAR;

static bool
contains_DAG(TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(Q_FORMULA); i++)
    if (DAG == stack_get(Q_FORMULA, i))
      return true;
  return false;
}


static unsigned
get_id(TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(Q_FORMULA); i++)
    if (DAG == stack_get(Q_FORMULA, i))
      return i;
  return (unsigned)-1;
}

/**
   \author Pascal Fontaine, Haniel Barbosa
   \brief prints proof step (for outputting the proof and debugging purposes)
   \param proof_step the proof step
   \param id the proof step id
   \param file the file to write to */
void
proof_step_print_old(Tproof_step proof_step, Tstack_proof_step steps,
                     Tproof id, FILE * file)
{
  unsigned i, nb_bound_vars, nb_reasons;
  Tproof_type type = proof_step->type;
  if (type == ps_type_input)
    {
      if (stack_size(proof_step->DAGs) != 1)
        my_error("proof_step_print: internal error\n");
      /* [TODO] check this, looks weird */
      char ** Pname = DAG_prop_get(stack_get(proof_step->DAGs, 0),
                                   DAG_PROP_NAMED);
      Pname = DAG_prop_get(stack_get(proof_step->DAGs, 0), DAG_PROP_NAMED);
      if (Pname)
        return;
    }
  fprintf(file, "(set .c%d (%s ", id, ps_type_desc[type].name);
  if (!strcmp("forall_inst",ps_type_desc[type].name))
    {
      /** get the quantified formula **/
      /* TDAG DAG = stack_get(proof_step->DAGs, 0); */
      TDAG DAG = DAG_arg0(DAG_arg0(stack_get(proof_step->DAGs, 0)));
      /* TDAG DAG = /\* DAG_arg1 *\/(stack_get(proof_step->DAGs, 0)); */
      unsigned id = 0;
      stack_push(DAG_FORMULA, stack_get(proof_step->DAGs, 0));
      if (contains_DAG(DAG))
        id = get_id(DAG);
      else
        {
          stack_push(Q_FORMULA, DAG);
          stack_push(ID_VAR, NULL);
          stack_INIT(stack_top(ID_VAR));
          id = stack_size(Q_FORMULA) - 1;
        }
      assert(!stack_is_empty(proof_step->args));
      /** DEO Added to get mor information for proof format **/
      for (i = 0; i < stack_size(proof_step->args); i += 2)
        {
          if (i) fprintf(file, " ");
          stack_push(stack_get(ID_VAR, id), stack_get(proof_step->args, i + 1));
          stack_push(stack_get(ID_VAR, id), stack_get(proof_step->args, i));
        }
    }
  /* get number of proof steps as reasons */
  assert(ps_type_desc[type].nb_reasons != -1 ||
         ps_type_desc[type].nb_params == 0);
  nb_reasons = ps_type_desc[type].nb_reasons != -1?
    ps_type_desc[type].nb_reasons :
    (proof_step->reasons? stack_size(proof_step->reasons) : 0);
  assert(nb_reasons == 0 ||
         (proof_step->reasons && nb_reasons <= stack_size(proof_step->reasons)));
  /* gen premisses */
  if (nb_reasons > 0)
    {
      fprintf(file, ":clauses (");
      for (i = 0; i < nb_reasons; ++i)
        {
          assert(stack_get(proof_step->reasons, i) <= stack_size(steps));
          Tproof_step proof_step2 =
            stack_get(steps, stack_get(proof_step->reasons, i));
          if (proof_step2->type == ps_type_input)
            {
              char ** Pname;
              if (stack_size(proof_step2->DAGs) != 1)
                my_error("proof_step_print: internal error\n");
              Pname = DAG_prop_get(stack_get(proof_step2->DAGs, 0),
                                   DAG_PROP_NAMED);
              if (Pname)
                {
                  fprintf(file, i?" %s":"%s", *Pname);
                  continue;
                }
            }
          fprintf(file, i?" .c%d":".c%d", stack_get(proof_step->reasons, i));
        }
      fprintf(file, ") ");
    }
  /* gen context */
  if (type >= ps_type_subproof)
    {
      if (proof_step->args)
        {
          fprintf(file, ":args (");
          nb_bound_vars = stack_top(proof_step->args);
          if (nb_bound_vars)
            {
              fprintf(file, "(");
              for (i = 0; i < nb_bound_vars; ++i)
                {
                  fprintf(file, "%s", i? " " : "");
                  DAG_proof_print(file, stack_get(proof_step->args, i));
                }
              fprintf(file, ")");
            }
          for (i = nb_bound_vars; i < stack_size(proof_step->args) - 1u; i += 2)
            {
              fprintf(file, "%s(:= ", i > nb_bound_vars? " " : "");
              DAG_proof_print(file, stack_get(proof_step->args, i));
              fprintf(file, " ");
              DAG_proof_print(file, stack_get(proof_step->args, i + 1));
              fprintf(file, ")");
            }
          fprintf(file, ")");
        }
      fprintf(file, "\n");
      for (i = 1; i < stack_size(proof_step->subproof_steps); ++i)
        proof_step_print_old(stack_get(proof_step->subproof_steps, i),
                             proof_step->subproof_steps, i, file);
    }
  else
    {
      if (proof_step->args)
        {
          assert(!stack_is_empty(proof_step->args));
          fprintf(file, ":args (");
          /** DEO Added to get mor information for proof format **/
          for (i = 0; i < stack_size(proof_step->args); i += 2)
            {
              if (i) fprintf(file, " ");
              fprintf(file, "(");
              DAG_proof_print(file, stack_get(proof_step->args, i + 1));
              fprintf(file, "/");
              DAG_proof_print(file, stack_get(proof_step->args, i));
              fprintf(file, ")");
            }
          fprintf(file, ") ");
        }
    }
  fprintf(file, ":conclusion (");
  for (i = 0; i < stack_size(proof_step->DAGs); ++i)
    {
      if (i) fprintf(file, " ");
      DAG_proof_print(file, stack_get(proof_step->DAGs, i));
    }
  fprintf(file, ")"); /* conclusion */
  fprintf(file, ")"); /* rule */
  fprintf(file, ")\n"); /* step */
}

/*--------------------------------------------------------------*/

void
proof_step_print(Tproof_step proof_step, Tstack_proof_step steps,
                 Tproof id, FILE * file)
{
  fprintf(file, "standard proof format not defined yet\n");
}

static bool
contains(Tstack_DAG *stack, TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(*stack); i++)
    if (stack_get(*stack, i) == DAG)
      return true;
  return false;
}


extern bool option_learning_instances;
/* #define SATINÂT */

void
useful_instances_print()
{
  unsigned i, j, k = 0;
  Tstack_DAG remember;
  stack_INIT(remember);
  for (i = 0; i < stack_size(Q_FORMULA); i++)
    {
      FILE *file_extract;
      char filename[256];
      unsigned nb_used = 0;
      sprintf(filename, "%s/useful-instances-%d.smt2", direname, k++);
      file_extract = fopen(filename, "w");
      stack_reset(remember);
      for (j = 0; j < stack_size(stack_get(ID_VAR, i)); j += 2)
        {
          if (contains(&remember, stack_get(stack_get(ID_VAR, i), j + 1)))
            {
              stack_reset(remember);
              break;
            }
          stack_push(remember, stack_get(stack_get(ID_VAR, i), j + 1));
          nb_used++;
        }
      fprintf(file_extract, "%d;", nb_used);
      DAG_fprint(file_extract, stack_get(Q_FORMULA, i));
      fprintf(file_extract, ";");
      stack_reset(remember);
      assert (stack_is_empty(remember));
      for (j = 0; j < stack_size(stack_get(ID_VAR, i)); j += 2)
        {
          if (contains(&remember, stack_get(stack_get(ID_VAR, i), j + 1)))
            {
              fclose(file_extract);
              sprintf(filename, "%s/useful-instances-%d.smt2", direname, k++);
              file_extract = fopen(filename, "w");
              stack_reset(remember);
              fprintf(file_extract, "%d;", nb_used);
              DAG_fprint(file_extract, stack_get(Q_FORMULA, i));
              fprintf(file_extract, ";");
            }
          stack_push(remember, stack_get(stack_get(ID_VAR, i), j + 1));
          if (i) fprintf(file_extract, " ");
          fprintf(file_extract, "(");
          DAG_proof_print(file_extract, stack_get(stack_get(ID_VAR, i), j + 1));
          fprintf(file_extract, "/");
          DAG_proof_print(file_extract, stack_get(stack_get(ID_VAR, i), j));
          fprintf(file_extract, ")");
        }
      fclose(file_extract);
      stack_reset(remember);
    }
  for (i = 0; i < stack_size(Q_FORMULA); i++)
    {
      stack_reset(stack_get(ID_VAR, i));
      stack_free(stack_get(ID_VAR, i));
    }
  stack_reset(ID_VAR);
  stack_reset(Q_FORMULA);
  stack_free(ID_VAR);
  stack_free(Q_FORMULA);
}

unsigned
nb_useful_roundi(unsigned nbi)
{
  unsigned i, j, l, k = 0, nb_inst = 0, nb_useful = 0, nb_round = 0;
  for (k = 0; k < stack_size(delay_round_unifier); k++)
    {
      if (!stack_get(delay_round_unifier, k).unifier)
        {
          nb_round++;
          if (nb_round > nbi)
            return nb_useful;
          continue;
        }
      if (nb_round == nbi)
        {
          for (i = 0; i < stack_size(Q_FORMULA); i++)
            {
              if (stack_get(delay_round_unifier, k).qDAG == stack_get(Q_FORMULA, i))
                {
                  nb_inst = 0;
                  Tunifier unifier = stack_get(delay_round_unifier, k).unifier;
                  for (l = 0; l < unifier->size; l++)
                    {
                      for (j = 0; j < stack_size(stack_get(ID_VAR, i)); j += 2)
                        {
                          if (unifier->val[l].var ==
                              stack_get(stack_get(ID_VAR, i), j + 1) &&
                              unifier->val[l].term ==
                              stack_get(stack_get(ID_VAR, i), j))
                            {
                              nb_inst++;
                              break;
                            }
                        }
                      if (nb_inst)
                        {
                          nb_useful++;
                          break;
                        }
                    }
                }
            }
        }
    }
  return nb_useful;
}

int
size_round(unsigned i)
{
  unsigned k, nb_round = 0;
  for (k = 0; k < stack_size(delay_round_unifier); k++)
    {
      if (!stack_get(delay_round_unifier, k).unifier)
        {
          if (nb_round == i)
            return stack_get(delay_round_unifier, k).round;
          nb_round++;
          continue;
        }
    }
  return 0;
}

void
useful_instances_features()
{
  unsigned i, j, k = 0, l,
    nb_inst = 0, nb_neg = 0, nb_round = 0,
    modulo = nb_useful_roundi(0), size = size_round(0),
    pos= 0;
  FILE * file_features = NULL;
  pos = (modulo > size - modulo);
  modulo = (modulo > size - modulo)? size - modulo:modulo;
  file_features = fopen(file_results, "w");
  for (k = 0; k < stack_size(delay_round_unifier); k++)
    {
      if (!stack_get(delay_round_unifier, k).unifier)
        continue;
      for (i = 0; i < stack_size(Q_FORMULA); i++)
        {
          if (stack_get(delay_round_unifier, k).qDAG == stack_get(Q_FORMULA, i))
            {
              nb_inst = 0;
              Tunifier unifier = stack_get(delay_round_unifier, k).unifier;
              for (l = 0; l < unifier->size; l++)
                {
                  for (j = 0; j < stack_size(stack_get(ID_VAR, i)); j += 2)
                    {
                      if (unifier->val[l].var ==
                          stack_get(stack_get(ID_VAR, i), j + 1) &&
                          unifier->val[l].term ==
                          stack_get(stack_get(ID_VAR, i), j))
                        {
                          nb_inst++;
                          break;
                        }
                    }
                  if (nb_inst)
                    break;
                }
              /** Full **/ 
              fprintf(file_features, "1\n");
              break;
            }
        }
      if (i < stack_size(Q_FORMULA))
        continue;
      for (i = 0; i < stack_size(conflicting_instances); i++)
        {
          if (stack_get(delay_round_unifier, k).qDAG == stack_get(conflicting_instances, i).qDAG)
            {
              nb_inst = 0;
              Tunifier unifier = stack_get(delay_round_unifier, k).unifier;
              Tunifier unifier2 = stack_get(conflicting_instances, k).unifier;
              for (l = 0; l < unifier->size; l++)
                {
                  for (j = 0; j < unifier2->size; j++)
                    {
                      if (unifier->val[l].var == unifier2->val[j].var &&
                          unifier->val[l].term == unifier2->val[j].term)
                        {
                          nb_inst++;
                          break;
                        }
                    }
                  if (nb_inst)
                    break;
                }
              /** Full **/
              fprintf(file_features, "1\n");
              break;
            }
        }
      if (i == stack_size(Q_FORMULA) || i == stack_size(conflicting_instances))
        fprintf(file_features, "0\n");

    }
  stack_reset(delay_round_unifier);
  stack_reset(conflicting_instances);
  stack_reset(ID_VAR);
  stack_reset(Q_FORMULA);
  stack_free(delay_round_unifier);
  stack_free(conflicting_instances);
  stack_free(ID_VAR);
  stack_free(Q_FORMULA);
}


/*--------------------------------------------------------------*/

void
proof_out(FILE * file)
{
  unsigned i;
  stack_INIT(Q_FORMULA);
  stack_INIT(DAG_FORMULA);
  stack_INIT(ID_VAR);
  if (option_learn_extract_features)
    {
      stack_reset(delay_round_unifier);
      stack_merge(delay_round_unifier, delay_analyse_round_unifier);
      stack_reset(delay_analyse_round_unifier);
      stack_free(delay_analyse_round_unifier);
    }

  if (option_proof_prune)
    {
      if (option_proof_merge)
        steps_merge();
      steps_prune();
    }
  if (proof_version == 2)
    for (i = 1; i < stack_size(top_steps); ++i)
      if (stack_get(top_steps, i)->type == ps_type_th_resolution)
        stack_get(top_steps, i)->type = ps_type_SAT_resolution;
  DAG_tmp_reserve();
  /* Collect choice functions */
  for (i = 0; i < stack_size(choices); ++i)
    DAG_tmp_unsigned[stack_get(choices, i).src] = stack_get(choices, i).dest;
  /* Collect ite csts */
  for (i = 0; i < stack_size(ite_csts); ++i)
    DAG_tmp_unsigned[stack_get(ite_csts, i).src] = stack_get(ite_csts, i).dest;
  /* Print steps */
  for (i = 1; i < stack_size(top_steps); ++i)
    if (proof_version == 2)
      proof_step_print_older(stack_get(top_steps, i), top_steps, i, file);
    else if (proof_version == 1)
      proof_step_print_old(stack_get(top_steps, i), top_steps, i, file);
    else
      proof_step_print(stack_get(top_steps, i), top_steps, i, file);
  if (option_dumper_data)
    {
      useful_instances_print();
    }
  else if (option_extract_features || option_learn_extract_features)
    {
      useful_instances_features();
    }
  /* else if (option_learning_instances) */
  /*   stat_learn_instances_print(); */
  for (i = 1; i < stack_size(top_steps); ++i)
    proof_reset_DAG_tmp(stack_get(top_steps, i));
  /* Clean for choice functions */
  for (i = 0; i < stack_size(choices); ++i)
    {
      DAG_tmp_unsigned[stack_get(choices, i).src] = DAG_NULL;
      DAG_tmp_reset_unsigned(stack_get(choices, i).dest);
    }
  /* Clean for ite csts */
  for (i = 0; i < stack_size(ite_csts); ++i)
    {
      /* [TODO] understand this asserts */
      DAG_tmp_reset_unsigned(stack_get(ite_csts, i).src);
      assert(!DAG_tmp_unsigned[stack_get(ite_csts, i).dest]);
    }
  DAG_tmp_release();
}

#endif /* PROOF */

