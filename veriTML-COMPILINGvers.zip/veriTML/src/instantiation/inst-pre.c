#define DEBUG_INST_PRE 0

#include "options.h"
#include "statistics.h"
#include "polarities.h"
#include "recursion.h"
#include "DAG-print.h"
#include "DAG-subst.h"
#include "DAG-tmp.h"
#include "DAG-prop.h"
#include "qnt-trigger.h"
#include "qnt-tidy.h"
#include "qnt-utils.h"

#include "free-vars.h"
#include "inst-pre.h"

extern bool enable_nnf_simp;

/*
  --------------------------------------------------------------
  Normal forms
  --------------------------------------------------------------
*/

#define cnf_count ((unsigned **) DAG_tmp)
#define cnf_count_clauses(D) cnf_count[D][0]

/*--------------------------------------------------------------*/

static inline unsigned
cnf_count_DAGs(TDAG DAG)
{
  unsigned i, total = 0;
  assert(cnf_count[DAG] && cnf_count[DAG][0]);
  for (i = 1; i <= cnf_count[DAG][0]; ++i)
    total += cnf_count[DAG][i];
  return total;
}

/*--------------------------------------------------------------*/

void
DAG_tmp_reset_cnf_count(TDAG DAG)
{
  unsigned i;
  if (!cnf_count[DAG])
    return;
  free(cnf_count[DAG]);
  cnf_count[DAG] = NULL;
  for (i = 0; i < DAG_arity(DAG); ++i)
    DAG_tmp_reset_cnf_count(DAG_arg(DAG, i));
}

/*--------------------------------------------------------------*/

extern int ccfv_cnf_threshold;

static void
count_CNF_nodes(TDAG DAG)
{
  unsigned i, j, k1, k2, clauses, arg_clauses;
  Tsymb top_symbol = DAG_symb(DAG);
  assert(top_symbol != QUANTIFIER_FORALL);
  if (cnf_count[DAG])
    return;
  if (DAG_literal(DAG))
    {
      assert(!quantifier(top_symbol) || top_symbol == QUANTIFIER_EXISTS);
      MY_MALLOC(cnf_count[DAG], 2 * sizeof(unsigned));
      cnf_count_clauses(DAG) = 1;
      cnf_count[DAG][1] = 1;
      return;
    }
  if (top_symbol == CONNECTOR_AND)
    {
      clauses = 0;
      MY_MALLOC(cnf_count[DAG], sizeof(unsigned));
      for (i = 0; i < DAG_arity(DAG); ++i)
        {
          count_CNF_nodes(DAG_arg(DAG, i));
          if (!cnf_count_clauses(DAG_arg(DAG, i)))
            break;
          MY_REALLOC(cnf_count[DAG],
                     (clauses + cnf_count_clauses(DAG_arg(DAG, i)) + 1) *
                     sizeof(unsigned));
          for (j = 1; j <= cnf_count_clauses(DAG_arg(DAG, i)); ++j)
            cnf_count[DAG][++clauses] = cnf_count[DAG_arg(DAG, i)][j];
        }
      cnf_count_clauses(DAG) = clauses;
      /* Whether it exploded */
      if (i != DAG_arity(DAG) || cnf_count_DAGs(DAG) > ccfv_cnf_threshold)
        {
          cnf_count_clauses(DAG) = 0;
          return;
        }
#if DEBUG_INST_PRE > 2
      my_DAG_message("CNF count of %D: %d clauses, %d DAGs\n", DAG,
                     cnf_count_clauses(DAG), cnf_count_DAGs(DAG));
#endif
      return;
    }
  // OR
  assert(top_symbol == CONNECTOR_OR && DAG_arity(DAG));
  /* [TODO] Improve this so it does not go separately at 0 */
  clauses = 0;
  count_CNF_nodes(DAG_arg(DAG, 0));
  /* Whether it exploded */
  if (!cnf_count_clauses(DAG_arg(DAG, 0)))
    {
      MY_MALLOC(cnf_count[DAG], sizeof(unsigned));
      cnf_count_clauses(DAG) = 0;
      return;
    }
  MY_REALLOC(cnf_count[DAG],
             (cnf_count_clauses(DAG_arg(DAG, 0)) + 1) * sizeof(unsigned));
  cnf_count_clauses(DAG) = cnf_count_clauses(DAG_arg(DAG, 0));
  for (i = 1; i <= cnf_count_clauses(DAG_arg(DAG, 0)); ++i)
    cnf_count[DAG][++clauses] = cnf_count[DAG_arg(DAG, 0)][i];
  for (i = 1; i < DAG_arity(DAG); ++i)
    {
      count_CNF_nodes(DAG_arg(DAG, i));
      /* Whether it exploded */
      if (!cnf_count_clauses(DAG_arg(DAG, i)))
        break;
      arg_clauses = cnf_count_clauses(DAG_arg(DAG, i));
      k2 = clauses;
      clauses = clauses * arg_clauses;
      MY_REALLOC(cnf_count[DAG], (clauses + 1) * sizeof(unsigned));
      for (j = clauses; j > 0; )
        {
          for (k1 = 0; k1 < arg_clauses; ++k1)
            cnf_count[DAG][j - k1] =
              cnf_count[DAG_arg(DAG, i)][arg_clauses - k1] + cnf_count[DAG][k2];
          j -= k1;
          --k2;
        }
      cnf_count_clauses(DAG) = clauses;
      /* Whether it exploded */
      if (cnf_count_DAGs(DAG) > ccfv_cnf_threshold)
        break;
    }
  /* Whether it exploded */
  if (i != DAG_arity(DAG))
    {
      cnf_count_clauses(DAG) = 0;
      return;
    }
#if DEBUG_INST_PRE > 2
  my_DAG_message("CNF count of %D: %d clauses, %d DAGs\n", DAG,
                 cnf_count_clauses(DAG), cnf_count_DAGs(DAG));
#endif
}

/**
   \brief Traverses DAG applying the distributive law whenever necessary
   \param DAG a prenexed quantified formula in NNF
   \return Always return either a single literal of a conjunction of clauses
   \remark Naive (on purpose, though), exponential. Treats EXISTS as atom for
   now. */
#define cnf_of ((Tstack_DAGstack *) DAG_tmp)

/*--------------------------------------------------------------*/

void
DAG_tmp_reset_cnf(TDAG DAG)
{
  unsigned i;
  if (!cnf_of[DAG])
    return;
  stack_apply(cnf_of[DAG], stack_free);
  stack_free(cnf_of[DAG]);
  for (i = 0; i < DAG_arity(DAG); ++i)
    DAG_tmp_reset_cnf(DAG_arg(DAG, i));
}

/*--------------------------------------------------------------*/

static void
set_CNF_rec(TDAG DAG)
{
  unsigned i, j;
  Tstack_DAG old_clause, new_clause;
  Tstack_DAGstack clauses;
  Tsymb top_symbol = DAG_symb(DAG);
  assert(top_symbol != QUANTIFIER_FORALL);
  if (cnf_of[DAG])
    return;
  stack_INIT(cnf_of[DAG]);
  if (DAG_literal(DAG))
    {
      /* Put literal into a new clause */
      assert(!quantifier(top_symbol) || top_symbol == QUANTIFIER_EXISTS);
      stack_INIT(new_clause);
      stack_push(new_clause, DAG);
      stack_push(cnf_of[DAG], new_clause);
      return;
    }
  if (top_symbol == CONNECTOR_AND)
    {
      /* Put the CNF of each argument in a new clause */
      for (i = 0; i < DAG_arity(DAG); ++i)
        {
          set_CNF_rec(DAG_arg(DAG, i));
          for (j = 0; j < stack_size(cnf_of[DAG_arg(DAG, i)]); ++j)
            {
              stack_COPY(new_clause, stack_get(cnf_of[DAG_arg(DAG, i)], j));
              stack_push(cnf_of[DAG], new_clause);
            }
        }
#if DEBUG_INST_PRE > 1
      my_DAG_message("CNF of %D:\n", DAG);
      print_Tstack_DAGstack(cnf_of[DAG]);
#endif
      return;
    }
  // OR
  assert(top_symbol == CONNECTOR_OR && DAG_arity(DAG));
  /* [TODO] Improve this so it does not go separately at 0 */
  set_CNF_rec(DAG_arg(DAG, 0));
  for (i = 0; i < stack_size(cnf_of[DAG_arg(DAG, 0)]); ++i)
    {
      stack_COPY(new_clause, stack_get(cnf_of[DAG_arg(DAG, 0)], i));
      stack_push(cnf_of[DAG], new_clause);
    }
  for (i = 1; i < DAG_arity(DAG); ++i)
    {
      /* For each disjunct, compute its CNF. Then combine each of its clauses
         with every clause from the previous disjuncts */
      set_CNF_rec(DAG_arg(DAG, i));
      stack_INIT(clauses);
      while (!stack_is_empty(cnf_of[DAG]))
        {
          old_clause = stack_pop(cnf_of[DAG]);
          for (j = 0; j < stack_size(cnf_of[DAG_arg(DAG, i)]); ++j)
            {
              stack_COPY(new_clause, old_clause);
              stack_merge(new_clause, stack_get(cnf_of[DAG_arg(DAG, i)], j));
              stack_push(clauses, new_clause);
            }
          stack_free(old_clause);
        }
      stack_free(cnf_of[DAG]);
      stack_COPY(cnf_of[DAG], clauses);
      stack_free(clauses);
    }
#if DEBUG_INST_PRE > 1
  my_DAG_message("CNF of %D:\n", DAG);
  print_Tstack_DAGstack(cnf_of[DAG]);
#endif
}

/*--------------------------------------------------------------*/

/**
   \author Haniel Barbosa
   \brief removes all nested occurrences of universal quantifiers while
   accumulating the respective bounded variables
   \param DAG a formula
   \param all_vars all bound variables accumulated so far
   \param ubound_vars all universally bound variables accumulated so far
   \return a DAG without universals
   \remark not destructive to parameters, however all prenexed DAGs created
   during the process that are not necessary ultimately (the temporary
   "and/or") are destructed
   \remark does variable renaming to avoid capture (same variable under the
   scope of two quantifiers) */
static unsigned
prenex_rec(TDAG DAG, Tstack_DAG * ubound_vars)
{
  unsigned i, res = 0;
  TDAG tmp_DAG;
  Tstack_DAG DAGs;
  Tsymb top_symbol = DAG_symb(DAG);
  if (DAG_tmp_DAG[DAG])
    return DAG_tmp_DAG[DAG] != DAG;
  if (!DAG_quant(DAG) || (DAG_literal(DAG) && top_symbol != QUANTIFIER_FORALL))
    {
      DAG_tmp_DAG[DAG] = DAG;
      return 0;
    }
  if (top_symbol == QUANTIFIER_FORALL)
    {
      for (i = 0; i < DAG_arity(DAG) - 1; ++i)
        stack_push(*ubound_vars, DAG_arg(DAG, i));
      prenex_rec(DAG_arg_last(DAG), ubound_vars);
      DAG_tmp_DAG[DAG] = DAG_tmp_DAG[DAG_arg_last(DAG)];
      return 1;
    }
  assert(top_symbol == CONNECTOR_OR || top_symbol == CONNECTOR_AND);
  for (i = 0; i < DAG_arity(DAG); ++i)
    res |= prenex_rec(DAG_arg(DAG, i), ubound_vars);
  if (res)
    {
      stack_INIT(DAGs);
      for (i = 0; i < DAG_arity(DAG); ++i)
        stack_push(DAGs, DAG_tmp_DAG[DAG_arg(DAG, i)]);
      tmp_DAG = DAG_new_stack(top_symbol, DAGs);
      stack_free(DAGs);
      DAG_tmp_DAG[DAG] = tmp_DAG;
      return 1;
    }
  DAG_tmp_DAG[DAG] = DAG;
  return 0;
}

/*--------------------------------------------------------------*/

TDAG
prenex(TDAG DAG)
{
  TDAG body_DAG;
  Tstack_DAG DAGs;
  assert(DAG_symb(DAG) == QUANTIFIER_FORALL);
  stack_INIT(DAGs);
  /* Prenex universal quantifiers in DAG */
  DAG_tmp_reserve();
  prenex_rec(DAG, &DAGs);
  body_DAG = DAG_tmp_DAG[DAG_arg_last(DAG)];
  DAG_tmp_reset_DAG(DAG);
  if (body_DAG != DAG_arg_last(DAG))
    {
      stack_push(DAGs, body_DAG);
      DAG = DAG_new_stack(QUANTIFIER_FORALL, DAGs);
    }
  DAG_tmp_release();
  stack_free(DAGs);
  return DAG;
}

/*--------------------------------------------------------------*/

/**
   \author Haniel Barbosa
   \brief resets DAG_tmp_DAG of all subDAGs execept if they are variables among
   the given set
   \param DAG a DAG
   \param vars a set of variables */
static void
DAG_tmp_reset_DAG_except_vars(TDAG DAG, Tstack_DAG vars)
{
  unsigned i;
  if (!DAG_tmp_DAG[DAG])
    return;
  if (DAG_arity(DAG) || !vars || !stack_DAG_contains(vars, DAG))
    DAG_tmp_DAG[DAG] = DAG_NULL;
  for (i = 0; i < DAG_arity(DAG); i++)
    DAG_tmp_reset_DAG_except_vars(DAG_arg(DAG, i), vars);
}

/*--------------------------------------------------------------*/

unsigned
qnt_uniq_vars_rec(TDAG DAG, Tstack_DAG * bound_vars)
{
  unsigned i, j, res = 0;
  Tsymb top_symbol = DAG_symb(DAG);
  TDAG tmp_DAG, var, new_var = 0;
  Tstack_DAG DAGs, trigger, previous_vars = NULL;
  Tstack_DAGstack * Ptriggers, triggers;
  if (DAG_tmp_DAG[DAG])
    return DAG_tmp_DAG[DAG] != DAG;
  if (quantifier(top_symbol))
    {
      if (stack_size(*bound_vars))
        stack_COPY(previous_vars, *bound_vars);
      stack_INIT(DAGs);
      for (i = 0; i < DAG_arity(DAG) - 1; ++i)
        {
          var = DAG_arg(DAG, i);
          if (stack_DAG_contains(*bound_vars, var))
            {
              /* [TODO] DAG_dup new variables, later free them */
              new_var = DAG_new_nullary(DAG_symb_variable(DAG_sort(var)));
              DAG_tmp_DAG[var] = new_var;
              var = new_var;
            }
          else
            stack_push(*bound_vars, var);
          stack_push(DAGs, var);
        }
      stack_sort(*bound_vars, DAG_cmp_q);
      res = qnt_uniq_vars_rec(DAG_arg_last(DAG), bound_vars) || new_var;
      if (res)
        {
          stack_push(DAGs, DAG_tmp_DAG[DAG_arg_last(DAG)]);
          tmp_DAG = DAG_new_stack(top_symbol, DAGs);
          DAG_tmp_DAG[DAG] = tmp_DAG;
          Ptriggers = DAG_prop_get(DAG, DAG_PROP_TRIGGER);
          if (Ptriggers)
            {
              /* Need to rename variables in each DAG in triggers */
              if (new_var)
                {
                  /* [TODO] Make sure this is correct */
                  stack_INIT(triggers);
                  for (i = 0; i < stack_size(*Ptriggers); ++i)
                    {
                      trigger = stack_get(*Ptriggers, i);
                      stack_inc(triggers);
                      stack_INIT(stack_top(triggers));
                      for (j = 0; j < stack_size(trigger); ++j)
                        {
                          DAG_tmp_subst(stack_get(trigger, j));
                          stack_push(stack_top(triggers),
                                     DAG_dup(DAG_tmp_DAG[stack_get(trigger,
                                                                   j)]));
                        }
                    }
                }
              else
                triggers = copy_triggers(*Ptriggers);
              DAG_prop_set(tmp_DAG, DAG_PROP_TRIGGER, &triggers);
            }
        }
      else
        DAG_tmp_DAG[DAG] = DAG;
      /* Since an equal subDAG may appear under another quantifier */
      if (previous_vars)
        {
          DAG_tmp_reset_DAG_except_vars(DAG_arg_last(DAG), previous_vars);
          stack_free(previous_vars);
        }
      else
        {
          DAG_tmp_reset_DAG(DAG_arg_last(DAG));
          stack_apply(*bound_vars, DAG_tmp_reset_DAG);
          stack_reset(*bound_vars);
        }
      stack_free(DAGs);
      return res;
    }
  for (i = 0; i < DAG_arity(DAG); i++)
    res |= qnt_uniq_vars_rec(DAG_arg(DAG, i), bound_vars);
  if (res)
    {
      stack_INIT(DAGs);
      /* Some subformulas of quantifiers may appear outside quantifiers, so
         their DAG_tmp would have been reset */
      for (i = 0; i < DAG_arity(DAG); i++)
        if (DAG_tmp_DAG[DAG_arg(DAG, i)])
          stack_push(DAGs, DAG_tmp_DAG[DAG_arg(DAG, i)]);
        else
          stack_push(DAGs, DAG_arg(DAG, i));
      tmp_DAG = DAG_new_stack(top_symbol, DAGs);
      stack_free(DAGs);
      DAG_tmp_DAG[DAG] = tmp_DAG;
      return 1;
    }
  DAG_tmp_DAG[DAG] = DAG;
  return 0;
}

/*--------------------------------------------------------------*/

TDAG
qnt_uniq_vars(TDAG DAG)
{
  TDAG result;
  Tstack_DAG DAGs;
  stack_INIT(DAGs);
  DAG_tmp_reserve();
  qnt_uniq_vars_rec(DAG, &DAGs);
  result = DAG_dup(DAG_tmp_DAG[DAG]);
  stack_apply(DAGs, DAG_tmp_reset_DAG);
  DAG_tmp_reset_DAG(DAG);
  DAG_tmp_release();
  stack_free(DAGs);
  return result;
}

/*--------------------------------------------------------------*/

TDAG
NNF(TDAG DAG, bool pol)
{
  unsigned i, j;
  TDAG nnf_DAG, tmp_NNF;
  Tstack_DAG DAGs;
  Tsymb nnf_symbol, top_symbol = DAG_symb(DAG);
  if (top_symbol == CONNECTOR_NOT)
    return NNF(DAG_arg0(DAG), !pol);
  if (top_symbol == CONNECTOR_AND || top_symbol == CONNECTOR_OR)
    {
      nnf_symbol = pol? top_symbol :
        (top_symbol == CONNECTOR_OR? CONNECTOR_AND : CONNECTOR_OR);
      stack_INIT(DAGs);
      for (i = 0; i < DAG_arity(DAG); ++i)
        {
          tmp_NNF = NNF(DAG_arg(DAG, i), pol);
          if (DAG_symb(tmp_NNF) == nnf_symbol)
            {
              for (j = 0; j < DAG_arity(tmp_NNF); ++j)
                stack_push(DAGs, DAG_dup(DAG_arg(tmp_NNF, j)));
              DAG_free(DAG_dup(tmp_NNF));
            }
          else
            stack_push(DAGs, DAG_dup(tmp_NNF));
        }
      nnf_DAG = DAG_new_stack(nnf_symbol, DAGs);
      stack_apply(DAGs, DAG_free);
      stack_free(DAGs);
      return nnf_DAG;
    }
  if (top_symbol == CONNECTOR_IMPLIES)
    {
      if (pol)
        return DAG_or2(NNF(DAG_arg0(DAG), 0),
                       NNF(DAG_arg1(DAG), 1));
      return DAG_and2(NNF(DAG_arg0(DAG), 1),
                      NNF(DAG_arg1(DAG), 0));
    }
  if (top_symbol == CONNECTOR_EQUIV)
    {
      if (pol)
        return DAG_and2(DAG_or2(NNF(DAG_arg0(DAG), 0),
                                NNF(DAG_arg1(DAG), 1)),
                        DAG_or2(NNF(DAG_arg1(DAG), 0),
                                NNF(DAG_arg0(DAG), 1)));
      return DAG_or2(DAG_and2(NNF(DAG_arg0(DAG), 1),
                              NNF(DAG_arg1(DAG), 0)),
                     DAG_and2(NNF(DAG_arg1(DAG), 1),
                              NNF(DAG_arg0(DAG), 0)));
      /* [TODO] test if this is OK */
      /* return DAG_and2(DAG_or2(NNF(DAG_arg0(DAG), 1), */
      /*                         NNF(DAG_arg1(DAG), 1)), */
      /*                DAG_or2(NNF(DAG_arg0(DAG), 0), */
      /*                         NNF(DAG_arg1(DAG), 0))); */
    }
  if (top_symbol == CONNECTOR_ITE)
    {
      if (pol)
        return DAG_and2(DAG_or2(NNF(DAG_arg(DAG, 0), 0),
                                NNF(DAG_arg(DAG, 1), 1)),
                        DAG_or2(NNF(DAG_arg(DAG, 0), 1),
                                NNF(DAG_arg(DAG, 2), 1)));
      return DAG_or2(DAG_and2(NNF(DAG_arg(DAG, 0), 1),
                              NNF(DAG_arg(DAG, 1), 0)),
                     DAG_and2(NNF(DAG_arg(DAG, 0), 0),
                              NNF(DAG_arg(DAG, 2), 0)));
    }
  if (quantifier(top_symbol))
    {
      stack_INIT(DAGs);
      nnf_symbol = pol? top_symbol :
        (top_symbol == QUANTIFIER_FORALL? QUANTIFIER_EXISTS
         : QUANTIFIER_FORALL);
      for (i = 0; i < DAG_arity(DAG) - 1; ++i)
        stack_push(DAGs, DAG_arg(DAG, i));
      stack_push(DAGs, NNF(DAG_arg_last(DAG), pol));
      nnf_DAG = DAG_new_stack(nnf_symbol, DAGs);
      stack_free(DAGs);
      return nnf_DAG;
    }
  if (DAG_literal(DAG))
    return pol? DAG : DAG_neg(DAG);
  my_DAG_error("NNF: Symbol %s is not supported.\n",
               DAG_symb_name2(top_symbol));
  return DAG_NULL;
}

/*--------------------------------------------------------------*/

static unsigned
qnt_connectives_rec(TDAG DAG, bool in_qnt_body)
{
  unsigned i, res = 0;
  Tsymb top_symbol = DAG_symb(DAG);
  TDAG tmp_DAG, tmp_arg0, tmp_arg1, tmp_arg2;
  Tstack_DAG DAGs;
  Tstack_DAGstack * Ptriggers, triggers;
  if (DAG_tmp_DAG[DAG])
    return DAG_tmp_DAG[DAG] != DAG;
  if (quantifier(top_symbol))
    {
      res = qnt_connectives_rec(DAG_arg_last(DAG), true);
      if (res)
        {
          /* [TODO] Use directly *PDAG */
          stack_INIT(DAGs);
          for (i = 0; i < DAG_arity(DAG) - 1; ++i)
            stack_push(DAGs, DAG_arg(DAG, i));
          stack_push(DAGs, DAG_tmp_DAG[DAG_arg_last(DAG)]);
          tmp_DAG = DAG_new_stack(top_symbol, DAGs);
          stack_free(DAGs);
          Ptriggers = DAG_prop_get(DAG, DAG_PROP_TRIGGER);
          if (Ptriggers)
            {
              triggers = copy_triggers(*Ptriggers);
              DAG_prop_set(tmp_DAG, DAG_PROP_TRIGGER, &triggers);
            }
          DAG_tmp_DAG[DAG] = tmp_DAG;
          return 1;
        }
      DAG_tmp_DAG[DAG] = DAG;
      return 0;
    }
  if (DAG_symb(DAG) == CONNECTOR_NOT)
    {
      res = qnt_connectives_rec(DAG_arg0(DAG), in_qnt_body);
      if (res)
        {
          tmp_DAG = DAG_not(DAG_tmp_DAG[DAG_arg0(DAG)]);
          DAG_tmp_DAG[DAG] = tmp_DAG;
          return 1;
        }
      DAG_tmp_DAG[DAG] = DAG;
      return 0;
    }
  if (DAG_literal(DAG) || (!in_qnt_body && !DAG_quant(DAG)))
    {
      DAG_tmp_DAG[DAG] = DAG;
      return 0;
    }
  if (in_qnt_body && DAG_symb(DAG) == CONNECTOR_IMPLIES)
    {
      qnt_connectives_rec(DAG_arg0(DAG), in_qnt_body);
      qnt_connectives_rec(DAG_arg1(DAG), in_qnt_body);
      /* [TODO] is this necessary? I'm just scared */
      tmp_arg0 = DAG_tmp_DAG[DAG_arg0(DAG)];
      tmp_arg1 = DAG_tmp_DAG[DAG_arg1(DAG)];
      tmp_DAG = DAG_or2(DAG_not(tmp_arg0), tmp_arg1);
      DAG_tmp_DAG[DAG] = tmp_DAG;
      return 1;
    }
  if (in_qnt_body && DAG_symb(DAG) == CONNECTOR_EQUIV)
    {
      qnt_connectives_rec(DAG_arg0(DAG), in_qnt_body);
      qnt_connectives_rec(DAG_arg1(DAG), in_qnt_body);
      tmp_arg0 = DAG_tmp_DAG[DAG_arg0(DAG)];
      tmp_arg1 = DAG_tmp_DAG[DAG_arg1(DAG)];
      tmp_DAG = DAG_and2(DAG_or2(DAG_not(tmp_arg0), tmp_arg1),
                         DAG_or2(DAG_not(tmp_arg1), tmp_arg0));
      DAG_tmp_DAG[DAG] = tmp_DAG;
      return 1;
    }
  if (in_qnt_body && DAG_symb(DAG) == CONNECTOR_ITE)
    {
      qnt_connectives_rec(DAG_arg(DAG, 0), in_qnt_body);
      qnt_connectives_rec(DAG_arg(DAG, 1), in_qnt_body);
      qnt_connectives_rec(DAG_arg(DAG, 2), in_qnt_body);
      tmp_arg0 = DAG_tmp_DAG[DAG_arg(DAG, 0)];
      tmp_arg1 = DAG_tmp_DAG[DAG_arg(DAG, 1)];
      tmp_arg2 = DAG_tmp_DAG[DAG_arg(DAG, 2)];
      tmp_DAG = DAG_and2(DAG_or2(DAG_not(tmp_arg0), tmp_arg1),
                         DAG_or2(tmp_arg0, tmp_arg2));
      DAG_tmp_DAG[DAG] = tmp_DAG;
      return 1;
    }
  for (i = 0; i < DAG_arity(DAG); i++)
    res |= qnt_connectives_rec(DAG_arg(DAG, i), in_qnt_body);
  if (res)
    {
      stack_INIT(DAGs);
#ifdef DEBUG
      for (i = 0; i < DAG_arity(DAG); i++)
        assert(DAG_tmp_DAG[DAG_arg(DAG, i)]);
#endif
      for (i = 0; i < DAG_arity(DAG); i++)
        stack_push(DAGs, DAG_tmp_DAG[DAG_arg(DAG, i)]);
      tmp_DAG = DAG_new_stack(top_symbol, DAGs);
      stack_free(DAGs);
      DAG_tmp_DAG[DAG] = tmp_DAG;
      return 1;
    }
  DAG_tmp_DAG[DAG] = DAG;
  return 0;
}

/*--------------------------------------------------------------*/

TDAG
qnt_connectives(TDAG DAG)
{
  TDAG result;
  DAG_tmp_reserve();
  qnt_connectives_rec(DAG, false);
  result = DAG_dup(DAG_tmp_DAG[DAG]);
  DAG_tmp_reset_DAG(DAG);
  DAG_tmp_release();
  return result;
}

/*--------------------------------------------------------------*/

typedef struct TDAG_pol
{
  TDAG pol[3];
} * TDAG_pol;

#define DAG_tmp_DAG_pol ((TDAG_pol *) DAG_tmp)

#define DAG_for_pol(A, p)                       \
  (p == POL_NEG? DAG_tmp_DAG_pol[A]->pol[0] :   \
   (p == POL_POS? DAG_tmp_DAG_pol[A]->pol[1] :  \
    DAG_tmp_DAG_pol[A]->pol[2]))

#define get_DAG(A, p)                           \
  ((DAG_tmp_DAG_pol[A] && DAG_for_pol(A, p)) ?  \
   DAG_for_pol(A, p) : A)

#define set_DAG_pol(A, pol, B)                          \
  if (!DAG_tmp_DAG_pol[A])                              \
    {                                                   \
      MY_MALLOC(DAG_tmp_DAG_pol[A], 3 * sizeof(TDAG));  \
      DAG_tmp_DAG_pol[A]->pol[0] = DAG_NULL;            \
      DAG_tmp_DAG_pol[A]->pol[1] = DAG_NULL;            \
      DAG_tmp_DAG_pol[A]->pol[2] = DAG_NULL;            \
    }                                                   \
  if (pol == POL_NEG)                                   \
    DAG_tmp_DAG_pol[A]->pol[0] = B;                     \
  else if (pol == POL_POS)                              \
    DAG_tmp_DAG_pol[A]->pol[1] = B;                     \
  else                                                  \
    DAG_tmp_DAG_pol[A]->pol[2] = B;


/*--------------------------------------------------------------*/

static void
DAG_tmp_reset_DAG_pol(TDAG DAG)
{
  unsigned i;
  if (!DAG_tmp_DAG_pol[DAG])
    return;
  if (DAG_tmp_DAG_pol[DAG]->pol[0])
    DAG_free(DAG_tmp_DAG_pol[DAG]->pol[0]);
  if (DAG_tmp_DAG_pol[DAG]->pol[1])
    DAG_free(DAG_tmp_DAG_pol[DAG]->pol[1]);
  if (DAG_tmp_DAG_pol[DAG]->pol[2])
    DAG_free(DAG_tmp_DAG_pol[DAG]->pol[2]);
  free(DAG_tmp_DAG_pol[DAG]);
  DAG_tmp_DAG_pol[DAG] = NULL;
  for (i = 0; i < DAG_arity(DAG); ++i)
    DAG_tmp_reset_DAG_pol(DAG_arg(DAG, i));
}

/*--------------------------------------------------------------*/

static unsigned
NNF_new(TDAG DAG, Tpol pol)
{
  unsigned i, res = 0;
  TDAG dest;
  Tstack_DAG DAGs;
  Tsymb nnf_symbol;
  Tstack_DAGstack * Ptriggers, triggers;
  if (DAG_tmp_DAG_pol[DAG] && DAG_for_pol(DAG, pol))
    return DAG_for_pol(DAG, pol) != DAG;
  if (DAG_symb(DAG) == CONNECTOR_NOT)
    {
      /* Always push it down */
      NNF_new(DAG_arg0(DAG), INV_POL(pol));
      dest = DAG_dup(DAG_for_pol(DAG_arg0(DAG), INV_POL(pol)));
      set_DAG_pol(DAG, pol, dest);
      return 1;
    }
  if (DAG_symb(DAG) == CONNECTOR_AND || DAG_symb(DAG) == CONNECTOR_OR)
    {
      nnf_symbol = (pol == POL_POS) ? DAG_symb(DAG) :
        (DAG_symb(DAG) == CONNECTOR_OR? CONNECTOR_AND : CONNECTOR_OR);
      res = nnf_symbol != DAG_symb(DAG);
      for (i = 0; i < DAG_arity(DAG); ++i)
        res |= NNF_new(DAG_arg(DAG, i), pol);
      if (res)
        {
          stack_INIT(DAGs);
          for (i = 0; i < DAG_arity(DAG); ++i)
            stack_push(DAGs, DAG_for_pol(DAG_arg(DAG, i), pol));
          dest = DAG_dup(DAG_new_stack(nnf_symbol, DAGs));
          stack_free(DAGs);
          set_DAG_pol(DAG, pol, dest);
          return 1;
        }
      set_DAG_pol(DAG, pol, DAG_dup(DAG));
      return 0;
    }
  if (quantifier(DAG_symb(DAG)))
    {
      nnf_symbol = (pol == POL_POS)? DAG_symb(DAG) :
        (DAG_symb(DAG) == QUANTIFIER_FORALL? QUANTIFIER_EXISTS :
         QUANTIFIER_FORALL);
      res = NNF_new(DAG_arg_last(DAG), pol) || nnf_symbol != DAG_symb(DAG);
      if (res)
        {
          stack_INIT(DAGs);
          for (i = 0; i < DAG_arity(DAG) - 1; ++i)
            stack_push(DAGs, DAG_arg(DAG, i));
          stack_push(DAGs, DAG_for_pol(DAG_arg_last(DAG), pol));
          dest = DAG_dup(DAG_new_stack(nnf_symbol, DAGs));
          stack_free(DAGs);
          set_DAG_pol(DAG, pol, dest);
          Ptriggers = DAG_prop_get(DAG, DAG_PROP_TRIGGER);
          if (Ptriggers)
            {
              triggers = copy_triggers(*Ptriggers);
              DAG_prop_set(dest, DAG_PROP_TRIGGER, &triggers);
            }
          return 1;
        }
      set_DAG_pol(DAG, pol, DAG_dup(DAG));
      return 0;
    }
  assert(DAG_literal(DAG));
  if (pol == POL_NEG)
    {
      dest = DAG_dup(DAG_neg(DAG));
      set_DAG_pol(DAG, pol, dest);
      return 1;
    }
  set_DAG_pol(DAG, pol, DAG_dup(DAG));
  return 0;
}

/*--------------------------------------------------------------*/

static unsigned
qnt_NNF_rec(TDAG src, Tpol pol, unsigned binders)
{
  unsigned i, res = 0;
  Tsymb nnf_symbol;
  TDAG dest, * PDAG;
  Tstack_DAGstack * Ptriggers, triggers;
  if (DAG_tmp_DAG_pol[src] && DAG_for_pol(src, pol))
    return DAG_for_pol(src, pol) != src;
  /* Subformula outside binders that does contain quantifiers */
  if (!DAG_quant(src) && !binders)
    {
      set_DAG_pol(src, pol, DAG_dup(src));
      return 0;
    }
  assert(pol == POL_POS || pol == POL_NEG);
  if (DAG_symb(src) == CONNECTOR_XOR)
    {
      qnt_NNF_rec(DAG_arg0(src), POL_POS, binders);
      qnt_NNF_rec(DAG_arg0(src), POL_NEG, binders);
      qnt_NNF_rec(DAG_arg1(src), POL_POS, binders);
      qnt_NNF_rec(DAG_arg1(src), POL_NEG, binders);
      if (pol == POL_POS)
        dest = DAG_dup(DAG_or2(DAG_and2(get_DAG(DAG_arg0(src), POL_POS),
                                        get_DAG(DAG_arg1(src), POL_NEG)),
                               DAG_and2(get_DAG(DAG_arg0(src), POL_NEG),
                                        get_DAG(DAG_arg1(src), POL_POS))));
      else
        dest = DAG_dup(DAG_and2(DAG_or2(get_DAG(DAG_arg0(src), POL_NEG),
                                        get_DAG(DAG_arg1(src), POL_POS)),
                                DAG_or2(get_DAG(DAG_arg0(src), POL_POS),
                                        get_DAG(DAG_arg1(src), POL_NEG))));
      set_DAG_pol(src, pol, dest);
      return 1;
    }
  if (DAG_symb(src) == CONNECTOR_EQUIV)
    {
      qnt_NNF_rec(DAG_arg0(src), POL_POS, binders);
      qnt_NNF_rec(DAG_arg0(src), POL_NEG, binders);
      qnt_NNF_rec(DAG_arg1(src), POL_POS, binders);
      qnt_NNF_rec(DAG_arg1(src), POL_NEG, binders);
      if (pol == POL_POS)
        dest = DAG_dup(DAG_and2(DAG_or2(get_DAG(DAG_arg0(src), POL_NEG),
                                        get_DAG(DAG_arg1(src), POL_POS)),
                                DAG_or2(get_DAG(DAG_arg0(src), POL_POS),
                                        get_DAG(DAG_arg1(src), POL_NEG))));
      else
        dest = DAG_dup(DAG_or2(DAG_and2(get_DAG(DAG_arg0(src), POL_POS),
                                        get_DAG(DAG_arg1(src), POL_NEG)),
                               DAG_and2(get_DAG(DAG_arg0(src), POL_NEG),
                                        get_DAG(DAG_arg1(src), POL_POS))));
      set_DAG_pol(src, pol, dest);
      return 1;
    }
  if (DAG_symb(src) == CONNECTOR_ITE)
    {
      qnt_NNF_rec(DAG_arg(src, 0), POL_POS, binders);
      qnt_NNF_rec(DAG_arg(src, 0), POL_NEG, binders);
      if (pol == POL_POS)
        {
          qnt_NNF_rec(DAG_arg(src, 1), POL_POS, binders);
          qnt_NNF_rec(DAG_arg(src, 2), POL_POS, binders);
          dest = DAG_dup(DAG_and2(DAG_or2(get_DAG(DAG_arg(src, 0), POL_NEG),
                                          get_DAG(DAG_arg(src, 1), POL_POS)),
                                  DAG_or2(get_DAG(DAG_arg(src, 0), POL_POS),
                                          get_DAG(DAG_arg(src, 2), POL_POS))));
        }
      else
        {
          qnt_NNF_rec(DAG_arg(src, 1), POL_NEG, binders);
          qnt_NNF_rec(DAG_arg(src, 2), POL_NEG, binders);
          dest = DAG_dup(DAG_and2(DAG_or2(get_DAG(DAG_arg(src, 0), POL_POS),
                                          get_DAG(DAG_arg(src, 1), POL_NEG)),
                                  DAG_or2(get_DAG(DAG_arg(src, 0), POL_NEG),
                                          get_DAG(DAG_arg(src, 2), POL_NEG))));
        }
      set_DAG_pol(src, pol, dest);
      return 1;
    }
  if (DAG_symb(src) == CONNECTOR_IMPLIES)
    {
      qnt_NNF_rec(DAG_arg0(src), INV_POL(pol), binders);
      qnt_NNF_rec(DAG_arg1(src), pol, binders);
      if (pol == POL_POS)
        dest = DAG_dup(DAG_or2(get_DAG(DAG_arg0(src), POL_NEG),
                               get_DAG(DAG_arg1(src), POL_POS)));
      else
        dest = DAG_dup(DAG_and2(get_DAG(DAG_arg0(src), POL_POS),
                                get_DAG(DAG_arg1(src), POL_NEG)));
      set_DAG_pol(src, pol, dest);
      return 1;
    }
  if (DAG_symb(src) == CONNECTOR_AND || DAG_symb(src) == CONNECTOR_OR)
    {
      for (i = 0; i < DAG_arity(src); ++i)
        res = qnt_NNF_rec(DAG_arg(src, i), pol, binders) | res;
      assert(pol != POL_NEG || res);
      if (res)
        {
          MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
          for (i = 0; i < DAG_arity(src); ++i)
            PDAG[i] = get_DAG(DAG_arg(src, i), pol);
          nnf_symbol = pol == POL_POS? DAG_symb(src) :
            (DAG_symb(src) == CONNECTOR_OR? CONNECTOR_AND : CONNECTOR_OR);
          dest = DAG_dup(DAG_new(nnf_symbol, DAG_arity(src), PDAG));
          set_DAG_pol(src, pol, dest);
          return 1;
        }
      set_DAG_pol(src, pol, DAG_dup(src));
      return 0;
    }
  if (DAG_symb(src) == CONNECTOR_NOT)
    {
      qnt_NNF_rec(DAG_arg0(src), INV_POL(pol), binders);
      dest = DAG_dup(get_DAG(DAG_arg0(src), INV_POL(pol)));
      set_DAG_pol(src, pol, dest);
      return 1;
    }
  if (quantifier(DAG_symb(src)))
    {
      res = qnt_NNF_rec(DAG_arg_last(src), pol, binders + 1);
      nnf_symbol = pol == POL_POS? DAG_symb(src) :
        (DAG_symb(src) == QUANTIFIER_FORALL?
         QUANTIFIER_EXISTS : QUANTIFIER_FORALL);
      assert(nnf_symbol == DAG_symb(src) || res);
      if (res)
        {
          MY_MALLOC(PDAG, DAG_arity(src) * sizeof(TDAG));
          for (i = 0; i < DAG_arity(src) - 1; ++i)
            PDAG[i] = DAG_arg(src, i);
          PDAG[i] = get_DAG(DAG_arg(src, i), pol);
          dest = DAG_dup(DAG_new(nnf_symbol, DAG_arity(src), PDAG));
          {
            Ptriggers = DAG_prop_get(src, DAG_PROP_TRIGGER);
            if (Ptriggers)
              {
                triggers = copy_triggers(*Ptriggers);
                DAG_prop_set(dest, DAG_PROP_TRIGGER, &triggers);
              }
          }
          set_DAG_pol(src, pol, dest);
          return 1;
        }
      set_DAG_pol(src, pol, DAG_dup(src));
      return 0;
    }
  if (!DAG_literal(src))
    my_error ("qnt_NNF_rec: unable to NNF quantifier\n");
  if (pol == POL_NEG)
    {
      dest = DAG_dup(DAG_not(src));
      set_DAG_pol(src, pol, dest);
      return 1;
    }
  set_DAG_pol(src, pol, DAG_dup(src));
  return 0;
}

/*--------------------------------------------------------------*/

TDAG
qnt_NNF(TDAG src)
{
  TDAG dest;
  DAG_tmp_reserve();
  qnt_NNF_rec(src, POL_POS, 0);
  dest = DAG_dup(get_DAG(src, POL_POS));
  DAG_tmp_reset_DAG_pol(src);
  DAG_tmp_release();
  return dest;
}

/*--------------------------------------------------------------*/

TDAG
qnt_NF(TDAG src)
{
  TDAG dest;
  /* Remove conectives besides AND/OR/NOT from scope of quantifiers */
  dest = qnt_connectives(src);
  DAG_free(src);
  src = dest;
  /* Put quantified formulas in NNF, remove weak existentials */
  dest = qnt_NNF(src);
  DAG_free(src);
  src = dest;
  /* Rename variables so that none appear in more than one quantifier */
  dest = qnt_uniq_vars(src);
  DAG_free(src);
  return dest;
}

/*--------------------------------------------------------------*/

void
set_NFs(TDAG DAG)
{
  unsigned i, j;
  bool cnf_explosion;
  TDAG tmp_DAG, prenex_DAG;
  Tstack_DAG tmp;
  Tstack_DAGstack cnf;
  if (!enable_nnf_simp)
    {
      tmp_DAG = DAG_dup(NNF(DAG, true));
      prenex_DAG = DAG_dup(prenex(tmp_DAG));
      DAG_free(tmp_DAG);
    }
  else
    prenex_DAG = DAG_dup(prenex(DAG));
  /* Computes a set of sets representing CNF of given DAG */
  DAG_tmp_reserve();
  count_CNF_nodes(DAG_arg_last(prenex_DAG));
  /* Whether it exploded */
  cnf_explosion = !cnf_count[DAG_arg_last(prenex_DAG)] ||
    !cnf_count_clauses(DAG_arg_last(prenex_DAG));
  DAG_tmp_reset_cnf_count(DAG_arg_last(prenex_DAG));
  DAG_tmp_release();
  if (cnf_explosion)
    {
      DAG_free(prenex_DAG);
      return;
    }
  DAG_tmp_reserve();
  set_CNF_rec(DAG_arg_last(prenex_DAG));
  stack_INIT(cnf);
  for (i = 0; i < stack_size(cnf_of[DAG_arg_last(prenex_DAG)]); ++i)
    {
      stack_COPY(tmp, stack_get(cnf_of[DAG_arg_last(prenex_DAG)], i));
      stack_apply(tmp, DAG_dup);
      stack_push(cnf, tmp);
    }
  DAG_prop_set(DAG, DAG_PROP_CNF, &cnf);
  DAG_tmp_reset_cnf(DAG_arg_last(prenex_DAG));
  DAG_tmp_release();
  /* [TODO] only one DAG_tmp for all... have a set_fvars_array/stack? */
  /* Sets bound variables of all DAGs in CNF */
  for (i = 0; i < stack_size(cnf); ++i)
    for (j = 0; j < stack_size(stack_get(cnf, i)); ++j)
      set_fvars(stack_get(stack_get(cnf, i), j));
  DAG_free(prenex_DAG);
}

/*--------------------------------------------------------------*/
