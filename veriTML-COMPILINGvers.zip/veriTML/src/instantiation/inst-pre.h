#ifndef __INST_PRE_H
#define __INST_PRE_H

#include "congruence.h"

/*
  --------------------------------------------------------------
  Preprocessing quantified formulas for instantiation
  --------------------------------------------------------------
*/



/*
  --------------------------------------------------------------
  Normal forms
  --------------------------------------------------------------
*/

/* [TODO] Should me merged into set_NFs */
/**
   \remark assumes tree structure (no "lets")
   \remark assumes DAG is in PNNF */
extern void set_CNF(TDAG DAG);

/**
   \brief computes prenexed NNF and CNF of quantified DAG with arbitrary boolean structure
   \param DAG a quantified formula
   \remark assumes tree structure (no "lets")

   \remark No miniscoping/Skolemization is done. Only prenex universal
   quantifiers not under the scope of existential ones. */
extern void set_NFs(TDAG DAG);

/**
   \author Haniel Barbosa

   \brief takes formula and for each quantifier occurrence puts it in prenexed
   NNF
   \param DAG a formula

   \remark Assumes no quantifier occurs

   \remark No miniscoping/Skolemization is done. Only prenex universal
   quantifiers not under the scope of existential ones.

   \remark Renames variables so that prenexing does not mess up univesal
   quantification. Does not account for existentials, so the latter may range
   over universally quantified variables (a subsequent call to qnt_tidy will be
   required then)

   \remark Not sure about how destructive it is */
extern TDAG qnt_NF(TDAG DAG);

extern TDAG qnt_connectives(TDAG DAG);
extern TDAG qnt_NNF(TDAG src);
extern TDAG qnt_uniq_vars(TDAG DAG);

/*
  --------------------------------------------------------------
  Symbols
  --------------------------------------------------------------
*/

#endif
