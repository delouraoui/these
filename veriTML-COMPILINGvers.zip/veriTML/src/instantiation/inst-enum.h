/**
   \file enum.h
   \author Haniel Barbosa
   \brief Module for enumerating instances */
#ifndef __INST_ENUM_H
#define __INST_ENUM_H

#include "unify.h"
#include "inst-strategy.h"

/**
   \author Hanel Barbosa
   \brief initializes module */
extern void inst_enum_init(void);

/**
   \author Hanel Barbosa
   \brief releases module */
extern void inst_enum_done(void);
/**
   \author Hanel Barbosa
   \brief performs enumerative instantiation */
extern bool inst_enum(void);

#endif
