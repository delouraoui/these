type t = V of int
       | A of int * t list;;

let md5s s = Int64.to_int ((Obj.magic (Digest.to_hex (Digest.string s))) : int64);;

open Ast;;

let cst2t = function
  | CstNumeral x
  | CstDecimal x
  | CstHexadecimal x
  | CstBinary x
  | CstString x -> A (md5s x, [])
  | CstBool true -> A (1, [])
  | CstBool _ -> A (0, []);;

let sym2t = function SimpleSymbol s
| QuotedSymbol s -> md5s s;;


let id2t = function
  | IdSymbol s
  | IdUnderscore (s, _) -> sym2t (s.symbol_desc);;

let qid2t = function
  | QualIdentifierIdentifier i
  | QualIdentifierAs (i, _) -> id2t i.id_desc;;

let constsvar = 153;;
let constbinding = 121;;
let constlet = 179;;
let constforall = 323;;
let constexists = 353;;
let consteps = 383;;


let rec sort2t s = match s.sort_desc with
  | SortIdentifier i -> A(id2t (i.id_desc), [])
  | SortFun (i, ss) -> A(id2t (i.id_desc), List.map sort2t ss);;

let rec vbd2t (VarBinding (s, t)) = A(constbinding, [A(sym2t (s.symbol_desc), []); t2t t])
and vb2t vb = vbd2t (vb.var_binding_desc)

and svdt2 (SortedVar (s, srt)) = A(constsvar, [V (sym2t s.symbol_desc); sort2t srt])
and sv2t sv = svdt2 (sv.sorted_var_desc)

and t2t t = match t.term_desc with
  | TermSpecConstant c -> cst2t c
  | TermQualIdentifier q -> A (qid2t (q.qual_identifier_desc), [])
  | TermQualIdentifierTerms (q, ts) -> A (qid2t (q.qual_identifier_desc), List.map t2t ts)
  | TermLetTerm (v, t) -> A (constlet, t2t t :: (List.map vb2t v))
  | TermForallTerm (sv, t) -> A (constforall, t2t t :: (List.map sv2t sv))
  | TermExistsTerm (sv, t) -> A (constexists, t2t t :: (List.map sv2t sv))
  | TermEpsTerm (sv, t) -> A (consteps, t2t t :: (List.map sv2t sv))
  | TermAnnotatedTerm (t, _) -> t2t t;;

let pp_print_var f i =
  Format.pp_print_char f (Char.chr (65 + i mod 26)); if i > 25 then Format.pp_print_int f (i / 26);;

let rec pp_iter f fn sep = function
    [] -> ()
  | [e] -> fn f e
  | h :: t -> fn f h; Format.pp_print_string f sep; pp_iter f fn sep t;;

let rec pp_print_term f = function
    V i -> pp_print_var f i
  | A (i, l) ->
      Format.pp_print_int f i;
      if l <> [] then begin Format.pp_print_char f '('; pp_iter f pp_print_term "," l; Format.pp_print_char f ')' end;;

let print_to_string printer =
  let buf = Buffer.create 10 in
  let fmt = Format.formatter_of_buffer buf in
  Format.pp_set_max_boxes fmt 1000;
  fun x -> printer fmt x; Format.pp_print_flush fmt (); let s = Buffer.contents buf in Buffer.reset buf; s;;

let string_of_term = print_to_string pp_print_term;;

(*let (lexbuf, close) = Do_parse.lex_file "/tmp/a/insert_even.smt2/dump-1.smt2";;
let sexpr = Parser.term Lexer.token lexbuf;;
 *)

(*instances-1-1.smt2*)
(*let (lexbuf, close) = Do_parse.lex_file "/tmp/a/dumped-data/list1.smt2/useful-instances-0.smt2";;*)

(*let (lexbuf, close) = Do_parse.lex_file "/home/delour/verit/veriT/dumped-data/insert_even.smt2/instances-10-1661.smt2";;*)

let open_file f =
  Do_parse.lex_file f

(*let (n, t, ii) = Parser.instance Lexer.token lexbuf;;*)

let features_modulo = 262139;; (* prime 2 ^ 18 - 5 *)
let fmod n = 1 + let r = n mod features_modulo in
if r < 0 then r + features_modulo else r;;
let fmod3 n = 1 + let r = n mod (features_modulo * 3) in
if r < 0 then r + (features_modulo * 3) else r;;

let fea_vconst = 17;;
(* let rec bit_features_cont last sf = function
 *   | V _ -> last * fea_vconst :: fea_vconst :: sf
 *   | A (f, l) -> List.fold_left (bit_features_cont f) (last * f :: f :: sf) l;;
 * let bit_features sf (n, l) = List.fold_left (bit_features_cont n) (n :: sf) l;; *)

module Im = Map.Make(struct type t = int let compare = compare end);;

let imincr1 key sf =
  let key = fmod key in
  try let ov = Im.find key sf in
      Im.add key (ov + 1) sf
  with Not_found -> Im.add key 1 sf;;
let imincr = imincr1;;

let fea_prime = 1933;;
let fea_pat_len = ref 3;;
(* adds:  v   v + p*a   v + p*a + p*p*b   ... *)
let rec ubitn_add current prime sf len = function
  | [] -> imincr current sf
  | h :: t ->
     if len <= 0 then imincr current sf else
     ubitn_add (current * prime + h) (prime * fea_prime) (imincr current sf) (len - 1) t;;
let rec ubitn_cont lasts sf = function
  | V _ ->
     ubitn_add fea_vconst fea_prime sf !fea_pat_len lasts
  | A (f, l) ->
     List.fold_left (ubitn_cont (f :: lasts)) (ubitn_add f fea_prime sf !fea_pat_len lasts) l;;
let fea_nocount = ref false;;

let unpack_im im =
  if !fea_nocount then List.rev (Im.fold (fun i _ sf -> (i, 1) :: sf) im [])
  else List.rev (Im.fold (fun i n sf -> (i, n) :: sf) im []);;

let ubit2 t = ubitn_cont [] Im.empty t;;
(*let fea = unpack_im (ubit2 (t2t t));;*)

(* type info_type =
 *     INST | DUMPS | MODE | USE | SKIP *)
let statistics d =
  let dirh = Unix.opendir d in
  let goodname s = s <> "." && s <> ".." in
  let dumps = ref [] in
  let models = ref [] in
  let instances = ref [] in
  let useful = ref [] in
  let get_round_inst s =
    let i = String.index s '-' in
    let round = String.sub s 0 i in
    int_of_string round in
    let get_round s =
    let i = String.index s '.' in
    let round = String.sub s 0 i in
    int_of_string round in
  let handle path = function
    | s when String.sub s 0 9 = "instances" ->
      let suffixe = String.sub s 10 ((String.length s) - 10) in
      let round = get_round_inst suffixe in
      (* Printf.printf "INSTANCE ROUND %d \n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let (n, t, ii) = Parser.instance Lexer.token lexbuf_file in
      instances := (round, (n, t, ii)) :: !instances;
      close_file ()
    | s when String.sub s 0 4 = "dump" ->
      let suffixe = String.sub s 5 ((String.length s) - 5) in
      let round = get_round suffixe in
      (* Printf.printf "DUMP ROUND %d\n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let t = Parser.list_term Lexer.token lexbuf_file in
      dumps := (round, t) :: !dumps;
      close_file ()
    | s when String.sub s 0 6 = "useful" ->
      let suffixe = String.sub s 17 ((String.length s) - 17) in
      let round = get_round suffixe in
      (* Printf.printf "USEFUL ROUND %d\n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let (n, t, ii) = Parser.instance Lexer.token lexbuf_file in
      useful := (round, (n, t, ii)) :: !useful;
      close_file ()
    | s when String.sub s 0 5 = "model" ->
      let suffixe = String.sub s 6 ((String.length s) - 6) in
      let round = get_round suffixe in
      (* Printf.printf "MODEL ROUND %d\n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let t = Parser.list_term Lexer.token lexbuf_file in
      models := (round, t) :: !models;
      close_file ()
    | _ -> () in
  let rec fs acc = try
      fs (let l = Unix.readdir dirh in if goodname l then
            ((* Printf.printf "%s\n" l; *)
             handle d l;
             l :: acc) else acc)
    with End_of_file -> acc in
  let _ = fs [] in
  Printf.printf "used:%d generated:%d \n"
    (List.fold_left (fun acc (u, (x,y,t)) ->
         (int_of_string x) + acc ) 0 (!useful)) (List.fold_left (fun acc (u, (x,y,t)) ->
        (int_of_string x) + acc ) 0 (!instances));;

let dirents d =
  let dirh = Unix.opendir d in
  let goodname s = s <> "." && s <> ".." in
  let dumps = ref [] in
  let models = ref [] in
  let instances = ref [] in
  let useful = ref [] in
  let get_round_inst s =
    let i = String.index s '-' in
    let round = String.sub s 0 i in
    int_of_string round in
    let get_round s =
    let i = String.index s '.' in
    let round = String.sub s 0 i in
    int_of_string round in
  let handle path = function
    | s when String.sub s 0 9 = "instances" ->
      let suffixe = String.sub s 10 ((String.length s) - 10) in
      let round = get_round_inst suffixe in
      (* Printf.printf "INSTANCE ROUND %d \n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let (n, t, ii) = Parser.instance Lexer.token lexbuf_file in
      instances := (round, (n, t, ii)) :: !instances;
      close_file ()
    | s when String.sub s 0 4 = "dump" ->
      let suffixe = String.sub s 5 ((String.length s) - 5) in
      let round = get_round suffixe in
      (* Printf.printf "DUMP ROUND %d\n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let t = Parser.list_term Lexer.token lexbuf_file in
      dumps := (round, t) :: !dumps;
      close_file ()
    | s when String.sub s 0 6 = "useful" ->
      let suffixe = String.sub s 17 ((String.length s) - 17) in
      let round = get_round suffixe in
      (* Printf.printf "USEFUL ROUND %d\n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let (n, t, ii) = Parser.instance Lexer.token lexbuf_file in
      useful := (round, (n, t, ii)) :: !useful;
      close_file ()
    | s when String.sub s 0 5 = "model" ->
      let suffixe = String.sub s 6 ((String.length s) - 6) in
      let round = get_round suffixe in
      (* Printf.printf "MODEL ROUND %d\n" round; *)
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let t = Parser.list_term Lexer.token lexbuf_file in
      models := (round, t) :: !models;
      close_file ()
    | _ -> () in
  let rec fs acc = try
      fs (let l = Unix.readdir dirh in if goodname l then
            ((* Printf.printf "%s\n" l; *)
             handle d l;
             l :: acc) else acc)
    with End_of_file -> acc in
  let _ = fs [] in
  let cmp = (fun x y -> if fst x > fst y then 1 else 0) in 
  let sort_l l  = List.sort cmp !l in
  let useful  =  sort_l useful in
  let sdumps  =  sort_l dumps in
  let smodels  =  sort_l models in
  let i = ref 1 in
(*  List.iter (fun (_head, (x, _t, _y)) -> Printf.printf "%s, " x) (sort_l instances);*)
  let pairs  =
      List.fold_left (fun (acc, res) (head, tuple) ->
          if head = !i then (tuple::acc, res) else (incr i; ([tuple], acc::res)) )
        ([], []) (sort_l instances) in
  (* fold left should always be reordred  *)
  let sinstances = List.rev ((fst pairs) :: (snd pairs)) in
  let rounds =
    List.mapi (fun i x -> (snd (List.nth sdumps i), snd (List.nth smodels i), x)) sinstances in
  Unix.closedir dirh;
  (rounds, (List.map (fun (_i, x) -> x) useful));;

let dirents_learn d =
  let dirh = Unix.opendir d in
  let goodname s = s <> "." && s <> ".." in
  let dumps = ref [] in
  let models = ref [] in
  let instances = ref [] in
  let get_round s =
    let i = String.index s '.' in
    let round = String.sub s 0 i in
    int_of_string round in
  let handle path = function
    | s when String.sub s 0 9 = "instances" ->
      let suffixe = String.sub s 10 ((String.length s) - 10) in
      let round = get_round suffixe in
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let (n, t, ii) = Parser.instance Lexer.token lexbuf_file in
      instances := (round, (n, t, ii)) :: !instances;
      close_file ()
    | s when String.sub s 0 4 = "dump" ->
      let suffixe = String.sub s 5 ((String.length s) - 5) in
      let round = get_round suffixe in
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let t = Parser.list_term Lexer.token lexbuf_file in
      dumps := (round, t) :: !dumps;
      close_file ()
    | s when String.sub s 0 5 = "model" ->
      let suffixe = String.sub s 6 ((String.length s) - 6) in
      let round = get_round suffixe in
      let (lexbuf_file, close_file) =
        open_file (Printf.sprintf "%s/%s" path s) in
      let t = Parser.list_term Lexer.token lexbuf_file in
      models := (round, t) :: !models;
      close_file ()
    | _ -> () in
  let rec fs acc = try
      fs (let l = Unix.readdir dirh in if goodname l then
            (handle d l; l :: acc) else acc)
    with End_of_file -> acc in
  let _ = fs [] in
  let cmp = (fun x y -> if fst x > fst y then 1 else 0) in
  let sort_l l  = List.sort cmp !l in
  let sdumps  =  sort_l dumps in
  let smodels  =  sort_l models in
  let sinstances  =  List.map (fun (x,y) -> y) (sort_l instances) in
  let rounds = (snd (List.nth sdumps 0), snd (List.nth smodels 0), sinstances) in
  Unix.closedir dirh;
  rounds;;

(*dirents "/home/delour/verit/veriT/dumped-data/set6.smt2" ;;*)
(*Print_endline (string_of_term (t2t t));;*)
(* print_endline (String.concat " " (List.map (fun (a,b) -> Printf.sprintf "%i:%i" a b) fea));; *)

(*close ();;*)

let rec term_size sf = function
  | A(_,fargs) -> List.fold_left term_size (sf + 1) fargs
  | V(_) -> sf + 1;;

let rec term_depth = function
  | A(_,fargs) -> 1 + List.fold_left (fun sf t -> max sf (term_depth t)) 0 fargs
  | V(_) -> 1;;

let shift i l = List.map (fun (x, n) -> (x + i * features_modulo, n)) l;;

let first (x, _, _) = x;;
let second(_, x, _) = x;;
let third (_, _, x) = x;;

let ubit sf t = ubitn_cont [] sf t;;

let add_i_fea sf (v, i) = ubit (Im.add (fmod v) 1 sf) i;;

let map_is (a, b, c) = (a, t2t b, List.map (fun (s, t) -> ((sym2t s.symbol_desc), t2t t)) c);;


(* let write_out fea used =
 *   print_string (if used then "1" else "-1");
 *   List.iter (fun (i,n) -> print_string " "; print_int i; print_string ":"; print_int n) fea;
 *   print_char '\n'
 * ;; *)

let write_out fea used oc =
  Printf.fprintf oc "%s" (if used then "1" else "0");
  (*  Printf.fprintf oc "%s" (if used then "1" else "-1");**)
  List.iter (fun (i,n) -> Printf.fprintf oc " %d:%d" i n) fea;
  Printf.fprintf oc "\n"
;;

let fea_instance oc useful fea_common fea_art1 (no, qf, is) =
  let fea_qf = shift 3 (unpack_im (ubit Im.empty qf)) in
  let fea_is = shift 4 (unpack_im (List.fold_left add_i_fea Im.empty is)) in
  let art_no = int_of_string no in
  let art_s = List.fold_left (fun sf (_, t) -> term_size sf t) 0 is in
  let art_md = List.fold_left (fun sf (_, t) -> max sf (term_depth t)) 0 is in
  let fea_art = fea_art1 @ shift 5 [(7, art_no); (8, art_s); (9, art_md)] in
  write_out (fea_common @ fea_qf @ fea_is @ fea_art) (List.mem is useful) oc
;;

let fea_rnd useful (dd, d, is) oc =
  let dd = List.map t2t dd and d = List.map t2t d and is = List.map map_is is in
  let fea_dd = unpack_im (List.fold_left ubit Im.empty dd) in
  let fea_d = shift 1 (unpack_im (List.fold_left ubit Im.empty d)) in
  let art_dd = List.length dd in
  let art_d = List.length d in
  let art_ds = List.fold_left term_size 0 d in
  let qform = List.sort_uniq compare (List.map second is) in
  let fea_qf = shift 2 (unpack_im (List.fold_left ubit Im.empty qform)) in
  let art_ql = List.length qform in
  let art_qs = List.fold_left term_size 0 qform in
  let art_qmd = List.fold_left max 0 (List.map term_depth qform) in
  let fea_art = shift 5 [(1, art_dd); (2, art_d); (3, art_ds); (4, art_ql); (5, art_qs); (6, art_qmd)] in
  let common = fea_dd @ fea_d @ fea_qf in
  List.iter (fea_instance oc useful common fea_art) is
;;

(** For learning **)
(* let rnds, useful = dirents Sys.argv.(1);;
 * let useful = List.map (fun x -> third (map_is x)) useful;;
 * List.iter (fea_rnd useful) rnds;; *)

(* external transform : string -> unit = "ocaml_transform" *)

(** For evaluation **)
(* let rnds = dirents_learn Sys.argv.(1);; *)
let ocaml_transform s file =
  let oc = open_out file in
  let rnds = dirents_learn s in
  fea_rnd [] rnds oc; close_out oc;;

(* let ocaml_transform s =  Printf.printf "Program name is '%s'.\n" s;flush stdout
 * (\* (statistics Sys.argv.(1));; *\) *)

(* On program initialisation, register functions to be called from C. *)
let () =
  Callback.register "ocaml_transform" ocaml_transform
