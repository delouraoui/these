
module MenhirBasics = struct
  
  exception Error
  
  type token = 
    | UNDERSCORE
    | SYMBOL of (
# 146 "parser.mly"
       (string)
# 12 "parser.ml"
  )
    | STRING of (
# 143 "parser.mly"
       (string)
# 17 "parser.ml"
  )
    | SLASH
    | SETOPTION
    | SETLOGIC
    | SETINFO
    | SEMICOLON
    | RPAREN
    | RESETASSERTIONS
    | RESET
    | QUOTEDSYMBOL of (
# 147 "parser.mly"
       (string)
# 30 "parser.ml"
  )
    | PUSH
    | POP
    | PAR
    | NUMERAL of (
# 139 "parser.mly"
       (Ast.numeral)
# 38 "parser.ml"
  )
    | METAINFO
    | LPAREN
    | LET
    | KEYWORD of (
# 145 "parser.mly"
       (string)
# 46 "parser.ml"
  )
    | HEXADECIMAL of (
# 141 "parser.mly"
       (string)
# 51 "parser.ml"
  )
    | GETVALUE
    | GETUNSATCORE
    | GETUNSATASSUMPTIONS
    | GETPROOF
    | GETOPTION
    | GETMODEL
    | GETINFO
    | GETASSIGNMENT
    | GETASSERTIONS
    | FORALL
    | EXIT
    | EXISTS
    | EPSILON
    | EOF
    | ECHO
    | DEFINESORT
    | DEFINEFUNREC
    | DEFINEFUN
    | DECLARESORT
    | DECLAREFUN
    | DECLARECONST
    | DECIMAL of (
# 140 "parser.mly"
       (string)
# 77 "parser.ml"
  )
    | CHOICE
    | CHECKSAT
    | BOOL of (
# 144 "parser.mly"
       (bool)
# 84 "parser.ml"
  )
    | BINARY of (
# 142 "parser.mly"
       (string)
# 89 "parser.ml"
  )
    | BANG
    | ASSERT
    | AS
  
end

include MenhirBasics

let _eRR =
  MenhirBasics.Error

type _menhir_env = {
  _menhir_lexer: Lexing.lexbuf -> token;
  _menhir_lexbuf: Lexing.lexbuf;
  _menhir_token: token;
  mutable _menhir_error: bool
}

and _menhir_state = 
  | MenhirState334
  | MenhirState331
  | MenhirState330
  | MenhirState327
  | MenhirState326
  | MenhirState323
  | MenhirState321
  | MenhirState316
  | MenhirState311
  | MenhirState307
  | MenhirState305
  | MenhirState301
  | MenhirState299
  | MenhirState295
  | MenhirState293
  | MenhirState289
  | MenhirState288
  | MenhirState287
  | MenhirState286
  | MenhirState275
  | MenhirState270
  | MenhirState265
  | MenhirState263
  | MenhirState261
  | MenhirState258
  | MenhirState256
  | MenhirState255
  | MenhirState253
  | MenhirState251
  | MenhirState248
  | MenhirState247
  | MenhirState245
  | MenhirState244
  | MenhirState242
  | MenhirState239
  | MenhirState236
  | MenhirState234
  | MenhirState232
  | MenhirState230
  | MenhirState224
  | MenhirState223
  | MenhirState220
  | MenhirState219
  | MenhirState214
  | MenhirState212
  | MenhirState211
  | MenhirState210
  | MenhirState207
  | MenhirState205
  | MenhirState202
  | MenhirState201
  | MenhirState199
  | MenhirState197
  | MenhirState193
  | MenhirState190
  | MenhirState187
  | MenhirState184
  | MenhirState179
  | MenhirState176
  | MenhirState172
  | MenhirState169
  | MenhirState166
  | MenhirState163
  | MenhirState160
  | MenhirState157
  | MenhirState155
  | MenhirState153
  | MenhirState151
  | MenhirState149
  | MenhirState146
  | MenhirState144
  | MenhirState141
  | MenhirState138
  | MenhirState136
  | MenhirState134
  | MenhirState132
  | MenhirState129
  | MenhirState127
  | MenhirState125
  | MenhirState122
  | MenhirState120
  | MenhirState115
  | MenhirState113
  | MenhirState111
  | MenhirState110
  | MenhirState105
  | MenhirState104
  | MenhirState102
  | MenhirState91
  | MenhirState87
  | MenhirState86
  | MenhirState85
  | MenhirState84
  | MenhirState83
  | MenhirState80
  | MenhirState78
  | MenhirState73
  | MenhirState68
  | MenhirState64
  | MenhirState62
  | MenhirState58
  | MenhirState55
  | MenhirState52
  | MenhirState51
  | MenhirState50
  | MenhirState46
  | MenhirState43
  | MenhirState33
  | MenhirState32
  | MenhirState31
  | MenhirState23
  | MenhirState22
  | MenhirState21
  | MenhirState20
  | MenhirState18
  | MenhirState17
  | MenhirState16
  | MenhirState14
  | MenhirState9
  | MenhirState8
  | MenhirState7
  | MenhirState2

# 18 "parser.mly"
  
    open Ast
    open Locations ;;

    let pp_success () =
       if Config.get_smtsuccess () then Format.printf "success@.";
    ;;

    (* Helper construction functions.
       File locations is handled in production rules.
       *)
    let mk_sexpr sexpr_desc sexpr_loc = { sexpr_desc; sexpr_loc; } ;;
    let mk_identifier id_desc id_loc = { id_desc; id_loc; } ;;

    let mk_sort sort_desc sort_loc = { sort_desc; sort_loc; } ;;

    let mk_command command_desc command_loc =
      pp_success ();
      { command_desc; command_loc; }
    ;;

    let mk_fun_def fun_def_desc fun_def_loc =
      { fun_def_desc; fun_def_loc; }
    ;;

    let mk_fun_rec_def fun_rec_def_desc fun_rec_def_loc =
      { fun_rec_def_desc; fun_rec_def_loc; }
    ;;

    let mk_sorted_var sorted_var_desc sorted_var_loc =
      { sorted_var_desc; sorted_var_loc; }
    ;;

    let mk_qual_identifier qual_identifier_desc qual_identifier_loc =
      { qual_identifier_desc; qual_identifier_loc; }
    ;;

    let mk_var_binding var_binding_desc var_binding_loc =
      { var_binding_desc; var_binding_loc; }
    ;;

    let mk_term term_desc term_loc = { term_desc; term_loc; } ;;

    let mk_smt_option smt_option_desc smt_option_loc = {
        smt_option_desc; smt_option_loc ;
      }
    ;;

    let mk_script script_commands script_loc =
      { script_commands; script_loc; }
    ;;

    let mk_attribute attribute_desc attribute_loc =
      { attribute_desc; attribute_loc; }
    ;;

    let mk_attr_value attr_value_desc attr_value_loc =
      { attr_value_desc; attr_value_loc; }
    ;;

    let mk_info_flag info_flag_desc info_flag_loc =
      { info_flag_desc; info_flag_loc; }
    ;;

    let mk_symbol symbol_desc symbol_loc = { symbol_desc; symbol_loc; } ;;

# 300 "parser.ml"

let rec _menhir_reduce98 : _menhir_env -> 'ttv_tail * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _endpos__1_, _menhir_s, (_1 : 'tv_qual_identifier), _startpos__1_) = _menhir_stack in
    let _endpos = _endpos__1_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 309 "parser.ml"
    ) = let _endpos = _endpos__1_ in
    let _startpos = _startpos__1_ in
    
# 310 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermQualIdentifier _1) loc )
# 316 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_goto_list_sort_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_sort_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState248 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1225 * Lexing.position * _menhir_state * 'tv_sort) * _menhir_state * 'tv_list_sort_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1223 * Lexing.position * _menhir_state * 'tv_sort) * _menhir_state * 'tv_list_sort_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _endpos_x_, _menhir_s, (x : 'tv_sort)), _, (xs : 'tv_list_sort_)) = _menhir_stack in
        let _v : 'tv_list_sort_ = 
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 333 "parser.ml"
         in
        _menhir_goto_list_sort_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1224)) : 'freshtv1226)
    | MenhirState247 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv1231 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv1227 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState251 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState251 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState251 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState251) : 'freshtv1228)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv1229 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1230)) : 'freshtv1232)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_sorted_var_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_sorted_var_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState220 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1215 * _menhir_state * 'tv_sorted_var) * _menhir_state * 'tv_list_sorted_var_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1213 * _menhir_state * 'tv_sorted_var) * _menhir_state * 'tv_list_sorted_var_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (x : 'tv_sorted_var)), _, (xs : 'tv_list_sorted_var_)) = _menhir_stack in
        let _v : 'tv_list_sorted_var_ = 
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 383 "parser.ml"
         in
        _menhir_goto_list_sorted_var_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1214)) : 'freshtv1216)
    | MenhirState219 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1221 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1217 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState223 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState223 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState223 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState223) : 'freshtv1218)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1219 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1220)) : 'freshtv1222)
    | _ ->
        _menhir_fail ()

and _menhir_goto_qual_identifier : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_qual_identifier -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v, _startpos) in
    match _menhir_s with
    | MenhirState334 | MenhirState326 | MenhirState323 | MenhirState316 | MenhirState307 | MenhirState301 | MenhirState295 | MenhirState263 | MenhirState224 | MenhirState160 | MenhirState120 | MenhirState122 | MenhirState2 | MenhirState113 | MenhirState104 | MenhirState105 | MenhirState83 | MenhirState80 | MenhirState73 | MenhirState64 | MenhirState58 | MenhirState46 | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1205 * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce98 _menhir_env (Obj.magic _menhir_stack) : 'freshtv1206)
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1207 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState104 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState104 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState104) : 'freshtv1208)
    | MenhirState287 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1209 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState334 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState334 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState334) : 'freshtv1210)
    | MenhirState286 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1211 * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce98 _menhir_env (Obj.magic _menhir_stack) : 'freshtv1212)
    | _ ->
        _menhir_fail ()

and _menhir_goto_nonempty_list_sorted_var_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_sorted_var_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1131 * _menhir_state * 'tv_sorted_var) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1129 * _menhir_state * 'tv_sorted_var) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (x : 'tv_sorted_var)), _, (xs : 'tv_nonempty_list_sorted_var_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_sorted_var_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 504 "parser.ml"
         in
        _menhir_goto_nonempty_list_sorted_var_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1130)) : 'freshtv1132)
    | MenhirState50 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1137 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1133 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState58 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState58 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState58) : 'freshtv1134)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1135 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1136)) : 'freshtv1138)
    | MenhirState62 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1143 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1139 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState64 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState64 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState64) : 'freshtv1140)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1141 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1142)) : 'freshtv1144)
    | MenhirState68 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1161 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1157 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv1153 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | CHOICE ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((((('freshtv1149 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
                    ((let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | SYMBOL _v ->
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : (((((('freshtv1145 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) = Obj.magic _menhir_stack in
                        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                        let (_v : (
# 146 "parser.mly"
       (string)
# 628 "parser.ml"
                        )) = _v in
                        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                        ((let _menhir_stack = (_menhir_stack, _endpos, _v, _startpos) in
                        let _menhir_env = _menhir_discard _menhir_env in
                        let _tok = _menhir_env._menhir_token in
                        match _tok with
                        | BINARY _v ->
                            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | BOOL _v ->
                            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | DECIMAL _v ->
                            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | HEXADECIMAL _v ->
                            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | LPAREN ->
                            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState73 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | NUMERAL _v ->
                            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | QUOTEDSYMBOL _v ->
                            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | STRING _v ->
                            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | SYMBOL _v ->
                            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState73 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | _ ->
                            assert (not _menhir_env._menhir_error);
                            _menhir_env._menhir_error <- true;
                            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState73) : 'freshtv1146)
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : (((((('freshtv1147 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) = Obj.magic _menhir_stack in
                        ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1148)) : 'freshtv1150)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((((('freshtv1151 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
                    ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1152)) : 'freshtv1154)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv1155 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1156)) : 'freshtv1158)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1159 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1160)) : 'freshtv1162)
    | MenhirState78 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1167 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1163 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState80 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState80 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState80) : 'freshtv1164)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1165 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1166)) : 'freshtv1168)
    | MenhirState299 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1173 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1169 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState301 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState301 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState301) : 'freshtv1170)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1171 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1172)) : 'freshtv1174)
    | MenhirState305 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1179 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1175 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState307 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState307 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState307) : 'freshtv1176)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1177 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1178)) : 'freshtv1180)
    | MenhirState311 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1197 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1193 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv1189 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | CHOICE ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((((('freshtv1185 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
                    ((let _menhir_env = _menhir_discard _menhir_env in
                    let _tok = _menhir_env._menhir_token in
                    match _tok with
                    | SYMBOL _v ->
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : (((((('freshtv1181 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) = Obj.magic _menhir_stack in
                        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                        let (_v : (
# 146 "parser.mly"
       (string)
# 849 "parser.ml"
                        )) = _v in
                        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                        ((let _menhir_stack = (_menhir_stack, _endpos, _v, _startpos) in
                        let _menhir_env = _menhir_discard _menhir_env in
                        let _tok = _menhir_env._menhir_token in
                        match _tok with
                        | BINARY _v ->
                            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | BOOL _v ->
                            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | DECIMAL _v ->
                            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | HEXADECIMAL _v ->
                            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | LPAREN ->
                            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState316 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | NUMERAL _v ->
                            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | QUOTEDSYMBOL _v ->
                            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | STRING _v ->
                            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | SYMBOL _v ->
                            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState316 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                        | _ ->
                            assert (not _menhir_env._menhir_error);
                            _menhir_env._menhir_error <- true;
                            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState316) : 'freshtv1182)
                    | _ ->
                        assert (not _menhir_env._menhir_error);
                        _menhir_env._menhir_error <- true;
                        let (_menhir_env : _menhir_env) = _menhir_env in
                        let (_menhir_stack : (((((('freshtv1183 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) = Obj.magic _menhir_stack in
                        ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
                        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1184)) : 'freshtv1186)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : ((((('freshtv1187 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
                    ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1188)) : 'freshtv1190)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv1191 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1192)) : 'freshtv1194)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1195 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1196)) : 'freshtv1198)
    | MenhirState321 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1203 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1199 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState323 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState323 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState323) : 'freshtv1200)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1201 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1202)) : 'freshtv1204)
    | _ ->
        _menhir_fail ()

and _menhir_reduce79 : _menhir_env -> ((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__5_ ->
    let ((((_menhir_stack, _menhir_s, _startpos__1_), _), _endpos_id_, _, (id : 'tv_identifier), _startpos_id_), _endpos_so_, _, (so : 'tv_sort)) = _menhir_stack in
    let _5 = () in
    let _2 = () in
    let _1 = () in
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__5_ in
    let _v : 'tv_qual_identifier = let _endpos = _endpos__5_ in
    let _startpos = _startpos__1_ in
    
# 351 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_qual_identifier (QualIdentifierAs (id, so)) loc )
# 966 "parser.ml"
     in
    _menhir_goto_qual_identifier _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_goto_nonempty_list_sort_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_sort_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState23 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1105 * Lexing.position * _menhir_state * 'tv_sort) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1103 * Lexing.position * _menhir_state * 'tv_sort) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _endpos_x_, _menhir_s, (x : 'tv_sort)), _, (xs : 'tv_nonempty_list_sort_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_sort_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 983 "parser.ml"
         in
        _menhir_goto_nonempty_list_sort_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1104)) : 'freshtv1106)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv1113 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1109 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1107 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
            let (_endpos__4_ : Lexing.position) = _endpos in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _endpos_id_, _, (id : 'tv_identifier), _startpos_id_), _, (sorts : 'tv_nonempty_list_sort_)) = _menhir_stack in
            let _4 = () in
            let _1 = () in
            let _endpos = _endpos__4_ in
            let _v : 'tv_sort = let _endpos = _endpos__4_ in
            let _startpos = _startpos__1_ in
            
# 280 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_sort (SortFun (id, sorts)) loc )
# 1009 "parser.ml"
             in
            _menhir_goto_sort _menhir_env _menhir_stack _endpos _menhir_s _v) : 'freshtv1108)) : 'freshtv1110)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1111 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1112)) : 'freshtv1114)
    | MenhirState214 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv1127 * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1123 * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1121 * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
            let (_endpos__4_ : Lexing.position) = _endpos in
            ((let (((_menhir_stack, _menhir_s), _startpos__2_), _, (sorts : 'tv_nonempty_list_sort_)) = _menhir_stack in
            let _4 = () in
            let _2 = () in
            let _1 = () in
            let _v : 'tv_poly_parameters = 
# 267 "parser.mly"
                                 ( sorts )
# 1040 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1119) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_poly_parameters) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1117) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_poly_parameters) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1115) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((x : 'tv_poly_parameters) : 'tv_poly_parameters) = _v in
            ((let _v : 'tv_option_poly_parameters_ = 
# 102 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( Some x )
# 1057 "parser.ml"
             in
            _menhir_goto_option_poly_parameters_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1116)) : 'freshtv1118)) : 'freshtv1120)) : 'freshtv1122)) : 'freshtv1124)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1125 * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sort_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1126)) : 'freshtv1128)
    | _ ->
        _menhir_fail ()

and _menhir_reduce14 : _menhir_env -> ((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_ -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__5_ ->
    let ((((_menhir_stack, _menhir_s, _startpos__1_), _), _endpos_symb_, _, (symb : 'tv_symbol), _startpos_symb_), _, (indexes : 'tv_nonempty_list_index_)) = _menhir_stack in
    let _5 = () in
    let _2 = () in
    let _1 = () in
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__5_ in
    let _v : 'tv_identifier = let _endpos = _endpos__5_ in
    let _startpos = _startpos__1_ in
    
# 294 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_identifier (IdUnderscore (symb, indexes)) loc )
# 1084 "parser.ml"
     in
    _menhir_goto_identifier _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_goto_instances : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_instances -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv1091 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1096 "parser.ml"
        )) * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_instances) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv1089 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1104 "parser.ml"
        )) * Lexing.position) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((i : 'tv_instances) : 'tv_instances) = _v in
        ((let ((((_menhir_stack, _menhir_s, _startpos__1_), _endpos_s_, _, (s : 'tv_symbol), _startpos_s_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1111 "parser.ml"
        ))), _endpos__5_) = _menhir_stack in
        let _5 = () in
        let _3 = () in
        let _1 = () in
        let _v : 'tv_instances = 
# 428 "parser.mly"
   ( (s,t) :: i )
# 1119 "parser.ml"
         in
        _menhir_goto_instances _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1090)) : 'freshtv1092)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1101 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 1127 "parser.ml"
        ) * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1131 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_instances) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1099 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 1139 "parser.ml"
        ) * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1143 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((i : 'tv_instances) : 'tv_instances) = _v in
        ((let ((_menhir_stack, _endpos_n_, (n : (
# 139 "parser.mly"
       (Ast.numeral)
# 1150 "parser.ml"
        )), _startpos_n_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1154 "parser.ml"
        ))) = _menhir_stack in
        let _4 = () in
        let _2 = () in
        let _v : (
# 153 "parser.mly"
       ((string * Ast.term * (Ast.symbol * Ast.term) list))
# 1161 "parser.ml"
        ) = 
# 424 "parser.mly"
  ( (n, t, i) )
# 1165 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1097) = _menhir_stack in
        let (_v : (
# 153 "parser.mly"
       ((string * Ast.term * (Ast.symbol * Ast.term) list))
# 1172 "parser.ml"
        )) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1095) = Obj.magic _menhir_stack in
        let (_v : (
# 153 "parser.mly"
       ((string * Ast.term * (Ast.symbol * Ast.term) list))
# 1179 "parser.ml"
        )) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1093) = Obj.magic _menhir_stack in
        let ((_1 : (
# 153 "parser.mly"
       ((string * Ast.term * (Ast.symbol * Ast.term) list))
# 1186 "parser.ml"
        )) : (
# 153 "parser.mly"
       ((string * Ast.term * (Ast.symbol * Ast.term) list))
# 1190 "parser.ml"
        )) = _v in
        (Obj.magic _1 : 'freshtv1094)) : 'freshtv1096)) : 'freshtv1098)) : 'freshtv1100)) : 'freshtv1102)
    | _ ->
        _menhir_fail ()

and _menhir_reduce99 : _menhir_env -> (('ttv_tail * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_ -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__4_ ->
    let (((_menhir_stack, _menhir_s, _startpos__1_), _endpos_qualid_, _, (qualid : 'tv_qual_identifier), _startpos_qualid_), _, (ts : 'tv_nonempty_list_term_)) = _menhir_stack in
    let _4 = () in
    let _1 = () in
    let _endpos = _endpos__4_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 1205 "parser.ml"
    ) = let _endpos = _endpos__4_ in
    let _startpos = _startpos__1_ in
    
# 313 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermQualIdentifierTerms(qualid, ts)) loc )
# 1212 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_reduce51 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_list_sort_ = 
# 185 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [] )
# 1221 "parser.ml"
     in
    _menhir_goto_list_sort_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce53 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_list_sorted_var_ = 
# 185 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [] )
# 1230 "parser.ml"
     in
    _menhir_goto_list_sorted_var_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce78 : _menhir_env -> 'ttv_tail * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _endpos_id_, _menhir_s, (id : 'tv_identifier), _startpos_id_) = _menhir_stack in
    let _startpos = _startpos_id_ in
    let _endpos = _endpos_id_ in
    let _v : 'tv_qual_identifier = let _endpos = _endpos_id_ in
    let _startpos = _startpos_id_ in
    
# 348 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_qual_identifier (QualIdentifierIdentifier id) loc )
# 1245 "parser.ml"
     in
    _menhir_goto_qual_identifier _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_goto_sort : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_sort -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState214 | MenhirState23 | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1037 * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState23 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState23 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState23 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1035 * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _endpos_x_, _menhir_s, (x : 'tv_sort)) = _menhir_stack in
            let _v : 'tv_nonempty_list_sort_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 1272 "parser.ml"
             in
            _menhir_goto_nonempty_list_sort_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1036)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState23) : 'freshtv1038)
    | MenhirState20 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1043 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1039 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce79 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv1040)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1041 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1042)) : 'freshtv1044)
    | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv1059 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1055 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1053 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos__4_ : Lexing.position) = _endpos in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _endpos_symb_, _, (symb : 'tv_symbol), _startpos_symb_), _endpos_so_, _, (so : 'tv_sort)) = _menhir_stack in
            let _4 = () in
            let _1 = () in
            let _v : 'tv_sorted_var = let _endpos = _endpos__4_ in
            let _startpos = _startpos__1_ in
            
# 272 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_sorted_var (SortedVar (symb, so)) loc )
# 1321 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1051) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_sorted_var) = _v in
            ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            match _menhir_s with
            | MenhirState321 | MenhirState311 | MenhirState305 | MenhirState299 | MenhirState78 | MenhirState68 | MenhirState62 | MenhirState55 | MenhirState50 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv1047 * _menhir_state * 'tv_sorted_var) = Obj.magic _menhir_stack in
                ((assert (not _menhir_env._menhir_error);
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState55 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | RPAREN ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : 'freshtv1045 * _menhir_state * 'tv_sorted_var) = Obj.magic _menhir_stack in
                    ((let (_menhir_stack, _menhir_s, (x : 'tv_sorted_var)) = _menhir_stack in
                    let _v : 'tv_nonempty_list_sorted_var_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 1344 "parser.ml"
                     in
                    _menhir_goto_nonempty_list_sorted_var_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1046)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState55) : 'freshtv1048)
            | MenhirState220 | MenhirState219 ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv1049 * _menhir_state * 'tv_sorted_var) = Obj.magic _menhir_stack in
                ((assert (not _menhir_env._menhir_error);
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState220 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | RPAREN ->
                    _menhir_reduce53 _menhir_env (Obj.magic _menhir_stack) MenhirState220
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState220) : 'freshtv1050)
            | _ ->
                _menhir_fail ()) : 'freshtv1052)) : 'freshtv1054)) : 'freshtv1056)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv1057 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1058)) : 'freshtv1060)
    | MenhirState205 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv1065 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((('freshtv1061 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState207 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState207
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState207) : 'freshtv1062)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((('freshtv1063 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1064)) : 'freshtv1066)
    | MenhirState223 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv1067 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState224 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState224 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState224) : 'freshtv1068)
    | MenhirState248 | MenhirState247 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv1069 * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState248 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState248 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState248 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce51 _menhir_env (Obj.magic _menhir_stack) MenhirState248
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState248) : 'freshtv1070)
    | MenhirState251 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv1075 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((((('freshtv1071 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState253 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState253
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState253) : 'freshtv1072)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((((('freshtv1073 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1074)) : 'freshtv1076)
    | MenhirState256 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1081 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1077 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState258 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState258
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState258) : 'freshtv1078)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1079 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1080)) : 'freshtv1082)
    | MenhirState331 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1087 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1083 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce79 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv1084)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1085 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1086)) : 'freshtv1088)
    | _ ->
        _menhir_fail ()

and _menhir_goto_nonempty_list_index_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_index_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1023 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1019 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce14 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv1020)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1021 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1022)) : 'freshtv1024)
    | MenhirState14 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1027 * _menhir_state * 'tv_index) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1025 * _menhir_state * 'tv_index) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (x : 'tv_index)), _, (xs : 'tv_nonempty_list_index_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_index_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 1560 "parser.ml"
         in
        _menhir_goto_nonempty_list_index_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1026)) : 'freshtv1028)
    | MenhirState289 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1033 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1029 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce14 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv1030)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1031 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_nonempty_list_index_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1032)) : 'freshtv1034)
    | _ ->
        _menhir_fail ()

and _menhir_goto_nonempty_list_fun_rec_def_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_fun_rec_def_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState210 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv1013 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1009 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv1005 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState230 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState230
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState230) : 'freshtv1006)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv1007 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1008)) : 'freshtv1010)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv1011 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1012)) : 'freshtv1014)
    | MenhirState232 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1017 * _menhir_state * 'tv_fun_rec_def) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv1015 * _menhir_state * 'tv_fun_rec_def) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (x : 'tv_fun_rec_def)), _, (xs : 'tv_nonempty_list_fun_rec_def_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_fun_rec_def_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 1641 "parser.ml"
         in
        _menhir_goto_nonempty_list_fun_rec_def_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1016)) : 'freshtv1018)
    | _ ->
        _menhir_fail ()

and _menhir_run111 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState111 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState111 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState111

and _menhir_run116 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv1003) = Obj.magic _menhir_stack in
    let (_endpos__1_ : Lexing.position) = _endpos in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : 'tv_instances = 
# 429 "parser.mly"
         ( [] )
# 1672 "parser.ml"
     in
    _menhir_goto_instances _menhir_env _menhir_stack _menhir_s _v) : 'freshtv1004)

and _menhir_goto_nonempty_list_term_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_term_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState105 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv979 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1685 "parser.ml"
        )) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv977 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1691 "parser.ml"
        )) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _endpos_x_, _menhir_s, (x : (
# 151 "parser.mly"
       (Ast.term)
# 1696 "parser.ml"
        ))), _, (xs : 'tv_nonempty_list_term_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_term_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 1701 "parser.ml"
         in
        _menhir_goto_nonempty_list_term_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv978)) : 'freshtv980)
    | MenhirState104 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv985 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv981 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce99 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv982)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv983 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv984)) : 'freshtv986)
    | MenhirState160 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv995 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv991 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv987 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState163 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState163
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState163) : 'freshtv988)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (((('freshtv989 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv990)) : 'freshtv992)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv993 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv994)) : 'freshtv996)
    | MenhirState334 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv1001 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv997 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce99 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv998)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv999 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv1000)) : 'freshtv1002)
    | _ ->
        _menhir_fail ()

and _menhir_reduce105 : _menhir_env -> ((((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1791 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__7_ ->
    let ((((((_menhir_stack, _menhir_s, _startpos__1_), _), _startpos__3_), _, (svars : 'tv_nonempty_list_sorted_var_)), _endpos__5_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1797 "parser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _1 = () in
    let _endpos = _endpos__7_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 1808 "parser.ml"
    ) = let _endpos = _endpos__7_ in
    let _startpos = _startpos__1_ in
    
# 331 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermEpsTerm (svars, t)) loc )
# 1815 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_reduce104 : _menhir_env -> ((((((((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 1822 "parser.ml"
) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1826 "parser.ml"
)) * Lexing.position -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__11_ ->
    let (((((((((_menhir_stack, _menhir_s, _startpos__1_), _), _startpos__3_), _, (svars : 'tv_nonempty_list_sorted_var_)), _endpos__5_), _startpos__6_), _endpos_s_, (s : (
# 146 "parser.mly"
       (string)
# 1832 "parser.ml"
    )), _startpos_s_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1836 "parser.ml"
    ))), _endpos__10_) = _menhir_stack in
    let _11 = () in
    let _10 = () in
    let _7 = () in
    let _6 = () in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _1 = () in
    let _endpos = _endpos__11_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 1850 "parser.ml"
    ) = let _endpos = _endpos__11_ in
    let _startpos = _startpos__1_ in
    
# 328 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermEpsTerm (svars, t)) loc )
# 1857 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_reduce102 : _menhir_env -> ((((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1864 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__7_ ->
    let ((((((_menhir_stack, _menhir_s, _startpos__1_), _), _startpos__3_), _, (svars : 'tv_nonempty_list_sorted_var_)), _endpos__5_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1870 "parser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _1 = () in
    let _endpos = _endpos__7_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 1881 "parser.ml"
    ) = let _endpos = _endpos__7_ in
    let _startpos = _startpos__1_ in
    
# 322 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermExistsTerm (svars, t)) loc )
# 1888 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_reduce101 : _menhir_env -> ((((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1895 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__7_ ->
    let ((((((_menhir_stack, _menhir_s, _startpos__1_), _), _startpos__3_), _, (svars : 'tv_nonempty_list_sorted_var_)), _endpos__5_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1901 "parser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _1 = () in
    let _endpos = _endpos__7_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 1912 "parser.ml"
    ) = let _endpos = _endpos__7_ in
    let _startpos = _startpos__1_ in
    
# 319 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermForallTerm (svars, t)) loc)
# 1919 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_reduce100 : _menhir_env -> ((((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 1926 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__7_ ->
    let ((((((_menhir_stack, _menhir_s, _startpos__1_), _), _startpos__3_), _, (vbindings : 'tv_nonempty_list_var_binding_)), _endpos__5_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 1932 "parser.ml"
    ))) = _menhir_stack in
    let _7 = () in
    let _5 = () in
    let _3 = () in
    let _2 = () in
    let _1 = () in
    let _endpos = _endpos__7_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 1943 "parser.ml"
    ) = let _endpos = _endpos__7_ in
    let _startpos = _startpos__1_ in
    
# 316 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermLetTerm (vbindings, t)) loc )
# 1950 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_goto_nonempty_list_var_binding_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_var_binding_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv963 * _menhir_state * 'tv_var_binding) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv961 * _menhir_state * 'tv_var_binding) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (x : 'tv_var_binding)), _, (xs : 'tv_nonempty_list_var_binding_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_var_binding_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 1967 "parser.ml"
         in
        _menhir_goto_nonempty_list_var_binding_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv962)) : 'freshtv964)
    | MenhirState31 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv969 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv965 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState46 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState46 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState46) : 'freshtv966)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv967 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv968)) : 'freshtv970)
    | MenhirState293 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv975 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv971 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState295 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState295 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState295) : 'freshtv972)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv973 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv974)) : 'freshtv976)
    | _ ->
        _menhir_fail ()

and _menhir_reduce103 : _menhir_env -> ((('ttv_tail * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2062 "parser.ml"
)) * _menhir_state * 'tv_nonempty_list_attribute_ -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__5_ ->
    let ((((_menhir_stack, _menhir_s, _startpos__1_), _), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 2068 "parser.ml"
    ))), _, (attrs : 'tv_nonempty_list_attribute_)) = _menhir_stack in
    let _5 = () in
    let _2 = () in
    let _1 = () in
    let _endpos = _endpos__5_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 2077 "parser.ml"
    ) = let _endpos = _endpos__5_ in
    let _startpos = _startpos__1_ in
    
# 325 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermAnnotatedTerm(t, attrs)) loc )
# 2084 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_goto_option_poly_parameters_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_option_poly_parameters_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState212 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv953 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv949 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState219 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | RPAREN ->
                _menhir_reduce53 _menhir_env (Obj.magic _menhir_stack) MenhirState219
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState219) : 'freshtv950)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv951 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv952)) : 'freshtv954)
    | MenhirState245 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv959 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv955 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState247 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState247 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState247 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | RPAREN ->
                _menhir_reduce51 _menhir_env (Obj.magic _menhir_stack) MenhirState247
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState247) : 'freshtv956)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv957 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv958)) : 'freshtv960)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_symbol_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_symbol_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState202 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv941 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_list_symbol_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv939 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_list_symbol_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _endpos_x_, _menhir_s, (x : 'tv_symbol), _startpos_x_), _, (xs : 'tv_list_symbol_)) = _menhir_stack in
        let _v : 'tv_list_symbol_ = 
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 2170 "parser.ml"
         in
        _menhir_goto_list_symbol_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv940)) : 'freshtv942)
    | MenhirState201 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv947 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv943 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState205 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState205 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState205 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState205) : 'freshtv944)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((('freshtv945 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv946)) : 'freshtv948)
    | _ ->
        _menhir_fail ()

and _menhir_goto_identifier : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_identifier -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v, _startpos) in
    match _menhir_s with
    | MenhirState17 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv925 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState20 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState20 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState20 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState20) : 'freshtv926)
    | MenhirState21 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv927 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState22 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState22 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState22 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState22) : 'freshtv928)
    | MenhirState331 | MenhirState256 | MenhirState247 | MenhirState251 | MenhirState248 | MenhirState223 | MenhirState214 | MenhirState205 | MenhirState52 | MenhirState20 | MenhirState22 | MenhirState23 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv931 * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv929 * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _endpos_id_, _menhir_s, (id : 'tv_identifier), _startpos_id_) = _menhir_stack in
        let _endpos = _endpos_id_ in
        let _v : 'tv_sort = let _endpos = _endpos_id_ in
        let _startpos = _startpos_id_ in
        
# 278 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_sort (SortIdentifier id) loc )
# 2255 "parser.ml"
         in
        _menhir_goto_sort _menhir_env _menhir_stack _endpos _menhir_s _v) : 'freshtv930)) : 'freshtv932)
    | MenhirState287 | MenhirState334 | MenhirState326 | MenhirState323 | MenhirState316 | MenhirState307 | MenhirState301 | MenhirState295 | MenhirState263 | MenhirState224 | MenhirState160 | MenhirState120 | MenhirState122 | MenhirState2 | MenhirState113 | MenhirState7 | MenhirState104 | MenhirState105 | MenhirState83 | MenhirState80 | MenhirState73 | MenhirState64 | MenhirState58 | MenhirState46 | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv933 * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce78 _menhir_env (Obj.magic _menhir_stack) : 'freshtv934)
    | MenhirState330 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv935 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState331 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState331 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState331 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState331) : 'freshtv936)
    | MenhirState286 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv937 * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce78 _menhir_env (Obj.magic _menhir_stack) : 'freshtv938)
    | _ ->
        _menhir_fail ()

and _menhir_goto_index : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_index -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv923 * _menhir_state * 'tv_index) = Obj.magic _menhir_stack in
    ((assert (not _menhir_env._menhir_error);
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | NUMERAL _v ->
        _menhir_run11 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState14 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run10 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState14 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | RPAREN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv921 * _menhir_state * 'tv_index) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, (x : 'tv_index)) = _menhir_stack in
        let _v : 'tv_nonempty_list_index_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 2304 "parser.ml"
         in
        _menhir_goto_nonempty_list_index_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv922)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState14) : 'freshtv924)

and _menhir_goto_term : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 151 "parser.mly"
       (Ast.term)
# 2315 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv787 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2325 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv783 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2335 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv781 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2343 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos__4_ : Lexing.position) = _endpos in
            ((let (((_menhir_stack, _menhir_s, _startpos__1_), _endpos_symb_, _, (symb : 'tv_symbol), _startpos_symb_), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 2349 "parser.ml"
            ))) = _menhir_stack in
            let _4 = () in
            let _1 = () in
            let _v : 'tv_var_binding = let _endpos = _endpos__4_ in
            let _startpos = _startpos__1_ in
            
# 357 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_var_binding (VarBinding (symb, t)) loc )
# 2359 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv779) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_var_binding) = _v in
            ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv777 * _menhir_state * 'tv_var_binding) = Obj.magic _menhir_stack in
            ((assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState43 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv775 * _menhir_state * 'tv_var_binding) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s, (x : 'tv_var_binding)) = _menhir_stack in
                let _v : 'tv_nonempty_list_var_binding_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 2380 "parser.ml"
                 in
                _menhir_goto_nonempty_list_var_binding_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv776)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState43) : 'freshtv778)) : 'freshtv780)) : 'freshtv782)) : 'freshtv784)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv785 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2394 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv786)) : 'freshtv788)
    | MenhirState46 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv793 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2403 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv789 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2413 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce100 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv790)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv791 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2425 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv792)) : 'freshtv794)
    | MenhirState58 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv799 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2434 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv795 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2444 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce101 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv796)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv797 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2456 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv798)) : 'freshtv800)
    | MenhirState64 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv805 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2465 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv801 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2475 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce102 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv802)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv803 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2487 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv804)) : 'freshtv806)
    | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv815 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 2496 "parser.ml"
        ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2500 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((((('freshtv811 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 2510 "parser.ml"
            ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2514 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((((((((('freshtv807 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 2526 "parser.ml"
                ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2530 "parser.ml"
                )) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_env = _menhir_discard _menhir_env in
                _menhir_reduce104 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv808)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((((((((('freshtv809 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 2542 "parser.ml"
                ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2546 "parser.ml"
                )) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv810)) : 'freshtv812)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((((('freshtv813 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 2557 "parser.ml"
            ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2561 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv814)) : 'freshtv816)
    | MenhirState80 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv821 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2570 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv817 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2580 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce105 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv818)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv819 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2592 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv820)) : 'freshtv822)
    | MenhirState83 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv823 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2601 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState84 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState84) : 'freshtv824)
    | MenhirState334 | MenhirState160 | MenhirState105 | MenhirState104 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv827 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2617 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState105 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState105 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv825 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2645 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _endpos_x_, _menhir_s, (x : (
# 151 "parser.mly"
       (Ast.term)
# 2650 "parser.ml"
            ))) = _menhir_stack in
            let _v : 'tv_nonempty_list_term_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 2655 "parser.ml"
             in
            _menhir_goto_nonempty_list_term_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv826)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState105) : 'freshtv828)
    | MenhirState2 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv833 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 2667 "parser.ml"
        ) * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2671 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMICOLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv829 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 2681 "parser.ml"
            ) * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2685 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EOF ->
                _menhir_run116 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState110
            | LPAREN ->
                _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState110 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState110) : 'freshtv830)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv831 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 2705 "parser.ml"
            ) * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2709 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv832)) : 'freshtv834)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv839 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2718 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv835 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2728 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | EOF ->
                _menhir_run116 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState115
            | LPAREN ->
                _menhir_run111 _menhir_env (Obj.magic _menhir_stack) MenhirState115 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState115) : 'freshtv836)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv837 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2750 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv838)) : 'freshtv840)
    | MenhirState122 | MenhirState120 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv841 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2759 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | EOF ->
            _menhir_run121 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState122 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState122 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState122) : 'freshtv842)
    | MenhirState224 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv873 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2793 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv871 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2799 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (((((((_menhir_stack, _endpos_symb_, _menhir_s, (symb : 'tv_symbol), _startpos_symb_), _, (polys : 'tv_option_poly_parameters_)), _startpos__3_), _, (svars : 'tv_list_sorted_var_)), _endpos__5_), _endpos_so_, _, (so : 'tv_sort)), _endpos_t_, _, (t : (
# 151 "parser.mly"
       (Ast.term)
# 2804 "parser.ml"
        ))) = _menhir_stack in
        let _5 = () in
        let _3 = () in
        let _startpos = _startpos_symb_ in
        let _endpos = _endpos_t_ in
        let _v : 'tv_fun_def = 
# 249 "parser.mly"
  ( (symb, polys, svars, so, t) )
# 2813 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv869) = _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_fun_def) = _v in
        let (_startpos : Lexing.position) = _startpos in
        ((let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v, _startpos) in
        match _menhir_s with
        | MenhirState211 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv855 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_def * Lexing.position) = Obj.magic _menhir_stack in
            ((assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv851 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_def * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_env = _menhir_discard _menhir_env in
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv849 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_def * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos__3_ : Lexing.position) = _endpos in
                ((let ((_menhir_stack, _menhir_s, _startpos__1_), _endpos_fd_, _, (fd : 'tv_fun_def), _startpos_fd_) = _menhir_stack in
                let _3 = () in
                let _1 = () in
                let _v : 'tv_fun_rec_def = let _endpos = _endpos__3_ in
                let _startpos = _startpos__1_ in
                
# 261 "parser.mly"
 ( let s, ps, svs, so, t = fd in
   let loc = mk_loc _startpos _endpos in
   mk_fun_rec_def (FunRecDef (s, ps, svs, so, t)) loc )
# 2847 "parser.ml"
                 in
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv847) = _menhir_stack in
                let (_menhir_s : _menhir_state) = _menhir_s in
                let (_v : 'tv_fun_rec_def) = _v in
                ((let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : 'freshtv845 * _menhir_state * 'tv_fun_rec_def) = Obj.magic _menhir_stack in
                ((assert (not _menhir_env._menhir_error);
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run211 _menhir_env (Obj.magic _menhir_stack) MenhirState232 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | RPAREN ->
                    let (_menhir_env : _menhir_env) = _menhir_env in
                    let (_menhir_stack : 'freshtv843 * _menhir_state * 'tv_fun_rec_def) = Obj.magic _menhir_stack in
                    ((let (_menhir_stack, _menhir_s, (x : 'tv_fun_rec_def)) = _menhir_stack in
                    let _v : 'tv_nonempty_list_fun_rec_def_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 2868 "parser.ml"
                     in
                    _menhir_goto_nonempty_list_fun_rec_def_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv844)
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState232) : 'freshtv846)) : 'freshtv848)) : 'freshtv850)) : 'freshtv852)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv853 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_def * Lexing.position) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv854)) : 'freshtv856)
        | MenhirState234 ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv867 * Lexing.position * _menhir_state * 'tv_fun_def * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv865 * Lexing.position * _menhir_state * 'tv_fun_def * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _endpos_fd_, _menhir_s, (fd : 'tv_fun_def), _startpos_fd_) = _menhir_stack in
            let _endpos = _endpos_fd_ in
            let _v : 'tv_fun_nonrec_def = let _endpos = _endpos_fd_ in
            let _startpos = _startpos_fd_ in
            
# 254 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    let s, ps, svs, so, t = fd in
    mk_fun_def (FunDef (s, ps, svs, so, t)) loc )
# 2896 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv863) = _menhir_stack in
            let (_endpos : Lexing.position) = _endpos in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : 'tv_fun_nonrec_def) = _v in
            ((let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v) in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv861 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_nonrec_def) = Obj.magic _menhir_stack in
            ((assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv857 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_nonrec_def) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState236 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState236
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState236) : 'freshtv858)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv859 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_nonrec_def) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv860)) : 'freshtv862)) : 'freshtv864)) : 'freshtv866)) : 'freshtv868)
        | _ ->
            _menhir_fail ()) : 'freshtv870)) : 'freshtv872)) : 'freshtv874)
    | MenhirState263 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv879 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2939 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv875 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2949 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState265 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState265
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState265) : 'freshtv876)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv877 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2971 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv878)) : 'freshtv880)
    | MenhirState295 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv885 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2980 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv881 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 2990 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce100 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv882)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv883 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3001 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv884)) : 'freshtv886)
    | MenhirState301 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv891 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3010 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv887 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3020 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce101 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv888)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv889 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3031 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv890)) : 'freshtv892)
    | MenhirState307 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv897 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3040 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv893 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3050 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce102 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv894)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv895 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3061 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv896)) : 'freshtv898)
    | MenhirState316 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv907 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 3070 "parser.ml"
        ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3074 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((((('freshtv903 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 3084 "parser.ml"
            ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3088 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((((((((('freshtv899 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 3100 "parser.ml"
                ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3104 "parser.ml"
                )) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                (_menhir_reduce104 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv900)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((((((((('freshtv901 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 3115 "parser.ml"
                ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3119 "parser.ml"
                )) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv902)) : 'freshtv904)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (((((((('freshtv905 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 3130 "parser.ml"
            ) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3134 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv906)) : 'freshtv908)
    | MenhirState323 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv913 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3143 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv909 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3153 "parser.ml"
            )) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce105 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv910)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((((('freshtv911 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3164 "parser.ml"
            )) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv912)) : 'freshtv914)
    | MenhirState326 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv915 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3173 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState327 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState327) : 'freshtv916)
    | MenhirState286 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv919 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3189 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv917 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3195 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _endpos__1_, _menhir_s, (_1 : (
# 151 "parser.mly"
       (Ast.term)
# 3200 "parser.ml"
        ))) = _menhir_stack in
        Obj.magic _1) : 'freshtv918)) : 'freshtv920)
    | _ ->
        _menhir_fail ()

and _menhir_goto_nonempty_list_attribute_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_nonempty_list_attribute_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState84 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv763 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3215 "parser.ml"
        )) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv759 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3225 "parser.ml"
            )) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce103 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv760)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv761 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3237 "parser.ml"
            )) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv762)) : 'freshtv764)
    | MenhirState102 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv767 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv765 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _endpos_x_, _menhir_s, (x : 'tv_attribute), _startpos_x_), _, (xs : 'tv_nonempty_list_attribute_)) = _menhir_stack in
        let _v : 'tv_nonempty_list_attribute_ = 
# 197 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 3250 "parser.ml"
         in
        _menhir_goto_nonempty_list_attribute_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv766)) : 'freshtv768)
    | MenhirState327 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv773 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3258 "parser.ml"
        )) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv769 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3268 "parser.ml"
            )) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce103 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv770)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ((('freshtv771 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 3279 "parser.ml"
            )) * _menhir_state * 'tv_nonempty_list_attribute_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv772)) : 'freshtv774)
    | _ ->
        _menhir_fail ()

and _menhir_reduce75 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_option_poly_parameters_ = 
# 100 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( None )
# 3291 "parser.ml"
     in
    _menhir_goto_option_poly_parameters_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run213 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LPAREN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv755 * _menhir_state) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState214 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState214 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState214 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState214) : 'freshtv756)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv757 * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv758)

and _menhir_reduce55 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_list_symbol_ = 
# 185 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [] )
# 3332 "parser.ml"
     in
    _menhir_goto_list_symbol_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce82 : _menhir_env -> 'ttv_tail * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _endpos_symb_, _menhir_s, (symb : 'tv_symbol), _startpos_symb_) = _menhir_stack in
    let _v : (
# 150 "parser.mly"
       (Ast.sexpr)
# 3342 "parser.ml"
    ) = let _endpos = _endpos_symb_ in
    let _startpos = _startpos_symb_ in
    
# 387 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_sexpr (SexprSymbol symb) loc )
# 3349 "parser.ml"
     in
    _menhir_goto_sexpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run21 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LPAREN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState21 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState21 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState21 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | UNDERSCORE ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState21
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState21

and _menhir_reduce13 : _menhir_env -> 'ttv_tail * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack ->
    let (_menhir_stack, _endpos_symb_, _menhir_s, (symb : 'tv_symbol), _startpos_symb_) = _menhir_stack in
    let _startpos = _startpos_symb_ in
    let _endpos = _endpos_symb_ in
    let _v : 'tv_identifier = let _endpos = _endpos_symb_ in
    let _startpos = _startpos_symb_ in
    
# 292 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_identifier (IdSymbol symb) loc )
# 3382 "parser.ml"
     in
    _menhir_goto_identifier _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_run10 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 146 "parser.mly"
       (string)
# 3389 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv753) = Obj.magic _menhir_stack in
    let (_endpos__1_ : Lexing.position) = _endpos in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((_1 : (
# 146 "parser.mly"
       (string)
# 3400 "parser.ml"
    )) : (
# 146 "parser.mly"
       (string)
# 3404 "parser.ml"
    )) = _v in
    let (_startpos__1_ : Lexing.position) = _startpos in
    ((let _v : 'tv_index = let _endpos = _endpos__1_ in
    let _startpos = _startpos__1_ in
    
# 286 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    IdxSymbol (mk_symbol (SimpleSymbol _1) loc) )
# 3413 "parser.ml"
     in
    _menhir_goto_index _menhir_env _menhir_stack _menhir_s _v) : 'freshtv754)

and _menhir_run11 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 139 "parser.mly"
       (Ast.numeral)
# 3420 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv751) = Obj.magic _menhir_stack in
    let (_endpos__1_ : Lexing.position) = _endpos in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((_1 : (
# 139 "parser.mly"
       (Ast.numeral)
# 3431 "parser.ml"
    )) : (
# 139 "parser.mly"
       (Ast.numeral)
# 3435 "parser.ml"
    )) = _v in
    let (_startpos__1_ : Lexing.position) = _startpos in
    ((let _v : 'tv_index = 
# 284 "parser.mly"
          ( IdxNum _1 )
# 3441 "parser.ml"
     in
    _menhir_goto_index _menhir_env _menhir_stack _menhir_s _v) : 'freshtv752)

and _menhir_reduce81 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_spec_constant -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos_sc_ _menhir_s (sc : 'tv_spec_constant) _startpos_sc_ ->
    let _v : (
# 150 "parser.mly"
       (Ast.sexpr)
# 3450 "parser.ml"
    ) = let _endpos = _endpos_sc_ in
    let _startpos = _startpos_sc_ in
    
# 384 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_sexpr (SexprConstant sc) loc )
# 3457 "parser.ml"
     in
    _menhir_goto_sexpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_reduce97 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_spec_constant -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : 'tv_spec_constant) _startpos__1_ ->
    let _endpos = _endpos__1_ in
    let _v : (
# 151 "parser.mly"
       (Ast.term)
# 3467 "parser.ml"
    ) = let _endpos = _endpos__1_ in
    let _startpos = _startpos__1_ in
    
# 307 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_term (TermSpecConstant _1) loc )
# 3474 "parser.ml"
     in
    _menhir_goto_term _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_goto_option_NUMERAL_ : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_option_NUMERAL_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState146 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv743 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv739 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState149 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState149
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState149) : 'freshtv740)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv741 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv742)) : 'freshtv744)
    | MenhirState151 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv749 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv745 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState153 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState153
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState153) : 'freshtv746)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv747 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv748)) : 'freshtv750)
    | _ ->
        _menhir_fail ()

and _menhir_goto_attribute : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_attribute -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v, _startpos) in
    match _menhir_s with
    | MenhirState327 | MenhirState102 | MenhirState84 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv713 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState102 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv711 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _endpos_x_, _menhir_s, (x : 'tv_attribute), _startpos_x_) = _menhir_stack in
            let _v : 'tv_nonempty_list_attribute_ = 
# 195 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [ x ] )
# 3562 "parser.ml"
             in
            _menhir_goto_nonempty_list_attribute_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv712)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState102) : 'freshtv714)
    | MenhirState127 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv725 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv723 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _endpos_attr_, _menhir_s, (attr : 'tv_attribute), _startpos_attr_) = _menhir_stack in
        let _endpos = _endpos_attr_ in
        let _v : 'tv_smt_option = let _endpos = _endpos_attr_ in
        let _startpos = _startpos_attr_ in
        
# 408 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_smt_option (OptionAttribute attr) loc )
# 3582 "parser.ml"
         in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv721) = _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_smt_option) = _v in
        ((let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v) in
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv719 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_smt_option) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv715 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_smt_option) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState129 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState129
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState129) : 'freshtv716)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv717 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_smt_option) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv718)) : 'freshtv720)) : 'freshtv722)) : 'freshtv724)) : 'freshtv726)
    | MenhirState136 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv731 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv727 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState138 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState138
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState138) : 'freshtv728)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv729 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv730)) : 'freshtv732)
    | MenhirState155 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv737 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv733 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState157 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState157
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState157) : 'freshtv734)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv735 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv736)) : 'freshtv738)
    | _ ->
        _menhir_fail ()

and _menhir_goto_attribute_value : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_attribute_value -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv709 * Lexing.position * _menhir_state * (
# 145 "parser.mly"
       (string)
# 3685 "parser.ml"
    ) * Lexing.position) = Obj.magic _menhir_stack in
    let (_endpos : Lexing.position) = _endpos in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let (_v : 'tv_attribute_value) = _v in
    ((let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv707 * Lexing.position * _menhir_state * (
# 145 "parser.mly"
       (string)
# 3694 "parser.ml"
    ) * Lexing.position) = Obj.magic _menhir_stack in
    let (_endpos_attrval_ : Lexing.position) = _endpos in
    let (_ : _menhir_state) = _menhir_s in
    let ((attrval : 'tv_attribute_value) : 'tv_attribute_value) = _v in
    ((let (_menhir_stack, _endpos_kwd_, _menhir_s, (kwd : (
# 145 "parser.mly"
       (string)
# 3702 "parser.ml"
    )), _startpos_kwd_) = _menhir_stack in
    let _startpos = _startpos_kwd_ in
    let _endpos = _endpos_attrval_ in
    let _v : 'tv_attribute = let _endpos = _endpos_attrval_ in
    let _startpos = _startpos_kwd_ in
    
# 402 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_attribute (AttrKeywordValue (kwd, attrval)) loc )
# 3712 "parser.ml"
     in
    _menhir_goto_attribute _menhir_env _menhir_stack _endpos _menhir_s _v _startpos) : 'freshtv708)) : 'freshtv710)

and _menhir_reduce84 : _menhir_env -> ('ttv_tail * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_ -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__3_ ->
    let ((_menhir_stack, _menhir_s, _startpos__1_), _, (sexprs : 'tv_list_sexpr_)) = _menhir_stack in
    let _3 = () in
    let _1 = () in
    let _v : (
# 150 "parser.mly"
       (Ast.sexpr)
# 3724 "parser.ml"
    ) = let _endpos = _endpos__3_ in
    let _startpos = _startpos__1_ in
    
# 393 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_sexpr (SexprParens sexprs) loc )
# 3731 "parser.ml"
     in
    _menhir_goto_sexpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_fail : unit -> 'a =
  fun () ->
    Printf.fprintf Pervasives.stderr "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

and _menhir_goto_symbol : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_symbol -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v, _startpos) in
    match _menhir_s with
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv651 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | NUMERAL _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState9 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState9 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState9) : 'freshtv652)
    | MenhirState334 | MenhirState287 | MenhirState331 | MenhirState330 | MenhirState326 | MenhirState323 | MenhirState316 | MenhirState307 | MenhirState301 | MenhirState295 | MenhirState263 | MenhirState256 | MenhirState251 | MenhirState248 | MenhirState247 | MenhirState224 | MenhirState223 | MenhirState214 | MenhirState205 | MenhirState160 | MenhirState120 | MenhirState122 | MenhirState2 | MenhirState113 | MenhirState104 | MenhirState105 | MenhirState7 | MenhirState83 | MenhirState80 | MenhirState73 | MenhirState64 | MenhirState58 | MenhirState52 | MenhirState46 | MenhirState33 | MenhirState20 | MenhirState23 | MenhirState22 | MenhirState21 | MenhirState17 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv653 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce13 _menhir_env (Obj.magic _menhir_stack) : 'freshtv654)
    | MenhirState32 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv655 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState33 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState33 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState33) : 'freshtv656)
    | MenhirState51 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv657 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState52 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState52 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState52 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState52) : 'freshtv658)
    | MenhirState275 | MenhirState86 | MenhirState91 | MenhirState87 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv659 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce82 _menhir_env (Obj.magic _menhir_stack) : 'freshtv660)
    | MenhirState85 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv663 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv661 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _endpos_symb_, _menhir_s, (symb : 'tv_symbol), _startpos_symb_) = _menhir_stack in
        let _endpos = _endpos_symb_ in
        let _v : 'tv_attribute_value = let _endpos = _endpos_symb_ in
        let _startpos = _startpos_symb_ in
        
# 375 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_attr_value (AttrValSymbol symb) loc )
# 3823 "parser.ml"
         in
        _menhir_goto_attribute_value _menhir_env _menhir_stack _endpos _menhir_s _v) : 'freshtv662)) : 'freshtv664)
    | MenhirState111 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv669 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SLASH ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv665 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState113 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState113 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState113) : 'freshtv666)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv667 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv668)) : 'freshtv670)
    | MenhirState132 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv675 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv671 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState134 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState134
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState134) : 'freshtv672)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv673 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv674)) : 'freshtv676)
    | MenhirState199 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv681 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv677 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState201 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState201 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | RPAREN ->
                _menhir_reduce55 _menhir_env (Obj.magic _menhir_stack) MenhirState201
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState201) : 'freshtv678)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv679 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv680)) : 'freshtv682)
    | MenhirState202 | MenhirState201 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv683 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState202 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState202 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce55 _menhir_env (Obj.magic _menhir_stack) MenhirState202
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState202) : 'freshtv684)
    | MenhirState234 | MenhirState211 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv685 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PAR ->
            _menhir_run213 _menhir_env (Obj.magic _menhir_stack) MenhirState212
        | LPAREN ->
            _menhir_reduce75 _menhir_env (Obj.magic _menhir_stack) MenhirState212
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState212) : 'freshtv686)
    | MenhirState239 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv695 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | NUMERAL _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv691 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            let (_v : (
# 139 "parser.mly"
       (Ast.numeral)
# 3970 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _endpos, _v, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((('freshtv687 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 3982 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState242 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState242
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState242) : 'freshtv688)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ((('freshtv689 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 4004 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                ((let ((_menhir_stack, _, _menhir_s, _, _), _, _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv690)) : 'freshtv692)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv693 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv694)) : 'freshtv696)
    | MenhirState244 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv697 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | PAR ->
            _menhir_run213 _menhir_env (Obj.magic _menhir_stack) MenhirState245
        | LPAREN ->
            _menhir_reduce75 _menhir_env (Obj.magic _menhir_stack) MenhirState245
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState245) : 'freshtv698)
    | MenhirState255 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv699 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            _menhir_run21 _menhir_env (Obj.magic _menhir_stack) MenhirState256 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState256 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState256 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState256) : 'freshtv700)
    | MenhirState270 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv701 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce82 _menhir_env (Obj.magic _menhir_stack) : 'freshtv702)
    | MenhirState288 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv703 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | NUMERAL _v ->
            _menhir_run11 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState289 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run10 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState289 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState289) : 'freshtv704)
    | MenhirState286 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv705 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        (_menhir_reduce13 _menhir_env (Obj.magic _menhir_stack) : 'freshtv706)
    | _ ->
        _menhir_fail ()

and _menhir_goto_spec_constant : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'tv_spec_constant -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    match _menhir_s with
    | MenhirState334 | MenhirState326 | MenhirState323 | MenhirState316 | MenhirState307 | MenhirState301 | MenhirState295 | MenhirState263 | MenhirState224 | MenhirState160 | MenhirState120 | MenhirState122 | MenhirState2 | MenhirState113 | MenhirState104 | MenhirState105 | MenhirState83 | MenhirState80 | MenhirState73 | MenhirState64 | MenhirState58 | MenhirState46 | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv639) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_spec_constant) = _v in
        let (_startpos : Lexing.position) = _startpos in
        (_menhir_reduce97 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos : 'freshtv640)
    | MenhirState275 | MenhirState86 | MenhirState91 | MenhirState87 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv641) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_spec_constant) = _v in
        let (_startpos : Lexing.position) = _startpos in
        (_menhir_reduce81 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos : 'freshtv642)
    | MenhirState85 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv645) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_spec_constant) = _v in
        let (_startpos : Lexing.position) = _startpos in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv643) = Obj.magic _menhir_stack in
        let (_endpos_sc_ : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((sc : 'tv_spec_constant) : 'tv_spec_constant) = _v in
        let (_startpos_sc_ : Lexing.position) = _startpos in
        ((let _endpos = _endpos_sc_ in
        let _v : 'tv_attribute_value = let _endpos = _endpos_sc_ in
        let _startpos = _startpos_sc_ in
        
# 372 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_attr_value (AttrValSpecConstant sc) loc )
# 4109 "parser.ml"
         in
        _menhir_goto_attribute_value _menhir_env _menhir_stack _endpos _menhir_s _v) : 'freshtv644)) : 'freshtv646)
    | MenhirState270 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv647) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_spec_constant) = _v in
        let (_startpos : Lexing.position) = _startpos in
        (_menhir_reduce81 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos : 'freshtv648)
    | MenhirState286 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv649) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _endpos in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : 'tv_spec_constant) = _v in
        let (_startpos : Lexing.position) = _startpos in
        (_menhir_reduce97 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos : 'freshtv650)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_term : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 152 "parser.mly"
       (Ast.term list)
# 4134 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    match _menhir_s with
    | MenhirState122 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv633 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 4143 "parser.ml"
        )) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : (
# 152 "parser.mly"
       (Ast.term list)
# 4149 "parser.ml"
        )) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv631 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 4155 "parser.ml"
        )) = Obj.magic _menhir_stack in
        let (_ : _menhir_state) = _menhir_s in
        let ((ts : (
# 152 "parser.mly"
       (Ast.term list)
# 4161 "parser.ml"
        )) : (
# 152 "parser.mly"
       (Ast.term list)
# 4165 "parser.ml"
        )) = _v in
        ((let (_menhir_stack, _endpos_t_, _menhir_s, (t : (
# 151 "parser.mly"
       (Ast.term)
# 4170 "parser.ml"
        ))) = _menhir_stack in
        let _v : (
# 152 "parser.mly"
       (Ast.term list)
# 4175 "parser.ml"
        ) = 
# 419 "parser.mly"
   ( t :: ts )
# 4179 "parser.ml"
         in
        _menhir_goto_list_term _menhir_env _menhir_stack _menhir_s _v) : 'freshtv632)) : 'freshtv634)
    | MenhirState120 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv637) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let (_v : (
# 152 "parser.mly"
       (Ast.term list)
# 4189 "parser.ml"
        )) = _v in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv635) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = _menhir_s in
        let ((_1 : (
# 152 "parser.mly"
       (Ast.term list)
# 4197 "parser.ml"
        )) : (
# 152 "parser.mly"
       (Ast.term list)
# 4201 "parser.ml"
        )) = _v in
        (Obj.magic _1 : 'freshtv636)) : 'freshtv638)
    | _ ->
        _menhir_fail ()

and _menhir_goto_list_delimited_LPAREN_command_RPAREN__ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_delimited_LPAREN_command_RPAREN__ -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v, _startpos) in
    match _menhir_s with
    | MenhirState129 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv511 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_smt_option) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv509 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_smt_option) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_sopt00_, _, (sopt00 : 'tv_smt_option)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_sopt0_ = _endpos_sopt00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let sopt0 = sopt00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_sopt_ = _endpos_sopt0_ in
            let _startpos__1_ = _startpos__10_ in
            let sopt = sopt0 in
            let _1 = _10 in
            let _endpos = _endpos_sopt_ in
            let _startpos = _startpos__1_ in
            
# 242 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdSetOption sopt) loc )
# 4239 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4245 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4251 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv510)) : 'freshtv512)
    | MenhirState134 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv515 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv513 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_symb00_, _, (symb00 : 'tv_symbol), _startpos_symb00_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_symb0_ = _endpos_symb00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let symb0 = symb00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_symb_ = _endpos_symb0_ in
            let _startpos__1_ = _startpos__10_ in
            let symb = symb0 in
            let _1 = _10 in
            let _endpos = _endpos_symb_ in
            let _startpos = _startpos__1_ in
            
# 239 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdSetLogic symb) loc )
# 4282 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4288 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4294 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv514)) : 'freshtv516)
    | MenhirState138 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv519 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv517 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_attr00_, _, (attr00 : 'tv_attribute), _startpos_attr00_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_attr0_ = _endpos_attr00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let attr0 = attr00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_attr_ = _endpos_attr0_ in
            let _startpos__1_ = _startpos__10_ in
            let attr = attr0 in
            let _1 = _10 in
            let _endpos = _endpos_attr_ in
            let _startpos = _startpos__1_ in
            
# 236 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdSetInfo attr) loc )
# 4325 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4331 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4337 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv518)) : 'freshtv520)
    | MenhirState141 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv523 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv521 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 212 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdResetAssertions loc )
# 4366 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4372 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4378 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv522)) : 'freshtv524)
    | MenhirState144 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv527 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv525 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 209 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdReset loc )
# 4407 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4413 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4419 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv526)) : 'freshtv528)
    | MenhirState149 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv531 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv529 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos_num00_, _, (num00 : 'tv_option_NUMERAL_)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_num0_ = _endpos_num00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let num0 = num00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_num_ = _endpos_num0_ in
            let _startpos__1_ = _startpos__10_ in
            let num = num0 in
            let _1 = _10 in
            let _endpos = _endpos_num_ in
            let _startpos = _startpos__1_ in
            
# 233 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdPush num) loc )
# 4450 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4456 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4462 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv530)) : 'freshtv532)
    | MenhirState153 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv535 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv533 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos_num00_, _, (num00 : 'tv_option_NUMERAL_)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_num0_ = _endpos_num00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let num0 = num00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_num_ = _endpos_num0_ in
            let _startpos__1_ = _startpos__10_ in
            let num = num0 in
            let _1 = _10 in
            let _endpos = _endpos_num_ in
            let _startpos = _startpos__1_ in
            
# 230 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdPop num) loc )
# 4493 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4499 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4505 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv534)) : 'freshtv536)
    | MenhirState157 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv539 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv537 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_attr00_, _, (attr00 : 'tv_attribute), _startpos_attr00_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_attr0_ = _endpos_attr00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let attr0 = attr00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_attr_ = _endpos_attr0_ in
            let _startpos__1_ = _startpos__10_ in
            let attr = attr0 in
            let _1 = _10 in
            let _endpos = _endpos_attr_ in
            let _startpos = _startpos__1_ in
            
# 227 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdMetaInfo attr) loc )
# 4536 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4542 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4548 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv538)) : 'freshtv540)
    | MenhirState163 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv543 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv541 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _startpos__200_), _, (ts00 : 'tv_nonempty_list_term_)), _endpos__400_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _400 = () in
        let _200 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__40_ = _endpos__400_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _40 = _400 in
          let ts0 = ts00 in
          let _20 = _200 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__4_ = _endpos__40_ in
            let _startpos__1_ = _startpos__10_ in
            let _4 = _40 in
            let ts = ts0 in
            let _2 = _20 in
            let _1 = _10 in
            let _endpos = _endpos__4_ in
            let _startpos = _startpos__1_ in
            
# 224 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdGetValue ts) loc )
# 4585 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4591 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4597 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv542)) : 'freshtv544)
    | MenhirState166 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv547 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv545 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 218 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdGetUnsatCore loc )
# 4626 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4632 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4638 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv546)) : 'freshtv548)
    | MenhirState169 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv551 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv549 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 221 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdGetUnsatAssumptions loc )
# 4667 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4673 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4679 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv550)) : 'freshtv552)
    | MenhirState172 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv555 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv553 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 215 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdGetProof loc )
# 4708 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4714 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4720 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv554)) : 'freshtv556)
    | MenhirState176 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv559 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 145 "parser.mly"
       (string)
# 4728 "parser.ml"
        ) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv557 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 145 "parser.mly"
       (string)
# 4734 "parser.ml"
        ) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_kwd00_, (kwd00 : (
# 145 "parser.mly"
       (string)
# 4739 "parser.ml"
        )), _startpos_kwd00_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_kwd0_ = _endpos_kwd00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let kwd0 = kwd00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_kwd_ = _endpos_kwd0_ in
            let _startpos__1_ = _startpos__10_ in
            let kwd = kwd0 in
            let _1 = _10 in
            let _endpos = _endpos_kwd_ in
            let _startpos = _startpos__1_ in
            
# 206 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdGetOption kwd) loc )
# 4763 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4769 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4775 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv558)) : 'freshtv560)
    | MenhirState179 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv563 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv561 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 203 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdGetModel loc )
# 4804 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4810 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4816 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv562)) : 'freshtv564)
    | MenhirState184 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv567 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * 'tv_info_flag) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv565 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * 'tv_info_flag) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_iflag00_, (iflag00 : 'tv_info_flag)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_iflag0_ = _endpos_iflag00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let iflag0 = iflag00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_iflag_ = _endpos_iflag0_ in
            let _startpos__1_ = _startpos__10_ in
            let iflag = iflag0 in
            let _1 = _10 in
            let _endpos = _endpos_iflag_ in
            let _startpos = _startpos__1_ in
            
# 200 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdGetInfo iflag) loc )
# 4847 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4853 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4859 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv566)) : 'freshtv568)
    | MenhirState187 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv571 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv569 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 197 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdGetAssignment loc )
# 4888 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4894 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4900 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv570)) : 'freshtv572)
    | MenhirState190 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv575 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv573 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 194 "parser.mly"
    ( let loc = mk_loc _startpos _endpos in
      mk_command CmdGetAssertions loc )
# 4929 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4935 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4941 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv574)) : 'freshtv576)
    | MenhirState193 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv579 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv577 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 191 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command CmdExit loc )
# 4970 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 4976 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 4982 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv578)) : 'freshtv580)
    | MenhirState197 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv583 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 143 "parser.mly"
       (string)
# 4990 "parser.ml"
        ) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv581 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 143 "parser.mly"
       (string)
# 4996 "parser.ml"
        ) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_s00_, (s00 : (
# 143 "parser.mly"
       (string)
# 5001 "parser.ml"
        )), _startpos_s00_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_s0_ = _endpos_s00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let s0 = s00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_s_ = _endpos_s0_ in
            let _startpos__1_ = _startpos__10_ in
            let s = s0 in
            let _1 = _10 in
            let _endpos = _endpos_s_ in
            let _startpos = _startpos__1_ in
            
# 188 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdEcho s) loc )
# 5025 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5031 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5037 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv582)) : 'freshtv584)
    | MenhirState207 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv587 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv585 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_symb00_, _, (symb00 : 'tv_symbol), _startpos_symb00_), _startpos__300_), _, (symbs00 : 'tv_list_symbol_)), _endpos__500_), _endpos_so00_, _, (so00 : 'tv_sort)), _endpos__31_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _31 = () in
        let _500 = () in
        let _300 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_so0_ = _endpos_so00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _31 in
          let so0 = so00 in
          let _50 = _500 in
          let symbs0 = symbs00 in
          let _30 = _300 in
          let symb0 = symb00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_so_ = _endpos_so0_ in
            let _startpos__1_ = _startpos__10_ in
            let so = so0 in
            let _5 = _50 in
            let symbs = symbs0 in
            let _3 = _30 in
            let symb = symb0 in
            let _1 = _10 in
            let _endpos = _endpos_so_ in
            let _startpos = _startpos__1_ in
            
# 185 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdDefineSort (symb, symbs, so)) loc )
# 5078 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5084 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5090 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv586)) : 'freshtv588)
    | MenhirState230 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv591 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv589 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _startpos__200_), _, (frdefs00 : 'tv_nonempty_list_fun_rec_def_)), _endpos__400_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _400 = () in
        let _200 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__40_ = _endpos__400_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _40 = _400 in
          let frdefs0 = frdefs00 in
          let _20 = _200 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__4_ = _endpos__40_ in
            let _startpos__1_ = _startpos__10_ in
            let _4 = _40 in
            let frdefs = frdefs0 in
            let _2 = _20 in
            let _1 = _10 in
            let _endpos = _endpos__4_ in
            let _startpos = _startpos__1_ in
            
# 182 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_command (CmdDefineFunRec frdefs) loc )
# 5127 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5133 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5139 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv590)) : 'freshtv592)
    | MenhirState236 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv595 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_nonrec_def) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv593 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_nonrec_def) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_fdef00_, _, (fdef00 : 'tv_fun_nonrec_def)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_fdef0_ = _endpos_fdef00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let fdef0 = fdef00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_fdef_ = _endpos_fdef0_ in
            let _startpos__1_ = _startpos__10_ in
            let fdef = fdef0 in
            let _1 = _10 in
            let _endpos = _endpos_fdef_ in
            let _startpos = _startpos__1_ in
            
# 179 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_command (CmdDefineFun fdef) loc )
# 5170 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5176 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5182 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv594)) : 'freshtv596)
    | MenhirState242 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv599 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 5190 "parser.ml"
        ) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv597 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 5196 "parser.ml"
        ) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_symb00_, _, (symb00 : 'tv_symbol), _startpos_symb00_), _endpos_num00_, (num00 : (
# 139 "parser.mly"
       (Ast.numeral)
# 5201 "parser.ml"
        )), _startpos_num00_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_num0_ = _endpos_num00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let num0 = num00 in
          let symb0 = symb00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_num_ = _endpos_num0_ in
            let _startpos__1_ = _startpos__10_ in
            let num = num0 in
            let symb = symb0 in
            let _1 = _10 in
            let _endpos = _endpos_num_ in
            let _startpos = _startpos__1_ in
            
# 176 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdDeclareSort(symb, num)) loc )
# 5227 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5233 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5239 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv598)) : 'freshtv600)
    | MenhirState253 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((((('freshtv603 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((((('freshtv601 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((((((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_symb00_, _, (symb00 : 'tv_symbol), _startpos_symb00_), _, (polys00 : 'tv_option_poly_parameters_)), _startpos__400_), _, (sorts00 : 'tv_list_sort_)), _endpos__600_), _endpos_so00_, _, (so00 : 'tv_sort)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _600 = () in
        let _400 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_so0_ = _endpos_so00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let so0 = so00 in
          let _60 = _600 in
          let sorts0 = sorts00 in
          let _40 = _400 in
          let polys0 = polys00 in
          let symb0 = symb00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_so_ = _endpos_so0_ in
            let _startpos__1_ = _startpos__10_ in
            let so = so0 in
            let _6 = _60 in
            let sorts = sorts0 in
            let _4 = _40 in
            let polys = polys0 in
            let symb = symb0 in
            let _1 = _10 in
            let _endpos = _endpos_so_ in
            let _startpos = _startpos__1_ in
            
# 173 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdDeclareFun (symb, polys, sorts, so)) loc )
# 5282 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5288 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5294 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv602)) : 'freshtv604)
    | MenhirState258 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv607 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv605 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_symb00_, _, (symb00 : 'tv_symbol), _startpos_symb00_), _endpos_so00_, _, (so00 : 'tv_sort)), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_so0_ = _endpos_so00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let so0 = so00 in
          let symb0 = symb00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_so_ = _endpos_so0_ in
            let _startpos__1_ = _startpos__10_ in
            let so = so0 in
            let symb = symb0 in
            let _1 = _10 in
            let _endpos = _endpos_so_ in
            let _startpos = _startpos__1_ in
            
# 169 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_command (CmdDeclareConst(symb, so)) loc )
# 5327 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5333 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5339 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv606)) : 'freshtv608)
    | MenhirState261 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv611 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv609 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _startpos__11_), _endpos__100_, _startpos__100_), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos__10_ = _endpos__100_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos__1_ = _endpos__10_ in
            let _startpos__1_ = _startpos__10_ in
            let _1 = _10 in
            let _endpos = _endpos__1_ in
            let _startpos = _startpos__1_ in
            
# 167 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_command CmdCheckSat loc )
# 5367 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5373 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5379 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv610)) : 'freshtv612)
    | MenhirState265 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv615 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 5387 "parser.ml"
        )) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv613 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 5393 "parser.ml"
        )) * Lexing.position) * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((((_menhir_stack, _menhir_s, _startpos__11_), _startpos__100_), _endpos_t00_, _, (t00 : (
# 151 "parser.mly"
       (Ast.term)
# 5398 "parser.ml"
        ))), _endpos__30_), _, (xs : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_xs_) = _menhir_stack in
        let _30 = () in
        let _100 = () in
        let _11 = () in
        let _startpos = _startpos__11_ in
        let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = let x =
          let _endpos_t0_ = _endpos_t00_ in
          let _startpos__10_ = _startpos__100_ in
          let _3 = _30 in
          let t0 = t00 in
          let _10 = _100 in
          let _1 = _11 in
          let x =
            let _endpos_t_ = _endpos_t0_ in
            let _startpos__1_ = _startpos__10_ in
            let t = t0 in
            let _1 = _10 in
            let _endpos = _endpos_t_ in
            let _startpos = _startpos__1_ in
            
# 165 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_command (CmdAssert t) loc )
# 5421 "parser.ml"
            
          in
          
# 174 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x )
# 5427 "parser.ml"
          
        in
        
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5433 "parser.ml"
         in
        _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos) : 'freshtv614)) : 'freshtv616)
    | MenhirState125 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv629 * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | EOF ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv625 * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv623 * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos__2_ : Lexing.position) = _endpos in
            ((let (_menhir_stack, _menhir_s, (commands : 'tv_list_delimited_LPAREN_command_RPAREN__), _startpos_commands_) = _menhir_stack in
            let _2 = () in
            let _v : (
# 149 "parser.mly"
       (Ast.script)
# 5454 "parser.ml"
            ) = let _endpos = _endpos__2_ in
            let _startpos = _startpos_commands_ in
            
# 159 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_script commands loc )
# 5461 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv621) = _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : (
# 149 "parser.mly"
       (Ast.script)
# 5469 "parser.ml"
            )) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv619) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let (_v : (
# 149 "parser.mly"
       (Ast.script)
# 5477 "parser.ml"
            )) = _v in
            ((let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv617) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = _menhir_s in
            let ((_1 : (
# 149 "parser.mly"
       (Ast.script)
# 5485 "parser.ml"
            )) : (
# 149 "parser.mly"
       (Ast.script)
# 5489 "parser.ml"
            )) = _v in
            (Obj.magic _1 : 'freshtv618)) : 'freshtv620)) : 'freshtv622)) : 'freshtv624)) : 'freshtv626)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv627 * _menhir_state * 'tv_list_delimited_LPAREN_command_RPAREN__ * Lexing.position) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv628)) : 'freshtv630)
    | _ ->
        _menhir_fail ()

and _menhir_reduce73 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let (_, _endpos) = Obj.magic _menhir_stack in
    let _v : 'tv_option_NUMERAL_ = 
# 100 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( None )
# 5508 "parser.ml"
     in
    _menhir_goto_option_NUMERAL_ _menhir_env _menhir_stack _endpos _menhir_s _v

and _menhir_run147 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 139 "parser.mly"
       (Ast.numeral)
# 5515 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv507) = Obj.magic _menhir_stack in
    let (_endpos_x_ : Lexing.position) = _endpos in
    let (_menhir_s : _menhir_state) = _menhir_s in
    let ((x : (
# 139 "parser.mly"
       (Ast.numeral)
# 5526 "parser.ml"
    )) : (
# 139 "parser.mly"
       (Ast.numeral)
# 5530 "parser.ml"
    )) = _v in
    let (_startpos_x_ : Lexing.position) = _startpos in
    ((let _endpos = _endpos_x_ in
    let _v : 'tv_option_NUMERAL_ = 
# 102 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( Some x )
# 5537 "parser.ml"
     in
    _menhir_goto_option_NUMERAL_ _menhir_env _menhir_stack _endpos _menhir_s _v) : 'freshtv508)

and _menhir_run85 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 145 "parser.mly"
       (string)
# 5544 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_stack = (_menhir_stack, _endpos, _menhir_s, _v, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | BINARY _v ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | BOOL _v ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | DECIMAL _v ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | HEXADECIMAL _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | LPAREN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv503) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState85 in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | KEYWORD _v ->
            _menhir_run88 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run87 _menhir_env (Obj.magic _menhir_stack) MenhirState86 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState86 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce49 _menhir_env (Obj.magic _menhir_stack) MenhirState86
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState86) : 'freshtv504)
    | NUMERAL _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState85 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | KEYWORD _ | RPAREN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv505 * Lexing.position * _menhir_state * (
# 145 "parser.mly"
       (string)
# 5607 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _endpos_kwd_, _menhir_s, (kwd : (
# 145 "parser.mly"
       (string)
# 5612 "parser.ml"
        )), _startpos_kwd_) = _menhir_stack in
        let _startpos = _startpos_kwd_ in
        let _endpos = _endpos_kwd_ in
        let _v : 'tv_attribute = let _endpos = _endpos_kwd_ in
        let _startpos = _startpos_kwd_ in
        
# 399 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_attribute (AttrKeyword kwd) loc )
# 5622 "parser.ml"
         in
        _menhir_goto_attribute _menhir_env _menhir_stack _endpos _menhir_s _v _startpos) : 'freshtv506)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState85

and _menhir_run211 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState211 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState211 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState211

and _menhir_goto_list_sexpr_ : _menhir_env -> 'ttv_tail -> _menhir_state -> 'tv_list_sexpr_ -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv481 * _menhir_state * (
# 150 "parser.mly"
       (Ast.sexpr)
# 5654 "parser.ml"
        )) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv479 * _menhir_state * (
# 150 "parser.mly"
       (Ast.sexpr)
# 5660 "parser.ml"
        )) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, (x : (
# 150 "parser.mly"
       (Ast.sexpr)
# 5665 "parser.ml"
        ))), _, (xs : 'tv_list_sexpr_)) = _menhir_stack in
        let _v : 'tv_list_sexpr_ = 
# 187 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( x :: xs )
# 5670 "parser.ml"
         in
        _menhir_goto_list_sexpr_ _menhir_env _menhir_stack _menhir_s _v) : 'freshtv480)) : 'freshtv482)
    | MenhirState87 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv487 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv483 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            _menhir_reduce84 _menhir_env (Obj.magic _menhir_stack) _endpos) : 'freshtv484)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv485 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv486)) : 'freshtv488)
    | MenhirState86 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv495 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv491 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv489 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            let (_endpos__3_ : Lexing.position) = _endpos in
            ((let ((_menhir_stack, _menhir_s, _startpos__1_), _, (sexprs : 'tv_list_sexpr_)) = _menhir_stack in
            let _3 = () in
            let _1 = () in
            let _endpos = _endpos__3_ in
            let _v : 'tv_attribute_value = let _endpos = _endpos__3_ in
            let _startpos = _startpos__1_ in
            
# 378 "parser.mly"
 ( let loc = mk_loc _startpos _endpos in
   mk_attr_value (AttrValSexpr sexprs) loc )
# 5716 "parser.ml"
             in
            _menhir_goto_attribute_value _menhir_env _menhir_stack _endpos _menhir_s _v) : 'freshtv490)) : 'freshtv492)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv493 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv494)) : 'freshtv496)
    | MenhirState275 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv501 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv497 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            (_menhir_reduce84 _menhir_env (Obj.magic _menhir_stack) _endpos : 'freshtv498)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv499 * _menhir_state * Lexing.position) * _menhir_state * 'tv_list_sexpr_) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv500)) : 'freshtv502)
    | _ ->
        _menhir_fail ()

and _menhir_goto_sexpr : _menhir_env -> 'ttv_tail -> _menhir_state -> (
# 150 "parser.mly"
       (Ast.sexpr)
# 5750 "parser.ml"
) -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _v ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _v) in
    match _menhir_s with
    | MenhirState275 | MenhirState86 | MenhirState91 | MenhirState87 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv473 * _menhir_state * (
# 150 "parser.mly"
       (Ast.sexpr)
# 5760 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((assert (not _menhir_env._menhir_error);
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | KEYWORD _v ->
            _menhir_run88 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run87 _menhir_env (Obj.magic _menhir_stack) MenhirState91 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState91 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce49 _menhir_env (Obj.magic _menhir_stack) MenhirState91
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState91) : 'freshtv474)
    | MenhirState270 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv477 * _menhir_state * (
# 150 "parser.mly"
       (Ast.sexpr)
# 5796 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv475 * _menhir_state * (
# 150 "parser.mly"
       (Ast.sexpr)
# 5802 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, (_1 : (
# 150 "parser.mly"
       (Ast.sexpr)
# 5807 "parser.ml"
        ))) = _menhir_stack in
        Obj.magic _1) : 'freshtv476)) : 'freshtv478)
    | _ ->
        _menhir_fail ()

and _menhir_reduce92 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 143 "parser.mly"
       (string)
# 5816 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 143 "parser.mly"
       (string)
# 5821 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_spec_constant = 
# 365 "parser.mly"
          ( CstString _1 )
# 5828 "parser.ml"
     in
    _menhir_goto_spec_constant _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_reduce91 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 139 "parser.mly"
       (Ast.numeral)
# 5835 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 139 "parser.mly"
       (Ast.numeral)
# 5840 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_spec_constant = 
# 364 "parser.mly"
          ( CstNumeral _1 )
# 5847 "parser.ml"
     in
    _menhir_goto_spec_constant _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_run17 : _menhir_env -> 'ttv_tail * _menhir_state * Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LPAREN ->
        _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState17 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState17 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState17 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState17

and _menhir_reduce95 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 146 "parser.mly"
       (string)
# 5871 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 146 "parser.mly"
       (string)
# 5876 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_symbol = let _endpos = _endpos__1_ in
    let _startpos = _startpos__1_ in
    
# 300 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_symbol (SimpleSymbol _1) loc )
# 5885 "parser.ml"
     in
    _menhir_goto_symbol _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_reduce96 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 147 "parser.mly"
       (string)
# 5892 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 147 "parser.mly"
       (string)
# 5897 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_symbol = let _endpos = _endpos__1_ in
    let _startpos = _startpos__1_ in
    
# 302 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in mk_symbol (QuotedSymbol _1) loc )
# 5906 "parser.ml"
     in
    _menhir_goto_symbol _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_run8 : _menhir_env -> 'ttv_tail * _menhir_state * Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _menhir_stack = (_menhir_stack, _menhir_s) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState8 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState8 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState8

and _menhir_reduce94 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 141 "parser.mly"
       (string)
# 5928 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 141 "parser.mly"
       (string)
# 5933 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_spec_constant = 
# 367 "parser.mly"
              ( CstHexadecimal _1 )
# 5940 "parser.ml"
     in
    _menhir_goto_spec_constant _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_reduce90 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 140 "parser.mly"
       (string)
# 5947 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 140 "parser.mly"
       (string)
# 5952 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_spec_constant = 
# 363 "parser.mly"
          ( CstDecimal _1 )
# 5959 "parser.ml"
     in
    _menhir_goto_spec_constant _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_reduce93 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 144 "parser.mly"
       (bool)
# 5966 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 144 "parser.mly"
       (bool)
# 5971 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_spec_constant = 
# 366 "parser.mly"
          ( CstBool _1 )
# 5978 "parser.ml"
     in
    _menhir_goto_spec_constant _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_reduce89 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 142 "parser.mly"
       (string)
# 5985 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos__1_ _menhir_s (_1 : (
# 142 "parser.mly"
       (string)
# 5990 "parser.ml"
  )) _startpos__1_ ->
    let _startpos = _startpos__1_ in
    let _endpos = _endpos__1_ in
    let _v : 'tv_spec_constant = 
# 362 "parser.mly"
          ( CstBinary _1 )
# 5997 "parser.ml"
     in
    _menhir_goto_spec_constant _menhir_env _menhir_stack _endpos _menhir_s _v _startpos

and _menhir_run121 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s ->
    let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv471) = Obj.magic _menhir_stack in
    let (_endpos__1_ : Lexing.position) = _endpos in
    let (_menhir_s : _menhir_state) = _menhir_s in
    ((let _1 = () in
    let _v : (
# 152 "parser.mly"
       (Ast.term list)
# 6011 "parser.ml"
    ) = 
# 420 "parser.mly"
         ( [] )
# 6015 "parser.ml"
     in
    _menhir_goto_list_term _menhir_env _menhir_stack _menhir_s _v) : 'freshtv472)

and _menhir_reduce21 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let (_, _startpos) = Obj.magic _menhir_stack in
    let _v : 'tv_list_delimited_LPAREN_command_RPAREN__ = 
# 185 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [] )
# 6025 "parser.ml"
     in
    _menhir_goto_list_delimited_LPAREN_command_RPAREN__ _menhir_env _menhir_stack _menhir_s _v _startpos

and _menhir_run126 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | ASSERT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv337 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState263 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState263 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState263) : 'freshtv338)
    | CHECKSAT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv343 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv339 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState261 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState261
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState261) : 'freshtv340)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv341 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv342)) : 'freshtv344)
    | DECLARECONST ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv345 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState255 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState255 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState255) : 'freshtv346)
    | DECLAREFUN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv347 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState244 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState244 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState244) : 'freshtv348)
    | DECLARESORT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv349 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState239 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState239 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState239) : 'freshtv350)
    | DEFINEFUN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv351 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState234 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState234 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState234) : 'freshtv352)
    | DEFINEFUNREC ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv357 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv353 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run211 _menhir_env (Obj.magic _menhir_stack) MenhirState210 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState210) : 'freshtv354)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv355 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv356)) : 'freshtv358)
    | DEFINESORT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv359 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState199 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState199 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState199) : 'freshtv360)
    | ECHO ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv369 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | STRING _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv365 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            let (_v : (
# 143 "parser.mly"
       (string)
# 6221 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _endpos, _v, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv361 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 143 "parser.mly"
       (string)
# 6233 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState197 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState197
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState197) : 'freshtv362)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv363 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 143 "parser.mly"
       (string)
# 6255 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                ((let (((_menhir_stack, _menhir_s, _), _), _, _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv364)) : 'freshtv366)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv367 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv368)) : 'freshtv370)
    | EXIT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv375 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv371 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState193 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState193
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState193) : 'freshtv372)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv373 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv374)) : 'freshtv376)
    | GETASSERTIONS ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv381 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv377 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState190 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState190
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState190) : 'freshtv378)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv379 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv380)) : 'freshtv382)
    | GETASSIGNMENT ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv387 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv383 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState187 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState187
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState187) : 'freshtv384)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv385 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv386)) : 'freshtv388)
    | GETINFO ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv403 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv399) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            let (_v : (
# 145 "parser.mly"
       (string)
# 6377 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv397) = Obj.magic _menhir_stack in
            let (_endpos_kwd_ : Lexing.position) = _endpos in
            let ((kwd : (
# 145 "parser.mly"
       (string)
# 6387 "parser.ml"
            )) : (
# 145 "parser.mly"
       (string)
# 6391 "parser.ml"
            )) = _v in
            let (_startpos_kwd_ : Lexing.position) = _startpos in
            ((let _endpos = _endpos_kwd_ in
            let _v : 'tv_info_flag = let _endpos = _endpos_kwd_ in
            let _startpos = _startpos_kwd_ in
            
# 414 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_info_flag (InfoFlagKeyword kwd) loc )
# 6401 "parser.ml"
             in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv395) = _menhir_stack in
            let (_endpos : Lexing.position) = _endpos in
            let (_v : 'tv_info_flag) = _v in
            ((let _menhir_stack = (_menhir_stack, _endpos, _v) in
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : (('freshtv393 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * 'tv_info_flag) = Obj.magic _menhir_stack in
            ((assert (not _menhir_env._menhir_error);
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv389 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * 'tv_info_flag) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState184 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState184
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState184) : 'freshtv390)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv391 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * 'tv_info_flag) = Obj.magic _menhir_stack in
                ((let (((_menhir_stack, _menhir_s, _), _), _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv392)) : 'freshtv394)) : 'freshtv396)) : 'freshtv398)) : 'freshtv400)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv401 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv402)) : 'freshtv404)
    | GETMODEL ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv409 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv405 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState179 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState179
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState179) : 'freshtv406)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv407 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv408)) : 'freshtv410)
    | GETOPTION ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv419 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv415 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            let (_v : (
# 145 "parser.mly"
       (string)
# 6490 "parser.ml"
            )) = _v in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _endpos, _v, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | RPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv411 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 145 "parser.mly"
       (string)
# 6502 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
                ((let _menhir_stack = (_menhir_stack, _endpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState176 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | EOF ->
                    _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState176
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState176) : 'freshtv412)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : (('freshtv413 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 145 "parser.mly"
       (string)
# 6524 "parser.ml"
                ) * Lexing.position) = Obj.magic _menhir_stack in
                ((let (((_menhir_stack, _menhir_s, _), _), _, _, _) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv414)) : 'freshtv416)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv417 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv418)) : 'freshtv420)
    | GETPROOF ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv425 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv421 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState172 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState172
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState172) : 'freshtv422)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv423 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv424)) : 'freshtv426)
    | GETUNSATASSUMPTIONS ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv431 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv427 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState169 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState169
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState169) : 'freshtv428)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv429 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv430)) : 'freshtv432)
    | GETUNSATCORE ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv437 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv433 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState166 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState166
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState166) : 'freshtv434)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv435 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv436)) : 'freshtv438)
    | GETVALUE ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv443 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv439 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState160 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState160 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState160) : 'freshtv440)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv441 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv442)) : 'freshtv444)
    | METAINFO ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv445 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState155 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState155) : 'freshtv446)
    | POP ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv447 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | NUMERAL _v ->
            _menhir_run147 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState151 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce73 _menhir_env (Obj.magic _menhir_stack) MenhirState151
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState151) : 'freshtv448)
    | PUSH ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv449 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | NUMERAL _v ->
            _menhir_run147 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState146 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce73 _menhir_env (Obj.magic _menhir_stack) MenhirState146
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState146) : 'freshtv450)
    | RESET ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv455 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv451 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState144 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState144
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState144) : 'freshtv452)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv453 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv454)) : 'freshtv456)
    | RESETASSERTIONS ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv461 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | RPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv457 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
            ((let _menhir_stack = (_menhir_stack, _endpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState141 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | EOF ->
                _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState141
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState141) : 'freshtv458)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv459 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
            ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv460)) : 'freshtv462)
    | SETINFO ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv463 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState136 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState136) : 'freshtv464)
    | SETLOGIC ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv465 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState132 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState132 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState132) : 'freshtv466)
    | SETOPTION ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv467 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | KEYWORD _v ->
            _menhir_run85 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState127 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState127) : 'freshtv468)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv469 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv470)

and _menhir_reduce49 : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    let _v : 'tv_list_sexpr_ = 
# 185 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
    ( [] )
# 6845 "parser.ml"
     in
    _menhir_goto_list_sexpr_ _menhir_env _menhir_stack _menhir_s _v

and _menhir_run87 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | BINARY _v ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | BOOL _v ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | DECIMAL _v ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | HEXADECIMAL _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | KEYWORD _v ->
        _menhir_run88 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | LPAREN ->
        _menhir_run87 _menhir_env (Obj.magic _menhir_stack) MenhirState87 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | NUMERAL _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState87 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | RPAREN ->
        _menhir_reduce49 _menhir_env (Obj.magic _menhir_stack) MenhirState87
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState87

and _menhir_run88 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 145 "parser.mly"
       (string)
# 6885 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce83 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_reduce83 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 145 "parser.mly"
       (string)
# 6894 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos_kwd_ _menhir_s (kwd : (
# 145 "parser.mly"
       (string)
# 6899 "parser.ml"
  )) _startpos_kwd_ ->
    let _v : (
# 150 "parser.mly"
       (Ast.sexpr)
# 6904 "parser.ml"
    ) = let _endpos = _endpos_kwd_ in
    let _startpos = _startpos_kwd_ in
    
# 390 "parser.mly"
  ( let loc = mk_loc _startpos _endpos in
    mk_sexpr (SexprKeyword kwd) loc )
# 6911 "parser.ml"
     in
    _menhir_goto_sexpr _menhir_env _menhir_stack _menhir_s _v

and _menhir_run271 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 146 "parser.mly"
       (string)
# 6918 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce95 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run272 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 143 "parser.mly"
       (string)
# 6926 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run273 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 147 "parser.mly"
       (string)
# 6934 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce96 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run274 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 139 "parser.mly"
       (Ast.numeral)
# 6942 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run16 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AS ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState16
    | UNDERSCORE ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState16
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState16

and _menhir_run32 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState32 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState32 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState32

and _menhir_run51 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState51 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState51 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState51

and _menhir_run4 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 143 "parser.mly"
       (string)
# 6995 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce92 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run6 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 139 "parser.mly"
       (Ast.numeral)
# 7004 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce91 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run7 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | AS ->
        _menhir_run17 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | BANG ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv305 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState7 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState83 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState83 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState83) : 'freshtv306)
    | CHOICE ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv311 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState7 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv307 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState78 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState78) : 'freshtv308)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv309 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv310)) : 'freshtv312)
    | EPSILON ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv317 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState7 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv313 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState68 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState68) : 'freshtv314)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv315 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv316)) : 'freshtv318)
    | EXISTS ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv323 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState7 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv319 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState62 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState62) : 'freshtv320)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv321 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv322)) : 'freshtv324)
    | FORALL ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv329 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState7 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv325 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState50 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState50) : 'freshtv326)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv327 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv328)) : 'freshtv330)
    | LET ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv335 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState7 in
        ((let _menhir_stack = (_menhir_stack, _menhir_s) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | LPAREN ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv331 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
            ((let _menhir_stack = (_menhir_stack, _startpos) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState31 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState31) : 'freshtv332)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : ('freshtv333 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
            ((let (_menhir_stack, _menhir_s) = _menhir_stack in
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv334)) : 'freshtv336)
    | LPAREN ->
        _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState7 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState7 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState7 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | UNDERSCORE ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState7
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState7

and _menhir_run34 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 141 "parser.mly"
       (string)
# 7209 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce94 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run35 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 140 "parser.mly"
       (string)
# 7218 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce90 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run36 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 144 "parser.mly"
       (bool)
# 7227 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce93 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run37 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 142 "parser.mly"
       (string)
# 7236 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce89 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_errorcase : _menhir_env -> 'ttv_tail -> _menhir_state -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s ->
    match _menhir_s with
    | MenhirState334 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv61 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv62)
    | MenhirState331 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv63 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv64)
    | MenhirState330 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv65 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv66)
    | MenhirState327 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv67 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7265 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv68)
    | MenhirState326 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv69 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv70)
    | MenhirState323 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv71 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv72)
    | MenhirState321 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv73 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv74)
    | MenhirState316 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv75 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 7289 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _), _), _), _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv76)
    | MenhirState311 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv77 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv78)
    | MenhirState307 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv79 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv80)
    | MenhirState305 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv81 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv82)
    | MenhirState301 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv83 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv84)
    | MenhirState299 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv85 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv86)
    | MenhirState295 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv87 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv88)
    | MenhirState293 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv89 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv90)
    | MenhirState289 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv91 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv92)
    | MenhirState288 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv93 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv94)
    | MenhirState287 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv95 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv96)
    | MenhirState286 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv97) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv98)
    | MenhirState275 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv99 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv100)
    | MenhirState270 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv101) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv102)
    | MenhirState265 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv103 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7361 "parser.ml"
        )) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv104)
    | MenhirState263 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv105 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv106)
    | MenhirState261 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv107 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv108)
    | MenhirState258 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv109 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv110)
    | MenhirState256 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv111 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv112)
    | MenhirState255 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv113 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv114)
    | MenhirState253 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((((('freshtv115 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv116)
    | MenhirState251 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((((('freshtv117 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sort_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv118)
    | MenhirState248 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv119 * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv120)
    | MenhirState247 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv121 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv122)
    | MenhirState245 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv123 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv124)
    | MenhirState244 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv125 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv126)
    | MenhirState242 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv127 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 7425 "parser.ml"
        ) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _, _menhir_s, _, _), _, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv128)
    | MenhirState239 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv129 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv130)
    | MenhirState236 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv131 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_fun_nonrec_def) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv132)
    | MenhirState234 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv133 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv134)
    | MenhirState232 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv135 * _menhir_state * 'tv_fun_rec_def) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv136)
    | MenhirState230 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv137 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_fun_rec_def_) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv138)
    | MenhirState224 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv139 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv140)
    | MenhirState223 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv141 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) * _menhir_state * 'tv_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv142)
    | MenhirState220 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv143 * _menhir_state * 'tv_sorted_var) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv144)
    | MenhirState219 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv145 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * _menhir_state * 'tv_option_poly_parameters_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv146)
    | MenhirState214 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv147 * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv148)
    | MenhirState212 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv149 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv150)
    | MenhirState211 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv151 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv152)
    | MenhirState210 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv153 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv154)
    | MenhirState207 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv155 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) * Lexing.position * _menhir_state * 'tv_sort) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv156)
    | MenhirState205 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv157 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) * _menhir_state * 'tv_list_symbol_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv158)
    | MenhirState202 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv159 * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv160)
    | MenhirState201 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv161 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv162)
    | MenhirState199 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv163 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv164)
    | MenhirState197 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv165 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 143 "parser.mly"
       (string)
# 7524 "parser.ml"
        ) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _), _), _, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv166)
    | MenhirState193 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv167 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv168)
    | MenhirState190 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv169 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv170)
    | MenhirState187 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv171 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv172)
    | MenhirState184 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv173 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * 'tv_info_flag) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _), _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv174)
    | MenhirState179 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv175 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv176)
    | MenhirState176 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv177 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * (
# 145 "parser.mly"
       (string)
# 7558 "parser.ml"
        ) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _), _), _, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv178)
    | MenhirState172 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv179 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv180)
    | MenhirState169 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv181 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv182)
    | MenhirState166 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv183 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv184)
    | MenhirState163 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((('freshtv185 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) * _menhir_state * 'tv_nonempty_list_term_) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv186)
    | MenhirState160 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv187 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv188)
    | MenhirState157 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv189 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv190)
    | MenhirState155 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv191 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv192)
    | MenhirState153 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv193 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv194)
    | MenhirState151 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv195 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv196)
    | MenhirState149 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv197 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position * _menhir_state * 'tv_option_NUMERAL_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv198)
    | MenhirState146 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv199 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv200)
    | MenhirState144 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv201 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv202)
    | MenhirState141 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv203 * _menhir_state * Lexing.position) * Lexing.position * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (((_menhir_stack, _menhir_s, _), _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv204)
    | MenhirState138 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv205 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv206)
    | MenhirState136 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv207 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv208)
    | MenhirState134 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv209 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv210)
    | MenhirState132 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv211 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv212)
    | MenhirState129 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv213 * _menhir_state * Lexing.position) * Lexing.position) * Lexing.position * _menhir_state * 'tv_smt_option) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv214)
    | MenhirState127 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv215 * _menhir_state * Lexing.position) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv216)
    | MenhirState125 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv217) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv218)
    | MenhirState122 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv219 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7666 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv220)
    | MenhirState120 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv221) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv222)
    | MenhirState115 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv223 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7679 "parser.ml"
        )) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv224)
    | MenhirState113 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv225 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position)) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv226)
    | MenhirState111 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv227 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv228)
    | MenhirState110 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((('freshtv229 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 7698 "parser.ml"
        ) * Lexing.position)) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7702 "parser.ml"
        ))) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv230)
    | MenhirState105 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv231 * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7711 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv232)
    | MenhirState104 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv233 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_qual_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv234)
    | MenhirState102 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv235 * Lexing.position * _menhir_state * 'tv_attribute * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv236)
    | MenhirState91 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv237 * _menhir_state * (
# 150 "parser.mly"
       (Ast.sexpr)
# 7730 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv238)
    | MenhirState87 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv239 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv240)
    | MenhirState86 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv241 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv242)
    | MenhirState85 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv243 * Lexing.position * _menhir_state * (
# 145 "parser.mly"
       (string)
# 7749 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv244)
    | MenhirState84 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv245 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * (
# 151 "parser.mly"
       (Ast.term)
# 7758 "parser.ml"
        )) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv246)
    | MenhirState83 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv247 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv248)
    | MenhirState80 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv249 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv250)
    | MenhirState78 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv251 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv252)
    | MenhirState73 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ((((((('freshtv253 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) * Lexing.position)) * Lexing.position * (
# 146 "parser.mly"
       (string)
# 7782 "parser.ml"
        ) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((((_menhir_stack, _menhir_s, _), _), _), _, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv254)
    | MenhirState68 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv255 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv256)
    | MenhirState64 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv257 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv258)
    | MenhirState62 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv259 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv260)
    | MenhirState58 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv261 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_sorted_var_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv262)
    | MenhirState55 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv263 * _menhir_state * 'tv_sorted_var) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv264)
    | MenhirState52 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv265 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv266)
    | MenhirState51 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv267 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv268)
    | MenhirState50 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv269 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv270)
    | MenhirState46 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (((('freshtv271 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) * _menhir_state * 'tv_nonempty_list_var_binding_) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s, _), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv272)
    | MenhirState43 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv273 * _menhir_state * 'tv_var_binding) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv274)
    | MenhirState33 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv275 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv276)
    | MenhirState32 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv277 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv278)
    | MenhirState31 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv279 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position) = Obj.magic _menhir_stack in
        ((let ((_menhir_stack, _menhir_s), _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv280)
    | MenhirState23 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv281 * Lexing.position * _menhir_state * 'tv_sort) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv282)
    | MenhirState22 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv283 * _menhir_state * Lexing.position) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv284)
    | MenhirState21 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv285 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv286)
    | MenhirState20 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv287 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_identifier * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv288)
    | MenhirState18 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv289 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv290)
    | MenhirState17 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv291 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv292)
    | MenhirState16 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv293 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv294)
    | MenhirState14 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv295 * _menhir_state * 'tv_index) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv296)
    | MenhirState9 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : (('freshtv297 * _menhir_state * Lexing.position) * _menhir_state) * Lexing.position * _menhir_state * 'tv_symbol * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _, _menhir_s, _, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv298)
    | MenhirState8 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv299 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv300)
    | MenhirState7 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv301 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
        ((let (_menhir_stack, _menhir_s, _) = _menhir_stack in
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv302)
    | MenhirState2 ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : ('freshtv303 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 7911 "parser.ml"
        ) * Lexing.position)) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv304)

and _menhir_run3 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 146 "parser.mly"
       (string)
# 7918 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce95 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run5 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 147 "parser.mly"
       (string)
# 7927 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    let _menhir_env = _menhir_discard _menhir_env in
    _menhir_reduce96 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run18 : _menhir_env -> 'ttv_tail -> _menhir_state -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _menhir_s _startpos ->
    let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
    let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | UNDERSCORE ->
        _menhir_run8 _menhir_env (Obj.magic _menhir_stack) MenhirState18
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState18

and _menhir_run279 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 141 "parser.mly"
       (string)
# 7949 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce94 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run280 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 140 "parser.mly"
       (string)
# 7957 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce90 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run281 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 144 "parser.mly"
       (bool)
# 7965 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce93 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_run282 : _menhir_env -> 'ttv_tail -> Lexing.position -> _menhir_state -> (
# 142 "parser.mly"
       (string)
# 7973 "parser.ml"
) -> Lexing.position -> 'ttv_return =
  fun _menhir_env _menhir_stack _endpos _menhir_s _v _startpos ->
    _menhir_reduce89 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos

and _menhir_discard : _menhir_env -> _menhir_env =
  fun _menhir_env ->
    let lexer = _menhir_env._menhir_lexer in
    let lexbuf = _menhir_env._menhir_lexbuf in
    let _tok = lexer lexbuf in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and _menhir_init : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> _menhir_env =
  fun lexer lexbuf ->
    let _tok = Obj.magic () in
    {
      _menhir_lexer = lexer;
      _menhir_lexbuf = lexbuf;
      _menhir_token = _tok;
      _menhir_error = false;
    }

and instance : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 153 "parser.mly"
       ((string * Ast.term * (Ast.symbol * Ast.term) list))
# 8003 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = _menhir_init lexer lexbuf in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv59) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | NUMERAL _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv55) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_v : (
# 139 "parser.mly"
       (Ast.numeral)
# 8019 "parser.ml"
        )) = _v in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _endpos, _v, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | SEMICOLON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv51 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 8031 "parser.ml"
            ) * Lexing.position) = Obj.magic _menhir_stack in
            ((let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState2 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState2 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState2) : 'freshtv52)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv53 * Lexing.position * (
# 139 "parser.mly"
       (Ast.numeral)
# 8065 "parser.ml"
            ) * Lexing.position) = Obj.magic _menhir_stack in
            (raise _eRR : 'freshtv54)) : 'freshtv56)
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv57) = Obj.magic _menhir_stack in
        (raise _eRR : 'freshtv58)) : 'freshtv60))

and list_term : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 152 "parser.mly"
       (Ast.term list)
# 8078 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = _menhir_init lexer lexbuf in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv49) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | BINARY _v ->
        _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | BOOL _v ->
        _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | DECIMAL _v ->
        _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | EOF ->
        _menhir_run121 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120
    | HEXADECIMAL _v ->
        _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | LPAREN ->
        _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState120 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | NUMERAL _v ->
        _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | STRING _v ->
        _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState120 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState120) : 'freshtv50))

and script : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 149 "parser.mly"
       (Ast.script)
# 8115 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = _menhir_init lexer lexbuf in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv47) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | LPAREN ->
        _menhir_run126 _menhir_env (Obj.magic _menhir_stack) MenhirState125 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | EOF ->
        _menhir_reduce21 _menhir_env (Obj.magic _menhir_stack) MenhirState125
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState125) : 'freshtv48))

and sexpr : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 150 "parser.mly"
       (Ast.sexpr)
# 8136 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = _menhir_init lexer lexbuf in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv45) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | BINARY _v ->
        _menhir_run282 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | BOOL _v ->
        _menhir_run281 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | DECIMAL _v ->
        _menhir_run280 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | HEXADECIMAL _v ->
        _menhir_run279 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | KEYWORD _v ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv41) = Obj.magic _menhir_stack in
        let (_endpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_curr_p in
        let (_menhir_s : _menhir_state) = MenhirState270 in
        let (_v : (
# 145 "parser.mly"
       (string)
# 8161 "parser.ml"
        )) = _v in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        (_menhir_reduce83 _menhir_env (Obj.magic _menhir_stack) _endpos _menhir_s _v _startpos : 'freshtv42)
    | LPAREN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv43) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState270 in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | BINARY _v ->
            _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | BOOL _v ->
            _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | DECIMAL _v ->
            _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | HEXADECIMAL _v ->
            _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | KEYWORD _v ->
            _menhir_run88 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | LPAREN ->
            _menhir_run87 _menhir_env (Obj.magic _menhir_stack) MenhirState275 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | NUMERAL _v ->
            _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | STRING _v ->
            _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState275 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | RPAREN ->
            _menhir_reduce49 _menhir_env (Obj.magic _menhir_stack) MenhirState275
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState275) : 'freshtv44)
    | NUMERAL _v ->
        _menhir_run274 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run273 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | STRING _v ->
        _menhir_run272 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run271 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState270 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState270) : 'freshtv46))

and term : (Lexing.lexbuf -> token) -> Lexing.lexbuf -> (
# 151 "parser.mly"
       (Ast.term)
# 8216 "parser.ml"
) =
  fun lexer lexbuf ->
    let _menhir_env = _menhir_init lexer lexbuf in
    Obj.magic (let (_menhir_env : _menhir_env) = _menhir_env in
    let (_menhir_stack : 'freshtv39) = ((), _menhir_env._menhir_lexbuf.Lexing.lex_curr_p) in
    ((let _menhir_env = _menhir_discard _menhir_env in
    let _tok = _menhir_env._menhir_token in
    match _tok with
    | BINARY _v ->
        _menhir_run282 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | BOOL _v ->
        _menhir_run281 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | DECIMAL _v ->
        _menhir_run280 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | HEXADECIMAL _v ->
        _menhir_run279 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | LPAREN ->
        let (_menhir_env : _menhir_env) = _menhir_env in
        let (_menhir_stack : 'freshtv37) = Obj.magic _menhir_stack in
        let (_menhir_s : _menhir_state) = MenhirState286 in
        let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
        ((let _menhir_stack = (_menhir_stack, _menhir_s, _startpos) in
        let _menhir_env = _menhir_discard _menhir_env in
        let _tok = _menhir_env._menhir_token in
        match _tok with
        | AS ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv1 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                _menhir_run18 _menhir_env (Obj.magic _menhir_stack) MenhirState330 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState330 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState330 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState330) : 'freshtv2)
        | BANG ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv3 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | BINARY _v ->
                _menhir_run37 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | BOOL _v ->
                _menhir_run36 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | DECIMAL _v ->
                _menhir_run35 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | HEXADECIMAL _v ->
                _menhir_run34 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | LPAREN ->
                _menhir_run7 _menhir_env (Obj.magic _menhir_stack) MenhirState326 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | NUMERAL _v ->
                _menhir_run6 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | STRING _v ->
                _menhir_run4 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState326 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState326) : 'freshtv4)
        | CHOICE ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv9 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv5 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState321 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState321) : 'freshtv6)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv7 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv8)) : 'freshtv10)
        | EPSILON ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv15 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv11 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState311 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState311) : 'freshtv12)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv13 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv14)) : 'freshtv16)
        | EXISTS ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv21 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv17 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState305 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState305) : 'freshtv18)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv19 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv20)) : 'freshtv22)
        | FORALL ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv27 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv23 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run51 _menhir_env (Obj.magic _menhir_stack) MenhirState299 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState299) : 'freshtv24)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv25 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv26)) : 'freshtv28)
        | LET ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv33 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | LPAREN ->
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv29 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                let (_startpos : Lexing.position) = _menhir_env._menhir_lexbuf.Lexing.lex_start_p in
                ((let _menhir_stack = (_menhir_stack, _startpos) in
                let _menhir_env = _menhir_discard _menhir_env in
                let _tok = _menhir_env._menhir_token in
                match _tok with
                | LPAREN ->
                    _menhir_run32 _menhir_env (Obj.magic _menhir_stack) MenhirState293 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
                | _ ->
                    assert (not _menhir_env._menhir_error);
                    _menhir_env._menhir_error <- true;
                    _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState293) : 'freshtv30)
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                let (_menhir_env : _menhir_env) = _menhir_env in
                let (_menhir_stack : ('freshtv31 * _menhir_state * Lexing.position) * _menhir_state) = Obj.magic _menhir_stack in
                ((let (_menhir_stack, _menhir_s) = _menhir_stack in
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) _menhir_s) : 'freshtv32)) : 'freshtv34)
        | LPAREN ->
            _menhir_run16 _menhir_env (Obj.magic _menhir_stack) MenhirState287 _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | QUOTEDSYMBOL _v ->
            _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState287 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | SYMBOL _v ->
            _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState287 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
        | UNDERSCORE ->
            let (_menhir_env : _menhir_env) = _menhir_env in
            let (_menhir_stack : 'freshtv35 * _menhir_state * Lexing.position) = Obj.magic _menhir_stack in
            let (_menhir_s : _menhir_state) = MenhirState287 in
            ((let _menhir_stack = (_menhir_stack, _menhir_s) in
            let _menhir_env = _menhir_discard _menhir_env in
            let _tok = _menhir_env._menhir_token in
            match _tok with
            | QUOTEDSYMBOL _v ->
                _menhir_run5 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState288 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | SYMBOL _v ->
                _menhir_run3 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState288 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
            | _ ->
                assert (not _menhir_env._menhir_error);
                _menhir_env._menhir_error <- true;
                _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState288) : 'freshtv36)
        | _ ->
            assert (not _menhir_env._menhir_error);
            _menhir_env._menhir_error <- true;
            _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState287) : 'freshtv38)
    | NUMERAL _v ->
        _menhir_run274 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | QUOTEDSYMBOL _v ->
        _menhir_run273 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | STRING _v ->
        _menhir_run272 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | SYMBOL _v ->
        _menhir_run271 _menhir_env (Obj.magic _menhir_stack) _menhir_env._menhir_lexbuf.Lexing.lex_curr_p MenhirState286 _v _menhir_env._menhir_lexbuf.Lexing.lex_start_p
    | _ ->
        assert (not _menhir_env._menhir_error);
        _menhir_env._menhir_error <- true;
        _menhir_errorcase _menhir_env (Obj.magic _menhir_stack) MenhirState286) : 'freshtv40))

# 219 "/home/delour/.opam/4.02.3/lib/menhir/standard.mly"
  


# 8478 "parser.ml"
