#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <math.h>
#include "DAG-print.h"
#include "DAG.h"
#include "DAG-stat.h"
#include "veriT-state.h"
#include "output-infos.h"
#include "congruence.h"
#include "free-vars.h"
#include "unify.h"
#include <libgen.h>
#include <sys/types.h>
#include <sys/stat.h>

/* #define GRID_L */
/* #define NO_LEARN */

char *resname = NULL;
unsigned roundi = 0;
unsigned timer_predictor;
Tstack_instance_round delay_round_unifier;
Tstack_instance_round conflicting_instances;
Tstack_instance_round delay_analyse_round_unifier;
Tstack_DAG features_record;
Tstack_instance_round delay_tmp_unifier;
extern Tstack_instance_round round_unifier;
FILE * file_features = NULL;
char *direname = NULL;
char file_extract[512];
char file_results[512];



extern bool option_extract_features;
extern bool option_show_learning_stats;
extern bool option_learn_extract_features;
extern bool option_learning_instances;
extern bool option_learning_native;
extern bool option_dumper_data;
extern bool proof_on;

void replaceAll(char * str, char oldChar, char newChar)
{
  int i = 0;
  /* Run till end of string */
  while(str[i] != '\0')
    {
      if(str[i] == oldChar)
        str[i] = newChar;
      i++;
    }
}

void
veriT_init_file(char * file)
{
  if (!file) return;
  if (option_learning_native && !option_learn_extract_features)
    {
      init_fea();
      return;
    }
  char res[512];
  replaceAll(file, '/', '+');
#ifndef EXPER
  char tmp[] =  "dumpedXXXXXX";
  int fd = mkstemp(tmp);
  close(fd);
  remove(tmp);
#endif
  struct stat st = {0};
#ifdef GRID_L
  sprintf(res, "/home/delouraoui/dumped-data/%s",  file);
  direname = strmake(res);
  if (stat("/home/delouraoui/dumped-data", &st) == -1)
    mkdir("/home/delouraoui/dumped-data", 0777);
  if (stat(direname, &st) == -1)
    mkdir(direname, 0700);
  if (!option_learning_instances)
    proof_on = true;
#else
  if (stat("/home/delour/verit/veriT/dumped-data", &st) == -1)
    mkdir("/home/delour/verit/veriT/dumped-data", 0777);
  sprintf(res, "/home/delour/verit/veriT/dumped-data/%s", file);
#endif
  direname = strmake(res);
  if (stat(direname, &st) == -1)
    mkdir(direname, 0700);
  if (!option_learning_instances)
    proof_on = true;
  if (option_extract_features || option_learn_extract_features)
    {
      init_fea();
      sprintf(file_extract, "%s/features", direname);
      sprintf(file_results, "%s/results", direname);
      file_features = fopen(file_extract, "w");
    }
}


/*
  --------------------------------------------------------------
  MACHINE LEARNING PART
  --------------------------------------------------------------
*/

char file_extract[512];
char file_results[512];
long long nb_instances = 0;
long long nb_instances_conflict = 0;
long long nb_instances_gen = 0;
unsigned nb_edges = 0;
unsigned nb_nodes = 0;

typedef struct instance
{
  float rate;
  TDAG DAG;
  unsigned round;
} instance;

TSstack(_instances, instance);
TSstack(_float, float);

Tstack_instances used_instances_total;

instance inst_null = {0.0, DAG_NULL};
float born = 0.40;

extern Tstack_DAG DAG_FORMULA;

static int
compare(instance *a, instance *b)
{
  if (a->rate > b->rate)
    return 1;
  else if (a->rate < b->rate)
    return -1;
  return 0;
}
static float
compute_average(Tstack_instances stack);

void
stat_learn_instances_print()
{
  float avg_useful, avg_used;
  unsigned i, j, nb_to_bad = 0/* , nb_useful = 0 */;
  Tstack_instances remember;
  FILE *file_used, *file_useful, *file_size;
  char filename_used[256];
  char filename_useful[256];
  char filename_size[256];
  stack_INIT(remember);
  sprintf(filename_used, "%s/stats-used.smt2", direname);
  sprintf(filename_useful, "%s/stats-useful.smt2", direname);
  sprintf(filename_size, "%s/size.smt2", direname);
  file_useful = fopen(filename_useful, "w");
  for (i = 0; i < stack_size(DAG_FORMULA); i++)
    {
      for (j = 0; j < stack_size(used_instances_total); j++)
        {
          if (stack_get(used_instances_total, j).DAG == stack_get(DAG_FORMULA, i))
            {
              stack_push(remember, stack_get(used_instances_total, j));
              break;
            }
        }
    }
  stack_sort(remember, compare);
  avg_useful = compute_average(remember);
  /* nb_useful = stack_size(remember); */
   for (i = 0; i < stack_size(DAG_FORMULA); i++)
     fprintf(file_useful, "%d,\n", stack_get(DAG_FORMULA, i));
  while(!stack_is_empty(remember) && stack_top(remember).rate >= 0.1)
    {
      /* fprintf(file_useful, "%f, %d, %d\n", */
      /*         stack_top(remember).rate, stack_top(remember).DAG, stack_top(remember).round); */
      stack_dec(remember);
    }
  file_used = fopen(filename_used, "w");
  nb_to_bad = stack_size(remember);
  while(!stack_is_empty(remember))
    {
      /* fprintf(file_useful, "%f, %d, %d\n", */
      /*         stack_top(remember).rate, stack_top(remember).DAG, stack_top(remember).round); */
      stack_dec(remember);
    }
  stack_reset(remember);
  for (i = 0; i < stack_size(used_instances_total); i++)
    {
      stack_push(remember, stack_get(used_instances_total, i));
      fprintf(file_used, "%d\n", stack_get(used_instances_total, i).DAG);
    }
  stack_sort(remember, compare);
  avg_used = compute_average(remember);
  while(!stack_is_empty(remember))
    {
      fprintf(file_used, "%f, %d, %d\n",
              stack_top(remember).rate,
              stack_top(remember).DAG, stack_top(remember).round);
      stack_dec(remember);
    }
  file_size = fopen(filename_size, "w");
  /* printf("%d %d \n", stack_size(used_instances_total), stack_size(DAG_FORMULA)); */
  printf("STAT: nb_used=%d\n", stack_size(used_instances_total));
  printf("STAT: avg_used=%f\n", avg_used);
  printf("STAT: nb_useful=%d\n", /* nb_useful,  */stack_size(DAG_FORMULA));
  printf("STAT: avg_useful=%f\n", avg_useful);
  printf("STAT: nb_to_bad=%d\n", nb_to_bad);
  fprintf(file_size, "%d, %f\n", stack_size(used_instances_total), avg_used);
  fprintf(file_size, "%d, %f\n", stack_size(DAG_FORMULA), avg_useful);
  stack_reset(used_instances_total);
  stack_reset(DAG_FORMULA);
  stack_free(used_instances_total);
  stack_free(DAG_FORMULA);
  stack_free(remember);
  fclose(file_useful);
  fclose(file_used);
  fclose(file_size);
}


static void
delete_unif(TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(delay_round_unifier); i++)
    {
      if (stack_get(delay_round_unifier, i).DAG == DAG)
        {
          stack_delete(delay_round_unifier, i);
          return;
        }
    }
}


static void
clean_dir(bool all)
{
  char res[512];
  DIR * d = opendir(direname);
  struct dirent * dir;
  while (d && (dir = readdir(d)) != NULL)
    {
      if (strcmp(dir->d_name, ".") == 0 ||
          strcmp(dir->d_name, "..") == 0 ||
          (!all && (strcmp(dir->d_name, "model-0.smt2") == 0 ||
                    strcmp(dir->d_name, "dump-0.smt2") == 0)))
        continue;
      sprintf(res, "%s/%s", direname, dir->d_name);
      remove(res);
    }
  closedir(d);
}

static int
indice_dicho(Tstack_instances stack, instance inst)
{
  unsigned i;
  for (i = 0; i < stack_size(stack); i++)
    {
      if (stack_get(stack, i).rate >= inst.rate)
        {
          if (stack_get(stack, i).DAG != inst.DAG)
            return i;
          else
            return -1;
        }
    }
  return -1;
}
static unsigned round_i = 0;

unsigned dump_ni = 0;
unsigned model_ni = 0;
FILE * file_model = NULL;
FILE * file_dump = NULL;

static void
open_model_sp(void)
{
  char filename[256];
  if (!option_learning_instances)
    sprintf(filename, "%s/model-%u.smt2", direname, ++model_ni);
  else
    sprintf(filename, "%s/model-0.smt2", direname);
  file_model = fopen(filename, "w");
}

static void
remove_model_sp(void)
{
  char filename[256];
  if (!option_learning_instances)
    sprintf(filename, "%s/model-%u.smt2", direname, model_ni);
  else
    sprintf(filename, "%s/model-0.smt2", direname);
  remove(filename);
  fclose(file_model);
}

static void
open_dump_sp(void)
{
  char filename[256];
  if (!option_learning_instances)
    sprintf(filename, "%s/dump-%u.smt2", direname, ++dump_ni);
  else
    sprintf(filename, "%s/dump-0.smt2", direname);
  file_dump = fopen(filename, "w");
}

static void
remove_dump_sp(void)
{
  char filename[256];
  if (!option_learning_instances)
    sprintf(filename, "%s/dump-%u.smt2", direname, dump_ni);
  else
    sprintf(filename, "%s/dump-0.smt2", direname);
  fclose(file_dump);
  remove(filename);
}

static void
veriT_output_model_sp(void)
{
  unsigned i, j;
  TDAG * PDAG;
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG));
  for (i = 0, j = 0; i < SAT_literal_stack_n; ++i)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      if (boolean_connector(DAG_symb(DAG)))
        continue;
      PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
      if (!DAG_quant(PDAG[j-1]))
        DAG_fprint(file_model, PDAG[j-1]);
    }
  for (i = 0; i < j; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
  fclose(file_model);
}

static void
veriT_dump_literals_sp()
{
  unsigned i;
  TDAG * PDAG;

  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof (TDAG));
  for (i = 0; i < SAT_literal_stack_n; i++)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      assert(DAG);
      PDAG[i] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
      if (!DAG_quant(PDAG[i]))
        DAG_fprint(file_dump, PDAG[i]);
    }
  for (i = 0; i < SAT_literal_stack_n; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
  fclose(file_dump);
}

#include "DAG-stat.h"
TSstack(_double, double);

static void
veriT_extract_features(void)
{
  unsigned i, j, k, l;
  Tstack_double features;
  TDAG * PDAG;
  stack_INIT(features);
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG));
  for (i = 0, j = 0; i < SAT_literal_stack_n; ++i)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      if (boolean_connector(DAG_symb(DAG)))
        continue;
      PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
    }
  init_model_stack(PDAG, j);
  for (k = 0; k < stack_size(round_unifier); k++)
    {
      stack_push(features, DAG_count_atoms(stack_get(round_unifier, k).qDAG));
      stack_push(features, DAG_max_depth(stack_get(round_unifier, k).qDAG));
      stack_push(features, DAG_min_depth(stack_get(round_unifier, k).qDAG));
      stack_push(features, DAG_avg_depth(stack_get(round_unifier, k).qDAG));
      stack_push(features, DAG_intersect_symbols(stack_get(round_unifier, k).qDAG));
      stack_push(features,
                 DAG_biggest_intersect_term(stack_get(round_unifier, k).qDAG));
      stack_push(features,
                 DAG_count_differents_atoms(stack_get(round_unifier, k).qDAG));
      stack_push(features, DAG_predicats_appear(stack_get(round_unifier, k).qDAG));
      for (l = 0;  l < 4; l++)
        stack_push(features, DAG_nb_arity_term(stack_get(round_unifier, k).qDAG, l));
      /** instances features **/
      /** number of quantifier **/
      double sum = 0;
      Tunifier unifier = stack_get(round_unifier, k).unifier;
      /** number of quantifier **/
      stack_push(features, (double)unifier->size);
      /** depth avg of terms **/
      for (i = 0, sum = 0; i < unifier->size;
           sum += DAG_count_atoms(unifier->val[i].term), i++);
      stack_push(features, (sum / (double) unifier->size));
      /** depth max of term **/
      for (i = 0, sum = 0; i < unifier->size;
           sum =  (sum <= DAG_depth(unifier->val[i].term))?
             DAG_depth(unifier->val[i].term):sum, i++);
      stack_push(features, (double)sum);
      /** depth min of term **/
      for (i = 0, sum = UINT_MAX; i < unifier->size;
           sum = (sum > DAG_depth(unifier->val[i].term))?
             DAG_depth(unifier->val[i].term):sum, i++);
      stack_push(features, (double)sum);
      /** nb symbol intersect **/
      for (i = 0, sum = 0; i < unifier->size;
           sum += DAG_intersect_symbols(unifier->val[i].term), i++);
      stack_push(features, (double)sum);
      /** nb atom differents **/
      for (i = 0, sum = 0; i < unifier->size;
           sum += DAG_count_differents_atoms(unifier->val[i].term), i++);
      stack_push(features, (double)sum);
      /** nb predicat appear **/
      for (i = 0, sum = 0; i < unifier->size;
           sum += DAG_predicats_appear(unifier->val[i].term), i++);
      stack_push(features, (double)sum);

      /** nb arity terms **/
      for (l = 0;  l < 4; l++)
        {
          for (i = 0, sum = 0; i < unifier->size;
               sum += DAG_nb_arity_term(unifier->val[i].term, l), i++);
          stack_push(features, (double)sum);
        }

      for (i = 0; i < stack_size(features); i++)
        {
          if ( i == stack_size(features) - 1)
            fprintf(file_features, "%f\n", stack_get(features, i));
          else
            fprintf(file_features, "%f, ", stack_get(features, i));
        }
      stack_reset(features);
      stack_push(delay_round_unifier, stack_get(round_unifier, k));
    }
  free_model_stack();
  for (i = 0; i < j; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
  stack_reset(round_unifier);
}


static unsigned DAG_DUP = 0;
static unsigned DAG_MOD = 0;

static void
extract_light_model_to_xgb(void)
{
  unsigned i, j;
  TDAG * PDAG;
  /** Dump **/
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG));
  for (i = DAG_DUP, j = DAG_DUP; i < SAT_literal_stack_n; ++i)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      if (boolean_connector(DAG_symb(DAG)))
        continue;
      if (!DAG_quant(DAG))
        {
          PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
          add_to_model(PDAG[j - 1],  j - 1, 0, 7);
        }
    }
  DAG_DUP = j;
  for (i = DAG_DUP; i < j; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
  /** Model **/
  /* MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG)); */
  /* for (i = DAG_MOD, j = DAG_MOD; i < SAT_literal_stack_n; ++i) */
  /*   { */
  /*     Tlit lit = SAT_literal_stack[i]; */
  /*     TDAG DAG = var_to_DAG(lit_var(lit)); */
  /*     if (!DAG_quant(DAG)) */
  /*       { */
  /*         PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG)); */
  /*         add_to_model(PDAG[j - 1], j - 1, 1, 7); */
  /*       } */
  /*   } */
  /* DAG_MOD = j; */
  /* for (i = DAG_MOD; i < j; i++) */
  /*   DAG_free(PDAG[i]); */
  /* free(PDAG); */
  init_translate_model(NULL, 0, 2, 11);
}


static void
extract_model_to_xgb(void)
{
  unsigned i, j;
  TDAG * PDAG;
  /** Dump **/
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG));
  for (i = DAG_DUP, j = DAG_DUP; i < SAT_literal_stack_n; ++i)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      if (boolean_connector(DAG_symb(DAG)))
        continue;
      if (!DAG_quant(DAG))
        {
          PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
          add_to_model(PDAG[j - 1],  j - 1, 0, 1);
        }
    }
  DAG_DUP = j;
  for (i = DAG_DUP; i < j; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
  /** Model **/
  MY_MALLOC(PDAG, SAT_literal_stack_n * sizeof(*PDAG));
  for (i = DAG_MOD, j = DAG_MOD; i < SAT_literal_stack_n; ++i)
    {
      Tlit lit = SAT_literal_stack[i];
      TDAG DAG = var_to_DAG(lit_var(lit));
      if (!DAG_quant(DAG))
        {
          PDAG[j++] = DAG_dup(lit_pol(lit)?DAG:DAG_not(DAG));
          add_to_model(PDAG[j - 1], j - 1, 1, 1);
        }
    }
  DAG_MOD = j;
  for (i = DAG_MOD; i < j; i++)
    DAG_free(PDAG[i]);
  free(PDAG);
  MY_MALLOC(PDAG, stack_size(round_unifier) * sizeof(*PDAG));
  for (i = 0; i < stack_size(round_unifier); i++)
    PDAG[i] = stack_get(round_unifier, i).qDAG;
  init_translate_model(PDAG, stack_size(round_unifier), 2, 2);
  free(PDAG);
}

#include "DAG-prop.h"

unsigned nb_skolem = 0;

static void
instances_to_xgb(Tunifier unifier, TDAG qform, bool simple)
{
  unsigned i, j, l, m,
    max_depth = 0, nb_skolem_round = 0, nb_triggers = 0,
    nb_triggers_par_var = 0, cc_pol = 0, cc_size = 0, cc_pred = 0;
  Tstack_DAGstack * Ptriggers =
    (Tstack_DAGstack *) DAG_prop_get(qform, DAG_PROP_TRIGGER);
  for (i = 0; i < unifier->size;i++)
    {
      if (!unifier->val[i].term)
        continue;
      if (!simple)
      {
        Tstack_DAG sig =
          CC_get_sig_DAG(DAG_symb(unifier->val[i].term), unifier->val[i].term);
        if (CC_diseqs(unifier->val[i].term))
          {
            Tstack_DAG diseq = CC_diseqs(unifier->val[i].term);
            for (j = 0; j < stack_size(diseq);
                 DAG_encode_fea(stack_get(diseq, j)),
                   DAG_translate_fea(stack_get(diseq, j), 2),
                   DAG_extra_fea(stack_get(diseq, j), stack_size(diseq)), j++);
          }
        for (j = 0; j < stack_size(sig);
             DAG_encode_fea(stack_get(sig, j)),
               DAG_translate_fea(stack_get(sig, j), 3),
               DAG_extra_fea(stack_get(sig, j), stack_size(sig)),j++);
      }
      unsigned value;
      if (CC_abstract_p(unifier->val[i].term) == UNDEFINED)
        value = 2;
      else if (CC_abstract_p(unifier->val[i].term) == FALSE)
        value = 3;
      else 
        value = 5;
      cc_pol =  value + cc_pol;
      cc_size = CC_size(unifier->val[i].term) + cc_size;
      cc_pred = CC_nb_pred(unifier->val[i].term) + cc_pred;

      for (j = 0; Ptriggers && j < stack_size(*Ptriggers); ++j)
        {
          Tstack_DAG trigger = stack_get(*Ptriggers, j);
          for (l = 0; l < stack_size(trigger); ++l)
            {
              Tstack_DAG fvars = get_fvars(stack_get(trigger, l));
              if (fvars)
                {
                  for (m = 0; m < stack_size(fvars); ++m)
                    if (unifier->val[i].var == stack_get(fvars, m))
                      {
                        if (DAG_depth(stack_get(trigger, l))  > max_depth)
                          max_depth = DAG_depth(stack_get(trigger, l));
                        if (DAG_symb_type(DAG_symb(unifier->val[i].term)) & SYMB_NUMBER ||
                            !strncmp(DAG_symb_name2(DAG_symb(unifier->val[i].term)), "@sk", 3))
                          {
                            nb_skolem++;
                            nb_skolem_round++;
                          }
                        nb_triggers++;
                        nb_triggers_par_var++;
                        DAG_encode_fea(stack_get(trigger, l));
                        /* my_DAG_message("--------------- [TRIGGER]%D %d ------------------\n", stack_get(trigger, l), nb_triggers_par_var); */
                        DAG_translate_fea(stack_get(trigger, l), 1);
                        /* my_DAG_message("--------------- [END TRIGGER] ------------------\n"); */

                        DAG_extra_fea(stack_get(trigger, l), stack_size(trigger));
                      }
                }
            }
        }
      /* my_DAG_message("[INSTANCE] %D %d\n", unifier->val[i].var, nb_triggers_par_var); */
      DAG_encode_fea(unifier->val[i].term);
      DAG_translate_fea(unifier->val[i].term, 4);
      DAG_extra_fea(unifier->val[i].term, unifier->size);
      DAG_custom_fea(nb_triggers_par_var, 5);
      nb_triggers_par_var = 0;
    }
  DAG_custom_fea(nb_skolem, 17);
  DAG_custom_fea(nb_skolem_round, 21);
  DAG_custom_fea(max_depth, 11);
  DAG_custom_fea(nb_triggers, 13);
  /* DAG_custom_fea(cc_pol, 6); */
  /* DAG_custom_fea(cc_size, 7); */
  /* DAG_custom_fea(cc_pred, 8); */
  stack_push(features_record, qform);
  stack_push(features_record, nb_skolem);
  stack_push(features_record, nb_skolem_round);
  stack_push(features_record, max_depth);
  stack_push(features_record, nb_triggers);
  stack_push(features_record, cc_pol);
  stack_push(features_record, cc_size);
  stack_push(features_record, cc_pred);
  stack_push(features_record, unifier->size);
}


void
veriT_extract_conflicting_instances(void)
{
  unsigned k;
  Tunifier unifier;
  for (k = 0; k < stack_size(round_unifier); k++)
    {
      unifier = stack_get(round_unifier, k).unifier;
      stack_push(conflicting_instances, stack_get(round_unifier, k));
    }
  /* printf("%d %d\n", stack_size(conflicting_instances), stack_size(round_unifier)); */
  Tinstance_round inst = {stack_size(round_unifier), NULL, 0, 0};
  stack_push(conflicting_instances, inst);
  stack_reset(round_unifier);
}

void
veriT_extract_features_to_xgb_v2(void)
{
  unsigned k;
  Tunifier unifier;
  /* extract_light_model_to_xgb(); */
  for (k = 0; k < stack_size(round_unifier); k++)
    {
      unifier = stack_get(round_unifier, k).unifier;
      instances_to_xgb(unifier, stack_get(round_unifier, k).qDAG, true);
      write_fea(file_features);
      stack_push(delay_round_unifier, stack_get(round_unifier, k));
    }
  Tinstance_round inst = {stack_size(round_unifier), NULL, 0, 0};
  stack_push(delay_round_unifier, inst);
  stack_reset(round_unifier);
}

static void
veriT_extract_features_to_xgb_v1(void)
{
  unsigned k, i;
  Tunifier unifier;
  extract_model_to_xgb();
  for (k = 0; k < stack_size(round_unifier); k++)
    {
      unifier = stack_get(round_unifier, k).unifier;
      DAG_translate_fea(stack_get(round_unifier, k).qDAG, 3);
      for (i = 0; i < unifier->size;
           DAG_encode_fea(unifier->val[i].term),
             DAG_translate_fea(unifier->val[i].term, 4),
             DAG_extra_fea(unifier->val[i].term, unifier->size),i++);
      write_fea(file_features);
      stack_push(delay_round_unifier, stack_get(round_unifier, k));
    }
  Tinstance_round inst = {stack_size(round_unifier), NULL, 0, 0};
  stack_push(delay_round_unifier, inst);
  stack_reset(round_unifier);
}

#include <float.h>


static float
compute_average(Tstack_instances stack)
{
  unsigned i;
  float sum = 0.0;
  for (i = 0; i < stack_size(stack); sum += stack_get(stack, i).rate,i++);
  return sum / stack_size(stack);
}

static float
compute_average_square(Tstack_instances stack)
{
  unsigned i;
  float sum = 0.0;
  for (i = 0; i < stack_size(stack);
       sum += (stack_get(stack, i).rate * stack_get(stack, i).rate),i++);
  return sum / stack_size(stack);
}


static float
compute_ecart_type(Tstack_instances stack)
{
  float avg = compute_average(stack),
    avg_sq = compute_average_square(stack), diff = 0.0;
  diff = avg_sq - avg;
  return sqrtf((diff > 0.0)?diff:(-1.0 * diff));
}

static float
quartile(float q, float n)
{
  return (q * n) / 4;
}

static float
cut_quantile(Tstack_instances stack, float q)
{
  return stack_get(stack, (unsigned)quartile(q, stack_size(stack))).rate;
}

static float
find_deno(float q, float avg)
{
  float i;
  for (i = 1; q != 0 && (avg/i > q); i = i + 0.5);
  return i;
}

static void
uniq(Tstack_instances *stack, float avg, bool delay)
{
  bool active = true;
  unsigned i, stack_i = 0, stack_j = 1;
  unsigned count = 0;
  /* Tstack_instances st; */
  /* stack_INIT(st); */
  /* float cut = (avg > 0.3)?avg - 0.05:(avg > 0.1)?avg - 0.05:0.05; */
 if (stack_size(*stack) > 1)
  {
    while (stack_j < stack_size(*stack))
      if (stack_get(*stack, stack_j).rate == stack_get(*stack, stack_i).rate)
        {

          if (count == 0 && active)
            {
              active = false;
              count = find_deno(stack_get(*stack, stack_j).rate, avg);
              /* printf ("count: %d %f\n", count, stack_get(*stack, stack_j).rate); */
            }
          if (/* stack_get(*stack, stack_j).rate < 0.1 */ count > 0)
            {
              /* printf ("count: %d %f\n", count, stack_get(*stack, stack_j).rate); */
              (*stack)->data[++stack_i] = (*stack)->data[stack_j++];
              count--;
              continue;
            }
          if (!delay)
            {
              /* stack_push(st, stack_get(*stack, stack_j)); */
              for (i = 0; i < stack_size(round_unifier); i++)
                {
                  if (stack_get(*stack, stack_j).DAG ==
                      stack_get(round_unifier, i).DAG)
                    {
                      stack_push(delay_round_unifier, stack_get(round_unifier, i));
                      stack_j++;
                      break;
                    }
                }
            }
          else
            stack_j++;
        }
      else
        {
          count = 0;
          active = true;
          (*stack)->data[++stack_i] = (*stack)->data[stack_j++];
        }
    (*stack)->size = stack_i + 1;
    /* printf("[AFTER] %d fresh_inst %f \n", */
    /*        stack_size(st), compute_average(st)); */
  }
}

static unsigned
redudondante(Tstack_instances stack)
{
  unsigned i, count = 0;
 if (stack_size(stack) > 1)
  {
    for (i = 0; i < stack_size(stack) - 1; i++)
    if (stack_get(stack, i).rate == stack_get(stack, i + 1).rate)
      count++;
  }
 return count;
}

unsigned strategie = 2;


void
native_predictions_v2(bool delay, Tstack_DAG *stack, Tstack_instances *instances_rates)
{
  float rate_avg = 0.0;
  unsigned k,
    size_unif = stack_size((delay)?delay_round_unifier:round_unifier), max_depth = 0, tmp = 0;
  Tunifier unifier;
  float prediction;

  for (k = 0; k < size_unif; k++)
    {
      unifier = stack_get((delay)?delay_round_unifier:round_unifier, k).unifier;
      instances_to_xgb(unifier,
                       stack_get((delay)?delay_round_unifier:round_unifier, k).qDAG, false);
      /* if (strategie == 4) */
      /*   prediction = get_prediction(100, 1); */
      prediction = get_prediction(100, nb_skolem);
      /* else */
      /*   prediction = get_prediction(100, 4); */
      instance inst =
        {prediction ,
         stack_get((delay)?delay_round_unifier:round_unifier, k).DAG, round_i};
      stack_push(*instances_rates, inst);
      /* my_DAG_message("[RATE] %d %f DEPTH : %d %f %d \n", */
      /*                stack_top(*instances_rates).DAG, */
      /*                stack_top(*instances_rates).rate, */
      /*                max_depth, */
      /*                prediction, */
      /*                nb_skolem); */
      rate_avg += (float)stack_top(*instances_rates).rate;
      stack_push(delay_tmp_unifier, stack_get(round_unifier, k));
    }
  /* my_DAG_message("Rate avg %d %d %f\n", max_depth, nb_skolem, rate_avg / (float) size_unif); */
}

void
native_predictions_v1(bool delay, Tstack_DAG *stack, Tstack_instances *instances_rates)
{
  float rate_avg = 0.0;
  unsigned k, i, size_unif = stack_size((delay)?delay_round_unifier:round_unifier);
  Tunifier unifier;
  float prediction;

  for (k = 0; k < size_unif; k++)
    {
      unifier = stack_get((delay)?delay_round_unifier:round_unifier, k).unifier;
      DAG_translate_fea(stack_get((delay)?delay_round_unifier:
                                  round_unifier, k).qDAG, 3);
      for (i = 0; i < unifier->size;
           DAG_encode_fea(unifier->val[i].term),
             DAG_translate_fea(unifier->val[i].term, 4),
             DAG_extra_fea(unifier->val[i].term, unifier->size),i++);
      prediction = get_prediction(100, nb_skolem);
      instance inst =
        {prediction ,
         stack_get((delay)?delay_round_unifier:round_unifier, k).DAG, round_i};
      stack_push(*instances_rates, inst);
      /* my_DAG_message("[RATE] %d %f\n", */
      /*                stack_top(*instances_rates).DAG, */
      /*                stack_top(*instances_rates).rate); */
      /* exit(0); */
      rate_avg += (float)stack_top(*instances_rates).rate;
    }
  /* my_DAG_message("Rate avg %f\n", rate_avg / (float) size_unif); */
}

static bool switch_strategie = true;
static bool delay = false;
static unsigned prev_size = 0;
/* #define LEARN_VERBOSE */

static bool
contains(Tstack_DAG *stack, TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(*stack); i++)
    if (stack_get(*stack, i) == DAG)
      return true;
  return false;
}

static bool
extract_and_learn()
{
  bool simple_stats = false;
  Tunifier unifier;
  unsigned i, j = 0, nb_insts = 0;
  for (j = 0; j < stack_size(delay_tmp_unifier); j++)
    {
      for (i = 0; i < stack_size(features_record); i+=9)
        {
          if (stack_get(delay_tmp_unifier, j).qDAG ==
              stack_get(features_record, i))
            {
              if (simple_stats)
                {
                  write_stats_fea(file_features,
                                  stack_get(features_record, i + 1),
                                  stack_get(features_record, i + 2),
                                  stack_get(features_record, i + 3),
                                  stack_get(features_record, i + 4),
                                  stack_get(features_record, i + 5),
                                  stack_get(features_record, i + 6),
                                  stack_get(features_record, i + 7),
                                  stack_get(features_record, i + 8));
                }
              else
                {
                  unifier = stack_get(delay_tmp_unifier, j).unifier;
                  instances_to_xgb(unifier, stack_get(delay_tmp_unifier, j).qDAG, true);
                  write_fea(file_features);
                }
              stack_push(delay_analyse_round_unifier, stack_get(delay_tmp_unifier, j));
              nb_insts++;

              break;
            }
        }
    }
  Tinstance_round inst = {nb_insts, NULL, 0, 0};
  stack_push(delay_analyse_round_unifier, inst);
  stack_reset(delay_tmp_unifier);
  stack_reset(features_record);
}




void
veriT_learning(void)
{
  int i;
  unsigned redudant = 0, old_took = 0,
    upper_limit_delay =
    (!stack_is_empty(delay_round_unifier))?stack_size(delay_round_unifier):0;
  float best_current, best_delay, bound/* , best */;
  Tstack_DAG  analyse_delay, analyse_current;
  Tstack_instances update_delay_rates, instances_rates;
  round_i++;
  /** Disable learning with strategie 3 **/
  born = 0.0;
  stack_INIT(analyse_delay);
  stack_INIT(analyse_current);
  stack_INIT(update_delay_rates);
  stack_INIT(instances_rates);
  assert(stack_size(veriT_lemmas) == stack_size(round_unifier));
  if (option_show_learning_stats)
    printf("[LEARNING  NEW ROUND (to filter %d %d)]\n",
           stack_size(veriT_lemmas), upper_limit_delay);

  if (option_learning_native)
    {
      native_predictions_v2(false, &analyse_current, &instances_rates);
      if (!stack_is_empty(delay_round_unifier))
        native_predictions_v2(true, &analyse_delay, &update_delay_rates);
    }
  assert(stack_size(veriT_lemmas) == stack_size(instances_rates));
  assert(stack_size(delay_round_unifier) == stack_size(update_delay_rates));
  stack_reset(veriT_lemmas);


  if (!stack_is_empty(update_delay_rates))
    stack_sort(update_delay_rates, compare);
  if (!stack_is_empty(instances_rates))
    stack_sort(instances_rates, compare);
  best_current = stack_top(instances_rates).rate;
  best_delay =
    (!stack_is_empty(update_delay_rates))?stack_top(update_delay_rates).rate:0.0;
  /* best = (best_current >= best_delay)?best_current:best_delay; */
  redudant = redudondante(instances_rates);
  /* printf("[REDUDANTE] %d\n", redudant); */
  if (switch_strategie &&
      (compute_average(instances_rates) < 0.3 ||
       (compute_average(instances_rates) < 0.3 &&
        !stack_is_empty(update_delay_rates) &&
        compute_average(update_delay_rates) < 0.3)))
    strategie = 4;

  /* printf("[REDUDANTE] %d %d\n", redudant, strategie); */
  if (compute_average(instances_rates) < 0.07)
    {
      printf("[FORGIVE]  fresh_inst %f fresh_EType %f\n",
             compute_average(instances_rates),
             compute_ecart_type(instances_rates));
      while (!stack_is_empty(instances_rates))
        stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
    }
  else if (strategie == 2)
    {
      float rate_lim = 0.5;
      born = 0.4;
      /* printf("number of lemmas %f \n", ii); */
       if (stack_is_empty(update_delay_rates))
        {
          if (option_show_learning_stats)
            printf("[STRAT(2) STATS] best_fresh %f fresh_inst %f fresh_EType %f \n",
                   best_current, compute_average(instances_rates),
                   compute_ecart_type(instances_rates));
          while (!stack_is_empty(instances_rates) && stack_top(instances_rates).rate >= rate_lim)
            {
              stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
            }
        }
       else
         {
           if (option_show_learning_stats)
             printf("[STRAT(2) STATS] best_fresh %f best delay %f fresh_avg %f delay_avg %f fresh_EType %f delay_EType %f\n",
                    best_current, best_delay,
                    compute_average(instances_rates),
                    compute_average(update_delay_rates),
                    compute_ecart_type(instances_rates),
                    compute_ecart_type(update_delay_rates));
           while (!stack_is_empty(instances_rates) ||
                  !stack_is_empty(update_delay_rates))
             {
               if (stack_is_empty(update_delay_rates) &&
                   stack_top(instances_rates).rate >= rate_lim)
                 stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
               else if (stack_is_empty(instances_rates) &&
                        stack_top(update_delay_rates).rate >= rate_lim)
                 {
                   stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG);
                   delete_unif(stack_pop(update_delay_rates).DAG);
                 }
               else if (stack_is_empty(update_delay_rates) &&
                        stack_top(instances_rates).rate < rate_lim)
                 break;
               else if (stack_is_empty(instances_rates) &&
                        stack_top(update_delay_rates).rate < rate_lim)
                 break;
               else if ((stack_top(update_delay_rates).rate >=
                         stack_top(instances_rates).rate)
                        && stack_top(update_delay_rates).rate >= rate_lim)
                 {
                   old_took++;
                   stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG);
                   delete_unif(stack_pop(update_delay_rates).DAG);
                 }
               else if (stack_top(instances_rates).rate >= rate_lim)
                 stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
               else
                 break;
             }
         }
    }
  else if (strategie == 4 || (strategie == 1 && redudant >= 100))
    {
      float
        /** Plus sa valeur est haute plus on coupe bas les donnees**/
        /** Pas mal comme relage:
            1) param = 0.25, parmastreng = 0.01
         **/
        param = 0.26,
        /* param = 0.005, */
        /** Perme de descendre plus bas quand la moyen est trop basse (raffinement)**/
        parmastreng = 0.01;
        /* tmpavg = compute_average(instances_rates), */
        /* tmpetype = compute_ecart_type(instances_rates); */
      /* float tmpcut = */
      /*   fabsf(tmpavg - ((param * ((tmpavg < 0.1)?parmastreng:1.0)) * tmpetype)); */
      /** STRATEGIE 4 **/
      /* printf("minus %f\n", */
      /*        compute_average(instances_rates) - compute_ecart_type(instances_rates)); */
      /* if (compute_average(instances_rates) < 0.1) */
      if ((stack_size(instances_rates) <= 200 &&
           compute_ecart_type(instances_rates) -
           compute_average(instances_rates) < 0.1 ) ||
          compute_average(instances_rates) > 0.5)
        {
          if (option_show_learning_stats)
            printf("[STRAT 4 STATS_NO_FILTER] best_fresh %f fresh_inst %f fresh_EType %f\n",
                   best_current, compute_average(instances_rates),
                   compute_ecart_type(instances_rates));

          while (!stack_is_empty(instances_rates))
            {
              stack_push(used_instances_total, stack_top(instances_rates));
              stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
            }
        }
      else if (stack_is_empty(update_delay_rates))
        {
          float cut, strength,
            fresh_avg = compute_average(instances_rates),
            etype = compute_ecart_type(instances_rates);
          strength = (fresh_avg < 0.1)?parmastreng:1.0;
          cut =  fabsf(fresh_avg - ((param * strength) * etype));
          if (!stack_is_empty(instances_rates))
            uniq(&instances_rates, cut, false);
          if (option_show_learning_stats)
            printf("[STRAT 4 STATS] best_fresh %f fresh_inst %f fresh_EType %f cut %f\n",
                   best_current, fresh_avg, etype, cut);

          while (!stack_is_empty(instances_rates) &&
                 stack_top(instances_rates).rate > cut)
            {
              stack_push(used_instances_total, stack_top(instances_rates));
              stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
            }
        }
       else
         {
           float
             fcut, dcut, fstrength, dstrength,
             fresh_avg = compute_average(instances_rates),
             delay_avg = compute_average(update_delay_rates),
             fetype = compute_ecart_type(instances_rates),
             detype = compute_ecart_type(update_delay_rates);
           fstrength = (fresh_avg < 0.1)?parmastreng:1.0;
           dstrength = (delay_avg < 0.1)?parmastreng:1.0;
           fcut =
             fabsf(fresh_avg - ((param * fstrength) * fetype));
           dcut =
             fabsf(delay_avg - ((param * dstrength) * detype));
           if (!stack_is_empty(instances_rates))
             uniq(&instances_rates, fcut, false);
           if (!stack_is_empty(update_delay_rates) && (dcut < 0.15))
             uniq(&update_delay_rates, dcut, true);
           if (option_show_learning_stats)
             printf("[STRAT 4 STATS] best_fresh %f best delay %f fresh_avg %f delay_avg %f fresh_EType %f delay_EType %f fcut %f dcut %f\n",
                    best_current, best_delay, fresh_avg, delay_avg, fetype, detype, fcut, dcut);
           while ((!stack_is_empty(instances_rates) ||
                   !stack_is_empty(update_delay_rates)))
             {
               if (stack_is_empty(update_delay_rates) &&
                   stack_top(instances_rates).rate >= fcut)
                 {
                   stack_push(used_instances_total, stack_top(instances_rates));
                   stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
                   continue;
                 }
               else if (stack_is_empty(update_delay_rates) &&
                        stack_top(instances_rates).rate < fcut)
                 break;
               if (stack_is_empty(instances_rates) &&
                   stack_top(update_delay_rates).rate >= dcut)
                 {
                   old_took++;
                   stack_push(used_instances_total, stack_top(update_delay_rates));
                   stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG);
                   delete_unif(stack_pop(update_delay_rates).DAG);
                   continue;
                 }
               else if (stack_is_empty(instances_rates) &&
                        stack_top(update_delay_rates).rate < dcut)
                 break;
               if ((stack_top(update_delay_rates).rate >=
                    stack_top(instances_rates).rate))
                 {
                   if (stack_top(update_delay_rates).rate < dcut)
                     break;
                   old_took++;
                   stack_push(used_instances_total, stack_top(update_delay_rates));
                   stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG);
                   delete_unif(stack_pop(update_delay_rates).DAG);
                 }
               else if (stack_top(instances_rates).rate < fcut)
                 break;
               else
                 {
                   stack_push(used_instances_total, stack_top(instances_rates));
                   stack_push(veriT_lemmas, stack_pop(instances_rates).DAG);
                 }
             }
         }
      /* exit(0); */
    }

  /** Delay remaining lemmas**/
  while (!stack_is_empty(instances_rates))
    {
      for (i = 0; i < stack_size(round_unifier); i++)
        {
          if (stack_top(instances_rates).DAG ==
              stack_get(round_unifier, i).DAG)
            {
              stack_push(delay_round_unifier, stack_get(round_unifier, i));
              break;
            }
        }
      if (option_learn_extract_features)
        {
          for (i = 0; i < stack_size(delay_tmp_unifier); i++)
            {
              if (stack_top(instances_rates).DAG ==
                  stack_get(delay_tmp_unifier, i).DAG)
                {
                  stack_delete(delay_tmp_unifier, i);
                  break;
                }
            }
        }
      stack_dec(instances_rates);
    }
  if (option_learn_extract_features)
    extract_and_learn();
  nb_instances = nb_instances + stack_size(veriT_lemmas);
  if (option_show_learning_stats)
    printf("[STRATEGIE:(%d)] delay:%d veriT:%d old_took:%d TOTAL:%lld/%lld\n",
           /* (redudant >= 50)?4: */strategie, stack_size(delay_round_unifier), stack_size(veriT_lemmas),
           old_took, nb_instances, nb_instances_gen);
  if (switch_strategie && strategie == 4)
    strategie = 2;
  if (!option_learning_native)
    clean_dir(true);
  stack_reset(round_unifier);
  stack_reset(instances_rates);
  stack_free(instances_rates);
  stack_reset(update_delay_rates);
  stack_free(update_delay_rates);
  stack_reset(analyse_delay);
  stack_free(analyse_delay);
  stack_reset(analyse_current);
  stack_free(analyse_current);
}




/* void */
/* veriT_learning(void) */
/* { */
/*   int i; */
/*   unsigned redudant = 0, old_took = 0, */
/*     upper_limit_delay = */
/*     (!stack_is_empty(delay_round_unifier))?stack_size(delay_round_unifier):0; */
/*   float best_current, best_delay, bound/\* , best *\/; */
/*   Tstack_DAG  analyse_delay, analyse_current; */
/*   Tstack_instances update_delay_rates, instances_rates; */
/*   round_i++; */
/*   /\** Disable learning with strategie 3 **\/ */
/*   born = 0.0; */
/*   stack_INIT(analyse_delay); */
/*   stack_INIT(analyse_current); */
/*   stack_INIT(update_delay_rates); */
/*   stack_INIT(instances_rates); */
/*   assert(stack_size(veriT_lemmas) == stack_size(round_unifier)); */
/* #ifdef LEARN_VERBOSE */
/*   printf("[LEARNING  NEW ROUND (to filter %d %d)]\n", */
/*          stack_size(veriT_lemmas), upper_limit_delay); */
/* #endif */

/*   if (option_learning_native) */
/*     { */
/*       /\* extract_light_model_to_xgb(); *\/ */
/*       native_predictions_v2(false, &analyse_current, &instances_rates); */
/*       if (!stack_is_empty(delay_round_unifier)) */
/*         native_predictions_v2(true, &analyse_delay, &update_delay_rates); */
/*       /\* extract_model_to_xgb(); *\/ */
/*       /\* native_predictions_v1(false, &analyse_current, &instances_rates); *\/ */
/*       /\* if (!stack_is_empty(delay_round_unifier)) *\/ */
/*       /\*   native_predictions_v1(true, &analyse_delay, &update_delay_rates); *\/ */

/*     } */
/*   assert(stack_size(veriT_lemmas) == stack_size(instances_rates)); */
/*   assert(stack_size(delay_round_unifier) == stack_size(update_delay_rates)); */
/*   stack_reset(veriT_lemmas); */
/*   if (!stack_is_empty(update_delay_rates)) */
/*     stack_sort(update_delay_rates, compare); */
/*   if (!stack_is_empty(instances_rates)) */
/*     stack_sort(instances_rates, compare); */
/*   best_current = stack_top(instances_rates).rate; */
/*   best_delay = */
/*     (!stack_is_empty(update_delay_rates))?stack_top(update_delay_rates).rate:0.0; */
/*   /\* best = (best_current >= best_delay)?best_current:best_delay; *\/ */
/*   redudant = redudondante(instances_rates); */
/*   /\* printf("[REDUDANTE] %d\n", redudant); *\/ */
/*   if (switch_strategie && */
/*       (compute_average(instances_rates) < 0.3 || */
/*        (compute_average(instances_rates) < 0.3 && */
/*         !stack_is_empty(update_delay_rates) && */
/*         compute_average(update_delay_rates) < 0.3))) */
/*     strategie = 4; */
  /* printf("[REDUDANTE] %d %d\n", redudant, strategie); */

/*   if (compute_average(instances_rates) < 0.07) */
/*     { */
/*       printf("[FORGIVE]  fresh_inst %f fresh_EType %f\n", */
/*              compute_average(instances_rates), */
/*              compute_ecart_type(instances_rates)); */
/*       while (!stack_is_empty(instances_rates)) */
/*         stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*     } */
/*   else if ((strategie == 1 && redudant < 200) || */
/*            (strategie == 1 && compute_average(instances_rates) < 0.1)) */
/*     { */
/*       /\** STRATEGIE 1 **\/ */
/*       bound = 0.08; */
/*       if (stack_is_empty(update_delay_rates)) */
/*         { */
/*           /\* printf("[STATS]  fresh_inst %f fresh_EType %f\n", *\/ */
/*           /\*        compute_average(instances_rates), *\/ */
/*           /\*        compute_ecart_type(instances_rates)); *\/ */
/*           while (!stack_is_empty(instances_rates) && */
/*                  stack_top(instances_rates).rate >= bound) */
/*             stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*         } */
/*       else */
/*         { */
/*           /\* printf("[STATS]  fresh_inst %f fresh_EType %f delay_inst %f delay_EType %f\n", *\/ */
/*           /\*        compute_average(instances_rates), *\/ */
/*           /\*        compute_ecart_type(instances_rates), *\/ */
/*           /\*        compute_average(update_delay_rates), *\/ */
/*           /\*        compute_ecart_type(update_delay_rates)); *\/ */
/*           while ((!stack_is_empty(instances_rates) || */
/*                   !stack_is_empty(update_delay_rates))) */
/*             { */
/*               if (stack_is_empty(update_delay_rates) && */
/*                   !stack_is_empty(instances_rates) && */
/*                   stack_top(instances_rates).rate >= bound) */
/*                 stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*               else if (stack_is_empty(update_delay_rates) && */
/*                        !stack_is_empty(instances_rates) && */
/*                        stack_top(instances_rates).rate < bound) */
/*                 break; */
/*               else if (stack_is_empty(instances_rates) && */
/*                        !stack_is_empty(update_delay_rates) && */
/*                        stack_top(update_delay_rates).rate >= bound) */
/*                 { */
/*                   old_took++; */
/*                   stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                   delete_unif(stack_pop(update_delay_rates).DAG); */
/*                 } */
/*               else if (stack_is_empty(instances_rates) && */
/*                        !stack_is_empty(update_delay_rates) && */
/*                        stack_top(update_delay_rates).rate < bound) */
/*                 break; */
/*               else if ((stack_top(update_delay_rates).rate >= */
/*                         stack_top(instances_rates).rate)) */
/*                 { */
/*                   if ((stack_top(update_delay_rates).rate >= bound)) */
/*                     { */
/*                       old_took++; */
/*                       stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                       delete_unif(stack_pop(update_delay_rates).DAG); */
/*                     } */
/*                   else break; */
/*                 } */
/*               else if ((stack_top(instances_rates).rate > bound)) */
/*                 stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*               else */
/*                 break; */
/*             } */
/*         } */
/*     } */
/*   else if (strategie == 2) */
/*     { */
/*       float rate_lim = 0.5; */
/*       born = 0.4; */
/*       /\** STRATEGIE 2 **\/ */
/*       /\* float ii = (born / 100.0) * (stack_size(instances_rates) * 100); *\/ */
/*       /\* i = (born / 100.0) * (stack_size(instances_rates) * 100); *\/ */
/*       /\* printf("number of lemmas %f \n", ii); *\/ */
/*        if (stack_is_empty(update_delay_rates)) */
/*         { */
/* #ifdef LEARN_VERBOSE */
/*           printf("[STRAT(2) STATS] best_fresh %f fresh_inst %f fresh_EType %f \n", */
/*                  best_current, compute_average(instances_rates), */
/*                  compute_ecart_type(instances_rates)); */
/* #endif */
/*           while (!stack_is_empty(instances_rates) && stack_top(instances_rates).rate >= rate_lim) */
/*             { */
/*               stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*             } */
/*         } */
/*        else */
/*          { */
/* #ifdef LEARN_VERBOSE */
/*            printf("[STRAT(2) STATS] best_fresh %f best delay %f fresh_avg %f delay_avg %f fresh_EType %f delay_EType %f\n", */
/*                   best_current, best_delay, */
/*                   compute_average(instances_rates), */
/*                   compute_average(update_delay_rates), */
/*                   compute_ecart_type(instances_rates), */
/*                   compute_ecart_type(update_delay_rates)); */
/* #endif */
/*            while (!stack_is_empty(instances_rates) || */
/*                   !stack_is_empty(update_delay_rates)) */
/*              { */
/*                if (stack_is_empty(update_delay_rates) && */
/*                    stack_top(instances_rates).rate >= rate_lim) */
/*                  stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*                else if (stack_is_empty(instances_rates) && */
/*                         stack_top(update_delay_rates).rate >= rate_lim) */
/*                  { */
/*                    stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                    delete_unif(stack_pop(update_delay_rates).DAG); */
/*                  } */
/*                else if (stack_is_empty(update_delay_rates) && */
/*                         stack_top(instances_rates).rate < rate_lim) */
/*                  break; */
/*                else if (stack_is_empty(instances_rates) && */
/*                         stack_top(update_delay_rates).rate < rate_lim) */
/*                  break; */
/*                else if ((stack_top(update_delay_rates).rate >= */
/*                          stack_top(instances_rates).rate) */
/*                         && stack_top(update_delay_rates).rate >= rate_lim) */
/*                  { */
/*                    old_took++; */
/*                    stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                    delete_unif(stack_pop(update_delay_rates).DAG); */
/*                  } */
/*                else if (stack_top(instances_rates).rate >= rate_lim) */
/*                  stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*                else */
/*                  break; */
/*              } */
/*          } */
/*     } */
/*   else if (strategie == 3) */
/*     { */
/*       born = 0.0; */
/*       /\** STRATEGIE 3 **\/ */
/*       /\* printf("number of lemmas %d \n", i); *\/ */
/*       if (stack_is_empty(update_delay_rates)) */
/*         { */
/*           /\* printf("[STATS] best_fresh %f fresh_inst %f fresh_EType %f \n", *\/ */
/*           /\*        best_current, compute_average(instances_rates), *\/ */
/*           /\*        compute_ecart_type(instances_rates)); *\/ */
/*           while (!stack_is_empty(instances_rates) && */
/*                  stack_top(instances_rates).rate >= born) */
/*             { */
/*               stack_push(veriT_lemmas, stack_top(instances_rates).DAG); */
/*               stack_push(used_instances_total, stack_pop(instances_rates)); */
/*             } */
/*         } */
/*        else */
/*          { */
/*            /\* printf("[STATS] best_fresh %f best delay %f fresh_avg %f delay_avg %f fresh_EType %f delay_EType %f\n", *\/ */
/*            /\*        best_current, best_delay, *\/ */
/*            /\*        compute_average(instances_rates), *\/ */
/*            /\*        compute_average(update_delay_rates), *\/ */
/*            /\*        compute_ecart_type(instances_rates), *\/ */
/*            /\*        compute_ecart_type(update_delay_rates)); *\/ */
/*            while ((!stack_is_empty(instances_rates) && */
/*                    !stack_is_empty(update_delay_rates))  && */
/*                   (stack_top(instances_rates).rate >= born || */
/*                    stack_top(update_delay_rates).rate >= born)) */
/*              { */
/*                if ((stack_top(update_delay_rates).rate >= */
/*                     stack_top(instances_rates).rate)) */
/*                  { */
/*                    old_took++; */
/*                    stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                    delete_unif(stack_pop(update_delay_rates).DAG); */
/*                  } */
/*                else */
/*                  stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*              } */
/*          } */
/*     } */
/*   else if (strategie == 4 || (strategie == 1 && redudant >= 100)) */
/*     { */
/*       float */
/*         /\** Plus sa valeur est haute plus on coupe bas les donnees**\/ */
/*         /\** Pas mal comme relage: */
/*             1) param = 0.25, parmastreng = 0.01 */
/*          **\/ */
/*         param = 0.26, */
/*         /\* param = 0.005, *\/ */
/*         /\** Perme de descendre plus bas quand la moyen est trop basse (raffinement)**\/ */
/*         parmastreng = 0.01; */
/*         /\* tmpavg = compute_average(instances_rates), *\/ */
/*         /\* tmpetype = compute_ecart_type(instances_rates); *\/ */
/*       /\* float tmpcut = *\/ */
/*       /\*   fabsf(tmpavg - ((param * ((tmpavg < 0.1)?parmastreng:1.0)) * tmpetype)); *\/ */
/*       /\** STRATEGIE 4 **\/ */
/*       /\* printf("minus %f\n", *\/ */
/*       /\*        compute_average(instances_rates) - compute_ecart_type(instances_rates)); *\/ */
/*       /\* if (compute_average(instances_rates) < 0.1) *\/ */
/*       if ((stack_size(instances_rates) <= 200 && */
/*            compute_ecart_type(instances_rates) - */
/*            compute_average(instances_rates) < 0.1 ) || */
/*           compute_average(instances_rates) > 0.5) */
/*         { */
/* #ifdef LEARN_VERBOSE */
/*           printf("[STRAT 4 STATS_NO_FILTER] best_fresh %f fresh_inst %f fresh_EType %f\n", */
/*                  best_current, compute_average(instances_rates), */
/*                  compute_ecart_type(instances_rates)); */
/* #endif */
/*           while (!stack_is_empty(instances_rates)) */
/*             { */
/*               stack_push(used_instances_total, stack_top(instances_rates)); */
/*               stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*             } */
/*         } */
/*       else if (stack_is_empty(update_delay_rates)) */
/*         { */
/*           float cut, strength, */
/*             fresh_avg = compute_average(instances_rates), */
/*             etype = compute_ecart_type(instances_rates); */
/*           strength = (fresh_avg < 0.1)?parmastreng:1.0; */
/*           cut =  fabsf(fresh_avg - ((param * strength) * etype)); */
/*           if (!stack_is_empty(instances_rates)) */
/*             uniq(&instances_rates, cut, false); */
/* #ifdef LEARN_VERBOSE */
/*           printf("[STRAT 4 STATS] best_fresh %f fresh_inst %f fresh_EType %f cut %f\n", */
/*                  best_current, fresh_avg, etype, cut); */
/* #endif */
/*           while (!stack_is_empty(instances_rates) && */
/*                  stack_top(instances_rates).rate > cut) */
/*             { */
/*               stack_push(used_instances_total, stack_top(instances_rates)); */
/*               stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*             } */
/*         } */
/*        else */
/*          { */
/*            float */
/*              fcut, dcut, fstrength, dstrength, */
/*              fresh_avg = compute_average(instances_rates), */
/*              delay_avg = compute_average(update_delay_rates), */
/*              fetype = compute_ecart_type(instances_rates), */
/*              detype = compute_ecart_type(update_delay_rates); */
/*            fstrength = (fresh_avg < 0.1)?parmastreng:1.0; */
/*            dstrength = (delay_avg < 0.1)?parmastreng:1.0; */
/*            fcut = */
/*              fabsf(fresh_avg - ((param * fstrength) * fetype)); */
/*            dcut = */
/*              fabsf(delay_avg - ((param * dstrength) * detype)); */
/*            if (!stack_is_empty(instances_rates)) */
/*              uniq(&instances_rates, fcut, false); */
/*            if (!stack_is_empty(update_delay_rates) && (dcut < 0.15)) */
/*              uniq(&update_delay_rates, dcut, true); */
/* #ifdef LEARN_VERBOSE */
/*            printf("[STRAT 4 STATS] best_fresh %f best delay %f fresh_avg %f delay_avg %f fresh_EType %f delay_EType %f fcut %f dcut %f\n", */
/*                   best_current, best_delay, fresh_avg, delay_avg, fetype, detype, fcut, dcut); */
/* #endif */
/*            while ((!stack_is_empty(instances_rates) || */
/*                    !stack_is_empty(update_delay_rates))) */
/*              { */
/*                if (stack_is_empty(update_delay_rates) && */
/*                    stack_top(instances_rates).rate >= fcut) */
/*                  { */
/*                    stack_push(used_instances_total, stack_top(instances_rates)); */
/*                    stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*                    continue; */
/*                  } */
/*                else if (stack_is_empty(update_delay_rates) && */
/*                         stack_top(instances_rates).rate < fcut) */
/*                  break; */
/*                if (stack_is_empty(instances_rates) && */
/*                    stack_top(update_delay_rates).rate >= dcut) */
/*                  { */
/*                    old_took++; */
/*                    stack_push(used_instances_total, stack_top(update_delay_rates)); */
/*                    stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                    delete_unif(stack_pop(update_delay_rates).DAG); */
/*                    continue; */
/*                  } */
/*                else if (stack_is_empty(instances_rates) && */
/*                         stack_top(update_delay_rates).rate < dcut) */
/*                  break; */
/*                if ((stack_top(update_delay_rates).rate >= */
/*                     stack_top(instances_rates).rate)) */
/*                  { */
/*                    if (stack_top(update_delay_rates).rate < dcut) */
/*                      break; */
/*                    old_took++; */
/*                    stack_push(used_instances_total, stack_top(update_delay_rates)); */
/*                    stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                    delete_unif(stack_pop(update_delay_rates).DAG); */
/*                  } */
/*                else if (stack_top(instances_rates).rate < fcut) */
/*                  break; */
/*                else */
/*                  { */
/*                    stack_push(used_instances_total, stack_top(instances_rates)); */
/*                    stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*                  } */
/*              } */
/*          } */
/*     } */
/*   /\** Strategie 5 quantile Methode **\/ */
/*   else if (strategie == 5) */
/*     { */
/*       if (stack_is_empty(update_delay_rates)) */
/*         { */
/*           float cut = cut_quantile(instances_rates, 3); */
/*           while (!stack_is_empty(instances_rates) && */
/*                  stack_top(instances_rates).rate >= cut) */
/*             stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*         } */
/*       else */
/*         { */
/*           float */
/*             fcut = cut_quantile(instances_rates, 3), */
/*             dcut = cut_quantile(update_delay_rates, 3); */
/*           while ((!stack_is_empty(instances_rates) || */
/*                    !stack_is_empty(update_delay_rates))) */
/*             { */
/*               if (stack_is_empty(update_delay_rates) && */
/*                   stack_top(instances_rates).rate >= fcut) */
/*                 { */
/*                   stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*                   continue; */
/*                 } */
/*               else if (stack_is_empty(update_delay_rates) && */
/*                         stack_top(instances_rates).rate < fcut) */
/*                  break; */
/*               if (stack_is_empty(instances_rates) && */
/*                   stack_top(update_delay_rates).rate >= dcut) */
/*                 { */
/*                   old_took++; */
/*                   stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                   delete_unif(stack_pop(update_delay_rates).DAG); */
/*                   continue; */
/*                 } */
/*               else if (stack_is_empty(instances_rates) && */
/*                         stack_top(update_delay_rates).rate < dcut) */
/*                  break; */
/*               if ((stack_top(update_delay_rates).rate >= */
/*                     stack_top(instances_rates).rate)) */
/*                  { */
/*                    old_took++; */
/*                    stack_push(veriT_lemmas, stack_top(update_delay_rates).DAG); */
/*                    delete_unif(stack_pop(update_delay_rates).DAG); */
/*                  } */
/*                else */
/*                  stack_push(veriT_lemmas, stack_pop(instances_rates).DAG); */
/*             } */
/*         } */
/*     } */
/*   /\** Delay remaining lemmas**\/ */
/*   while (!stack_is_empty(instances_rates)) */
/*     { */
/*       for (i = 0; i < stack_size(round_unifier); i++) */
/*         { */
/*           if (stack_top(instances_rates).DAG == */
/*               stack_get(round_unifier, i).DAG) */
/*             { */
/*               stack_push(delay_round_unifier, stack_get(round_unifier, i)); */
/*               break; */
/*             } */
/*         } */
/*       if (option_learn_extract_features) */
/*         { */
/*           for (i = 0; i < stack_size(delay_tmp_unifier); i++) */
/*             { */
/*               if (stack_top(instances_rates).DAG == */
/*                   stack_get(delay_tmp_unifier, i).DAG) */
/*                 { */
/*                   stack_delete(delay_tmp_unifier, i); */
/*                   break; */
/*                 } */
/*             } */
/*         } */
/*       stack_dec(instances_rates); */
/*     } */
/*   if (option_learn_extract_features) */
/*     { */
/*       bool simple_stats = false; */
/*       Tunifier unifier; */
/*       unsigned j = 0, nb_insts = 0; */
/*       for (j = 0; j < stack_size(delay_tmp_unifier); j++) */
/*         { */
/*           for (i = 0; i < stack_size(features_record); i+=9) */
/*             { */
/*               if (stack_get(delay_tmp_unifier, j).qDAG == */
/*                   stack_get(features_record, i)) */
/*                 { */
/*                   if (simple_stats) */
/*                     { */
/*                       write_stats_fea(file_features, */
/*                                       stack_get(features_record, i + 1), */
/*                                       stack_get(features_record, i + 2), */
/*                                       stack_get(features_record, i + 3), */
/*                                       stack_get(features_record, i + 4), */
/*                                       stack_get(features_record, i + 5), */
/*                                       stack_get(features_record, i + 6), */
/*                                       stack_get(features_record, i + 7), */
/*                                       stack_get(features_record, i + 8)); */
/*                     } */
/*                   else */
/*                     { */
/*                       unifier = stack_get(delay_tmp_unifier, j).unifier; */
/*                       instances_to_xgb(unifier, stack_get(delay_tmp_unifier, j).qDAG, true); */
/*                       write_fea(file_features); */
/*                     } */
/*                   stack_push(delay_analyse_round_unifier, stack_get(delay_tmp_unifier, j)); */
/*                   nb_insts++; */

/*                   break; */
/*                 } */
/*             } */
/*         } */
/*       Tinstance_round inst = {nb_insts, NULL, 0, 0}; */
/*       stack_push(delay_analyse_round_unifier, inst); */
/*       stack_reset(delay_tmp_unifier); */
/*       stack_reset(features_record); */
/*     } */
/*   nb_instances = nb_instances + stack_size(veriT_lemmas); */
/* #ifdef LEARN_VERBOSE */
/*   printf("[STRATEGIE:(%d)] delay:%d veriT:%d old_took:%d TOTAL:%lld/%lld\n", */
/*          /\* (redudant >= 50)?4: *\/strategie, stack_size(delay_round_unifier), stack_size(veriT_lemmas), */
/*          old_took, nb_instances, nb_instances_gen); */
/* #endif */
/*   if (switch_strategie && strategie == 4) */
/*     strategie = 2; */
/*   if (!option_learning_native) */
/*     clean_dir(true); */
/*   stack_reset(round_unifier); */
/*   stack_reset(instances_rates); */
/*   stack_free(instances_rates); */
/*   stack_reset(update_delay_rates); */
/*   stack_free(update_delay_rates); */
/*   stack_reset(analyse_delay); */
/*   stack_free(analyse_delay); */
/*   stack_reset(analyse_current); */
/*   stack_free(analyse_current); */
/* } */


void
ml_init(void)
{
  stack_INIT(delay_round_unifier);
  stack_INIT(conflicting_instances);
  stack_INIT(delay_analyse_round_unifier);
  stack_INIT(delay_tmp_unifier);
  stack_INIT(features_record);
  stack_INIT(used_instances_total);
  stack_INIT(round_unifier);
}

void
ml_done(void)
{
  stack_reset(features_record);
  stack_free(features_record);
  if ((option_extract_features || option_learn_extract_features) &&
      file_features)
    {
      fclose(file_features);
    }
  if (option_extract_features)
    free_fea();
}
