/*** Lazy Higher-Order Congruence Closure ***/
/*** author= Daniel El Ouraoui ***/



#ifndef __CCS_H
#define __CCS_H

/* #include "literal.h" */
#include <stdarg.h>

#include "config.h"

#include "DAG.h"
#include "literal.h"
#include "veriT-status.h"
#include "veriT-state.h"
/*
  --------------------------------------------------------------
  Init/done
  --------------------------------------------------------------
*/

/**
   \brief initializes the module
   \remarks must be called before any other function of the module */
extern void     CCS_init(void);

/**
   \brief releases the module */
extern void     CCS_done(void);

/*
  --------------------------------------------------------------
  IO interface
  --------------------------------------------------------------
*/

/**
   \brief status of the simple congruence closure (SAT/UNSAT) */
extern Tstatus  CCS_status;
/* extern bool CCS_symb; */
/* extern bool *CCS_internal_DAG; */
extern unsigned backtrack_level;
/**
   \brief notifies the module that DAG is relevant for arithmetic
   \param DAG a formula */
/* IMPROVE THIS IS CURRENTLY NEVER BACKTRACKED */
extern void     CCS_DAG_arith(TDAG DAG);

/**
   \brief asserts a literal
   \param lit a literal
   \return UNSAT if the set of asserted things so for is unsatisfiable
   \return SAT otherwise */
extern Tstatus  CCS_assert(Tlit lit);

/**
   \brief asserts an equality between two terms
   \param DAG1 a term
   \param DAG2 a term
   \param lit a literal as a placeholder for premisses of equality
   \return UNSAT if the set of asserted things so for is unsatisfiable */
extern Tstatus  CCS_assert_eq(TDAG DAG1, TDAG DAG2, Tlit lit);

/**
   \brief stores in veriT_conflict all literals that lead to inconsistency
   \return the proof id of the clause
   \pre CC_satus == UNSAT
   \remark should only be called once after conflict detection */
extern void    CCS_conflict(void);
/** TODO **/
/* #ifdef PROOF */
/* extern Tproof  CC_conflict_proof(void); */
/* #endif */

extern void    CCS_hint_explain(Tlit lit);

/**
   \brief stores in veriT_conflict all literals that lead to DAG0 == DAG1
   \param DAG1 the first DAG in the equality
   \param DAG2 the second DAG in the equality
   \return the proof id of the clause
   \pre DAG0 and DAG1 should be equal according to CC */
extern void     CCS_premisses_eq(TDAG DAG1, TDAG DAG2);
/** TODO **/
/* #ifdef PROOF */
/* extern Tproof   CC_premisses_eq_proof(TDAG DAG1, TDAG DAG2); */
/* #endif */


extern void CCS_notify_formula(TDAG);

extern void CCS_add_formula(TDAG);

/*
  --------------------------------------------------------------
  Utilities for instantiation
  --------------------------------------------------------------
*/

/**
   \author DEO
   \brief applies f to every element in the signature table
   \param f function operating on signature */
extern void CCS_sig_apply(void (*f)(TDAG));

/**
   \author DEO
   \brief get the DAG that is signature equivalent with symb and parameters
   given
   \param symb topsymbol
   \param params parameters
   \return the DAG equivalent to arguments, DAG_NULL if none
   \remark public function */
extern TDAG CCS_sig_query_params(Tsymb symb, Tstack_DAG params);
/**
   \author DEO
   \brief returns the representative for input in congruence closure
   \param DAG a term
   \return a DAG representing the congruence class of DAG */
extern TDAG     CCS_abstract(TDAG DAG);

/**
   \author DEO
   \brief returns the boolean value of predicate over representative
   for input in congruence closure
   \param DAG a term
   \return returns the boolean value of predicate over representative */
extern Tboolean_value   CCS_abstract_p(TDAG DAG);

extern bool CCS_detect_cycle(void);


/**
   \author DEO
   \brief checks if two terms are desiqual in CC
   \param D0 a term
   \param D1 a term
   \return true if CC asserts them disequal, false otherwise */
extern bool     CCS_disequal(TDAG D0, TDAG D1);

/**
   \author DEO
   \brief collects all classes disequal to class of DAG
   \param DAG a term
   \return a (possibly empty) set of classes */
extern Tstack_DAG CCS_diseqs(TDAG DAG);

/**
   \brief returns one element per class that has the sort given in argument
   \param sort the sort
   \return the stack of class representatives */
extern Tstack_DAG CCS_get_sort_classes(Tsort sort);

extern Tstack_DAG CCS_get_sort_classes_ho(Tsort sort);

extern Tstack_DAG CCS_get_sig(Tsymb symb);
extern Tstack_DAG CCS_get_sig_DAG(Tsymb symb, TDAG DAG);

extern void CCS_extentionality(Tstack_DAG *);

extern void CCS_lazy_axioms(Tstack_DAG *lemmas);

extern void CCS_extentionality_axioms(Tstack_DAG *lemmas);

extern void CCS_reset();

/**
   \author 
   \brief checks if a given symbol is not present in the class of DAG
   \param DAG the DAG whose class is checked for symbol
   \param symbol the symbol to be checked
   \return false if symbol has a defined bitmask and it is not in the class,
   true otherwise
   \remark since a bit mask is used for fast check, up to 64 function symbols
   can be checked this way. For all other symbols above this threshold this
   function is useless */
extern bool CCS_class_has_symbol(TDAG DAG, Tsymb symbol);

/**
   \author DEO
   \brief given a disequality, sets the classes of its arguments as disequal
   \param DAG a disequality
   \remark modifies the "diseqs" parameter of each class */
extern void CCS_set_diseqs(TDAG DAG);

extern void CCS_set_symbols(TDAG DAG);

extern void CCS_reset_symbols(void);

extern void CCS_get_graph(unsigned *nb_edges, unsigned *nb_nodes);

/**
   \author 
   \brief releases all associations regarding disequalities between classes */
extern void CCS_free_diseqs(void);

#endif /* __CCS_H */
