/*** Higher-Order Congruence Closure ***/
/*** author= Daniel NODES[l Ouraoui ***/
#include <limits.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "HOL.h"
#include "config.h"
#include "general.h"
#include "stack.h"
#include "options.h"
#include "undo.h"
#include "bool.h"
#include "free-vars.h"
#include "simpl_congruence.h"
#include "DAG-symb.h"
#include "DAG.h"
#include "DAG-tmp.h"
#include "DAG-print.h"
#include "hint.h"
#include "literal.h"
#include "veriT-state.h"
#include "veriT-DAG.h"
#include "reduction.h"

typedef enum {EMPTY, CONST, APP, LAM} Tnode_type;
typedef enum {DISEQ, EQ, CONG, INJ} Tedge_type;
typedef enum {CONFLICT, NEUTREAL_EDGE} Ttype_backtrack;

typedef unsigned Tnode;
TSstack(_node, Tnode);

#define NODE_NULL 0

static Tnode node_true;

/**
   \author Daniel El Ouraoui
   \brief The edges representation */
typedef struct Tedge {
  Tedge_type type:3; /**< type the edge */
  unsigned level;/**< temp because not used yet */
  unsigned pending_congs; /**< the remaining congruences involves by this edge */
  Tnode node; /**< destination node */
  Tlit lit; /**< litteral implying equality between src and destination */
} Tedge;

/**
   \author Daniel El Ouraoui
   \brief Node is the internal representation of a term. A node has a type
   which can be APP for notify an application, CONST for a constant and LAM
   for lambda, and EMPTY for the empty node. Essentially node encode the
   binary structure of a term without the syntactic overload of the original
   one. In this way the node structure keeps only the essential information.
   Example f a b c --> .(.(.(f,a), b)) where the first children of  .(.(.(f,a), b), c)
   are .(.(f,a), b) an c and etc... Respectivly the first parent of .(.(f,a), b) is
   .(.(.(f,a), b), c) */
typedef struct TSnode {
  bool visited:1; /**< flag to know if the node have
                     been visited in walkthrough graph*/
  bool added:1;
  bool injective:1;
  Tnode_type type:2; /**< type the node */
  Tboolean_value boolean_value:2; /*< boolean value */
  unsigned nbparents:16; /**< number of parents of the node */
  unsigned nbedges:16; /**< number of neighbours of the node */
  unsigned asserted; /**< flag to notify if the node was asserted **/
  unsigned position;
  Tnode  repr; /**< representative of the equivalent class the current node */
  TDAG DAG_arith;
  Tnode sons[2];
  Tnode *parents;
  Tedge *edges;
  Tstack_DAG diseqs;
  unsigned long long int symbols;
} TSnode;


typedef struct Tnode_app_infos {
  unsigned position;
  TDAG DAG;
  Tnode node;
} Tnode_app_infos;


TSstack(_node_app_infos, Tnode_app_infos);
TSstack(_snode, TSnode);

/**
   \author Daniel El Ouraoui
   \brief The graph representation */
static Tstack_snode NODES;
static Tstack_node_app_infos app_table;
static bool first;

/**
   \author Daniel El Ouraoui
   \brief conversion to interfaces with DAGs of veriT
   used respectively by get_DAG(Tnode):TDAG and get_node(TDAG):Tnode */
static Tstack_DAG   node_to_DAG;
static Tstack_symb  node_to_symb;
static Tstack_node  DAG_to_node;
static Tstack_node  symb_to_node;

/*
  --------------------------------------------------------------
  Debugging macro definitions
  --------------------------------------------------------------
*/

/* #define DEBUG_SIG */
/* #define DEBUG_SIMPLE_CC */
/* #define DEBUG_SIMPLE_CC_NODE */
/* #define DEBUG_BACKTRACK */
/* #define LIGHT_DEBUG_ASSERT */
/* #define LIGHT_DEBUG_BACK */
/* #define LIGHT_DEBUG */
/* #define DISABLE_THEORY_PROPAGATION */
/* #define DISABLE_THEORY_PROPAGATION_INCR */

#define INJ_FUN
unsigned backtrack_level;
static Tstack_node backtrack_cons;
static bool backfire;
Tstatus  CCS_status = SAT;

/*
  --------------------------------------------------------------
  Set of array used to travel the graph of each connected components
  --------------------------------------------------------------
*/

static Tstack_node pred_explain; /**< predecessor table for the shortest path */
static Tstack_node pending; /**< stack for DFS travel */
static Tstack_node save_cc; /**< stack for DFS generic treatment */

static Tstack_node diseq_DAGs;

/*--------------------------------------------------------------*/
#ifdef SIMPLE_CONG
Tstack_DAG CC_quantified = NULL;
#endif

/*--------------------------------------------------------------*/

static void
clean_visited_node()
{

  TDAG source;
  while (!stack_is_empty(save_cc))
    {
      source = stack_pop(save_cc);
      if(source < stack_size(pred_explain))
        stack_set(pred_explain, source, UINT_MAX);
      stack_get(NODES, source).visited = false;
    }
}

/*
  --------------------------------------------------------------
  Pending stack of terms that must be merged
  --------------------------------------------------------------
*/

typedef struct Tpending_nodes
{
  Tedge_type type:3;
  Tnode fst;
  Tnode snd;
  Tlit lit;
  unsigned level;
} Tpending_nodes;

TSstack(_pending_nodes, Tpending_nodes);

static Tstack_pending_nodes merge_queue;

/*
  --------------------------------------------------------------
  Miscellaneous helpful functions to nodes and edges
  --------------------------------------------------------------
*/

static inline bool
exists_node(Tnode u)
{
  return u <  stack_size(NODES) && stack_get(NODES, u).type != EMPTY;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \param u a node from the intern representation of term
   \return the DAG representation (veriT) associate to u  */
static inline TDAG
get_DAG(Tnode u)
{
  assert(u >= 0 && u < stack_size(NODES));
  return stack_get(node_to_DAG, u);
}

/**
   \author Daniel El Ouraoui
   \param u a DAG of veriT
   \return the node associate to u in the congruence closure module */
static Tnode
get_node(TDAG u)
{
  if (u == 0) return 0;
  if (DAG_arity(u) > 0 && stack_size(DAG_to_node) > u)
    return stack_get(DAG_to_node, u);
  else if (DAG_arity(u) == 0 &&  stack_size(symb_to_node) > DAG_symb(u))
    return stack_get(symb_to_node, DAG_symb(u));
  /* else if (stack_size(symb_to_node) > DAG_symb(u)) */
  /*   return stack_get(symb_to_node, DAG_symb(u)); */
  return 0;
}

/*--------------------------------------------------------------*/

static Tnode
get_node_from_symb(Tsymb u)
{
  if (stack_size(symb_to_node) > u)
    return stack_get(symb_to_node, u);
  return 0;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \param u a node of the graph
   \return the node representative of u */
static inline Tnode
get_repr(Tnode u)
{
  assert(stack_get(NODES, u).repr != -1);
  return stack_get(NODES, u).repr;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \param u a node of the graph
   \return the node representative of u */
static inline Tnode
get_position(Tnode u)
{
  return stack_get(NODES, u).position;
}
/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \param DAG a DAG from veriT
   \return the DAG associate to the representative node of DAG
   in the congruence closure*/
static inline TDAG
class(TDAG DAG)
{
  return get_DAG(get_repr(get_node(DAG)));
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \param u a node
   \return the polarity of the class where u live */
static inline Tboolean_value
bvalue(Tnode u)
{
  return stack_get(NODES, get_repr(u)).boolean_value;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \param node a node
   \return the DAG of the class shared with arithmetic theory */
static inline TDAG
DAG_arith(Tnode node)
{
  return stack_get(NODES, get_repr(node)).DAG_arith;
}

/**
   \author Daniel El Ouraoui
   \param u a node of the graph
   \param v a node of the graph
   \param type the type of relation between u an v
   \return true if exists any edge between u and v
   with the type type */
static bool
exists_edge(Tnode u, Tnode v, Tedge_type type)
{
  unsigned i;
  assert(u >= 0 && u < stack_size(NODES));
  assert(v >= 0 && v < stack_size(NODES));
  for (i = 0; i < stack_get(NODES, u).nbedges; i++)
    {
      if (type == EQ || type == CONG)
        {
          if ((stack_get(NODES, u).edges[i].type == EQ ||
               stack_get(NODES, u).edges[i].type == CONG ||
               stack_get(NODES, u).edges[i].type == INJ) &&
              stack_get(NODES, u).edges[i].node == v)
            return true;
        }
      else if (stack_get(NODES, u).edges[i].type == type &&
               stack_get(NODES, u).edges[i].node == v)
        return true;
    }
  return false;
}

/*--------------------------------------------------------------*/
static const char*
edgetype_to_string(Tedge_type type);

/**
   \author Daniel El Ouraoui
   \param u a node of the graph
   \param v a node of the graph
   \param type the type of relation between u an v
   \return The literal which annotate the edge (u,v) if any
   otherwise 0 */
static Tlit
get_edge_lit(Tnode u, Tnode v, Tedge_type type)
{
  unsigned i;
  assert(exists_node(u));
  assert(exists_node(v));
  for (i = 0; i < stack_get(NODES, u).nbedges; i++)
    {
      if (stack_get(NODES, u).edges[i].type == type &&
          stack_get(NODES, u).edges[i].node == v    &&
          stack_get(NODES, u).edges[i].lit != 0)
        return stack_get(NODES, u).edges[i].lit;
    }
  return 0;
}

/*--------------------------------------------------------------*/

#ifdef LIGHT_DEBUG
static const char*
edgetype_to_string(Tedge_type type)
{
  if (type == EQ)
    return "EQ";
  else if (type == DISEQ)
    return "DISEQ";
  else if (type == CONG)
    return "CONG";
  else if (type == INJ)
    return "INJ";
  return "";
}

/*--------------------------------------------------------------*/

static const char*
nodetype_to_string(Tnode_type type)
{
  if (type == EMPTY)
    return "EMPTY";
  else if (type == CONST)
    return "CONST";
  else if (type == APP)
    return "APP";
  else if (type == LAM)
    return "LAM";
  return "";
}

/*--------------------------------------------------------------*/

static const char*
boolval_to_string(Tboolean_value val)
{
  if (val == UNDEFINED)
    return "UNDEFINED";
  else if (val == TRUE)
    return "TRUE";
  else if (val == FALSE)
    return "FALSE";
  return "";
}
#endif

static void
conflict_message(Tnode u, Tnode v, unsigned i)
{
#ifdef LIGHT_DEBUG
  my_DAG_message(" [conflict{%d}] (pol(%D)=%s pol(%D)=%s) \n",
                 i, get_DAG(u), boolval_to_string(bvalue(u)),
                 get_DAG(v), boolval_to_string(bvalue(v)));
#endif
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief Notice here we use a special function
   connected used only in the case of the
   comparison of arguments.
   Example imagine u = .(f,a) and v = .(f, b)
   and these two nodes have not yet been merged
   and f is still with the inactive status
   then if we use the above function the congruence
   will be fail a the question f = f.
   But if just in this case we relax the condition
   we can get the congruence.
   \param u the right hand side of the equality
   \param v the left hand side of the equality
   \return true if u and v are connected in the graph
   false otherwise */
static inline bool
are_connected(Tnode u, Tnode v)
{
  assert(exists_node(u));
  assert(exists_node(v));
  return u == v || get_repr(u) == get_repr(v);
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief test if two terms are congruents
   \param u the right hand side of the equality
   \param v the left hand side of the equality
   \return true if u and v are congruent false otherwise */
static bool
cong(Tnode u, Tnode v)
{
  assert(exists_node(u));
  assert(exists_node(v));
  /* my_DAG_message("{%d:%d}%D {%d:%d}%D [%d]\n", */
  /*                stack_get(NODES, u).type, */
  /*                stack_get(NODES, u).position, */
  /*                get_DAG(u), */
  /*                stack_get(NODES, v).type, */
  /*                stack_get(NODES, v).position, */
  /*                get_DAG(v), */
  /*                (stack_get(NODES, u).type == APP && stack_get(NODES, v).type == APP) && */
  /*                are_connected(stack_get(NODES, u).sons[0], stack_get(NODES, v).sons[0]) && */
  /*                are_connected(stack_get(NODES, u).sons[1], stack_get(NODES, v).sons[1])); */
  if (stack_get(NODES, u).type == APP && stack_get(NODES, v).type == APP)
    return
      are_connected(stack_get(NODES, u).sons[0], stack_get(NODES, v).sons[0]) &&
      are_connected(stack_get(NODES, u).sons[1], stack_get(NODES, v).sons[1]);
  return false;
}

static bool
inj(Tnode u, Tnode v)
{
  assert(exists_node(u));
  assert(exists_node(v));
 return
   (get_DAG(v) && get_DAG(u)) &&
   (DAG_symb(get_DAG(v)) == DAG_symb(get_DAG(u)));
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief the general condition on the graph path
   \param current a node
   \param source a node
   \param i is the i-eme neighbour of source
   \return true if u and v are congruent false otherwise */
static inline bool
condition_edge(Tnode current, Tnode source, unsigned i)
{
  return !stack_get(NODES, current).visited &&
    stack_get(NODES, source).edges[i].type != DISEQ;
}

/*
  --------------------------------------------------------------
  BFS function which init the predecessor table that give
  the shortest path between two nodes in the corresponding
  connected component
  --------------------------------------------------------------
*/

/**
   \author Daniel El Ouraoui
   \brief This function compute the covering tree
   needed to find the shortest path between two node in the CC.
   \param node0 the starting point in the graph */
static void
BFS(Tnode node0)
{
  Tstack_node queue;
  unsigned i, rear = 0, front = 0;
  Tnode target, neighbour;
  if (stack_size(pred_explain) < stack_size(NODES) && !stack_is_empty(pred_explain))
    {
      /* old_size = stack_size(pred_explain); */
      stack_inc_n(pred_explain, stack_size(NODES) - stack_size(pred_explain) + 1);
      for (i = 0; i < stack_size(NODES); i++)
        stack_set(pred_explain, i, UINT_MAX);
    }
  else if (stack_is_empty(pred_explain))
    {
      stack_inc_n(pred_explain, stack_size(NODES));
      for (i = 0; i < stack_size(NODES); i++)
        stack_set(pred_explain, i, UINT_MAX);
    }
  stack_get(NODES, node0).visited = true;
  stack_push(save_cc, node0);
  stack_INIT(queue);
  stack_push(queue, node0);
  while (front <= rear)
    {
      target = stack_get(queue, front++);
      for (i = 0; i < stack_get(NODES, target).nbedges; i++)
        {
          neighbour = stack_get(NODES, target).edges[i].node;
          if (condition_edge(neighbour, target, i))
            {
              stack_get(NODES, neighbour).visited = true;
              stack_push(save_cc, neighbour);
              stack_set(pred_explain, neighbour, target);
              assert(rear < (stack_size(NODES) * 2) - 1);
              stack_push(queue, neighbour);
              rear++;
            }
        }
    }
  stack_reset(queue);
  stack_free(queue);
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief This function do the Depth-first search and save all
   the elements of the class of node in the stack save_cc
   \param node0 the starting point in the graph */
static void
DFS(Tnode node)
{
  unsigned i;
  Tnode source, current;
  stack_push(pending, node);
  while (!stack_is_empty(pending))
    {
      source = stack_pop(pending);
      if (!stack_get(NODES, source).visited)
        stack_push(save_cc, source);
      stack_get(NODES, source).visited = true;
      for (i = 0; i < stack_get(NODES, source).nbedges; i++)
        {
          current = stack_get(NODES, source).edges[i].node;
          if (condition_edge(current, source, i))
            stack_push(pending, current);
        }
    }
}

/*--------------------------------------------------------------*/

#ifdef LIGHT_DEBUG
static void
print(Tnode node)
{
  Tnode current;
  printf("CC[");
  (get_DAG(get_repr(node)))?DAG_print(get_DAG(get_repr(node))):printf("--");
  printf("]:{ ");
  DFS(node);
  while (!stack_is_empty(save_cc))
    {
      current = stack_pop(save_cc);
      if (stack_get(NODES, current).nbedges > 0 && get_DAG(current))
        {
          DAG_print(get_DAG(current));
          printf(", ");
        }
      else if (current == node_true)
        printf(" true, ");
      stack_get(NODES, current).visited = false;
    }
  printf("}\n");
}
#endif
static void
print_element(Tnode_app_infos node_app)
{
  printf("[");
  DAG_print(node_app.DAG);
  printf(" %d %d ]", node_app.position, node_app.node);
}
/*
  --------------------------------------------------------------
  Terms construction
  --------------------------------------------------------------
*/

/**
   \author Daniel El Ouraoui
   \brief initialize an empty application node */
static Tnode_app_infos
empty_node_app()
{
  Tnode_app_infos node;
  node.DAG = DAG_NULL;
  node.position = -1;
  node.node = NODE_NULL;
  return node;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief initialize an empty node */
static TSnode
empty_node()
{
  TSnode node;
  node.type = EMPTY;
  node.repr = -1;
  node.nbparents = 0;
  node.parents = NULL;
  node.nbedges = 0;
  node.edges = NULL;
  node.visited = false;
  return node;
}

/**
   \author Daniel El Ouraoui
   \brief Take the id of the node and the of its parent
   and record idDAG as the parent of idDAGpred
   \param Tnode The first parent of idnode
   \param Tnode The children of idnodepred */
static void
record_parent(Tnode idnodepred, Tnode idnode)
{
  unsigned j = 0;
  /* my_DAG_message("%D{%d} <<- %D{%d}\n", */
  /*                get_DAG(idnode), (idnode), get_DAG(idnodepred), (idnodepred)); */
  assert(idnodepred > 0 && idnodepred < stack_size(NODES));
  assert(idnode > 0 && idnode < stack_size(NODES));
  if (DAG_symb(get_DAG(idnode)) == PREDICATE_EQ) return;
  if (stack_get(NODES, idnodepred).nbparents > 0)
    {
      for (j = 0; j < stack_get(NODES, idnodepred).nbparents; j++)
        if (stack_get(NODES, idnodepred).parents[j] == idnode)
          break;
      if (j > 0 && j == stack_get(NODES, idnodepred).nbparents)
        {
          MY_REALLOC(stack_get(NODES, idnodepred).parents,
                     (sizeof(Tnode) * (stack_get(NODES, idnodepred).nbparents + 1)));
          stack_get(NODES, idnodepred).
            parents[stack_get(NODES, idnodepred).nbparents] = idnode;
          /**< update parents of the class **/
          stack_get(NODES, idnodepred).nbparents++;
        }
      return;
    }
  else
    {
      assert(stack_get(NODES, idnodepred).parents == NULL);
      assert(stack_get(NODES, idnodepred).nbparents == 0);
      MY_MALLOC(stack_get(NODES, idnodepred).parents, sizeof(Tnode));
      stack_get(NODES, idnodepred).
        parents[stack_get(NODES, idnodepred).nbparents] = idnode;
      /**< update parents of the class **/
      stack_get(NODES, idnodepred).nbparents++;
    }
  assert(stack_get(NODES, idnodepred).parents);
  assert(stack_get(NODES, idnodepred).nbparents > 0);
  assert(stack_get(NODES, idnodepred).
         parents[stack_get(NODES, idnodepred).nbparents - 1] == idnode);
}


/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief the order function compare_terms decide
   given two DAG u and v if u is greater, less or equal to v
   \param u a the first DAG to compare
   \param posu is the position on u between 0 and arity(u) - 1 for example on u = (f a b)
   if I give the position 0 then the corresponding term is (f a) and (f a b) for 1
   \param v a the second DAG to compare
   \param posv the position on v
   \return -1 if u < v, 0 u = v and 1 if u > v */
static int
compare_fuction(TDAG u, unsigned posu,
                TDAG v, unsigned posv,
                bool class_cmp)
{
  unsigned i;
  if (DAG_symb(u) == DAG_symb(v) &&
      (DAG_arity(v) != DAG_arity(u)) && posu == posv)
    {
      /* my_DAG_message("%D %D\n", u, v); */
      for (i = 0; i <= posu; i++)
        {
          if (class_cmp)
            {
              if (!are_connected(get_node(DAG_arg(u, i)),
                                 get_node(DAG_arg(v, i))))
                break;
            }
          else
            {
              if (DAG_arg(u, i) != DAG_arg(v, i))
                break;
            }
        }
      if (i == posu + 1)
        return 0;
      if (class_cmp)
        {
          if (class(DAG_arg(u, i)) < class(DAG_arg(v, i)))
            return -1;
          else
            return 1;
        }
      else
        {
          if (DAG_arg(u, i) < DAG_arg(v, i))
            return -1;
          else
            return 1;
        }
    }
  if (DAG_arity(u) == DAG_arity(v) && !DAG_arity(v))
    {
      /* my_DAG_message("[COMPARE FUNCTION] %D %D\n", u, v); */
      if (class(u) == class(v))
        return 0;
      else if (DAG_symb(u) < DAG_symb(v))
        return -1;
      else
        return 1;
    }
  else if (DAG_arity(u) == DAG_arity(v))
    {
      if (DAG_symb(u) < DAG_symb(v))
        return -1;
      else if (DAG_symb(u) > DAG_symb(v))
        return 1;
      else if (posv == posu)
        {
          /* if (posu >= DAG_arity(u)) */
            /* my_DAG_message("%D %D %d:%d\n", u, v, posu, DAG_arity(u)); */
          for (i = 0; i <= posu /* && i < DAG_arity(u) */; i++)
            {
              if (class_cmp)
                {
                  if (!are_connected(get_node(DAG_arg(u, i)),
                                     get_node(DAG_arg(v, i))))
                    break;
                }
              else
                {
                  if (DAG_arg(u, i) != DAG_arg(v, i))
                    break;
                }
            }
          if (i == posu + 1 /* || i == DAG_arity(u) */)
            return 0;
          if (class_cmp)
            {
              if (class(DAG_arg(u, i)) < class(DAG_arg(v, i)))
                return -1;
              else
                return 1;
            }
          else
            {
              if (DAG_arg(u, i) < DAG_arg(v, i))
                return -1;
              else
                return 1;
            }
        }
      else if (posu < posv)
        return -1;
      else
        return 1;
    }
  else if (DAG_arity(u) < DAG_arity(v))
    return -1;
  else
    return 1;
}

/*--------------------------------------------------------------*/

static int
compare_terms_params(TDAG u, unsigned posu,
                     Tsymb symb, Tstack_DAG params, unsigned posv)
{
  unsigned i;
  if (DAG_symb(u) == symb &&
      (DAG_arity(u) != stack_size(params)) && posu == posv)
    {
      /* my_DAG_message("%D %D\n", u, v); */
      for (i = 0; i <= posu; i++)
        if (!are_connected(get_node(DAG_arg(u, i)),
                           get_node(stack_get(params, i))))
          break;
      if (i == posu + 1)
        return 0;
      if (class(DAG_arg(u, i)) < class(stack_get(params, i)))
        return -1;
      else
        return 1;
    }
  if (DAG_arity(u) == stack_size(params) && !DAG_arity(u))
    {
      if (DAG_symb(u) == symb)
        return 0;
      else if (DAG_symb(u) < symb)
        return -1;
      else
        return 1;
    }
  if (DAG_arity(u) == stack_size(params))
    {
      if (DAG_symb(u) < symb)
        return -1;
      else if (DAG_symb(u) > symb)
        return 1;
      else if (posv == posu)
        {
          for (i = 0; i <= posu; i++)
            if (!are_connected(get_node(DAG_arg(u, i)),
                               get_node(stack_get(params, i))))
              break;
          if (i == posu + 1)
            return 0;
          if (class(DAG_arg(u, i)) < class(stack_get(params, i)))
            return -1;
          else
            return 1;
        }
      else if (posu < posv)
        return -1;
      else
        return 1;
    }
  else if (DAG_arity(u) < stack_size(params))
    return -1;
  else
    return 1;
}

/*--------------------------------------------------------------*/

static int
compare_terms(TDAG u, unsigned posu, TDAG v, unsigned posv)
{
  return compare_fuction(u, posu, v, posv, false);
}

static int
compare_terms_by_terms(Tnode_app_infos *u, Tnode_app_infos *v)
{
  return compare_fuction(u->DAG, u->position, v->DAG, v->position, false);
}

static int
compare_terms_by_class(Tnode_app_infos *u, Tnode_app_infos *v)
{
  return compare_fuction(u->DAG, u->position, v->DAG, v->position, true);
}

/*--------------------------------------------------------------*/

static unsigned
linear_search(TDAG u, unsigned position, Tstack_DAG params)
{
  unsigned top = stack_size(app_table), i;
  if (stack_is_empty(app_table)) return UINT_MAX;
  for (i = 0; i < top; i++)
    {
      if (params)
        {
          if (!compare_terms_params(stack_get(app_table, i).DAG,
                                    stack_get(app_table, i).position, u, params, position))
            return i;
        }
      else
        {
          if (!compare_terms(u, position,
                             stack_get(app_table, i).DAG,
                             stack_get(app_table, i).position))
            return  i;
        }
    }
  return UINT_MAX;
}

static unsigned
dicho_search(TDAG u, unsigned position, Tstack_DAG params,
             int (*f)(TDAG, unsigned, TDAG, unsigned),
             int (*g)(TDAG, unsigned, Tsymb, Tstack_DAG, unsigned))
{
  int compare;
  int top = stack_size(app_table) - 1, bot = 0, middle;
  if (stack_is_empty(app_table)) return UINT_MAX;
  while (bot <= top)
    {
      middle = bot + (top - bot) / 2;
      if (params)
        compare = g(stack_get(app_table, middle).DAG,
                    stack_get(app_table, middle).position, u, params, position);
      else
        compare = f(stack_get(app_table, middle).DAG,
                    stack_get(app_table, middle).position, u, position);
      if (compare == 0)
        return middle;
      else if (compare == 1)
        top = middle - 1;
      else
        bot = middle + 1;
    }
  return linear_search(u, position, params);
}


/**
   \author Daniel El Ouraoui
   \param u a DAG of the veriT representation
   \param position the position on u
   \return the id of the node in the intern representation (app_table) or
   UINT_MAX if it doesn't appear in the signature */
static unsigned
exists_node_app(TDAG u, unsigned position)
{
  return dicho_search(u, position, NULL, compare_terms, NULL);
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief compute a new size for stack if any and
   initialize all new case to NODE_NULL
   \param stack a DAG of the veriT representation
   \param size the position on u */
static void
resize_signature(Tstack_node *stack, unsigned size)
{
  unsigned previous_size, i;
  if (stack_is_empty(*stack))
    {
      stack_inc_n(*stack,  size);
      for (i = 0; i < size; i++)
        stack_set(*stack, i, NODE_NULL);
    }
  else if (stack_size(*stack) < size)
    {
      previous_size = stack_size(*stack);
      stack_inc_n(*stack,  (size - previous_size));
      for (i = previous_size; i < size; i++)
        stack_set(*stack, i, NODE_NULL);
    }
}

/*--------------------------------------------------------------*/

TDAG
CCS_sig_query_params(Tsymb symb, Tstack_DAG params)
{
  unsigned query;
  if (first)
    {
      stack_sort(app_table, compare_terms_by_class);
      first = false;
    }
  query = dicho_search(symb, stack_size(params) - 1,
                       params, NULL, compare_terms_params);
  if (query == UINT_MAX || query + 1  > stack_size(app_table))
    return DAG_NULL;
  if (DAG_sort(class(stack_get(app_table, query).DAG)) != DAG_sort(stack_get(app_table, query).DAG))
    return DAG_NULL;
  assert(DAG_sort(class(stack_get(app_table, query).DAG)) == DAG_sort(stack_get(app_table, query).DAG));
  return class(stack_get(app_table, query).DAG);
}

/**
   \author Daniel El Ouraoui
   \brief insert a new term in the intern signature for application
   \param u a DAG of the veriT representation
   \param position the position on u */
static void
insert_node_app(TDAG u, unsigned position)
{
  unsigned k = 0;
  stack_push(node_to_DAG, u);
  if (!stack_is_empty(app_table))
    for (k = 0; k < stack_size(app_table) &&
           compare_terms(stack_get(app_table, k).DAG,
                         stack_get(app_table, k).position, u, position) != 1 ; k++);
  stack_insert(app_table, empty_node_app(), k);
  stack_get(app_table, k).DAG = u;
  stack_get(app_table, k).position = position;
  stack_get(app_table, k).node = stack_size(NODES) - 1;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief set a node to the corresponding values
   \param u a DAG of the veriT representation
   \param position the position on u
   \param type the type of the node application, constant, lambda,...
   \param sonl the left sons of u in the case of lambda and app
   \param sonl the right sons of u in the case of app
   \return the fresh node associate to the DAG u
   \remark in the case of u is constant symbol but is the symbol of function we give
   sonl not null to know that the node associate to u should not appear in node_to_DAG */
static Tnode
set_node(TDAG u, unsigned position, Tnode_type type, Tnode sonl, Tnode sonr)
{
  stack_push(NODES, empty_node());
  Tnode node = stack_size(NODES) - 1;
  if (type == APP)
    {
      insert_node_app(u, position);
      stack_top(NODES).sons[0] = sonl;
      stack_top(NODES).sons[1] = sonr;
      /* my_DAG_message("%D{%d} %d <<- %D{%d} [%d]\n", */
      /*                get_DAG(sonl), sonl, stack_get(NODES, sonl).type, get_DAG(node), node, type); */
      /* my_DAG_message("%D{%d} %d <<- %D{%d} [%d]\n", */
      /*                get_DAG(sonr), sonr, stack_get(NODES, sonr).type, get_DAG(node), node, type); */
      record_parent(stack_top(NODES).sons[0], node);
      record_parent(stack_top(NODES).sons[1], node);
    }
  else if (type == LAM)
    {
      stack_top(NODES).sons[0] = sonl;
      record_parent(stack_top(NODES).sons[0], node);
    }
  else
    {
      resize_signature(&symb_to_node, DAG_symb(u) + 1);
      resize_signature((Tstack_node *)&node_to_symb, stack_size(NODES));
      resize_signature((Tstack_node *)&node_to_DAG, stack_size(NODES));
      stack_set(symb_to_node, DAG_symb(u), node);
      stack_set(node_to_symb, node, DAG_symb(u));
      stack_set(node_to_DAG,  node, /* (sonl)?DAG_NULL: */u);
      /* my_DAG_message("%D %d\n", u, (sonl)?DAG_NULL:u); */
    }
  if (u && /* (DAG_symb_type(DAG_symb(u)) & SYMB_INJECTIVE) || */
      (DAG_symb_type(DAG_symb(u)) & SYMB_CONSTRUCTOR))
    stack_top(NODES).injective = true;
  else
    stack_top(NODES).injective = false;
  stack_top(NODES).type = type;
  stack_top(NODES).added = false;
  stack_top(NODES).asserted = 0;
  stack_top(NODES).repr = node;
  stack_top(NODES).position = position;
  stack_top(NODES).diseqs = NULL;
  stack_top(NODES).symbols = 0;
  stack_top(NODES).boolean_value = UNDEFINED;
  stack_top(NODES).DAG_arith = DAG_NULL;
  return stack_size(NODES) - 1;
}


/*
  --------------------------------------------------------------
  Backtrack prototypes
  --------------------------------------------------------------
*/

static void backtrack_store_quantified(void);
static void backtrack_status(void);
static void backtrack_undef_p(Tnode DAG);
static inline void backtrack_union_conflict(Tnode u, Tnode v, Tedge_type type);
static void backtrack_union(Tnode u, Tnode v, Tedge_type edge_type, bool adding, unsigned level);
/*--------------------------------------------------------------*/

static unsigned
compute_level(Tnode u, Tnode v)
{
  bool active = false;
  unsigned i, k, level[2], lit[2];
  Tnode traveler;
  level[0] = level[1] = lit[0] = lit[1] =0;
#ifdef DEBUG_BACKTRACK
  my_DAG_message(" compute_level(%D, %D) \n", get_DAG(u), get_DAG(v));
#endif
  for (k = 0; k < 2; k++)
    {
      traveler = stack_get(NODES, v).sons[k];
      BFS(stack_get(NODES, u).sons[k]);
      while (stack_get(pred_explain, traveler) != -1)
        {
          for (i = 0; i < stack_get(NODES, traveler).nbedges; i++)
            {
              if (stack_get(NODES, traveler).edges[i].node ==
                  stack_get(pred_explain, traveler) &&
                  stack_get(NODES, traveler).edges[i].level >= level[k])
                {
                  active = true;
                  level[k] = stack_get(NODES, traveler).edges[i].level;
                  lit[k] = stack_get(NODES, traveler).edges[i].lit;
                }
            }
          traveler = stack_get(pred_explain, traveler);
        }
      clean_visited_node();
    }
  if (!active) return UINT_MAX;
  k = ((level[0] < level[1])?1:0);
  /* my_DAG_message(" compute_level(%D, %D) level:%d %d cause: %D\n", */
  /*                get_DAG(u), get_DAG(v), level[k], backtrack_level, var_to_DAG(lit_var(lit[k]))); */
  assert(level[k] != UINT_MAX);
  return level[k];
}

static void CCS_merge(Tnode u, Tnode v, Tlit lit, bool adding);

static void
add_node(Tnode idnode, unsigned id_table)
{
  assert(id_table < stack_size(app_table));
  Tstack_node query_nodes;
  unsigned i, imax = id_table, imin = id_table, level,
    level_min = UINT_MAX,
    position = stack_get(app_table, id_table).position;
  Tnode query_node = 0;
  TDAG DAG = stack_get(app_table, id_table).DAG;
  stack_INIT(query_nodes);
  for (;imax < stack_size(app_table) &&
         DAG_symb(DAG) == DAG_symb(stack_get(app_table, imax).DAG) &&
         stack_get(app_table, imax).position == position; imax++);
  for (;imin > 0 &&
         DAG_symb(DAG) == DAG_symb(stack_get(app_table, imin).DAG) &&
         stack_get(app_table, imin).position == position; imin--);
  for (i = imin; i < imax; i++)
    if (stack_get(app_table, i).node != idnode &&
        cong(stack_get(app_table, i).node, idnode))
      stack_push(query_nodes, stack_get(app_table, i).node);
  for (i = 0; i < stack_size(query_nodes); i++)
    {
      level = compute_level(idnode, stack_get(query_nodes, i));
      if (level <= level_min)
        {
          query_node = stack_get(query_nodes, i);
          level_min = level;
        }
    }
  if (query_node && !exists_edge(query_node, idnode, EQ))
    {
      stack_get(NODES, idnode).added = true;
      if (level_min != UINT_MAX)
        CCS_merge(idnode, query_node, level_min, true);
      else
        CCS_merge(idnode, query_node, 0, false);
    }
  stack_reset(query_nodes);
  stack_free(query_nodes);
}

/**
   \author Daniel El Ouraoui
   \brief given a DAG u create a fresh node
   \param u a DAG of the veriT representation */
static void
create_node(TDAG u, bool add)
{
  unsigned i;
  Tnode idnode, idnodepred;
  /* my_DAG_message("[new node] %D\n", u); */
  if (DAG_symb(u) == LAMBDA && !get_node(u))
    {
      create_node(DAG_arg(u, (DAG_arity(u) - 1)), add);
      idnode = set_node(u, 0, LAM,
                        get_node(DAG_arg(u, (DAG_arity(u) - 1))), NODE_NULL);
    }
  else if (DAG_arity(u) > 0 && !get_node(u))
    {
      if (!get_node_from_symb(DAG_symb(u))) /**< create f a1 **/
        set_node(u, 0, CONST, 1, NODE_NULL);
      create_node(DAG_arg(u, 0), add); /**< create the node a1 */
      idnode = exists_node_app(u, 0);
      if (idnode == UINT_MAX)
        {
          idnode = set_node(u, 0, APP, get_node_from_symb(DAG_symb(u)),
                            get_node(DAG_arg(u, 0)));
          if (add && DAG_symb(u) != PREDICATE_EQ)
            add_node(idnode, exists_node_app(u, 0));
        }
      else
        idnode = stack_get(app_table, idnode).node;
      for (i = 1; i < DAG_arity(u); i++)
        {
          idnodepred = idnode;
          create_node(DAG_arg(u, i), add);
          idnode = exists_node_app(u, i);
          if (idnode != UINT_MAX)
            {
              idnode = stack_get(app_table, idnode).node;
              record_parent(stack_get(NODES, idnode).sons[0], idnode);
              record_parent(stack_get(NODES, idnode).sons[1], idnode);
              continue;
            }
          idnode = set_node(u, i, APP, idnodepred, get_node(DAG_arg(u, i)));
          /* record_parent(idnodepred, idnode); */
          assert(exists_node_app(u, i) != UINT_MAX);
          if (add && DAG_symb(u) != PREDICATE_EQ)
            add_node(idnode, exists_node_app(u, i));
        }
      resize_signature(&DAG_to_node, u + 1);
      /* */resize_signature((Tstack_node *)&node_to_DAG, stack_size(NODES));
      stack_set(DAG_to_node, u, idnode);
      /* */stack_set(node_to_DAG,  idnode, u);
    }
  else if (!get_node(u))
    {
      set_node(u, 0, CONST, NODE_NULL, NODE_NULL);
    }
}

/*
  --------------------------------------------------------------
  Graph construction
  --------------------------------------------------------------
*/

static void
create_edge(Tnode u, Tnode v, Tedge_type type, Tlit lit, unsigned level)
{
  if (v == node_true) return;
  assert(exists_node(u));
  assert(exists_node(v));
  if (stack_get(NODES, u).nbedges == 0)   /**< Connect u to v */
    {
      assert(!stack_get(NODES, u).edges);
      MY_MALLOC(stack_get(NODES, u).edges, sizeof(Tedge));
    }
  else
    {
      assert(stack_get(NODES, u).nbedges > 0);
      assert(stack_get(NODES, u).edges);
      MY_REALLOC(stack_get(NODES, u).edges, sizeof(Tedge) *
                 (stack_get(NODES, u).nbedges + 1));
    }
  assert(stack_get(NODES, u).edges);
  stack_get(NODES, u).edges[stack_get(NODES, u).nbedges].node = v;
  stack_get(NODES, u).edges[stack_get(NODES, u).nbedges].type = type;
  stack_get(NODES, u).edges[stack_get(NODES, u).nbedges].level = level;
  stack_get(NODES, u).edges[stack_get(NODES, u).nbedges].pending_congs = 0;
  stack_get(NODES, u).edges[stack_get(NODES, u).nbedges++].lit = lit;
  if (stack_get(NODES, v).nbedges == 0) /**< connect v to u */
    {
      assert(!stack_get(NODES, v).edges);
      MY_MALLOC(stack_get(NODES, v).edges, sizeof(Tedge));
    }
  else
    {
      assert(stack_get(NODES, v).nbedges > 0);
      assert(stack_get(NODES, v).edges);
      MY_REALLOC(stack_get(NODES, v).edges, sizeof(Tedge) *
                 (stack_get(NODES, v).nbedges + 1));
    }
  assert(stack_get(NODES, v).edges);
  stack_get(NODES, v).edges[stack_get(NODES, v).nbedges].node = u;
  stack_get(NODES, v).edges[stack_get(NODES, v).nbedges].type = type;
  stack_get(NODES, v).edges[stack_get(NODES, v).nbedges].level = level;
  stack_get(NODES, v).edges[stack_get(NODES, v).nbedges].pending_congs = 0;
  stack_get(NODES, v).edges[stack_get(NODES, v).nbedges++].lit = lit;
#ifdef LIGHT_DEBUG_BACK
  if (DAG_symb(get_DAG(u)) != PREDICATE_EQ)
    my_DAG_message(" create_edge  %D[%D]({%d}-|%d) o-- %s(%d) --o %D[%D]({%d}-|%d)\n",
                   get_DAG(u), get_DAG(get_repr(u)), u, stack_get(NODES, u).nbedges,
                   edgetype_to_string(type), level, 
                   get_DAG(v), get_DAG(get_repr(v)), v, stack_get(NODES, v).nbedges);
#endif
}

/*--------------------------------------------------------------*/

static void
swap_pair(Tnode u, unsigned i)
{
  Tedge tmp;
  assert(stack_get(NODES, u).nbedges > i + 1);
  tmp.node = stack_get(NODES, u).edges[i].node;
  tmp.type = stack_get(NODES, u).edges[i].type;
  tmp.level = stack_get(NODES, u).edges[i].level;
  tmp.pending_congs = stack_get(NODES, u).edges[i].pending_congs;
  tmp.lit  = stack_get(NODES, u).edges[i].lit;

  stack_get(NODES, u).edges[i].node = stack_get(NODES, u).edges[i + 1].node;
  stack_get(NODES, u).edges[i].type = stack_get(NODES, u).edges[i + 1].type;
  stack_get(NODES, u).edges[i].level = stack_get(NODES, u).edges[i + 1].level;
  stack_get(NODES, u).edges[i].pending_congs =
    stack_get(NODES, u).edges[i + 1].pending_congs;
  stack_get(NODES, u).edges[i].lit  =
    stack_get(NODES, u).edges[i + 1].lit;
  stack_get(NODES, u).edges[i + 1].node = tmp.node;
  stack_get(NODES, u).edges[i + 1].type = tmp.type;
  stack_get(NODES, u).edges[i + 1].level = tmp.level;
  stack_get(NODES, u).edges[i + 1].pending_congs = tmp.pending_congs;
  stack_get(NODES, u).edges[i + 1].lit  = tmp.lit;
}

/*--------------------------------------------------------------*/

static void
remove_edge(Tnode u, Tnode v, Tedge_type type)
{
  unsigned i, j, k;
  if (v == node_true) return;
#ifdef DEBUG_SIMPLE_CC
  my_DAG_message(" remove_edge (= %D %D)\n",  get_DAG(u), get_DAG(v));
#endif
  assert(exists_node(u));
  assert(exists_node(v));
  assert(stack_get(NODES, u).edges);
  assert(stack_get(NODES, v).edges);
  assert(stack_get(NODES, u).nbedges > 0);
  assert(stack_get(NODES, v).nbedges > 0);
  for (i = 0; i < stack_get(NODES, u).nbedges; i++)
    {
      assert(exists_node(stack_get(NODES, u).edges[i].node));
      if (stack_get(NODES, u).edges[i].node == v &&
          stack_get(NODES, u).edges[i].type == type )
        break;
    }
  for (j = 0; j < stack_get(NODES, v).nbedges; j++)
    {
      assert(exists_node(stack_get(NODES, v).edges[j].node));
      if (stack_get(NODES, v).edges[j].node == u &&
          stack_get(NODES, v).edges[j].type == type)
        break;
    }
#ifdef LIGHT_DEBUG
  if (j == stack_get(NODES, v).nbedges)
    printf("OUT of bound\n");
#endif
  for (k = i; k < stack_get(NODES, u).nbedges - 1; k++)
    swap_pair(u, k);
  for (k = j; k < stack_get(NODES, v).nbedges - 1; k++)
    swap_pair(v, k);
  MY_REALLOC(stack_get(NODES, u).edges, sizeof(Tedge) *
             (stack_get(NODES, u).nbedges - 1));
  MY_REALLOC(stack_get(NODES, v).edges, sizeof(Tedge) *
             (stack_get(NODES, v).nbedges - 1));
  stack_get(NODES, u).nbedges--;
  stack_get(NODES, v).nbedges--;
  if (!stack_get(NODES, u).nbedges)
    stack_get(NODES, u).edges = NULL;
  if (!stack_get(NODES, v).nbedges)
    stack_get(NODES, v).edges = NULL;
  assert(stack_get(NODES, u).nbedges >= 0);
  assert(stack_get(NODES, v).nbedges >= 0);
}

/*
  --------------------------------------------------------------
  Conflicts
  --------------------------------------------------------------
*/

static Tnode cNODE0 = NODE_NULL, cNODE1 = NODE_NULL;
static bool clash_conflict = false;
static bool cycle_conflict = false;
/**
   \brief throw conflict **/
static inline void
conflict_throw(void)
{
  CCS_status = UNSAT;
  backtrack_status();
}

/**
   \brief store information for conflict on predicates
   \param DAG0 first predicate
   \param DAG1 second predicate
   \remark DAG0 occurs positively, DAG1 negatively */
static inline void
conflict_rec(Tnode NODE0, Tnode NODE1)
{
  cNODE0 = NODE0;
  cNODE1 = NODE1;
}

/*
  --------------------------------------------------------------
  Watch
  --------------------------------------------------------------

*/
static inline bool
is_in_formula(Tnode node)
{
  if (stack_get(NODES, node).type == CONST) return true;
  return (DAG_arity(get_DAG(node)) - 1 == get_position(node) &&
          DAG_symb(get_DAG(node)) != PREDICATE_EQ
          && !stack_get(NODES, node).added);
}

static inline void
hint_p(Tnode node, bool bool_value, Tnode src)/**< propagate theory to SAT solver **/
{
  Tnode current;
  if (!is_in_formula(src)) return;
  DFS(node);
  while (!stack_is_empty(save_cc))
    {
      current = stack_pop(save_cc);
      stack_get(NODES, current).visited = false;
      if (is_in_formula(current))
        hint_CC(lit_make(DAG_to_var(get_DAG(current)), bool_value),
                get_DAG(src), false);
    }
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief find_first_asserted is used in the case where
   u is involved in predicate conflict. Then the function
   try to figured out the asserted node u' congruent with u.
   \param u is node associate with a conflicting predicate  */
static Tnode
find_first_asserted(Tnode u)
{
  unsigned i, max = 0;
  Tnode source, result = NODE_NULL, currentnode;
#ifdef LIGHT_DEBUG_
  my_DAG_message("present: %D\n", get_DAG(u));
#endif
  assert(stack_is_empty(pending));
  assert(stack_is_empty(save_cc));
  stack_push(pending, u);
  while (!stack_is_empty(pending))
    {
      source = stack_pop(pending);
      if (!stack_get(NODES, source).visited)
        stack_push(save_cc, source);
      stack_get(NODES, source).visited = true;
      for (i = 0; i < stack_get(NODES, source).nbedges; i++)
        {
          currentnode = stack_get(NODES, source).edges[i].node;
#ifdef LIGHT_DEBUG_
          my_DAG_message("%D -- %d --> %D\n", get_DAG(source),
                         stack_get(NODES, currentnode).asserted, get_DAG(currentnode));
#endif
          if (u != currentnode &&
              stack_get(NODES, currentnode).asserted >= max &&
              (stack_get(NODES, source).edges[i].type == CONG ||
               stack_get(NODES, source).edges[i].type == INJ))
            {
              result = currentnode;
              max = stack_get(NODES, currentnode).asserted;
            }
          if ((stack_get(NODES, source).edges[i].type == CONG ||
               stack_get(NODES, source).edges[i].type == INJ) &&
              !stack_get(NODES, currentnode).visited)
            stack_push(pending, currentnode);
        }
    }
  clean_visited_node();
  if (!result && stack_get(NODES, u).asserted)
    return u;
  if (result)
    return result;
  else return u;
}

static Tlit
find_first_asserted_eq(Tnode u)
{
  unsigned i;
  Tnode source, result = NODE_NULL, currentnode;
  Tlit lit = 0;
#ifdef LIGHT_DEBUG_
  my_DAG_message("present: %D\n", get_DAG(u));
#endif
  assert(stack_is_empty(pending));
  assert(stack_is_empty(save_cc));
  stack_push(pending, u);
  while (!stack_is_empty(pending))
    {
      source = stack_pop(pending);
      if (!stack_get(NODES, source).visited)
        stack_push(save_cc, source);
      stack_get(NODES, source).visited = true;
      for (i = 0; i < stack_get(NODES, source).nbedges; i++)
        {
          currentnode = stack_get(NODES, source).edges[i].node;
#ifdef LIGHT_DEBUG_
          my_DAG_message("%D -- %d --> %D\n", get_DAG(source),
                         stack_get(NODES, currentnode).asserted, get_DAG(currentnode));
#endif
          if (u != currentnode &&
              /* stack_get(NODES, currentnode).asserted >= max && */
              stack_get(NODES, source).edges[i].lit)
            {
              result = currentnode;
              lit = stack_get(NODES, source).edges[i].lit;
            }
          if (!stack_get(NODES, currentnode).visited)
            stack_push(pending, currentnode);
        }
    }
  clean_visited_node();
  if (!result && stack_get(NODES, u).asserted)
    return 0;
  if (result)
    return lit;
  else return 0;
}

static bool
clash(Tnode u, Tnode v, Tedge_type type)
{
  return
    stack_get(NODES, u).injective &&
    stack_get(NODES, v).injective &&
    /* is_in_formula(u) && */
    /* is_in_formula(v) && */
    DAG_symb(get_DAG(u)) != DAG_symb(get_DAG(v)) &&
    (type == EQ || type == CONG  || type == INJ);
}

/**
   \author Daniel El Ouraoui
   \brief this function update all the representative of u,
   propagate the polarity of the class of v to all elements of
   u, record all parents of class u and v and try to figured out a conflict if any.
   \param u the left hand-side of the equality and where representative
   of u is different of representative of v
   \param v the right hand-side of the equality
   \param repr_u is the old representative of the class of u */
static void
update_class(Tnode u, Tnode v, Tnode repr_u,
             Tnode node0, Tstack_node *ccpar_u, Tstack_node *ccpar_v,
             Tstack_node *cc)
{
  unsigned i, j;
  Tstack_node clash_stack;
  Tnode source, currentnode;
#ifndef DISABLE_THEORY_PROPAGATION
  Tboolean_value bvalue_u = bvalue(u);
#endif
  stack_INIT(clash_stack);
  assert(stack_is_empty(pending));
  assert(stack_is_empty(save_cc));
  stack_push(pending, get_repr(u)); /**< first travel u **/
  stack_push(pending, get_repr(v)); /**< second travel v **/
  if (DAG_arith(u) && !DAG_arith(get_repr(v)))
    stack_get(NODES, get_repr(v)).DAG_arith = DAG_arith(u);
  while (!stack_is_empty(pending))
    {
      source = stack_pop(pending);
      if (!stack_get(NODES, source).visited)
        {
#ifdef INJ_FUN
          if (stack_get(NODES, source).type == APP &&
              stack_get(NODES, source).injective)
            stack_push(*cc, source);
          if (stack_get(NODES, source).injective)
            stack_push(clash_stack, source);
#endif
          /**< look if source is the representative node0**/
          /**< record the parents of source **/
          if (get_repr(source) == node0)
            {
              for (j = 0; j < stack_get(NODES, source).nbparents; j++)
                stack_push(*ccpar_u, stack_get(NODES, source).parents[j]);
            }
          else
            for (j = 0; j < stack_get(NODES, source).nbparents; j++)
              stack_push(*ccpar_v, stack_get(NODES, source).parents[j]);
#ifndef DISABLE_THEORY_PROPAGATION
          if (get_repr(source) == repr_u && bvalue_u != bvalue(v))
            {
              if (bvalue_u == UNDEFINED && (is_in_formula(source) && is_in_formula(v)))
                hint_CC(lit_make(DAG_to_var(get_DAG(source)), bvalue(v) ==  TRUE),
                        get_DAG(v), false);
            }
#endif
          /**< update representative for all element of [u] U [v] **/
          stack_get(NODES, source).repr = get_repr(v);
          stack_push(save_cc, source);
        }
      stack_get(NODES, source).visited = true;
      for (i = 0; i < stack_get(NODES, source).nbedges; i++)
        {
          currentnode = stack_get(NODES, source).edges[i].node;
          /**< check if any conflict appear when we merge [u] and [v]**/
          if ( (stack_get(NODES, source).edges[i].type == DISEQ &&
              (get_repr(source) == repr_u || get_repr(source) == get_repr(v)) &&
              (get_repr(currentnode) == repr_u ||
               get_repr(currentnode) == get_repr(v))))
            {
#ifdef LIGHT_DEBUG
              my_DAG_message(" [conflict from %D = %D] (%D %D) :: ",
                             get_DAG(u), get_DAG(v),
                             get_DAG(u), get_DAG(currentnode));
              DAG_print(var_to_DAG(lit_var(stack_get(NODES, source).edges[i].lit)));
              printf(")\n");
#endif
              clash_conflict = false;
              clean_visited_node();
              stack_reset(pending);
              conflict_rec(NODE_NULL, stack_get(NODES, source).edges[i].lit);
              /**< record the litteral involved in the conflict
                 and change the statu to UNSAT**/
              conflict_throw();
              return;
            }
          if (((get_repr(source) == repr_u &&
                     get_repr(currentnode) == get_repr(v)) ||
                    (get_repr(source) == get_repr(v) &&
                     get_repr(currentnode) == repr_u)) &&
              (clash(source, currentnode, stack_get(NODES, source).edges[i].type)))
            {
              my_DAG_message(" [conflict from %D = %D] \n",
                             get_DAG(source), get_DAG(currentnode));
              clean_visited_node();
              stack_reset(pending);
              conflict_rec(source, currentnode);
              /**< record the litteral involved in the conflict
                 and change the statu to UNSAT**/
              clash_conflict = true;
              conflict_throw();
              return;
            }
          if (condition_edge(currentnode, source, i))
            stack_push(pending, currentnode);
        }
    }
  for (i = 0; i < stack_size(clash_stack); i++)
    {
      for (j = 0; j < stack_size(clash_stack); j++)
        {
          if (clash(stack_get(clash_stack, i), stack_get(clash_stack, j), EQ) &&
              !exists_edge(stack_get(clash_stack, i),
                          stack_get(clash_stack, j), DISEQ))
            {
              /* my_DAG_message(" [conflict from %D = %D] \n", */
              /*                get_DAG(stack_get(clash_stack, i)), */
              /*                get_DAG(stack_get(clash_stack, j))); */
              clean_visited_node();
              stack_reset(pending);
              conflict_rec(stack_get(clash_stack, i), stack_get(clash_stack, j));
              /**< record the litteral involved in the conflict
                 and change the statu to UNSAT**/
              clash_conflict = true;
              conflict_throw();
              return;
            }
        }
    }
  stack_reset(clash_stack);
  stack_free(clash_stack);
  clean_visited_node();
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief this function propagate the polarity if any where
   pol(u) = UNDEFINED xor  pol(v) = UNDEFINED. Otherwise in the case
   where pol(u) != pol(v) != UNDEFINED we detect a conflict and record
   the both conflicting predicates with find_first_asserted function.
   \param u node
   \param v node */
static int
set_bvalue(Tnode u, Tnode v, Tedge_type type, unsigned level, bool adding, Tlit lit)
{
  if (u != node_true && v != node_true && /**< case equivalent to CC_union_p **/
      bvalue(u) != bvalue(v)) /**< we are in the congruence case **/
    {
      if (bvalue(u) != bvalue(v))
        {
          if (bvalue(u) == UNDEFINED) /**< theory propagation case **/
            {
              conflict_message(u, v, 5);
              backtrack_union(u, v, type, adding, level);
              return false;
            }
          else if (bvalue(v) == UNDEFINED)  /** theory propagation case **/
            {
              conflict_message(u, v, 4);
              backtrack_union(v, u, type, adding, level);
              return true;
            }
          else if (bvalue(u) == FALSE) /**< conflict case **/
            {
              backtrack_union_conflict(u, v, type);
              conflict_rec(u, v);
              conflict_message(u, v, 3);
              conflict_throw();
              create_edge(u, v, type, lit, backtrack_level);
              return false;
            }
          else if (bvalue(u) == TRUE) /**< conflict case **/
            {
              backtrack_union_conflict(v, u, type);
              conflict_rec(v, u);
              conflict_message(v, u, 2);
              conflict_throw();
              create_edge(u, v, type, lit, backtrack_level);
              return false;
            }
        }
    }
  else if (v == node_true)/**< because predicate are only asserted at left */
    {
      /** equivalent to CC_set_p in the case of positive predicate **/
      if (bvalue(u) == UNDEFINED)  /**< propagate case **/
        { /**< give the litteral information to the sat solver 2 watch litterals **/
#ifndef DISABLE_THEORY_PROPAGATION_INCR
          hint_p(find_first_asserted(u), true, u);
#endif
          stack_get(NODES, u).asserted = level + 2u;
          backtrack_undef_p(u);
          stack_get(NODES, get_repr(u)).boolean_value = TRUE;
          return false;
        }
      else if (bvalue(u) == FALSE) /**< conflict case **/
        {
          conflict_rec(find_first_asserted(u), u);
          conflict_message(u, find_first_asserted(u), 1);
          conflict_throw();
          return false;
        }
    }
  else if (u != node_true  && v != node_true  && bvalue(u) != UNDEFINED &&
           bvalue(u) == bvalue(v))
    backtrack_union(u, v, type, adding, level);
  return false;
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief this function try to do the union of two classes [u] and [v]
   by create an edge between u and v if lit = 0 its a congruent
   edge otherwise its an equality
   \param u node
   \param v node
   \param lit the litteral  */
static void
CCS_union(Tnode u, Tnode v, Tlit lit, unsigned level, bool adding, Tedge_type type)
{
  unsigned i, j;
  Tpending_nodes deduction;
  Tstack_node ccpar_u, ccpar_v,
    /** implement injectivity **/
    cc;
  TDAG eq;
  Tnode currentu, currentv, node0, node1, other, tmp;
  if(set_bvalue(u, v, (lit)?EQ:CONG, level, adding, lit))
    {
      tmp = u;
      u = v;
      v = tmp;
    }
  /**< propagate the polarity or throw conflict if any where
     u and v are predicates **/
  if (v == node_true || CCS_status == UNSAT) return;
  if (DAG_arith(u) && DAG_arith(v) && backfire)
    { /**< says to arith module that u and v are shared **/
      veriT_xenqueue_type(XTYPE_CC_EQ);
      veriT_xenqueue_DAG(DAG_arith(v));
      veriT_xenqueue_DAG(DAG_arith(u));
    }
  stack_INIT(ccpar_u);
  stack_INIT(ccpar_v);
  stack_INIT(cc);
  /**< choose the right term to propagate inequalities u < v at the arith module
     this optimisation makes us win factor 5-7 times speed-up **/
  node0 = (((!DAG_arith(u)) != (!DAG_arith(v))) && DAG_arith(u))?
    get_repr(u):get_repr(v);
  node1 = (((!DAG_arith(u)) != (!DAG_arith(v))) && DAG_arith(u))?
    get_repr(v):get_repr(u);
  assert(node0 != node1);

  /**< update the new class [u] U [v] or throw conflict if any **/
  update_class(u, v, get_repr(u), node0, &ccpar_u, &ccpar_v, &cc);
  stack_get(NODES,  u).repr = get_repr(v);
  /**< create a new edge between u and v **/
  create_edge(u, v, type, lit, level);
  assert(get_repr(u) == get_repr(v));
  if (clash(u, v, EQ) /* && CCS_status != UNSAT */)
    {
      clean_visited_node();
      stack_reset(pending);
      conflict_rec(u, v);
      clash_conflict = true;
      conflict_throw();
      return;
    }

  if(CCS_status != UNSAT && stack_size(ccpar_v) && stack_size(ccpar_u))
    /**< stop the work if any conflict was appear before **/
    {
      for (i = 0; i < stack_size(ccpar_u); i++)   /**< Deduce rule */
        {
          for (j = 0; j < stack_size(ccpar_v); j++)
            {
              currentu = stack_get(ccpar_u, i);
              currentv = stack_get(ccpar_v, j);
              if (cong(currentu, currentv) &&
                  !are_connected(currentu,currentv))
                {
                  deduction.fst = currentu;
                  deduction.snd = currentv;
                  deduction.type = CONG;
                  deduction.lit = 0;
                  deduction.level = level;
                  stack_push(merge_queue, deduction);
                }
              if (i == 0 && (!DAG_arith(u)) != (!DAG_arith(v)) && (DAG_arith(node0)))
                {/** propagate inequalities to the arithmetic module **/
                  eq = get_DAG(currentv);
                  if (DAG_symb(eq) != PREDICATE_EQ ||
                      !exists_edge(get_node(DAG_arg0(eq)), get_node(DAG_arg1(eq)),
                                   DISEQ))
                    continue;
                  other = get_node((get_repr(get_node(DAG_arg0(eq))) == node1)?
                                   DAG_arg1(eq):DAG_arg0(eq));
                  if (DAG_arith(other))
                    {
                      veriT_xenqueue_type(XTYPE_CC_INEQ);
                      assert(!DAG_arith(get_node(DAG_arg0(eq))) ||
                             !DAG_arith(get_node(DAG_arg1(eq))));
                      veriT_xenqueue_DAG(DAG_arith(node0));
                      veriT_xenqueue_DAG(DAG_arith(other));
                    }
                }
            }
        }
      if (!DAG_arith(node0))/** propagate that now classes have both shared term
                                with arith theory **/
        stack_get(NODES, get_repr(node0)).DAG_arith = DAG_arith(node1);
      stack_reset(ccpar_u);
      stack_reset(ccpar_v);
    }
#ifdef INJ_FUN
  /* (cons (node (cons x3 x2)) x2) */
  /*   (cons (car (cons (node (cons x3 x2)) x2)) (cdr (cons (node (cons x3 x2)) x2))) */
  /**< Improve this part **/
  if (stack_size(cc))
    {
      for (i = 0; i < stack_size(cc); i++)   /**< Deduce rule */
        {
          for (j = i; j < stack_size(cc); j++)
            {
              if (i == j) continue;
              currentu = stack_get(cc, i);
              currentv = stack_get(cc, j);
              if (inj(currentu, currentv))
                {
                  if (!are_connected(stack_get(NODES, currentu).sons[0],
                                     stack_get(NODES, currentv).sons[0]))
                    {
                      deduction.fst = stack_get(NODES, currentu).sons[0];
                      deduction.snd = stack_get(NODES, currentv).sons[0];
                      deduction.type = INJ;
                      deduction.lit = 0;
                      deduction.level = level;
                      stack_push(merge_queue, deduction);
                    }
                  if (!are_connected(stack_get(NODES, currentu).sons[1],
                                     stack_get(NODES, currentv).sons[1]))
                    {
                      deduction.fst = stack_get(NODES, currentu).sons[1];
                      deduction.snd = stack_get(NODES, currentv).sons[1];
                      deduction.type = INJ;
                      deduction.lit = 0;
                      deduction.level = level;
                      stack_push(merge_queue, deduction);
                    }
                }
            }
        }
      stack_reset(cc);
    }
#endif
  stack_free(cc);
  stack_free(ccpar_u);
  stack_free(ccpar_v);
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief this function merge two class
   \param u node
   \param v node
   \param lit the litteral  */
static void
CCS_merge(Tnode u, Tnode v, Tlit lit, bool adding)
{
  unsigned k = 0;
  Tpending_nodes n;
  /* print(u); */
  /* print(v); */
  assert(exists_node(u));
  assert(exists_node(v));
  if (!are_connected(u, v))
    {
      /**< record u and v for backtrack **/
      if (bvalue(u) == UNDEFINED && bvalue(v) == UNDEFINED && v != node_true)
        backtrack_union(u, v, (adding)?CONG:((lit)?EQ:CONG),
                        adding, (adding)?lit:backtrack_level);
      CCS_union(u, v, (adding)?0:lit, (adding)?lit:backtrack_level, (adding),
                (adding)?CONG:((lit)?EQ:CONG));
    }
  backfire = true;
  if (v != node_true)
    assert(get_repr(u) == get_repr(v));
  while (k < stack_size(merge_queue) &&
         CCS_status != UNSAT)  /**< merge the deduced equality */
    {
      n = stack_get(merge_queue, k);
      assert(exists_node(n.fst));
      assert(exists_node(n.snd));
      if (!are_connected(n.fst, n.snd)) /**< do the union */
        {
          if (bvalue(n.fst) == UNDEFINED &&
              bvalue(n.snd) == UNDEFINED &&
              n.snd != node_true)
            backtrack_union(n.fst, n.snd, n.type, adding,
                            (adding)?n.level:backtrack_level);
          CCS_union(n.fst, n.snd, 0, (adding)?n.level:backtrack_level, adding, n.type);
#ifdef DEBUG_BACKTRACK
          my_DAG_message(" merge %D{%d:%d} %D{%d:%d} %s type %s \n",
                         get_DAG(n.fst), get_DAG(n.fst), n.fst,
                         get_DAG(n.snd), get_DAG(n.snd), n.snd,
                         boolval_to_string(bvalue(n.fst)),
                         edgetype_to_string(n.type));
#endif
        }

      assert(CCS_status == UNSAT || get_repr(n.fst) == get_repr(n.snd));
      k++;
    }
  stack_reset(merge_queue);
}

/*--------------------------------------------------------------*/

/**
   \author Daniel El Ouraoui
   \brief this function restore the representative repr and polarity to all
   elements of the graph of node
   \param node is one element of the graph 
   \param repr is the previous representative that we want restore to all
   element of the graph
   \param  bvalue_of_u the previous polarity */
static void
restore_class(Tnode node, Tnode repr)
{
  unsigned i;
  Tnode current;
  if (DAG_arith(node) && !DAG_arith(repr))
    stack_get(NODES, repr).DAG_arith = DAG_arith(node);
  DFS(node);
  for (i = 0; i < stack_size(save_cc); i++)
    {
      current = stack_get(save_cc, i);
      stack_get(NODES, current).visited = false;
      if (stack_get(NODES, current).nbedges > 0)
        stack_get(NODES, current).repr = repr;
    }
  stack_reset(save_cc);
}

/*--------------------------------------------------------------*/
/**
   \author Daniel El Ouraoui
   \brief this function undo the merge recorded in the backtrack stack
   \param u node
   \param v node
   \param type the type of the edge
   \param repr_u the old representative of u
   \param bvalue_of_u the old polarity of u
   \param bvalue_of_v the old polarity of v
   \param DAG_arith_of_u the old arithmetic shared term of u
   \param DAG_arith_of_v the old arithmetic shared term of v
   \remark we hold both because polarity pol(u) can be FALSE and before TRUE by
   congruence and UNDEFINED just before the congruence deduce and same for v */
static void
CCS_unmerge(Tnode u, Tnode v, Tedge_type type, Tnode repr_u,
            TDAG DAG_arith_of_u,  TDAG DAG_arith_of_v,
            unsigned type_unmerge)
{
  assert(exists_node(u));
  assert(exists_node(v));
  assert(v != node_true &&
         (type == EQ || type == CONG || type == INJ) && get_repr(u) == get_repr(v));
  remove_edge(u, v, type);
  restore_class(u, repr_u);
  stack_get(NODES, u).repr = repr_u;
  stack_get(NODES, get_repr(v)).DAG_arith = DAG_arith_of_v;
  stack_get(NODES, repr_u).DAG_arith = DAG_arith_of_u;
}

/*--------------------------------------------------------------*/

bool
injective_conflict(Tnode u, Tnode v, Tlit lit)
{
  unsigned i, j;
  Tnode current, currentu, currentv;
  Tstack_node check_u, check_v;
  stack_INIT(check_u);
  stack_INIT(check_v);
  DFS(u);
  while (!stack_is_empty(save_cc))
    {
      current = stack_pop(save_cc);
      stack_get(NODES, current).visited = false;
      stack_push(check_u, current);
    }
  DFS(v);
  while (!stack_is_empty(save_cc))
    {
      current = stack_pop(save_cc);
      stack_get(NODES, current).visited = false;
      stack_push(check_v, current);
    }
  for (i = 0; i < stack_size(check_u); i++)   /**< Deduce rule */
    {
      for (j = 0; j < stack_size(check_v); j++)
        {
          currentu = stack_get(check_u, i);
          currentv = stack_get(check_v, j);
          if (inj(currentu, currentv))
            {
              TDAG DAG1 = get_DAG(currentu);
              TDAG DAG2 = get_DAG(currentv);
              for (unsigned k = 0; k < DAG_arity(DAG1); k++)
                {
                  my_DAG_message("conflict %D %D\n",
                                 DAG_arg(DAG1, k), DAG_arg(DAG2, k));
                  if (are_connected(get_node(DAG_arg(DAG1, k)),
                                    get_node(DAG_arg(DAG2, k))) /* || */
                      /* (DAG_symb_type(DAG_symb(DAG_arg(DAG1, k))) & SYMB_FRESH_DATA) || */
                      /* (DAG_symb_type(DAG_symb(DAG_arg(DAG2, k))) & SYMB_FRESH_DATA) */
                      )
                    {
                      conflict_rec(NODE_NULL, lit);
                      my_DAG_message("conflict %D %D\n",
                                     get_DAG(currentu), get_DAG(currentv));
                      return true;
                    }
                }
            }
        }
    }
  return false;
}

static void
CCS_propagate_ineq(Tnode u, Tnode v, Tlit lit)
{
  unsigned eqargs = 0, i;
  Tnode sonui, sonvi;
  TDAG DAGu = get_DAG(u), DAGv = get_DAG(v);
  if (DAG_arity(DAGu) != DAG_arity(DAGv) ||
      stack_get(NODES, u).type != APP ||
      stack_get(NODES, v).type != APP ||
      DAG_symb(DAGu) !=  DAG_symb(DAGv))
    return;
  for (i = 0; i < DAG_arity(DAGu); i++)
    {
      sonui = get_node(DAG_arg(DAGu, i));
      sonvi = get_node(DAG_arg(DAGv, i));
      if (are_connected(sonui, sonvi))
        eqargs++;
    }
  /* my_DAG_message("PROPAGATE: %D(%d) %D(%d)\n", DAGu, DAG_arity(DAGu), DAGv, DAG_arity(DAGv)); */
  /* my_DAG_message("PROPAGATE: %d %d\n", eqargs, DAG_arity(DAGu)); */
  if (eqargs == DAG_arity(DAGu))
    {
      conflict_message(u, v, 6);
      conflict_rec(NODE_NULL, lit);
      conflict_throw();
      return;
    }
  else if (eqargs == DAG_arity(DAGu) - 1)
    {
      for (i = 0; i < DAG_arity(DAGu); i++)
        {
          sonui = get_node(DAG_arg(DAGu, i));
          sonvi = get_node(DAG_arg(DAGv, i));
          if (!are_connected(sonui, sonvi)
              && !exists_edge(sonui, sonvi, DISEQ))
            {
              TDAG eq = DAG_dup(DAG_eq(DAG_arg(DAGu, i), DAG_arg(DAGv, i)));
              TDAG neq = DAG_dup(DAG_neq(DAG_arg(DAGu, i), DAG_arg(DAGv, i)));
              if (DAG_is_lit(eq))
                {
                  if (!lit_pol(DAG_is_lit(eq)))
                    {
                      /* my_DAG_message("NO_PROPAG: %D NEGATIVE LIT\n", eq); */
                      break;
                    }
                  /* else if (lit_pol(DAG_is_lit(eq)) == UNDEFINED) */
                  /*   my_DAG_message("NO_PROPAG: %D UNDEFINED LIT\n", eq); */
                  else
                    {
                      /* absurde otherwise we have conflict*/
                      /* my_DAG_message("NO_PROPAG: %D POSITIVE LIT\n", eq); */
                      break;
                    }
                }
              else if (DAG_is_lit(neq))
                {
                  if (!lit_pol(DAG_is_lit(neq)))
                    {
                      /* absurde otherwise we have conflict*/
                      /* my_DAG_message("NO_PROPAG: %D NEGATIVE LIT\n", neq); */
                      break;
                    }
                  /* else if (lit_pol(DAG_is_lit(neq)) == UNDEFINED) */
                  /*   { */
                  /*     my_DAG_message("NO_PROPAG: %D UNDEF LIT\n", neq);  */
                  /*   } */
                  else
                    {
                      /* my_DAG_message("NO_PROPAG: %D POSITIVE LIT\n", neq); */
                      break;
                    }
                }
              Tlit lneq = DAG_to_lit(neq);
              my_DAG_message("PROPAG: %D %d\n", neq, DAG_is_lit(eq));
              create_node(neq, true);
              hint_CC(lneq, neq, false);
              break;
            }
        }
    }
}


/**
   \author Daniel El Ouraoui
   \brief this function record etheir a disequality or
   a predicat with negative polarity. Throw a conflict
   if any
   \param u node
   \param v node */
static void
CCS_assert_neq(Tnode u, Tnode v, Tlit lit, TDAG DAG) /**< equiv to CC_set_p - case**/
{
  if (DAG_symb(DAG) == PREDICATE_EQ)
    {
      if (!exists_edge(u, v, DISEQ))
        {
          backtrack_union(u, v, DISEQ, false, 0);
          create_edge(u, v, DISEQ, lit, backtrack_level);
        }
      if (are_connected(u, v)) /**< if u and v are connected then
                                  we have conflict implies by the
                                  current disequality **/
        {
          conflict_message(u, v, 6);
          conflict_rec(NODE_NULL, lit);
          conflict_throw();
          return;
        }
      /* CCS_propagate_ineq(u, v, lit); */
    }
  else /**< negative predicat case */
    {
      if (bvalue(u)  == UNDEFINED)
        {
          stack_get(NODES, u).asserted = backtrack_level + 2u;
#ifndef DISABLE_THEORY_PROPAGATION_INCR
          hint_p(u, false, u);
#endif
        }
      if (bvalue(u) == TRUE) /**< conflict case, which mean that
                                the predicat asserted appear in class with
                                positive polarity because bvalue(u) = TRUE **/
        {
          conflict_rec(u, find_first_asserted(u));
          conflict_message(u, find_first_asserted(u), 0);
          conflict_throw();
        }
    }
  if (bvalue(get_node(DAG)) == UNDEFINED)
    {
      backtrack_undef_p(get_node(DAG));
      stack_get(NODES, get_repr(get_node(DAG))).boolean_value = FALSE;
    }
}

/*
  --------------------------------------------------------------
  Interface between veriT and the congruence closure
  --------------------------------------------------------------
*/

void
CCS_DAG_arith(TDAG DAG)
{
  Tnode u;
  if (!get_node(DAG))
    {
      create_node(DAG, false);
    }
  u = get_node(DAG);
  if (DAG_arith(u))
    return;
#ifdef LIGHT_DEBUG
  my_DAG_message("CC_DAG_arith %D\n", DAG);
#endif
  stack_get(NODES, get_repr(u)).DAG_arith = DAG;
}

void CCS_add_formula(TDAG DAG);
extern bool smt2_sort_parametric(Tsort sort);

Tstatus
CCS_assert(Tlit lit)
{
  TDAG DAG = var_to_DAG(lit_var(lit));
#ifdef INCR_CCS1
  CCS_add_formula(DAG);
#endif
#ifdef LIGHT_DEBUG_ASSERT
  if (!DAG_quant(DAG))
    my_DAG_message("CCS_assert(%d) : %s%D{%d:%d}%s\n", lit,
                   lit_pol(lit)?"":"(not ", DAG, DAG, get_node(DAG), lit_pol(lit)?"":")");
#endif

  if (CCS_status == UNSAT)
    return CCS_status;
  backfire = true;
  assert(!boolean_connector(DAG_symb(DAG)));
  /* my_DAG_message("NO_ARITY: %D\n", DAG); */
  assert(DAG_arity(DAG));
  if (DAG_quant(DAG))
    {
      assert(quantifier(DAG_symb(DAG)));
      if ((lit_pol(lit) && DAG_symb(DAG) == QUANTIFIER_EXISTS) ||
          (!lit_pol(lit) && DAG_symb(DAG) == QUANTIFIER_FORALL))
        return CCS_status;
#ifdef SIMPLE_CONG
      stack_push(CC_quantified, DAG_dup(DAG));
      backtrack_store_quantified();
#endif
      return CCS_status;
    }
  if (DAG_symb(DAG) == PREDICATE_EQ && lit_pol(lit))
    CCS_merge(get_node(DAG_arg0(DAG)), get_node(DAG_arg1(DAG)), lit, false);
  else if (DAG_symb(DAG) == PREDICATE_EQ && !lit_pol(lit))
    {
      if (DAG_arith(get_node(DAG_arg0(DAG))) &&
          DAG_arith(get_node(DAG_arg1(DAG))))
        {
          veriT_xenqueue_type(XTYPE_CC_INEQ);
          veriT_xenqueue_DAG(DAG_arith(get_node(DAG_arg0(DAG))));
          veriT_xenqueue_DAG(DAG_arith(get_node(DAG_arg1(DAG))));
        }
      CCS_assert_neq(get_node(DAG_arg0(DAG)), get_node(DAG_arg1(DAG)), lit, DAG);
    }
  else
    {
      assert(!boolean_connector(DAG_symb(DAG)));
      assert(!lit_pol(lit) || DAG_symb(DAG) != PREDICATE_EQ);
      if (lit_pol(lit))
        CCS_merge(get_node(DAG), node_true, lit, false);
      else
        CCS_assert_neq(get_node(DAG), node_true, lit, DAG);
      return CCS_status;
    }
  return CCS_status;
}

/*--------------------------------------------------------------*/

Tstatus
CCS_assert_eq(TDAG DAG0, TDAG DAG1, Tlit lit)
{
  if (CCS_status == UNSAT)
    return CCS_status;
  if (get_repr(get_node(DAG0)) == get_repr(get_node(DAG1)))
    return CCS_status;
  backfire = (lit == LIT_MODEL_EQ);
#ifdef LIGHT_DEBUG
  if (backfire)
    my_DAG_message("CCS_assert_eq(-1) : (= %D %D) \n [LIT_MODEL_EQ]  \n", DAG0, DAG1);
  else
    my_DAG_message("CCS_assert_eq(%d) : (= %D %D) ", lit, DAG0, DAG1,
                   lit_pol(lit)?"\n":"not\n" );
#endif
  CCS_merge(get_node(DAG0), get_node(DAG1), lit, false);
  return CCS_status;
}

/*
  --------------------------------------------------------------
  Backtracking functions
  --------------------------------------------------------------
*/

enum {CCS_UNION = UNDO_CCS,
      CCS_NOTIFY,
      CCS_DAG_ADD,
      CCS_P_UNDEF,
      CCS_STORE_QUANTIFIED,
      CCS_STATUS
};

/*--------------------------------------------------------------*/

typedef struct Tunion_BTnode
{
  Tedge_type type:3;
  Ttype_backtrack type_unmerge:2;
  Tnode u;
  Tnode v;
  Tnode repr_u;
  TDAG DAG_arith_of_u;
  TDAG DAG_arith_of_v;
} Tunion_BTnode;

typedef Tunion_BTnode  *Tunion_BTnode_ptr;
TSstack(_union_BTnode, Tunion_BTnode_ptr);
TSstack(_stack_union_BTnode, Tstack_union_BTnode);
static Tstack_stack_union_BTnode backtrack_cong;

static void
unmerge_message(Tunion_BTnode * PBTnode, bool added_late)
{
#ifdef LIGHT_DEBUG
  printf("=============== UNMERGE ===============\n");
  if (PBTnode->type_unmerge == NEUTREAL_EDGE)
    my_DAG_message("%s_unmerge({%d:%d~%d}%D[%D]:%s, %D[%D]:%s) neq:%s --|%d|\n",
                   (added_late)?"LATE_ADDED":"CURRENT", get_DAG(PBTnode->u),
                   PBTnode->u, PBTnode->v, get_DAG(PBTnode->u),
                   get_DAG(get_repr(PBTnode->u)),
                   boolval_to_string(bvalue(PBTnode->u)),
                   get_DAG(PBTnode->v), get_DAG(get_repr(PBTnode->v)),
                   boolval_to_string(bvalue(PBTnode->v)),
                   edgetype_to_string(PBTnode->type), backtrack_level);
  else if (PBTnode->type_unmerge == CONFLICT)
    my_DAG_message("%s_unmerge_CONFLICT({%d:%d~%d}%D[%D]:%s, %D[%D]:%s) --|%d|\n",
                   (added_late)?"LATE_ADDED":"CURRENT", get_DAG(PBTnode->u),
                   PBTnode->u, PBTnode->v, get_DAG(PBTnode->u),
                   get_DAG(get_repr(PBTnode->u)),
                   boolval_to_string(bvalue(PBTnode->u)),
                   get_DAG(PBTnode->v), get_DAG(get_repr(PBTnode->v)),
                   boolval_to_string(bvalue(PBTnode->v)), backtrack_level);
  printf("=============== UNMERGE ===============\n");
#endif
}

/*--------------------------------------------------------------*/


static inline void
record_level(unsigned level, bool adding, Tunion_BTnode **PBTnode)
{
  if (!adding)
    {
      (* PBTnode) = (Tunion_BTnode *)undo_push(CCS_UNION);
      backtrack_level ++;
      stack_push(backtrack_cong, NULL);
      stack_push(backtrack_cons, 0);
    }
  else
    {
      MY_MALLOC((* PBTnode), sizeof(Tunion_BTnode));
      if (stack_get(backtrack_cons, level) == 0)
        stack_INIT(stack_get(backtrack_cong, level));
      stack_set(backtrack_cons, level, stack_get(backtrack_cons, level) + 1);
      stack_push(stack_get(backtrack_cong, level), *PBTnode);
    }
}

static inline void
record_backtrack(Tnode u, Tnode v, Tedge_type type, Tunion_BTnode **PBTnode)
{
  (*PBTnode)->u = u;
  (*PBTnode)->v = v;
  (*PBTnode)->type = type;
  (*PBTnode)->repr_u = get_repr(u);
  (*PBTnode)->DAG_arith_of_u = DAG_arith(u);
  (*PBTnode)->DAG_arith_of_v= DAG_arith(v);
}

static inline void
backtrack_union_conflict(Tnode u, Tnode v, Tedge_type type)
{
  Tunion_BTnode *PBTnode;
  record_level(UINT_MAX, false, &PBTnode);
  PBTnode->type_unmerge = CONFLICT;
  record_backtrack(u, v, type, &PBTnode);
}

static inline void
backtrack_union(Tnode u, Tnode v, Tedge_type type,
                bool adding, unsigned level)
{
  Tunion_BTnode *PBTnode;
  record_level(level, adding, &PBTnode);
  PBTnode->type_unmerge = NEUTREAL_EDGE;
  record_backtrack(u, v, type, &PBTnode);
}

static inline void
backtrack_undef_p(Tnode node)
{
  backtrack_level ++;
  stack_push(backtrack_cong, NULL);
  stack_push(backtrack_cons, 0);
  (*(Tnode *)undo_push(CCS_P_UNDEF)) = node;
}

/*--------------------------------------------------------------*/

static void
CCS_hook_union(Tunion_BTnode * PBTnode)
{
  unsigned k = 0;
  Tunion_BTnode *PBTcong_node;
  Tstack_union_BTnode consequences = stack_get(backtrack_cong, backtrack_level);
  if (stack_get(backtrack_cons, backtrack_level) > 0) /**< if the term was added on the fly**/
    {
      while (k < stack_size(consequences))
        {
          PBTcong_node = stack_get(consequences, k);
          unmerge_message(PBTcong_node, true);
          if (PBTcong_node->type_unmerge == CONFLICT || PBTcong_node->type == DISEQ)
            remove_edge(PBTcong_node->u, PBTcong_node->v, PBTcong_node->type);
          else
            CCS_unmerge(PBTcong_node->u, PBTcong_node->v,
                        PBTcong_node->type, PBTcong_node->repr_u,
                        PBTcong_node->DAG_arith_of_u, PBTcong_node->DAG_arith_of_v,
                        PBTcong_node->type_unmerge);
          k++;
          free(PBTcong_node);
        }
      stack_free(consequences);
      stack_set(backtrack_cons, backtrack_level, 0);
    }
  unmerge_message(PBTnode, false);
  if (PBTnode->type_unmerge == CONFLICT || PBTnode->type == DISEQ)
    remove_edge(PBTnode->u, PBTnode->v, PBTnode->type);
  else
    CCS_unmerge(PBTnode->u, PBTnode->v, PBTnode->type, PBTnode->repr_u,
                PBTnode->DAG_arith_of_u, PBTnode->DAG_arith_of_v,
                PBTnode->type_unmerge);
  backtrack_level --;
}

/*--------------------------------------------------------------*/

static void
CCS_hook_set_p_undef(Tnode * node)
{
  backtrack_level --;
  stack_get(NODES, *node).asserted = 0;
  stack_get(NODES, get_repr(*node)).boolean_value = UNDEFINED;
}


/*--------------------------------------------------------------*/

static inline void
backtrack_store_quantified(void)
{
  undo_push(CCS_STORE_QUANTIFIED);
}

/*--------------------------------------------------------------*/

static void
CCS_hook_store_quantified(void)
{
#ifdef SIMPLE_CONG
  DAG_free(stack_pop(CC_quantified));
#endif
}

/*--------------------------------------------------------------*/

static void
backtrack_status(void)
{
  undo_push(CCS_STATUS);
}

/*--------------------------------------------------------------*/

static void
CCS_hook_status(void)
{
  CCS_status = SAT;
}

/*
  --------------------------------------------------------------
  Get equalities and all that
  --------------------------------------------------------------
*/
/** used to give a unique explanation of congruence paths  **/
static Tstack_node report;

static bool
already_seen(Tnode u, Tnode v)
{
  unsigned i;

  for (i = 0; i < stack_size(report); i = i + 2)
    if (stack_get(report, i) == u && stack_get(report, i + 1) == v)
      return true;
  return false;
}

static void
explain_eq_aux(Tnode u, Tnode v, Tstack_node *explain_pending)
{
  Tlit lit;
  Tnode traveler = v;
  BFS(u);
  while (stack_get(pred_explain, traveler) != -1)
    {
      lit = get_edge_lit(traveler, stack_get(pred_explain, traveler), EQ);
      if (lit == LIT_MODEL_EQ)
        {
          lit = DAG_to_lit(DAG_eq(get_DAG(traveler),
                                  get_DAG(stack_get(pred_explain, traveler))));
          create_node(DAG_eq(get_DAG(traveler),
                             get_DAG(stack_get(pred_explain, traveler))), true);
        }
      if (lit)
        stack_push(veriT_conflict, lit);
      else if (exists_edge(u, v, INJ) ||
               stack_get(NODES, traveler).type != APP)
        /**< Case of injective */
        {
          unsigned i, j;
          for (i = 0; i < stack_get(NODES, traveler).nbparents; i++)
            {
              for (j = 0;
                   j < stack_get(NODES,
                                 stack_get(pred_explain, traveler)).nbparents; j++)
                {
                  if (already_seen(stack_get(NODES, traveler).parents[i],
                                   stack_get(NODES, stack_get(pred_explain, traveler)).parents[j]))
                    continue;
                  if (are_connected(stack_get(NODES, traveler).parents[i],
                           stack_get(NODES, stack_get(pred_explain, traveler)).parents[j]))
                    {
                      stack_push(*explain_pending, stack_get(NODES, traveler).parents[i]);
                      stack_push(*explain_pending,
                                 stack_get(NODES, stack_get(pred_explain, traveler)).parents[j]);
                      stack_push(report, stack_get(NODES, traveler).parents[i]);
                      stack_push(report,
                                 stack_get(NODES, stack_get(pred_explain, traveler)).parents[j]);
                    }
                }
            }
        }
      else if (stack_get(NODES, traveler).type == APP &&
          stack_get(NODES, stack_get(pred_explain, traveler)).type == APP)
        /**< Case of congruence */
        {
          if (!already_seen(stack_get(NODES, traveler).sons[0],
                            stack_get(NODES,
                                      stack_get(pred_explain, traveler)).sons[0]))
            {
              stack_push(*explain_pending, stack_get(NODES, traveler).sons[0]);
              stack_push(*explain_pending,
                         stack_get(NODES, stack_get(pred_explain, traveler)).sons[0]);
              stack_push(report, stack_get(NODES, traveler).sons[0]);
              stack_push(report,
                         stack_get(NODES, stack_get(pred_explain, traveler)).sons[0]);
            }/** give a uniqe explanation is very important to not walnut the sat solver **/
          if (!already_seen(stack_get(NODES, traveler).sons[1],
                            stack_get(NODES, stack_get(pred_explain, traveler)).sons[1]))
            {
              stack_push(*explain_pending, stack_get(NODES, traveler).sons[1]);
              stack_push(*explain_pending,
                         stack_get(NODES, stack_get(pred_explain, traveler)).sons[1]);
              stack_push(report, stack_get(NODES, traveler).sons[1]);
              stack_push(report,
                         stack_get(NODES, stack_get(pred_explain, traveler)).sons[1]);
            }
        }
#ifdef LIGHT_DEBUG
      if (lit)
        {
          my_DAG_message(" %D{%d} -%d-> %D{%d} [", get_DAG(traveler), traveler, lit,
                         get_DAG(stack_get(pred_explain, traveler)),
                         stack_get(pred_explain, traveler));
          DAG_print(var_to_DAG(lit_var(lit))); printf("]\n");}
#endif

      traveler = stack_get(pred_explain, traveler);
    }
  clean_visited_node();
}

/*--------------------------------------------------------------*/

/** To explain equality between two terms we
    will use the BFS algorithm **/
static void
explain_eq(Tnode u, Tnode v)
{
  Tstack_node explain_pending;
  stack_INIT(explain_pending);
  stack_push(explain_pending, u);
  stack_push(explain_pending, v);
#ifdef LIGHT_DEBUG
  my_DAG_message("Explain %D %D \n", get_DAG(u), get_DAG(v));
  printf("=============== explain ===============\n");
#endif
  while (stack_size(explain_pending))
    {
      v = stack_pop(explain_pending);
      u = stack_pop(explain_pending);
      if (u != v)
        explain_eq_aux(u, v, &explain_pending);
    }
  stack_free(explain_pending);
  stack_reset(report);
#ifdef LIGHT_DEBUG
  printf("=============== explain ===============\n");
#endif
}

/*--------------------------------------------------------------*/

void
explain_predicates(Tnode u, Tnode v)
{
  Tstack_node predicates_explain_f, predicates_explain_t;
  Tnode source, currentnode;
  unsigned i, j;
  bool passed = false;

  stack_INIT(predicates_explain_f);
  stack_INIT(predicates_explain_t);
  assert(stack_is_empty(pending));
  assert(stack_is_empty(save_cc));
  stack_push(pending, u);
  stack_push(pending, v);
  while (!stack_is_empty(pending))
    {
      source = stack_pop(pending);
      if (!stack_get(NODES, source).visited)
        stack_push(save_cc, source);
      stack_get(NODES, source).visited = true;
      for (i = 0; i < stack_get(NODES, source).nbedges; i++)
        {
          currentnode = stack_get(NODES, source).edges[i].node;
          if (stack_get(NODES, source).edges[i].type == CONG)
            {
              if (bvalue(currentnode) == FALSE)
                {
                  for (j = 0; j < stack_size(predicates_explain_f); j++)
                    if(stack_get(predicates_explain_f, j) == currentnode)
                      break;
                  if (j == stack_size(predicates_explain_f))
                    stack_push(predicates_explain_f, currentnode);
                }
              else if (bvalue(currentnode) == TRUE)
                {
                  for (j = 0; j < stack_size(predicates_explain_t); j++)
                    if(stack_get(predicates_explain_t, j) == currentnode)
                      break;
                  if (j == stack_size(predicates_explain_t))
                    stack_push(predicates_explain_t, currentnode);
                }
            }
          if (stack_get(NODES, source).edges[i].type == CONG &&
              !stack_get(NODES, currentnode).visited)
            stack_push(pending, currentnode);
        }
    }
  clean_visited_node();
  for (i = 0; i < stack_size(predicates_explain_f); i++)
    {
      for (j = 0; j < stack_size(predicates_explain_t); j++)
        {
          if (stack_get(NODES, stack_get(predicates_explain_f, i)).asserted &&
              stack_get(NODES, stack_get(predicates_explain_t, j)).asserted)
            {
              Tlit l1 = lit_make(DAG_to_var(get_DAG(stack_get(predicates_explain_f, i))), 0);
              Tlit l2 = lit_make(DAG_to_var(get_DAG(stack_get(predicates_explain_t, j))), 1);
              stack_push(veriT_conflict, l1);
              stack_push(veriT_conflict, l2);
              explain_eq(stack_get(predicates_explain_f, i), stack_get(predicates_explain_t, j));
              passed = true;
            }
        }
    }
  stack_reset(predicates_explain_f);
  stack_reset(predicates_explain_t);
  stack_free(predicates_explain_f);
  stack_free(predicates_explain_t);
  if (!passed)
    {
      Tlit l1 = lit_make(DAG_to_var(get_DAG(u)), 0);
      Tlit l2 = lit_make(DAG_to_var(get_DAG(v)), 1);
      stack_push(veriT_conflict, l1);
      stack_push(veriT_conflict, l2);
      explain_eq(u, v);
    }
}

static Tstack_node cycle_explain;

void
explain_cycle(void)
{
  unsigned j;
  for (j = 0; j < stack_size(cycle_explain); j = j + 2)
    {
      Tnode n1 = stack_get(cycle_explain, j);
      Tnode n2 = stack_get(cycle_explain, j + 1);
      explain_eq(n1, n2);
    }
  explain_eq(cNODE0, cNODE1);
  stack_reset(cycle_explain);
  stack_free(cycle_explain);
}


void
CCS_conflict(void)
{
  if (cycle_conflict)
    {
#ifdef LIGHT_DEBUG
      my_DAG_message("Cycle Conflict %D %D \n ", get_DAG(cNODE0), get_DAG(cNODE1));
#endif
      explain_cycle();
      cycle_conflict = false;
      return;
    }
  else if (clash_conflict)
    {
#ifdef LIGHT_DEBUG
      my_DAG_message("Clash Conflict %D %D \n ", get_DAG(cNODE0), get_DAG(cNODE1));
#endif
      if (!cNODE0)
        {
          TDAG DAG1 = var_to_DAG(lit_var(cNODE1));
          stack_push(veriT_conflict, cNODE1);
          explain_eq(get_node(DAG_arg0(DAG1)),
                     get_node(DAG_arg1(DAG1)));

        }
      else
        explain_eq(cNODE0, cNODE1);
      clash_conflict = false;
    }
  else if (!cNODE0) /**< cDAG0 is null then this is an equality and cNODE1 is literal */
    {
      TDAG DAG1 = var_to_DAG(lit_var(cNODE1));
#ifdef LIGHT_DEBUG
      my_DAG_message("F Conflict %d %D \n ", cNODE1, DAG1);
#endif
      stack_push(veriT_conflict, cNODE1);
      explain_eq(get_node(DAG_arg0(DAG1)),
                 get_node(DAG_arg1(DAG1)));
      if (!cNODE0 && !cNODE1)
        exit(0);
    }
  else
    {
#ifdef LIGHT_DEBUG
      my_DAG_message("P Conflict  (not %D) %D \n ", get_DAG(cNODE0), get_DAG(cNODE1));
#endif
      explain_predicates(cNODE0, cNODE1); 
    }
}

void
CCS_hint_explain(Tlit lit)
{
  TDAG DAG0 = var_to_DAG(lit_var(lit));
  TDAG DAG1 = hint_CC_cause(lit);
  assert(class(DAG0));
  if (lit_pol(lit) && DAG_symb(DAG0) == PREDICATE_EQ)
    {
      stack_push(veriT_conflict, lit_neg(lit)); /* later double negated */
      explain_eq(get_node(DAG_arg0(DAG0)), get_node(DAG_arg1(DAG0)));
      return; 
    }
  assert(DAG0 != DAG1);
  /* assert(DAG_symb(DAG0) == DAG_symb(DAG1)); */
  stack_push(veriT_conflict, lit_neg(lit));
  stack_push(veriT_conflict, lit_make(DAG_to_var(DAG1), lit_pol(lit)));
  if (hint_CC_reversed(lit))
    {
      assert(DAG_symb(DAG0) == PREDICATE_EQ);
      explain_eq(get_node(DAG_arg0(DAG0)), get_node(DAG_arg1(DAG1)));
      explain_eq(get_node(DAG_arg1(DAG0)), get_node(DAG_arg0(DAG1)));
      return;
    }
  explain_eq(get_node(DAG0), get_node(DAG1));
}

/*--------------------------------------------------------------*/

void
CCS_premisses_eq(TDAG DAG0, TDAG DAG1)
{
  explain_eq(get_node(DAG0), get_node(DAG1));
}


/*--------------------------------------------------------------*/

static inline void
CCS_backtrack_top_notify(TDAG DAG)
{
  *(TDAG *)undo_top_push(CCS_NOTIFY) = DAG;
}

/*--------------------------------------------------------------*/

static void
CCS_hook_top_notify(TDAG * PDAG)
{
  DAG_free(*PDAG);
}

/*--------------------------------------------------------------*/

static void
DAG_add_q(TDAG DAG, bool add)
{
  unsigned i;
  if (ground(DAG) && !DAG_quant(DAG) && DAG_sort(DAG) != SORT_BOOLEAN)
    create_node(DAG, add);
  else if (quantifier(DAG_symb(DAG)))
    DAG_add_q(DAG_arg_last(DAG), add);
  else /**< for any non-ground term (boolean structure, =, ...) explore subterms */
    for (i = 0; i < DAG_arity(DAG); i++)
      DAG_add_q(DAG_arg(DAG, i), add);
}


/*--------------------------------------------------------------*/

static inline void
CCS_notify_atom(TDAG DAG, bool add)
{
  if (CCS_status == UNSAT)
    return;
  if (DAG_quant(DAG))
    DAG_add_q(DAG, add);
  else
    create_node(DAG, add);
}

/*--------------------------------------------------------------*/

/**
   \brief stores arithmetic definition for arithmetic atoms,
   and all arithmetic terms in DAG
   \param DAG a DAG */
static void
CCS_notify_formula_aux(TDAG DAG, bool add)
{
  unsigned i;
  Tsymb symb = DAG_symb(DAG);
  if (DAG_tmp_bool[DAG])
    return;
  DAG_tmp_bool[DAG] = 1;
  if (boolean_connector(symb))
    for (i = 0; i < DAG_arity(DAG); i++)
      CCS_notify_formula_aux(DAG_arg(DAG, i), add);
  else if (quantifier(symb))
    return;
  else if (symb == LET ||
           symb == FUNCTION_ITE)
    {
      printf(" %s \n", DAG_symb_name2(symb));
      my_error("CC: unaccepted symbol, internal error\n");
    }
  else
    CCS_notify_atom(DAG, add);
}

/*--------------------------------------------------------------*/

/**
   \brief stores arithmetic definition for arithmetic atoms,
   and all arithmetic terms in DAG
   \param DAG a DAG */
void
CCS_notify_formula(TDAG DAG)
{
  if (!first)
    {
      stack_sort(app_table, compare_terms_by_terms);
      first = true;
    }
  DAG_dup(DAG);
  CCS_backtrack_top_notify(DAG);
  DAG_tmp_reserve();
  CCS_notify_formula_aux(DAG, false);
  DAG_tmp_reset_bool(DAG);
  DAG_tmp_release();
}

/*--------------------------------------------------------------*/

void
CCS_add_formula(TDAG DAG)
{
  if (!first)
    {
      stack_sort(app_table, compare_terms_by_terms);
      first = true;
    }
  DAG_dup(DAG);
  CCS_backtrack_top_notify(DAG);
  DAG_tmp_reserve();
  CCS_notify_formula_aux(DAG, true);
  DAG_tmp_reset_bool(DAG);
  DAG_tmp_release();
}

/*--------------------------------------------------------------*/

static bool
query_DAG(TDAG DAG1, Tnode DAG2)
{
  unsigned i;
  if (DAG_arity(DAG1) != DAG_arity(DAG2))
    return false;
  if (DAG_symb(DAG1) != DAG_symb(DAG2))
    return false;
  /* if (!are_connected(get_node(DAG1), get_node(DAG2))) */
  /*   return false; */
  if (DAG_symb(DAG1) == PREDICATE_EQ)
    return
      (class(DAG_arg0(DAG1)) == class(DAG_arg0(DAG2)) &&
       class(DAG_arg1(DAG1)) == class(DAG_arg1(DAG2)) ) ||
      (class(DAG_arg0(DAG1)) == class(DAG_arg1(DAG2)) &&
       class(DAG_arg1(DAG1)) == class(DAG_arg0(DAG2)));

  for (i = 0; i < DAG_arity(DAG1); i++)
    {
      if (!get_node(DAG_arg(DAG1, i)))
        return false;
      assert(exists_node(get_node(DAG_arg(DAG1, i))));
      if (!are_connected(get_node(DAG_arg(DAG1, i)), get_node(DAG_arg(DAG2, i))))
        return false;
    }

  return true;
}

/*--------------------------------------------------------------*/
static bool
contains_class(Tstack_DAG stack, TDAG DAG)
{
  unsigned i;
  for (i = 0; i < stack_size(stack); i++)
    {
      if (query_DAG(DAG, stack_get(stack, i)))
        return true;
    }
  return false;
}

static bool
pre_def_symb(TDAG src)
{
    return (DAG_symb(src) == LET ||
          DAG_symb(src) == CONNECTOR_NOT ||
          DAG_symb(src) == CONNECTOR_OR ||
          DAG_symb(src) == CONNECTOR_XOR ||
          DAG_symb(src) == CONNECTOR_IMPLIES ||
          DAG_symb(src) ==  FUNCTION_ITE ||
          DAG_symb(src) == CONNECTOR_ITE ||
          DAG_symb(src) == PREDICATE_LESS ||
          DAG_symb(src) == PREDICATE_LEQ ||
          DAG_symb(src) == PREDICATE_GREATER ||
          DAG_symb(src) == PREDICATE_GREATEREQ ||
          DAG_symb(src) == PREDICATE_DISTINCT ||
          quantifier(DAG_symb(src)) ||
          DAG_symb(src) == FUNCTION_MINUS ||
          DAG_symb(src) == FUNCTION_SUM ||
          DAG_symb(src) == FUNCTION_MOD ||
          DAG_symb(src) == FUNCTION_PROD ||
          DAG_symb(src) == FUNCTION_UNARY_MINUS ||
          DAG_symb(src) == FUNCTION_UNARY_MINUS_ALT ||  
          DAG_symb(src) ==  FUNCTION_DIV ||
          unary_minus(DAG_symb(src)) ||
          DAG_symb(src) == CONNECTOR_EQUIV ||
          DAG_symb(src) == PREDICATE_EQ ||
            DAG_symb(src) ==  CONNECTOR_AND);
}


TDAG
get_sub_DAG(TDAG DAG, unsigned position, bool cont)
{
  unsigned i = -1;
  TDAG res;
  Tstack_DAG args;
  if (!DAG_arity(DAG) && cont && !position)
    return DAG;
  else if (!DAG_arity(DAG) && (cont || position))
    return DAG_NULL;
  else if (cont && DAG_symb(DAG) != APPLY)
    return DAG_dup(DAG_new_nullary(DAG_symb(DAG)));
  if (DAG_symb(DAG) == APPLY && !position)
    return DAG_NULL;
  stack_INIT(args);
  do
    {
      i++;
      stack_push(args, DAG_arg(DAG, i));
    }while (i < position);

  res = DAG_dup(DAG_new_stack(DAG_symb(DAG), args));
  stack_reset(args);
  stack_free(args);
  return res;
}


/*--------------------------------------------------------------*/

static bool
is_in(Tstack_node *stack, Tnode u, bool cycle)
{
  unsigned i;
  for (i = 0; *stack && i < stack_size(*stack); i++)
    {
      if ((stack_get(*stack, i) != u) &&
          are_connected(stack_get(*stack, i), u) && cycle)
        {
          conflict_rec(u, stack_get(*stack, i));
          cycle_conflict = true;
          conflict_throw();
          return true;
        }
      else if ((stack_get(*stack, i) !=  u) &&
               are_connected(stack_get(*stack, i), u) && !cycle)
        {
          stack_push(cycle_explain, stack_get(*stack, i));
          stack_push(cycle_explain, u);
          return true;
        }
    }
  return false;
}

static inline bool
is_constructor(Tnode node)
{
  return is_in_formula(node) &&
    (DAG_symb_type(DAG_symb(get_DAG(node))) & SYMB_CONSTRUCTOR) &&
    stack_get(NODES, node).injective &&
    stack_get(NODES, node).type == APP;
}



bool
traverse(Tnode t, Tstack_node *U, Tstack_node *P)
{
  unsigned i, j;
  bool answer  = false;
  TDAG constructor;
  Tnode current;
  Tstack_node tmp;
  
  if (is_in(P, t, true))
    return true;
  if (is_in(U, t, false))
    {
      DFS(t);
      stack_INIT(tmp);
      for (i = 0; i < stack_size(save_cc); i++)
        {
          current = stack_get(save_cc, i);
          stack_get(NODES, current).visited = false;
          stack_push(tmp, current);
        }
      stack_reset(save_cc);
      for (i = 0; i < stack_size(tmp); i++)
        {
          current = stack_get(tmp, i);
          if (get_DAG(current) && is_constructor(current))
            {
              /* my_DAG_message("IS_CONSTR: %D\n", get_DAG(current)); */
              constructor = get_DAG(current);
              for (j = 0; j < DAG_arity(constructor); j++)
                {
                  stack_push(*P, current);
                  answer =
                    traverse(get_node(DAG_arg(get_DAG(current), j)), U, P);
                  stack_dec(*P);
                  if (answer)
                    {
                      stack_reset(tmp);
                      stack_free(tmp);
                      return true;
                    }
                }
              for (j = 0; j < stack_size(*U); j++)
                if (stack_get(*U, j) == current)
                  break;
              if (j < stack_size(*U))
                stack_delete(*U, j);
            }
        }
      stack_reset(tmp);
      stack_free(tmp);
    }
  return answer;
}


bool
CCS_cycle(Tstack_node *U)
{
  /* printf("CYCLE DETECTION\n"); */
  unsigned i;
  Tstack_node P;
  stack_INIT(P);
  stack_INIT(cycle_explain);
  for (i = 0; i < stack_size(*U); i++)
    {
      if (traverse(stack_get(*U, i), U, &P))
        {
          stack_reset(P);
          stack_free(P);
          return true;
        }
      else
        stack_reset(P);
      stack_reset(cycle_explain);
    }
  stack_reset(P);
  stack_free(P);
  stack_reset(cycle_explain);
  stack_free(cycle_explain);
  cycle_conflict = false;
  CCS_status = SAT;
  return false;
}

bool
CCS_detect_cycle()
{
  Tnode node, current;
  unsigned i;
  Tstack_node U;
  stack_INIT(U);
  for (node = 1;  stack_size(NODES) > node; node++)
    {
      if (/* is_in_formula(node) && */
          stack_get(NODES, node).injective)
        {
          DFS(node);
          for (i = 0; i < stack_size(save_cc); i++)
            {
              current = stack_get(save_cc, i);
              stack_get(NODES, current).visited = false;
              stack_push(U, current);
            }
          stack_reset(save_cc);
        }
    }
  if (CCS_cycle(&U))
    {
      stack_reset(U);
      stack_free(U);
      return true;
    }
  stack_reset(U);
  stack_free(U);
  return false;
}

/*--------------------------------------------------------------*/

void
CCS_sig_apply(void (*f)(TDAG))
{
  /** FIXED don't touch anymore only on the function signature **/
  Tstack_DAG result;
  Tnode node;
  stack_INIT(result);
  for (node = 0;  stack_size(app_table) > node; node++)
    {
      if (DAG_arity(stack_get(app_table, node).DAG) ==
          stack_get(app_table, node).position + 1 &&
          !contains_class(result, stack_get(app_table, node).DAG))
        {
          stack_push(result, stack_get(app_table, node).DAG);
          f(stack_get(app_table, node).DAG);
        }
      else if (!contains_class(result, stack_get(app_table, node).DAG) &&
               DAG_symb(stack_get(app_table, node).DAG) &&
               !pre_def_symb(stack_get(app_table, node).DAG))
        {
          TDAG f;
          /* my_DAG_message("%d:%d %D \n", stack_get(app_table, node).node,  */
          /*                DAG_arity(stack_get(app_table, node).DAG), class(stack_get(app_table, node).DAG)); */
          f = get_sub_DAG(stack_get(app_table, node).DAG,
                          get_position(stack_get(app_table, node).node), false);

          if (!f)
            continue;
          if (DAG_arity(f))
            {
              stack_get(app_table, node).DAG = f;
              stack_push(result, stack_get(app_table, node).DAG);
            }
          else if (class(stack_get(app_table, node).DAG) != f)
            DAG_free(f);
        }
    }
  stack_reset(result);
  stack_free(result);
}

static Tstack_DAG CCS_get_sig_aux_stack;
static Tsymb CCS_get_sig_aux_symb;

static void
CCS_get_sig_aux(TDAG DAG)
{
  if (DAG_symb(DAG) == CCS_get_sig_aux_symb)
    stack_push(CCS_get_sig_aux_stack, DAG);
}

/*--------------------------------------------------------------*/

Tstack_DAG
CCS_get_sig(Tsymb symb)
{
  Tstack_DAG result;
  stack_INIT(result);
  if (symb == PREDICATE_EQ)
    return result;
  CCS_get_sig_aux_symb = symb;
  CCS_get_sig_aux_stack = result;
  CCS_sig_apply(CCS_get_sig_aux);
  result = CCS_get_sig_aux_stack;
  return result;
}

Tstack_DAG
CCS_get_sig_DAG(Tsymb symb, TDAG DAG)
{
  unsigned i;
  Tnode current;
  Tstack_DAG result;
  stack_INIT(result);
  if (symb == PREDICATE_EQ)
    return result;
  DFS(get_node(DAG));
  for (i = 0; i < stack_size(save_cc); i++)
    {
      current = stack_get(save_cc, i);
      stack_get(NODES, current).visited = false;
      stack_push(result, get_DAG(current));
    }
  stack_reset(save_cc);
  return result;
}



/*--------------------------------------------------------------*/

void
CCS_get_graph(unsigned *nb_edges, unsigned *nb_nodes)
{
  unsigned i, j, l = 0, r = 0, nbedges = 0, nbnodes = 0;
  Tnode node;
  Tstack_DAG saved;
  stack_INIT(saved);
  for (node = 0;  stack_size(NODES) > node; node++)
    {
      for (i = 0;  i < stack_get(NODES, node).nbedges; i++)
        {
          if (!i)
            nbnodes++;
          for (j = 0;  j < stack_size(saved); j++)
            {
              if (stack_get(saved, j) == stack_get(NODES, node).edges[i].node)
                l++;
              else if (stack_get(saved, j) == node)
                r++;
              if (l && r)
                break;
            }
          if (!(l && r))
            {
              nbedges++;
              stack_push(saved, node);
              stack_push(saved, stack_get(NODES, node).edges[i].node);
            }
            l = r = 0;
        }
    }
  /* printf("[NB_EDGES : %d NB_NODES: %d]\n", nbnodes, nbedges); */
  *nb_nodes += nbnodes;
  *nb_edges += nbedges;
  stack_reset(saved);
  stack_free(saved);
}

/*--------------------------------------------------------------*/

TDAG
CCS_abstract(TDAG DAG)
{
  if (!DAG || !get_node(DAG)) return DAG_NULL;
  return class(DAG);
}

/*--------------------------------------------------------------*/

static inline int
cmp_q_class(TDAG *PDAG1, TDAG *PDAG2)
{
  return (int) class(*PDAG1) - (int) class(*PDAG2);
}

/*--------------------------------------------------------------*/

static bool
stack_DAG_contains_class(Tstack_DAG stack, TDAG DAG)
{
  if (stack_is_empty(stack))
    return false;
  int imid, imin = 0, imax = stack_size(stack) - 1;
  while (imin <= imax)
    {
      imid = imin + (imax - imin) / 2;
      if (class(DAG) == class(stack_get(stack, imid)))
        return true;
      if (class(DAG) < class(stack_get(stack, imid)))
        imax = imid - 1;
      else if (class(DAG) > class(stack_get(stack, imid)))
        imin = imid + 1;
    }
  return false;
}
/*--------------------------------------------------------------*/

bool
CCS_disequal(TDAG D0, TDAG D1)
{
  Tstack_DAG diseqs0, diseqs1;
  if (!get_node(D1) || !get_node(D0)) return false;
  diseqs0 = stack_get(NODES, get_repr(get_node(D0))).diseqs;
  diseqs1 = stack_get(NODES, get_repr(get_node(D1))).diseqs;
  if (!diseqs0 || !diseqs1)
    return false;
  if (stack_size(diseqs0) > stack_size(diseqs1))
    {
      if (!stack_DAG_contains(diseqs1, class(D0)))
        return false;
    }
  else if (!stack_DAG_contains(diseqs0, class(D1)))
    return false;
  return true;
}

/*--------------------------------------------------------------*/

Tboolean_value
CCS_abstract_p(TDAG DAG)
{
  /** FIXED don't touch anymore**/
  if (!get_node(DAG))
    return UNDEFINED;
  return bvalue(get_node(DAG));
}

/*--------------------------------------------------------------*/

Tstack_DAG
CCS_diseqs(TDAG DAG)
{
  if (!DAG || !get_node(DAG)) return NULL;
  return stack_get(NODES, get_repr(get_node(DAG))).diseqs;
}

/*--------------------------------------------------------------*/

Tstack_DAG
CCS_get_sort_classes(Tsort sort)
{
  /** FIXED don't touch anymore**/ 
  Tnode node;
  Tstack_DAG samesortclasses;
  stack_INIT(samesortclasses);
  DAG_tmp_reserve();
  for (node = 1; node < stack_size(NODES); node++)
    {
      if (class(get_DAG(node)) && !DAG_tmp_bool[class(get_DAG(node))] &&
          DAG_sort(class(get_DAG(node))) == sort)
        {
          stack_push(samesortclasses, class(get_DAG(node)));
          DAG_tmp_bool[class(get_DAG(node))] = 1;
        }
    }
  for (node  = 0; node < stack_size(samesortclasses); node++)
    DAG_tmp_bool[stack_get(samesortclasses, node)] = 0;
  DAG_tmp_release();
  if (stack_is_empty(samesortclasses))
    {
      stack_free(samesortclasses);
      return NULL;
    }
  return samesortclasses;
}


static bool
node_is_function(Tnode node)
{
  TDAG original = get_DAG(node);
  original =  (DAG_symb(original) == APPLY)?head(original):original; 
   if (original && DAG_symb(original)
      && !pre_def_symb(original) && stack_get(NODES, node).type == APP)
    {
      Tsort try_sort = DAG_symb_sort(DAG_symb(original))/* , sort = DAG_sort(original) */;
      unsigned try_sort_arity = DAG_sort_arity(try_sort) - 1;
      /* my_DAG_message("IS FUN[%D]%D %S %S position: %d arity: %d diff: %d\n", */
      /*                get_DAG(node), original, try_sort, sort, get_position(node), try_sort_arity, */
      /*                (try_sort_arity - (get_position(node)))); */
      return (try_sort_arity - (get_position(node)));
    }
   else if (original && DAG_symb(original)
           && !pre_def_symb(original) && stack_get(NODES, node).type == CONST)
    {
      Tsort try_sort = DAG_symb_sort(DAG_symb(original))/* , sort = DAG_sort(original) */;
      unsigned try_sort_arity = DAG_sort_arity(try_sort);
      /* my_DAG_message("IS FUN[%D]%D %S %S position: %d arity: %d\n", */
      /*                get_DAG(node), original, try_sort, sort, get_position(node), try_sort_arity); */

      return try_sort_arity;
    }

  return false;
}

static bool
check_type(Tnode u, Tnode v)
{
  TDAG D0 = get_DAG(u), D1 = get_DAG(v);
  unsigned u_pos = get_position(u), v_pos = get_position(v);
  if ( u_pos == v_pos &&
       ((DAG_symb(head(D0)) == APPLY && DAG_symb(head(D0)) == DAG_symb(head(D1))) ||
        (DAG_symb(head(D0)) != APPLY && DAG_symb(head(D0)) != DAG_symb(head(D1)))))
    {
      D0 = (DAG_symb(D0) == APPLY)?head(D0):D0;
      D1 = (DAG_symb(D1) == APPLY)?head(D1):D1; 
      Tsort try_sort_u = DAG_symb_sort(DAG_symb(D0)), try_sort_v = DAG_symb_sort(DAG_symb(D1));
      /* my_DAG_message("%D %D %S %S \n", */
      /*                D0, D1, try_sort_u, try_sort_v); */
      return DAG_sort_combine(try_sort_u, try_sort_v);
    }

  return false;
}


extern Tsort
smt2_var_fun(Tsort sort, Tsort sort_list);


/*--------------------------------------------------------------*/


static TDAG
app_term(TDAG lambda, Tstack_symb term_list)
{
  unsigned i, arity_lam = DAG_arity(lambda);
  TDAG DAG;
  Tstack_DAG fun_args;
  stack_INIT(fun_args);
  for (i = 0; i < arity_lam; i++)
    stack_push(fun_args, DAG_arg(lambda, i));
  for (i = 0; i < stack_size(term_list); i++)
    {
      TDAG arg = DAG_dup(DAG_new_nullary(stack_get(term_list, i)));
      stack_push(fun_args, arg);
    }
  DAG = DAG_dup(DAG_new_stack(DAG_symb(lambda), fun_args));
  stack_reset(fun_args);
  stack_free(fun_args);
  return DAG;
}

TDAG
get_app_DAG(TDAG DAG)
{
  unsigned i;
  TDAG res;
  Tstack_DAG args;
  if (!DAG_arity(DAG) || DAG_symb(DAG) == APPLY)
    return DAG;
  stack_INIT(args);
  stack_push(args, DAG_dup(DAG_new_nullary(DAG_symb(DAG))));
  for (i = 0; i < DAG_arity(DAG); i++)
    stack_push(args, DAG_arg(DAG, i));
  res = DAG_dup(DAG_new_stack(APPLY, args));
  stack_reset(args);
  stack_free(args);
  return res;
}

TDAG
get_unapp_DAG(TDAG DAG)
{
  unsigned i;
  TDAG res;
  Tstack_DAG args;
  stack_INIT(args);
  for (i = 1; i < DAG_arity(DAG); i++)
    stack_push(args, DAG_arg(DAG, i));
  res = DAG_dup(DAG_new_stack(DAG_symb(head(DAG)), args));
  stack_reset(args);
  stack_free(args);
  return res;
}

/*--------------------------------------------------------------*/



Tstack_DAG
CCS_get_sort_classes_ho(Tsort sort)
{
  /** FIXED don't touch anymore**/
  Tnode node;
  Tstack_DAG samesortclasses;
  stack_INIT(samesortclasses);
  DAG_tmp_reserve();
  for (node = 1; node < stack_size(NODES); node++)
    {
      /* if (get_DAG(node)) */
      /* my_DAG_message("{%d} %D:S =?= %S\n", get_position(node), */
      /*                get_DAG(node), DAG_sort(get_DAG(node)), sort); */
      if (class(get_DAG(node)) && !DAG_tmp_bool[class(get_DAG(node))] &&
          DAG_sort(class(get_DAG(node))) == sort)
        {
          stack_push(samesortclasses, class(get_DAG(node)));
          DAG_tmp_bool[class(get_DAG(node))] = 1;
        }
      else if (/* DAG_sort_arity(sort) && */
               get_DAG(node) && DAG_symb(get_DAG(node))
               && !pre_def_symb(get_DAG(node)))
        {
          TDAG f;
          f = get_sub_DAG(get_DAG(node),
                          get_position(node),
                          stack_get(NODES, node).type == CONST);
          if (!f)
            continue;
          if (DAG_sort(f) == sort)
            {
              if (DAG_arity(f) || stack_get(NODES, node).type != CONST)
                {
                  unsigned iterm =
                    dicho_search(get_DAG(node), get_position(node), NULL, compare_terms, NULL);
                  /* my_DAG_message("[BEFORe] %D %d %d\n", get_DAG(node), get_position(node), iterm); */
                  if (iterm != UINT_MAX)
                    stack_get(app_table, iterm).DAG = f;
                  /* my_DAG_message("[AFTER] %D\n", stack_get(app_table, iterm).DAG); */
                }
              stack_push(samesortclasses, f); 
              DAG_tmp_bool[f] = 1;
            }
          else if (get_DAG(node) != f)
            DAG_free(f);
        }
    } 
  for (node  = 0; node < stack_size(samesortclasses); node++)
    DAG_tmp_bool[stack_get(samesortclasses, node)] = 0;
  DAG_tmp_release();
  return samesortclasses;
}

/*--------------------------------------------------------------*/

typedef struct Tpaire
{
  TDAG left;
  TDAG right;
} Tpaire;

TSstack(_paire, Tpaire);
Tstack_paire ext_eq;

static bool
contains_eq(TDAG left, TDAG right)
{
  unsigned i;
  for (i = 0; i < stack_size(ext_eq); i++)
    if ((stack_get(ext_eq, i).left == left  && stack_get(ext_eq, i).right == right)
        || (stack_get(ext_eq, i).right == left  && stack_get(ext_eq, i).left == right))
        return true;
  return false;
}


void
CCS_extentionality(Tstack_DAG *lemmas)
{
  unsigned i, j, k;
  int arity_sort, arity;
  Tsort sort_fun;
  TDAG tmp, fl, fr, hyp;
  Tnode node;
  Tstack_node U;
  Tstack_symb fun_args;
  Tpaire diseq;
  stack_INIT(U);
  for (node = 1;  stack_size(NODES) > node; node++)
    if (node_is_function(node))
      stack_push(U, node);

  for (i = 0;  stack_size(U) > i; i++)
    {
      for (j = 0;  stack_size(U) > j; j++)
        {
          if (i != j && stack_get(U, i) != stack_get(U, j) &&
              check_type(stack_get(U, i), stack_get(U, j)) &&
              stack_get(NODES, stack_get(U, i)).type ==
              stack_get(NODES, stack_get(U, j)).type)
            {
              if (!exists_edge(stack_get(U, i), stack_get(U, j), DISEQ))
                {
                  /* my_DAG_message("%D:%S{%d} %D:%S{%d} check:%d\n", */
                  /*                get_DAG(stack_get(U, i)), */
                  /*                DAG_sort(get_DAG(stack_get(U, i))), */
                  /*                get_position(stack_get(U, i)), */
                  /*                get_DAG(stack_get(U, j)), */
                  /*                DAG_sort(get_DAG(stack_get(U, j))), */
                  /*                get_position(stack_get(U, j)), */
                  /*                check_type(stack_get(U, i), stack_get(U, j))); */
                  fl = get_sub_DAG(get_DAG(stack_get(U, i)),
                                   get_position(stack_get(U, i)),
                                   stack_get(NODES, stack_get(U, i)).type == CONST);
                  fr = get_sub_DAG(get_DAG(stack_get(U, j)),
                                   get_position(stack_get(U, j)),
                                   stack_get(NODES, stack_get(U, j)).type == CONST);
                  /* my_DAG_message("FIRST Enter (%d:%d) {%d:%d}: %D %D %S = %S\n", */
                  /*                stack_get(NODES, stack_get(U, i)).type == CONST, */
                  /*                stack_get(NODES, stack_get(U, j)).type == CONST, */
                  /*                get_position(stack_get(U, i)), get_position(stack_get(U, j)), */
                  /*                fl, fr, DAG_sort(fl), DAG_sort(fr)); */
                  if (!fr || !fl || contains_eq(fl, fr) || fl == fr)
                    continue;
                  diseq.left = fl;
                  diseq.right = fr;
                  stack_push(ext_eq, diseq);
                  hyp = DAG_dup(DAG_neq(fl, fr));
                  sort_fun = DAG_symb_sort(DAG_symb(fl));
                  arity_sort = DAG_sort_arity(sort_fun) - 1;
                  arity = DAG_arity(fl);
                  /* my_DAG_message("TYU Enter : %D %D %d %d %D\n", fl, fr, arity_sort, arity, hyp); */
                  if (arity_sort > arity)
                    {
                      stack_INIT(fun_args);
                      for (k = arity; k < arity_sort; k++)
                        {
                          Tsymb symb_fun_arg = DAG_symb_skolem(DAG_sort_sub(sort_fun, k));
                          stack_push(fun_args, symb_fun_arg);
                        }
                      TDAG left = app_term(fl, fun_args);
                      TDAG right = app_term(fr, fun_args);
                      TDAG eq;
                      /** Boolean extentionality **/
                      if (DAG_sort(left) == SORT_BOOLEAN)
                        eq = DAG_dup(DAG_not(DAG_equiv(left, right)));
                      else
                        eq = DAG_dup(DAG_neq(left, right));
                      tmp = DAG_dup(DAG_implies(hyp, eq));
                      stack_push(*lemmas, tmp);
                      stack_reset(fun_args);
                      stack_free(fun_args);
                      /* my_DAG_message("TYU Enter : %D %D %S\n", hyp, tmp, DAG_sort(left)); */
                    }
                }
            }
        }
    }
  stack_reset(U);
  stack_free(U);
}

extern void
extensionality_axiom(Tsort sort, Tstack_DAG *lemmas);

extern void
lazy_axiom(TDAG APP_DAG, TDAG DAG, Tstack_DAG *lemmas);


void
CCS_extentionality_axioms(Tstack_DAG *lemmas)
{
  unsigned i;
  TDAG f;
  Tnode node;
  Tstack_node U;
  stack_INIT(U);
  /* printf(" =========== CCS_LAZY ===========\n"); */
  for (node = 1;  stack_size(NODES) > node; node++)
    if (node_is_function(node))
      stack_push(U, node);
  for (i = 0;  stack_size(U) > i; i++)
    {
      /* my_DAG_message("{%d} %D:%S %d\n", get_position(stack_get(U, i)), */
      /*                get_DAG(stack_get(U, i)), */
      /*                DAG_sort(get_DAG(stack_get(U, i))), */
      /*                DAG_sort_arity(DAG_sort(get_DAG(stack_get(U, i))))); */
      f = get_sub_DAG(get_DAG(stack_get(U, i)),
                      get_position(stack_get(U, i)),
                      stack_get(NODES, stack_get(U, i)).type == CONST);
      if (!f || !DAG_sort_arity(DAG_sort(f)) ||
          !DAG_sort_arity(DAG_sort(get_DAG(stack_get(U, i)))))
        continue;
      extensionality_axiom(DAG_sort(f), lemmas);
    }
  stack_reset(U);
  stack_free(U);
}

void
CCS_lazy_axioms(Tstack_DAG *lemmas)
{
  unsigned i;
  TDAG tmp, f, fapp;
  Tnode node;
  Tstack_node U;
  stack_INIT(U);
  /* printf(" =========== CCS_LAZY ===========\n"); */
  for (node = 1;  stack_size(NODES) > node; node++)
    if (node_is_function(node))
      stack_push(U, node);
  for (i = 0;  stack_size(U) > i; i++)
    {
      /* my_DAG_message("%D:%S{%d} \n", */
      /*                get_DAG(stack_get(U, i)), */
      /*                DAG_sort(get_DAG(stack_get(U, i))), */
      /*                get_position(stack_get(U, i))); */
      f = get_sub_DAG(get_DAG(stack_get(U, i)),
                      get_position(stack_get(U, i)),
                      stack_get(NODES, stack_get(U, i)).type == CONST);
      /* my_DAG_message("AFTER EXT Enter : %D %d\n", */
      /*                f, (DAG_symb_type(DAG_symb(f)) & SYMB_VARIABLE)); */
      if (!f || !DAG_sort_arity(DAG_sort(f)) ||
          DAG_sort_arity(DAG_sort(get_DAG(stack_get(U, i)))) ||
          (DAG_symb_type(DAG_symb(head(f))) & SYMB_VARIABLE))
        continue;
      /* my_DAG_message("APPLYr : %D\n", f); */
      /* my_DAG_message("AFTER EXT Enter : %D %d\n", */
      /*                f, (DAG_symb_type(DAG_symb(f)) & SYMB_VARIABLE)); */
      if (DAG_symb(f) == APPLY)
        {
          tmp = uncurry(f);
          fapp = f;
          f = tmp;
        }
      else
        fapp = get_app_DAG(f);
      /* my_DAG_message("AFTER EXT Enter : %D:%S %d\n", */
      /*                get_DAG(stack_get(U, i)), */
      /*                DAG_sort(get_DAG(stack_get(U, i))), */
      /*                DAG_sort_arity(DAG_sort(get_DAG(stack_get(U, i))))); */
      extensionality_axiom(DAG_sort(f), lemmas);
      lazy_axiom(fapp, f, lemmas);
    }
  stack_reset(U);
  stack_free(U);
}

/*--------------------------------------------------------------*/

unsigned long long int * symb_mask;
Tstack_DAG class_DAGs;

bool
CCS_class_has_symbol(TDAG DAG, Tsymb symbol)
{
  assert(symb_mask[symbol] || !symb_mask[symbol]);
  if (!symb_mask[symbol])
    return true;
  return (symb_mask[symbol] &
          stack_get(NODES, get_repr(get_node(DAG))).symbols) == 0 ? false : true;
}

/*--------------------------------------------------------------*/

void
CCS_set_symbols(TDAG DAG)
{
  unsigned i;
  Tnode current, tmp_class = get_repr(get_node(DAG));
  if (stack_get(NODES, tmp_class).symbols)
    return;
  stack_push(class_DAGs, tmp_class);
  stack_get(NODES, tmp_class).symbols =
    stack_get(NODES, tmp_class).symbols | symb_mask[DAG_symb(get_DAG(tmp_class))];
  DFS(tmp_class);
  for (i = 0; i < stack_size(save_cc); i++)
    {
      current = stack_get(save_cc, i);
      stack_get(NODES, current).visited = false;
      stack_get(NODES, tmp_class).symbols =
        stack_get(NODES, tmp_class).symbols
        | symb_mask[DAG_symb(get_DAG(current))];
    }
  clean_visited_node();
}

/*--------------------------------------------------------------*/
void
CCS_reset_symbols(void)
{
  unsigned i;
  for (i = 0; i < stack_size(class_DAGs); ++i)
    stack_get(NODES, get_repr(stack_get(class_DAGs, i))).symbols = 0;
  stack_reset(class_DAGs);
}

/*--------------------------------------------------------------*/

void
CCS_set_diseqs(TDAG DAG)
{
  unsigned i;
  if (!DAG || !get_node(DAG)) return;
  for (i = 0; i < DAG_arity(DAG); ++i)
    {
      if (!stack_get(NODES, get_repr(get_node(DAG_arg(DAG, i)))).diseqs)
        {
          stack_INIT(stack_get(NODES, get_repr(get_node(DAG_arg(DAG, i)))).diseqs);
          stack_push(stack_get(NODES, get_repr(get_node(DAG_arg(DAG, i)))).diseqs,
                     class(DAG_arg(DAG, 1 - i)));
          stack_push(diseq_DAGs, DAG_arg(DAG, i));
          continue;
        }
      if (
          stack_DAG_contains_class(stack_get(NODES, get_repr(get_node(DAG_arg(DAG, i)))).diseqs,
                                   DAG_arg(DAG, 1 - i)))
        continue;
      stack_push(stack_get(NODES, get_repr(get_node(DAG_arg(DAG, i)))).diseqs,
                 class(DAG_arg(DAG, 1 - i)));
      stack_sort(stack_get(NODES, get_repr(get_node(DAG_arg(DAG, i)))).diseqs, cmp_q_class);
    }
}

/*--------------------------------------------------------------*/

void
CCS_free_diseqs(void)
{
  unsigned i;
  stack_sort(diseq_DAGs, DAG_cmp_q);
  stack_uniq(diseq_DAGs);
  for (i = 0; i < stack_size(diseq_DAGs); i++)
    stack_free(stack_get(NODES, get_repr(get_node(stack_get(diseq_DAGs, i)))).diseqs);
  stack_reset(diseq_DAGs);
}

/*--------------------------------------------------------------*/

void
CCS_init()
{
  first = false;
  backfire = true;
  backtrack_level = -1;
  node_true = 0;
  CCS_status = SAT;
#ifdef SIMPLE_CONG
  stack_INIT(CC_quantified);
#endif
  undo_set_hook(CCS_P_UNDEF, (Tundo_hook)CCS_hook_set_p_undef, sizeof(Tnode));
  undo_set_hook(CCS_UNION, (Tundo_hook)CCS_hook_union, sizeof(Tunion_BTnode));
  undo_set_hook(CCS_STORE_QUANTIFIED, (Tundo_hook)CCS_hook_store_quantified, 0);
  undo_set_hook(CCS_STATUS, (Tundo_hook)CCS_hook_status, 0);
  undo_set_hook(CCS_NOTIFY, (Tundo_hook)CCS_hook_top_notify, sizeof(TDAG));
  stack_INIT(NODES);
  stack_INIT(backtrack_cons);
  stack_INIT(backtrack_cong);
  stack_INIT(class_DAGs);
  stack_INIT(app_table);
  stack_INIT(DAG_to_node);
  stack_INIT(symb_to_node);
  stack_INIT(node_to_DAG);
  stack_INIT(node_to_symb);
  stack_INIT(diseq_DAGs);
  stack_INIT(pending);
  stack_INIT(report);
  stack_INIT(pred_explain);
  stack_INIT(merge_queue);
  stack_INIT(save_cc);
  stack_INIT(ext_eq);
  stack_push(DAG_to_node, DAG_NULL);
  stack_push(symb_to_node, DAG_NULL);
  set_node(DAG_NULL, 0, CONST, NODE_NULL, NODE_NULL);
  stack_get(NODES, node_true).boolean_value = TRUE;
}

/*--------------------------------------------------------------*/

void
CCS_reset()
{
  unsigned i;
  backfire = true;
  node_true = 0;
  CCS_status = SAT;
  for (i = 0; i < stack_size(NODES); i++)
    {
      if (stack_get(NODES, i).nbparents > 0 && stack_get(NODES, i).parents != NULL)
        free(stack_get(NODES, i).parents);
      if (stack_get(NODES, i).nbedges > 0)
        free(stack_get(NODES, i).edges);
    }
  stack_reset(NODES);
  stack_reset(node_to_DAG);
  stack_reset(node_to_symb);
  stack_reset(DAG_to_node);
  stack_reset(symb_to_node);
  stack_reset(app_table);
  stack_reset(ext_eq);
  stack_push(DAG_to_node, DAG_NULL);
  stack_push(symb_to_node, DAG_NULL);
  set_node(DAG_NULL, 0, CONST, NODE_NULL, NODE_NULL);
  stack_get(NODES, node_true).boolean_value = TRUE;
}


void
CCS_done()
{
  unsigned i;
  backfire = true;
  stack_free(merge_queue);
  stack_free(pred_explain);
  for (i = 0; i < stack_size(NODES); i++)
    {
      if (stack_get(NODES, i).nbparents > 0 && stack_get(NODES, i).parents != NULL)
        free(stack_get(NODES, i).parents);
      if (stack_get(NODES, i).nbedges > 0)
        free(stack_get(NODES, i).edges);
    }
  stack_free(report);
  stack_free(NODES);
  stack_free(backtrack_cons);
  stack_free(backtrack_cong);
  stack_free(class_DAGs);
  stack_free(node_to_DAG);
  stack_free(node_to_symb);
  stack_free(DAG_to_node);
  stack_free(symb_to_node);
  stack_free(app_table);
  stack_free(diseq_DAGs);
  stack_free(pending);
  stack_free(save_cc);
  stack_reset(ext_eq);
  stack_free(ext_eq);
#ifdef SIMPLE_CONG
  stack_free(CC_quantified);
#endif
}
