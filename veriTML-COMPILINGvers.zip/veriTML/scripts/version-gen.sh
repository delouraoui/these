#!/usr/bin/env sh
# Print a versin string.
# For now this is a minimal script which prints a git-describe version string.
# In case of future releases this might either be extended to support e.g. a 
# local version file as fallback, or be removed.

v=`git describe --tag --dirty`
printf %s "$v"

