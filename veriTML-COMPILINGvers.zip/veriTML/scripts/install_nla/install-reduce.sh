#!/bin/sh
RELEASE=2251
svn export -r $RELEASE svn://svn.code.sf.net/p/reduce-algebra/code/trunk extern/reduce
(cd extern/reduce; DONT_USE_XPORT=1 ; ./configure --with-psl ; make)
(cd extern/reduce/generic/libreduce; make)
GUESS=`sh extern/reduce/config.guess`
REDARCH=`sh extern/reduce/scripts/findhost.sh $GUESS`
(cd extern; ln -s reduce/generic/libreduce/$REDARCH libreduce; rm libreduce/libreduce.so)
clear
echo "********************************************************************"
echo "* To enable non-linear arithmetics in the SMT-solver veriT, please *"
echo "* add the following variable definition to your shell environment: *"
echo "********************************************************************"
echo ""
echo "VERIT_REDUCE_PATH=$PWD/extern/reduce/bin/redpsl"
echo ""
echo "********************************************************************"
