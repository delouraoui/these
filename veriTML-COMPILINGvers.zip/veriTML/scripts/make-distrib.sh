#!/bin/sh
echo 'Available commands:'
echo 'MAKE_DISTRIB'
echo '   $1 = identifier'
echo 'Builds a source distribution from the current copy of the git repository'

INCLUDE_LICENSE()
{
	LICENSE=$1;
	FILE=$2;
	TEMPFILE=`mktemp -t licensed.XXXXXXXXXXX`;
	echo '/*' >> $TEMPFILE
	cat $LICENSE >> $TEMPFILE
	echo '*/' >> $TEMPFILE;
	echo >> $TEMPFILE
	cat $FILE >> $TEMPFILE;
	mv -f $TEMPFILE $FILE
}

INCLUDE_VERSION()
{
	VERSION=$1;
	FILE=$2;
	TMP_FILE=tmp.$RANDOM.txt
	sed -e s/^"#define PROGRAM_VERSION (\"dev\")"$/"#define PROGRAM_VERSION (\"$VERSION\")"/g src/config.h > $TMP_FILE
	mv $TMP_FILE $FILE
}

REMOVE_FILES()
{
  rm -fr $1/.gitignore
  rm -f $1/TAGS
  rm -f $1/TODO
  rm -f $1/src/arith/asm/asm-com.c
  rm -f $1/src/arith/asm/asm-mult-neg.c
  rm -f $1/src/arith/asm/asm-mult.c
  rm -f $1/src/arith/asm/readme.txt
  rm -Rf $1/extern/bliss
}

MAKE_DISTRIB()
{
	VERSION=$1
	TOP=veriT-"$VERSION"
	ZIPFILE="$TOP".zip
	DIR_INSTALL_FILES=scripts/install
	git archive --prefix="$TOP"/ --output=$ZIPFILE HEAD
	unzip -q $ZIPFILE
	rm -f $ZIPFILE
	echo "[1/6] source files fetched from git repository"
	pushd $TOP > /dev/null
	REMOVE_FILES .
	echo "[2/6] non-essential files removed"
	sed -e s/dev/$VERSION/1 configure.ac > configure.ac.tmp
	mv configure.ac.tmp configure.ac
	INCLUDE_VERSION $VERSION src/config.h
	echo "[3/6] release name inserted in source files"
	SOURCES=`find src/*.[ch] src/*/*.[ch]`
	for FILE in $SOURCES
	do
		INCLUDE_LICENSE $DIR_INSTALL_FILES/LICENSE $FILE
	done
	echo "[4/6] license description inserted in source files"
	mv $DIR_INSTALL_FILES/* .
	rm -Rf ./scripts
	for file in doc/Doxyfile.*
	do
		sed -e s/"\$VERSION"/$VERSION/ $file > doc/Doxyfile.tmp
		mv -f doc/Doxyfile.tmp $file
	done
	popd > /dev/null
	echo "[4/6] source distribution in directory $TOP"
	zip -qr $ZIPFILE $TOP
	echo "[5/6] $ZIPFILE generated"
	tar czf $TOP.tar.gz $TOP
	echo "[6/6] $TOP.tar.gz generated"
}

