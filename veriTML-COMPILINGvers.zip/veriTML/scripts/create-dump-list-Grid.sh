sed '/--/d' ~/benchmarks/UF-BALLEARNTRY_SKINFO2.txta > UF-GRID-solved-ml.txt
sed -i '/-1/d' UF-GRID-solved-ml.txt
sed -i 's/.smt2.*/.smt2/' UF-GRID-solved-ml.txt
perl -ne 'for$i(0..2896){print}' local-path.txt &> local-path-ntimes.txt
perl -ne 'for$i(0..2896){print}' GRID-path.txt &> GIRD-path-ntimes.txt
paste -d "" local-path-ntimes.txt UF-GRID-solved-ml.txt  &> UF-local-solved-ml-loop1.txt
paste -d "" GRID-path-ntimes.txt UF-GRID-solved-ml.txt  &> UF-GRID-solved-ml-loop1.txt
