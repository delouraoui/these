#!/bin/bash

# This file define help functions useful for debugging

#--------------------------------------------------------------
# Local information
#--------------------------------------------------------------

VERIT_EXEC=$VERIT_HOME/veriT

alias PRINT_FLAT="$VERIT_EXEC --disable-ackermann --disable-banner --disable-print-success --print-simp-and-exit"

#--------------------------------------------------------------
# Helping
#--------------------------------------------------------------

function TITLED()
{
    echo $1
    echo $1 | sed "s/./-/g"
}

function ERASE()
{
    STR=`echo $1 | sed "s/./\\\\\\\\b/g"`
    echo -n -e "$STR"
    STR=`echo $1 | sed "s/./ /g"`
    echo -n -e "$STR"
    STR=`echo $1 | sed "s/./\\\\\\\\b/g"`
    echo -n -e "$STR"
}

#--------------------------------------------------------------
# veriT options
#--------------------------------------------------------------

if [ ! -d $TMPDIR ]
then
  mkdir $TMPDIR
fi
TMPFILE=tmpfile.txt

# COMMAND LINE ARGUMENTS
# OPTIONS="--disable-simp --disable-unary-simp --output-conflict=-"
# OPTIONS="--check-deduced"

TIMEOUT=5
#TIMEOUT=unlimited
function RUN_WITH_TIMEOUT ()
{
    cat<<EOF>/tmp/tmp.sh
#!/bin/bash
ulimit -St $TIMEOUT
#ulimit -Ht $((TIMEOUT + 3))
$VERIT_EXEC $OPTIONS $EXAMPLE
EOF
    chmod +x /tmp/tmp.sh
    /tmp/tmp.sh
}

#--------------------------------------------------------------
# DDD, GDB FILE
#--------------------------------------------------------------

#shopt -s nullglob

# RUN veriT ON EXAMPLE
function CHECK()
{
    echo "CHECKING : $EXAMPLE"
    RUN_WITH_TIMEOUT
}

# CHECK A SERIES OF FILES
function CHECK_FILES()
{
    export OPTIONS="$OPTIONS --disable-banner"
    if [ "$1" != "" ]; then
        FILELIST=$1
    else
        FILELIST=$BENCH_HOME/lists/short_test_suite_smt2.list
    fi
    (TITLED "Checking $FILELIST"; echo) | tee report.txt
    (for file in `sed "s/#.*//;/^\$/d" $FILELIST`; do \
        echo "CHECKING :" $file && \
        export EXAMPLE=$BENCH_HOME/$file && \
        (time RUN_WITH_TIMEOUT) 2>&1; \
        done ) | grep -v "discarding annotation" | tee -a report.txt;
    grep "^CHECKING\|^sat\|^unsat\|error" report.txt | sed "s/CHECKING : //" > report-summary.txt
    $MORE report-summary.txt
}

# DEBUGGING veriT
function DEBUG_INSIGHT()
{
    echo "DEBUGGING : $EXAMPLE"
    cat <<EOF > /tmp/veriT.gdb
file $VERIT_EXEC
set args $OPTIONS $EXAMPLE
EOF
#break my_error
#break my_warning
#break breakpoint
    insight -x /tmp/veriT.gdb
    \rm -f /tmp/veriT.gdb
}

# DEBUGGING veriT
function DEBUG()
{
    echo "DEBUGGING : $EXAMPLE"
    cat <<EOF > /tmp/veriT.gdb
file $VERIT_EXEC
set args $OPTIONS $EXAMPLE
break my_error
break breakpoint
break veriT_error
break my_warning
EOF
#break my_warning
#break veriT_out
    export LANG=en_US.iso-8859-1
    ddd -x /tmp/veriT.gdb
    \rm -f /tmp/veriT.gdb
}

# LEAK FINDING
function LEAK()
{
    echo "FINDING LEAKS : $EXAMPLE"
    valgrind -v --track-origins=yes --leak-check=full --show-reachable=yes \
        --num-callers=50 --suppressions=$VERIT_HOME/scripts/suppressions.valgrind $1 \
        $VERIT_EXEC $OPTIONS $EXAMPLE > leaks.txt 2>&1
    $MORE leaks.txt
}

# LEAK FINDING - QUIET MODE / FOR REGRESSION TESTING
function LEAK_QUIET()
{
    echo "FINDING LEAKS : $EXAMPLE"
    valgrind -q --leak-check=full --show-reachable=yes \
        --suppressions=$VERIT_HOME/scripts/suppressions.valgrind $1 \
        $VERIT_EXEC $OPTIONS $EXAMPLE 2>&1
}

# CHECK MEMORY ERRORS ON A SERIES OF FILES
function LEAK_FILES()
{
    export OPTIONS="$OPTIONS --disable-banner"
    if [ "$1" != "" ]; then
        FILELIST=$1
    else
        FILELIST=$BENCH_HOME/lists/short_test_suite_smt2.list
    fi
    (TITLED "Checking $FILELIST for leaks"; echo) | tee report.txt
    (for file in `sed "s/#.*//;/^$/d" $FILELIST`; do \
        export EXAMPLE=$BENCH_HOME/$file && \
        LEAK_QUIET 2>&1; \
        done ) | grep -v "discarding annotation" | tee -a report.txt;
}

# PROFILING
function PROFILE()
{
    echo "PROFILING : $EXAMPLE"
    RUN_WITH_TIMEOUT
    gprof $VERIT_EXEC > profile.txt
    $MORE profile.txt
}

# CHECK conflicts, lemmas, and models with an external prover
CVC_COMMAND="cvc3 -lang smtlib -timeout 30"
CVC_COMMAND="z3"
SAT_COMMAND="picosat"
function CHECK_CONSISTENCY()
{
    echo "CHECK_CONSISTENCY : $EXAMPLE"
    CVCDIR=cvcdir
    export VERIT_CHECK_DEDUCED=1
    rm -Rf $CVCDIR
    mkdir $CVCDIR
    RUN_RES="unknown"
    RUN_RES=`RUN_WITH_TIMEOUT | grep "unsat\|sat\|unknown" 2>&1`
    export VERIT_CHECK_DEDUCED=0
    for i in conflict*.smt; do mv -f $i $CVCDIR; done
    for i in model*.smt; do mv -f $i $CVCDIR; done
    for i in lemma*.smt; do mv -f $i $CVCDIR; done
    mv -f boolean.cnf $CVCDIR
    N=`find "$CVCDIR" -name "conflict*.smt" | wc -l`
    echo "CONFLICTS : $N"
    N=`find "$CVCDIR" -name "model*.smt" | wc -l`
    echo "MODELS    : $N"
    N=`find "$CVCDIR" -name "lemma*.smt" | wc -l`
    echo "LEMMAS    : $N"
    OLDFILE=""
    for i in $CVCDIR/conflict*.smt $CVCDIR/model*.smt $CVCDIR/lemma*.smt; do
        ERASE $OLDFILE
        echo -n $i
        OLDFILE=$i
        RES=""
        RES=`$CVC_COMMAND $i | grep "^unsat$\|^sat$"`
        VC_NAME=${i##*/}
        VC_NAME=${VC_NAME%.smt}
        VC_TYPE=${VC_NAME%-*}
        if [[ "$VC_TYPE" != "conflict" \
            && "$VC_TYPE" != "model" \
            && "$VC_TYPE" != "lemma" ]]; then
            ERASE $OLDFILE
            echo
            echo "Bizarre verification condition $VC_NAME"
            echo
            OLDFILE=""
        fi
        if [[ "$RES" != "sat" && "$RES" != "unsat" ]]; then
            ERASE $OLDFILE
            echo
            echo "Timeout or error $VC_NAME"
            echo
            OLDFILE=""
        else if [[ ("$RES" == "unsat" && "$VC_TYPE" == "model") || \
            ("$RES" == "sat" && "$VC_TYPE" == "lemma") || \
            ("$RES" == "sat" && "$VC_TYPE" == "conflict") ]]; then
            ERASE $OLDFILE
            echo
            echo "Failed on $VC_NAME"
            echo
            OLDFILE=""
        fi
        fi
    done
    ERASE $OLDFILE
    OLDFILE=""
    EXPECTED_RES=`grep status $EXAMPLE | sed "s/:status//;s/(set-info//;s/[ )]*//g"`
    if [[ "$EXPECTED_RES" == "unknown" ]]; then
        echo "status field in file is unknown.  Trying CVC3 and Z3"
        EXPECTED_RES1=`cvc3 -lang smtlib $EXAMPLE | grep "^unsat$\|^sat$"`
        EXPECTED_RES2=`z3 $EXAMPLE | grep "^unsat$\|^sat$"`
        echo "CVC3: $EXPECTED_RES1"
        echo "Z3: $EXPECTED_RES2"
        if [[ "$EXPECTED_RES1" != "$EXPECTED_RES2" ]]; then
            echo "z3 and cvc3 disagree !!!!!!!!!!!!!"
        fi
        EXPECTED_RES=$EXPECTED_RES2;
    fi
    RES=`$SAT_COMMAND $CVCDIR/boolean.cnf | head -n 1 | \
        sed "s/s SATISFIABLE/sat/;s/s UNSATISFIABLE/unsat/;"`
    if [[ "$RUN_RES" != "unknown" ]]; then
        if [[ "$RUN_RES" != "$EXPECTED_RES" ]]; then
            echo "BOOLEAN STATUS DOES NOT MATCH"
            echo $RUN_RES '!=' $EXPECTED_RES
        fi
        if [[ "$RES" != "$EXPECTED_RES" ]]; then
            echo "BOOLEAN STATUS DOES NOT MATCH"
            echo $RES '!=' $EXPECTED_RES
        fi
    fi
}

function CHECK_CONSISTENCY_DIR()
{
    export OPTIONS="$OPTIONS --disable-banner"
    DIR=$1
    "Checking $DIR for consistency"
    for file in $DIR/*.smt; do
        export EXAMPLE=$file;
        CHECK_CONSISTENCY;
        read;
    done
}

function CHECK_CONSISTENCY_FILES()
{
    export OPTIONS="$OPTIONS --disable-banner"
    if [ "$1" != "" ]; then
        FILELIST=$1
    else
        FILELIST=$BENCH_HOME/lists/short_test_suite_smt2.list
    fi
    for file in `sed "s/#.*//;/^$/d" $FILELIST`; do
        export EXAMPLE=$BENCH_HOME/$file
        CHECK_CONSISTENCY
        read
    done
}

# INDENT THE CODE
function INDENT()
{
    for i in `find . -name "*.c"` ; do echo $i ; indent -l78 $i; done;
    for i in `find . -name "*.h"` ; do echo $i ; indent -l78 -di 10 $i; done
}

#--------------------------------------------------------------
# Statistic handling
#--------------------------------------------------------------

# Plots evolution of decisions
# compile with BOOL_STAT and STORE_LEVEL (config.h)

function PLOT_DECISIONS ()
{
    EXAMPLE=$1
    TITLE=$2
    FILENAME=$3
    $VERIT_EXEC $OPTIONS $EXAMPLE > out.txt 2>&1
    cat out.txt | grep "MSG" | sed "s/[A-Za-z :]*//g;s/,/ /g" | nl > tmp.dat
    if [[ -s tmp.dat ]]; then
        cat<<EOF>tmp.gplot
set title "$TITLE"
set xlabel "conflicts"
set ylabel "assignment size"
set terminal postscript color solid
set output "${FILENAME}-1.ps"
plot 'tmp.dat' using 1:2 with lines title "unbacktracked lits", \
     'tmp.dat' using 1:3 with lines title "number of lits", \
     'tmp.dat' using 1:4 with lines title "root", \
     'tmp.dat' using 1:7 with lines title "largest depth in confl", \
     'tmp.dat' using 1:8 with lines title "forlargest depth"
set output "${FILENAME}-2.ps"
plot 'tmp.dat' using 1:5 with lines title "unbacktracked decisions", \
     'tmp.dat' using 1:6 with lines title "max decisions", \
     'tmp.dat' using 1:9 with lines title "largest depth in confl", \
     'tmp.dat' using 1:10 with lines title "forlargest depth"
EOF
        gnuplot tmp.gplot;
    fi;
    echo "N,stack: preserved,stack: size,stack: root," \
        "declev: preserved, declev: max, " \
        "stack: max conflict, stack: foremax conflict, " \
        "declev: max conflict, declev: foremax conflict" > data.csv
    sed "s/\t/ /;s/^ *//;s/  */,/g" tmp.dat >> data.csv
    rm -f tmp.gplot tmp.dat
}
#PLOT_DECISIONS $EXAMPLE ${EXAMPLE#$BENCH_HOME} `echo ${EXAMPLE#$BENCH_HOME} | sed "s/\//_/g;s/.smt//"`

# CHECK MEMORY ERRORS ON A SERIES OF FILES
function PLOT_FILES()
{
    OPTIONS="--enable-simp --enable-unit-simp --cnf-p-definitional"
    export OPTIONS="$OPTIONS --disable-banner"
    if [ "$1" != "" ]; then
        FILELIST=$1
    else
        FILELIST=$BENCH_HOME/lists/short_test_suite_smt2.list
    fi
    for file in `sed "s/#.*//;/^\$/d" $FILELIST`; do \
        echo "CHECKING :" $file && \
        export EXAMPLE=$BENCH_HOME/$file && \
        PLOT_DECISIONS $EXAMPLE $file `echo $file | sed "s/\//_/g;s/.smt//"`;
    done
}

#--------------------------------------------------------------
# Code digging
#--------------------------------------------------------------

function DO_TAGS
{
    for file in `find $VERIT_HOME/src -name "*.[ch]" -print`; do \
      etags -a $file -o $VERIT_HOME/TAGS;
    done
}

function FIND_C
{
    find . -name "*.c" | xargs grep $1
}

function FIND_H
{
    find . -name "*.h" | xargs grep $1
}

function FIND_CH
{
    find . -name "*.h" | xargs grep $1
    find . -name "*.c" | xargs grep $1
}

# CREATE DEPENDENCY GRAPH
function DEP_GRAPH()
{
  mkdir tmp
  for i in `find . -name "*.h" -o -name "*.c" -o -name "*.lex" -o -name "*.y"`; do
      cp $i tmp/ ;
  done
  cd tmp
  for name in general table list hash FDAG FDAG-print statistics options; do
    for i in *; do grep -v "$name.h" $i > afile; mv -f afile $i; done
  done
  mv -f smtlib.lex smtlex.c
  mv -f smtlib.y smtlib.c
  cinclude2dot --merge module --exclude general* > dependency.dot
#  dot -Tps dependency.dot > dependency.ps
  grep -l list_ *; grep -l list.h *
  rm -f afile.dot
}

function REMOVESMTFILES()
{
   find $1 -name 'conflict-*.smt' -print0 | xargs -0 rm
   find $1 -name 'model-*.smt' -print0 | xargs -0 rm
   find $1 -name 'dump-*.smt' -print0 | xargs -0 rm
   find $1 -name 'lemma-*.smt' -print0 | xargs -0 rm
   find $1 -name 'prover.??.*' -print0 | xargs -0 rm
}

#--------------------------------------------------------------
# Use examples
#--------------------------------------------------------------

if [[ "$TERM" == "dumb" ]]; then
    MORE=`which cat`
else
    MORE=`which less`
fi
if [[ ! -x $MORE ]]; then
    MORE=more
fi

cat<<EOF
Make sure cvcl.sh is in the PATH.

Effects of this script:
- sets default options
- creates rv.gbd for the debugger
- creates rv-wrp, a wrapper with UNIX time and memory limits

CHECK         runs solver on the \$EXAMPLE file
DEBUG         runs solver within debugger on the \$EXAMPLE file
LEAK          runs solver within valgrind on the \$EXAMPLE file
LEAK_QUIET    runs solver within valgrind on the \$EXAMPLE file in quiet mode
CHECK_FILES arg
              runs solver on all files listed in file.  Outputs report.txt.
              if arg is empty, default is
              \$BENCH_HOME/lists/short_test_suite_smt2.list
LEAK_FILES arg
              runs solver within valgrind on all files listed in file in quiet mode
              if arg is empty, default is
              \$BENCH_HOME/lists/short_test_suite_smt2.list
CHECK_CONSISTENCY
              runs cvc on all conflicts, lemmas, and model produced
CHECK_BOOLEAN runs solver and checks with minisat on boolean.cnf
PROFILE       profiling on the \$EXAMPLE file
INDENT        indent the code
DO_TAGS       generates TAGS file in \$VERIT_HOME
FIND_C arg    finds arg in all C files
FIND_H arg    finds arg in all H files
FIND_CH arg   finds arg in all C or H files
CHECK_MEMORY arg
              runs valgrind on veriT with all files in the arg file
REMOVESMTFILES arg
              removes recursively all files matching "conflict*.smt",
              "model*.smt", "lemma*.smt", "dump*.smt" and "prover.??.*"
              from the given directory
EOF

if [[ "$BENCH_HOME" == "" ]]; then
    cat<<EOF
Please set in your shell init file (.bashrc, .profile, ...) variable
BENCH_HOME as being the root of the benchmark files
EOF
elif [[ "$VERIT_HOME" == "" ]]; then
    cat<<EOF
Please set in your shell init file (.bashrc, .profile, ...) variable
VERIT_HOME as being the root of the veriT source
EOF
elif [[ ! -x $VERIT_EXEC ]]; then
    cat<<EOF
Warning: No veriT executable found
EOF
fi
