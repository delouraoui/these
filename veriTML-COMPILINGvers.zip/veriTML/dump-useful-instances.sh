base=$(basename -- "$1")
grep -Po "forall_inst :args\K.*?(?= :con)" /home/delouraoui/dumped-data/$base/proof-$base > "/home/delouraoui/dumped-data/$base/useful-instances-$base"
